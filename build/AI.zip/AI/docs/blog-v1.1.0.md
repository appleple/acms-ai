# AI拡張アプリ v1.1.0 リリース — テンプレートに「AIボタン」を埋め込めるようになりました

a-blog cms の AI拡張アプリが **v1.1.0** になりました。

v1.0.0（配布名 `Prompt(仮)`）は「エントリー編集画面でユニットからタイトル・タグを生成する」という機能に絞ったリリースでしたが、v1.1.0 では正式名を **「AI拡張アプリ」** に改め、**AIアシスタント機能** を追加して生成系の使い道を一気に広げました。あわせて、サーバー側の OpenAI 連携を **Responses API ベースに全面的に作り直し** ています。

この記事では、v1.0.0 の zip（`AI1.0.0.zip`）と v1.1.0 の中身を実際に突き合わせて分かった変更点を、README には書ききれなかった「なぜこうしたのか」「使う上で気をつけてほしいこと」も含めて、開発者向けに少し技術寄りで掘り下げて紹介します。

---

## v1.0.0 → v1.1.0 の変更点まとめ

zip を比較すると、見た目以上に大きく作り変わっています。主な差分は次のとおりです。

### 機能面
- **AIアシスタント機能を新規追加**（v1.0.0 には存在しません）
  - ライトエディタに「AIアシスタント」ボタンが付き、編集中のテキストを文脈にして校正・要約・翻訳・書き直しを対話的に依頼できるようになりました。
  - `<acms-ai-assistant-button>` という **Web Component** を追加し、テンプレートの好きな場所（カスタムフィールド含む）に AI ボタンを置けるようになりました。**今回いちばんの目玉です。**
- **メディアの alt 自動生成（先行実装）** — `POST/AI/Media.php` `POST/AI/Media/Alt.php` を新規追加。ただし a-blog cms 側の UI 都合で **まだ無効化しています**（後述）。

### サーバー側のアーキテクチャ刷新
- **OpenAI API を Chat Completions → Responses API へ全面移行。**
  - v1.0.0 は `https://api.openai.com/v1/chat/completions` を直接叩いていました。v1.1.0 では `Services/AI/Endpoints/ResponsesClient.php` / `StreamingResponsesClient.php` を新設し、Responses API（会話コンテキスト引き継ぎ・ストリーミング）に統一しています。
- **エンドポイントを役割ごとに分割。**
  - v1.0.0 では `POST/AI/Chat.php` 1本が「タイトルもタグも生成する JSON 返却 API」を兼ねていました（名前は Chat ですが中身はチャットではありません）。
  - v1.1.0 では **`POST/AI/Title.php` / `POST/AI/Tag.php` に分離**し、`Chat.php` は **本物のストリーミングAIアシスタント**へ作り直しました。共通処理は `POST/AIPostTrait.php` と `Services/AI/EndpointTrait.php` に集約。
  - v1.0.0 にあった `POST/AI.php` と `Services/Prompt.php` は廃止されました。
- **サポートモデルを刷新。** `gpt-4o-mini / gpt-4o / gpt-3.5-turbo` → **`gpt-5.4 / gpt-5.4-pro / gpt-5.4-mini / gpt-5.4-nano`**。

### UI・動作環境
- エントリー編集画面のアコーディオンを、独自実装（`div.acms-admin-accordion` + `js-fader`）から **ネイティブの `<details>/<summary>`** に置き換え、アクセシビリティと国際化（`<!--T-->`）に対応。
- **動作環境を引き上げ。** a-blog cms `>=3.1` / PHP `>=7.3` → **a-blog cms 3.2.x / PHP 8.1–8.4**。Professional / Enterprise ライセンス専用である点も明記。
- README を大幅加筆（68行 → 181行）。Web Component の属性・イベント・スタイリングまで網羅。
- CI を Bitbucket Pipelines から GitHub Actions へ移行、`build/AI.zip` を直接ダウンロードできるよう整備。

以下、主役の **AIアシスタント機能** と **Responses API への移行** を中心に解説します。

---

## 目玉機能：`<acms-ai-assistant-button>` Web Component

### 何が嬉しいのか

v1.0.0 の AI 機能は「エントリー編集画面のタイトル欄・タグ欄」という固定の場所でしか使えませんでした。
でも実際の運用では、「このカスタムフィールドの本文を英訳したい」「概要欄を要約で埋めたい」のように、**サイト構築者が決めた任意の場所で AI を使いたい** はずです。

そこで v1.1.0 では、テンプレートにこう書くだけで AI ボタンを設置できるようにしました。

```html
<acms-ai-assistant-button target="#body">
  <button type="button" class="acms-admin-btn">AIアシスタントを開く</button>
</acms-ai-assistant-button>
```

`target` に textarea のセレクターを渡すと、その内容を文脈として AI チャットを開きます。JavaScript を書く必要はありません。

### 設計判断その1：Shadow DOM ではなく Light DOM を選んだ

Web Component というと Shadow DOM でスタイルをカプセル化するのが定石ですが、今回は **あえて Light DOM** を採用しました。

理由はシンプルで、**a-blog cms 管理画面の既存スタイルをそのまま使いたかった** からです。Shadow DOM でスタイルを隔離してしまうと、`acms-admin-btn` のような管理画面標準クラスが効かなくなり、ボタンの見た目だけ浮いてしまいます。

Light DOM にしたことで、

- 子要素に書いた `<button>` がそのまま使われる
- `acms-admin-btn` などの既存クラスや任意の CSS が普通に適用できる
- `<button>` を省略した場合は、要素内のテキストを `<button class="acms-admin-btn">` で自動的に包む

という、「管理画面に溶け込むボタン」を素直に実現できました。

```ts
// 子要素に <button> があればそれを使い、なければ自動生成する
this.button = this.querySelector(':scope > button')
if (!this.button) {
  const button = document.createElement('button')
  button.type = 'button'
  button.className = 'acms-admin-btn'
  while (this.firstChild) {
    button.appendChild(this.firstChild)
  }
  this.appendChild(button)
  this.button = button
}
```

### 設計判断その2：`connectedCallback` で子要素が取れない問題

Custom Element を実装したことがある方は踏んだことがあるかもしれませんが、`connectedCallback` は **HTML パーサが開始タグを読んだ瞬間に走ることがあり**、その時点では子要素（ここでは `<button>`）がまだパースされていません。素直に `this.querySelector('button')` してもボタンが取れない、という罠です。

ここは `document.readyState` を見て初期化タイミングを分岐させています。

```ts
connectedCallback() {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', this.init, { once: true })
  } else {
    // 同期パース中の子要素挿入完了をマイクロタスクで待つ
    queueMicrotask(this.init)
  }
}
```

読み込み中なら `DOMContentLoaded` を待ち、すでに読み込み済みなら `queueMicrotask` で1ティックだけ遅らせる。これで「子要素を後から追加した場合」「テンプレートに静的に書いた場合」のどちらでも安定して `<button>` を拾えます。

### 設計判断その3：「ドロワーを開かないモード」を用意した

AIアシスタントには2つの動作モードがあります。

| モード | 指定 | 挙動 |
|--------|------|------|
| ドロワーモード（デフォルト） | （指定なし） | 右側にチャットドロワーを開いて対話する |
| サイレントモード | `drawer-use="false"` | UI を出さず即実行し、結果を textarea に直接挿入する |

「誤字脱字を直すだけ」「英訳して別フィールドに入れるだけ」のような **ワンショットの処理** では、いちいちドロワーを開いて会話するのは過剰です。サイレントモードはそういうケース向けです。

```html
<acms-ai-assistant-button
  target="#body"
  prompt="誤字脱字を修正してください。修正後のテキストを &lt;correction&gt;&lt;/correction&gt; タグで囲んで返してください。"
  drawer-use="false"
>
  <button type="button" class="acms-admin-btn">自動校正する</button>
</acms-ai-assistant-button>
```

### `<correction>` タグという地味だけど効く工夫

サイレントモードで一番難しいのは、「AI の返答から “挿入すべきテキストだけ” をどう取り出すか」です。AI は親切心で「修正しました！変更点は〜」みたいな説明を付けてくることがあり、それをそのまま textarea に流し込むと台無しです。

そこで、**処理結果を必ず `<correction>...</correction>` で囲ませる** という約束をプロンプト側で結び、フロント側ではそのタグの中身だけを抜き出して挿入する、という設計にしました。

```ts
const correction = messages.find((m) => m.type === 'correction')
if (correction) {
  // correction の中身だけを textarea へ挿入する
} else {
  console.error('[acms-ai] correction not found. ...')
}
```

サーバー側のシステムプロンプトでもこのルールを強制していますが、モデルやプロンプト次第で稀に従わないことがあります。**もしサイレント実行の結果が安定しない場合は、`prompt` 末尾に「修正後のテキストを `<correction></correction>` タグで囲んで返してください。」を明示的に足してください。** これで成功率が上がります。

### サイレント実行のライフサイクルイベント

サイレントモードでは、ホスト要素に対して処理の進行に応じたカスタムイベントを発火します。ローディング表示やトースト通知など、サイト側の UI 制御に使えます。

| イベント名 | タイミング |
|-----------|-----------|
| `acms-ai:request-start` | AI へのリクエスト開始時 |
| `acms-ai:request-end` | レスポンス受信完了時 |
| `acms-ai:before-insert` | textarea への挿入直前 |
| `acms-ai:after-insert` | textarea への挿入直後 |

ローディング中はホスト要素に `loading` 属性が付き、ボタンが `disabled` + `aria-busy="true"` になり、スピナー用の `<span>` が表示されます。スピナーの標準スタイルは本アプリ側で用意していますが、`acms-ai-assistant-button[loading] button { ... }` で上書きできます。

### undo を壊さない挿入

地味なところですが、textarea への挿入は `document.execCommand('insertText')` を使っています。これは **ブラウザの undo 履歴を保ったまま** テキストを差し込めるためです。AI が入れた結果を `Ctrl+Z` で取り消せるのは、実運用ではかなり効きます。`execCommand` が使えない環境では、ネイティブの value setter にフォールバックします。

ライトエディタ連携の場合は、エディタ内部の undo/redo スタックを直接操作して、エディタの履歴とも整合するようにしています。

---

## サーバー側：Chat Completions から Responses API へ作り直した

ここが v1.0.0 と最も大きく変わった部分です。

### v1.0.0 はどうだったか

v1.0.0 のバックエンドは、`POST/AI/Chat.php` という1本のクラスが `https://api.openai.com/v1/chat/completions` を直接叩く作りでした。名前は「Chat」ですが、実態は **タイトル・タグ生成のための JSON 配列を返す API** です。

しかも、Chat Completions では出力形式を厳密に固定できないため、こんな力技でしのいでいました。

- システムプロンプトで「`[{"content": "..."}]` という JSON 配列で返せ」と指示する
- 返ってきた文字列を `json_decode` してみて、配列としてパースできるか検証する
- **失敗したら最大5回までリトライする**（`while ($attempts < $maxAttempts ...)`）
- それでも壊れていたら、外側の `[ ... ]` を正規表現で切り出して救済する

動くには動きますが、「AI が形式を守ってくれることを祈ってリトライする」という、いかにも過渡期な実装でした。

### v1.1.0 で Responses API に統一

v1.1.0 では、サーバー側の AI 連携を **OpenAI Responses API** ベースに作り直し、エンドポイントも役割ごとに分割しました（`Title.php` / `Tag.php` / `Chat.php`、共通処理は `AIPostTrait` と `EndpointTrait` に集約）。Responses API を選んだ理由は主に2つです。

1. **構造化出力（JSON Schema）を `strict` で強制できる。** タイトル・タグ生成は決まった JSON 形式で返ってこないと困りますが、Responses API ならスキーマを `strict: true` で固定でき、**v1.0.0 のリトライ＆正規表現救済が丸ごと不要になりました。** フォーマット崩れによるパースエラーが原理的に起きません。
2. **会話コンテキストをサーバー側で引き継げる。** `previous_response_id` を渡すだけで前のやり取りを踏まえた応答になるので、新設した AIアシスタントのドロワーでマルチターンな修正依頼が自然に成立します。

そして、この Responses API への移行があったからこそ、**ストリーミングのAIアシスタント** という新機能が現実的になりました。

### ストリーミングは3層で中継している

チャットの応答は1文字ずつ流れてくる方が体験が良いので、ストリーミングに対応しました。経路は **OpenAI → PHP → ブラウザ** の3層です。

- **OpenAI** が SSE（Server-Sent Events）でトークンを流す
- **PHP** が cURL の `WRITEFUNCTION` コールバックで受け取り、`ob_flush()` / `flush()` で即座にクライアントへ中継する
- **ブラウザ** が `response.body.getReader()` で受け取り、React の state に逐次反映する

ここで地味にハマりやすいのが **バッファリング** です。途中の層がレスポンスを溜め込むと、せっかくのストリーミングが「最後にまとめてドン」になってしまいます。そこで PHP 側で次のような対策を入れています。

- gzip 圧縮の無効化（圧縮はバッファリングを誘発する）
- `X-Accel-Buffering: no` ヘッダ（nginx のプロキシバッファリング抑制）
- Apache の `no-gzip` 設定

それでも、**サーバーの構成（nginx / Apache / FastCGI のバッファ設定）によってはストリーミングが効かない場合があります。** その場合でも応答が「まとめて表示」になるだけで、結果自体は正常に得られます。

---

## メディアの alt 自動生成について（現状の扱い）

画像を入れると AI が内容を読み取って alt テキスト（日本語・体言止め）を提案する機能を、v1.1.0 のコードには **先行して入れてあります**。Responses API の画像入力（`input_image`）に画像を Base64 で渡して生成する仕組みです。

ただし、これは **a-blog cms 側の UI に依存する部分があり、現状は無効化（コメントアウト）しています。** 正式に使えるようにするのは a-blog cms Ver. 3.3 系の対応を待ってからの予定です。「コードはあるけどまだ動かない」状態なので、期待してお待ちください。

---

## 使う上での注意点

README にも書いていますが、運用でつまずきやすいポイントを改めてまとめます。

### ライセンス
- **Professional / Enterprise ライセンス専用**です。スタンダードライセンスでの利用はライセンス違反になります。

### モデルが選択肢に出てこないとき
- OpenAI の **API キー側でモデル制限**がかかっていると、使いたいモデルが管理画面に出てきません。OpenAI 側のキー設定を確認してください。
- 認証情報やモデルは **config として保存され、キャッシュされます。** 設定したのにうまく反映されない場合は、ダッシュボードから **コンフィグキャッシュをクリア** してください。

### サイレント実行が安定しないとき
- 前述のとおり、`prompt` に「`<correction></correction>` で囲んで返す」指示を明示的に足してください。

### 再生成は前の結果を上書きします
- タイトルの「再生成」は前回のタイトルを **消して** 作り直します。タグの「追加生成」は前回分に **足して** いきます。挙動が異なる点に注意してください。
- いずれも **エントリーを保存するまでは確定しません。** 生成しただけで保存を忘れると反映されません。

### 動作環境
- a-blog cms: Ver. 3.2.x（3.3 系は未検証）
- PHP: 8.1 – 8.4（8.5 系は未検証）

---

## まとめ

v1.1.0 のポイントは、**AI を「決められた場所」から「サイト構築者が決める好きな場所」へ解き放った** ことです。

`<acms-ai-assistant-button>` を1行書くだけで、カスタムフィールドだろうとどこだろうと AI ボタンを置ける。Light DOM で既存スタイルに溶け込み、サイレントモードでワンショット処理もできる。裏側では Responses API とストリーミングで、対話としての体験も整えました。

ぜひテンプレートに `<acms-ai-assistant-button>` を仕込んで、自分のサイトに合った AI 活用を試してみてください。

- ダウンロード: [AI.zip（最新版）](https://github.com/appleple/acms-ai/raw/main/build/AI.zip)
- 過去バージョン: [Releases](https://github.com/appleple/acms-ai/releases)
