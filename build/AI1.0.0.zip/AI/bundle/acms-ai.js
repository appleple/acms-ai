function $T(b) {
  return b && b.__esModule && Object.prototype.hasOwnProperty.call(b, "default") ? b.default : b;
}
var U0 = { exports: {} }, rv = {}, z0 = { exports: {} }, Ot = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var xT;
function oD() {
  if (xT) return Ot;
  xT = 1;
  var b = Symbol.for("react.element"), m = Symbol.for("react.portal"), g = Symbol.for("react.fragment"), T = Symbol.for("react.strict_mode"), L = Symbol.for("react.profiler"), U = Symbol.for("react.provider"), x = Symbol.for("react.context"), S = Symbol.for("react.forward_ref"), ne = Symbol.for("react.suspense"), te = Symbol.for("react.memo"), Q = Symbol.for("react.lazy"), Z = Symbol.iterator;
  function A(N) {
    return N === null || typeof N != "object" ? null : (N = Z && N[Z] || N["@@iterator"], typeof N == "function" ? N : null);
  }
  var oe = { isMounted: function() {
    return !1;
  }, enqueueForceUpdate: function() {
  }, enqueueReplaceState: function() {
  }, enqueueSetState: function() {
  } }, q = Object.assign, ve = {};
  function Ae(N, J, Te) {
    this.props = N, this.context = J, this.refs = ve, this.updater = Te || oe;
  }
  Ae.prototype.isReactComponent = {}, Ae.prototype.setState = function(N, J) {
    if (typeof N != "object" && typeof N != "function" && N != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, N, J, "setState");
  }, Ae.prototype.forceUpdate = function(N) {
    this.updater.enqueueForceUpdate(this, N, "forceUpdate");
  };
  function Ye() {
  }
  Ye.prototype = Ae.prototype;
  function ut(N, J, Te) {
    this.props = N, this.context = J, this.refs = ve, this.updater = Te || oe;
  }
  var Ke = ut.prototype = new Ye();
  Ke.constructor = ut, q(Ke, Ae.prototype), Ke.isPureReactComponent = !0;
  var Ge = Array.isArray, Rt = Object.prototype.hasOwnProperty, Ne = { current: null }, lt = { key: !0, ref: !0, __self: !0, __source: !0 };
  function it(N, J, Te) {
    var We, st = {}, ft = null, St = null;
    if (J != null) for (We in J.ref !== void 0 && (St = J.ref), J.key !== void 0 && (ft = "" + J.key), J) Rt.call(J, We) && !lt.hasOwnProperty(We) && (st[We] = J[We]);
    var Et = arguments.length - 2;
    if (Et === 1) st.children = Te;
    else if (1 < Et) {
      for (var nt = Array(Et), wt = 0; wt < Et; wt++) nt[wt] = arguments[wt + 2];
      st.children = nt;
    }
    if (N && N.defaultProps) for (We in Et = N.defaultProps, Et) st[We] === void 0 && (st[We] = Et[We]);
    return { $$typeof: b, type: N, key: ft, ref: St, props: st, _owner: Ne.current };
  }
  function Jt(N, J) {
    return { $$typeof: b, type: N.type, key: J, ref: N.ref, props: N.props, _owner: N._owner };
  }
  function jt(N) {
    return typeof N == "object" && N !== null && N.$$typeof === b;
  }
  function Xe(N) {
    var J = { "=": "=0", ":": "=2" };
    return "$" + N.replace(/[=:]/g, function(Te) {
      return J[Te];
    });
  }
  var W = /\/+/g;
  function X(N, J) {
    return typeof N == "object" && N !== null && N.key != null ? Xe("" + N.key) : J.toString(36);
  }
  function ae(N, J, Te, We, st) {
    var ft = typeof N;
    (ft === "undefined" || ft === "boolean") && (N = null);
    var St = !1;
    if (N === null) St = !0;
    else switch (ft) {
      case "string":
      case "number":
        St = !0;
        break;
      case "object":
        switch (N.$$typeof) {
          case b:
          case m:
            St = !0;
        }
    }
    if (St) return St = N, st = st(St), N = We === "" ? "." + X(St, 0) : We, Ge(st) ? (Te = "", N != null && (Te = N.replace(W, "$&/") + "/"), ae(st, J, Te, "", function(wt) {
      return wt;
    })) : st != null && (jt(st) && (st = Jt(st, Te + (!st.key || St && St.key === st.key ? "" : ("" + st.key).replace(W, "$&/") + "/") + N)), J.push(st)), 1;
    if (St = 0, We = We === "" ? "." : We + ":", Ge(N)) for (var Et = 0; Et < N.length; Et++) {
      ft = N[Et];
      var nt = We + X(ft, Et);
      St += ae(ft, J, Te, nt, st);
    }
    else if (nt = A(N), typeof nt == "function") for (N = nt.call(N), Et = 0; !(ft = N.next()).done; ) ft = ft.value, nt = We + X(ft, Et++), St += ae(ft, J, Te, nt, st);
    else if (ft === "object") throw J = String(N), Error("Objects are not valid as a React child (found: " + (J === "[object Object]" ? "object with keys {" + Object.keys(N).join(", ") + "}" : J) + "). If you meant to render a collection of children, use an array instead.");
    return St;
  }
  function we(N, J, Te) {
    if (N == null) return N;
    var We = [], st = 0;
    return ae(N, We, "", "", function(ft) {
      return J.call(Te, ft, st++);
    }), We;
  }
  function Ue(N) {
    if (N._status === -1) {
      var J = N._result;
      J = J(), J.then(function(Te) {
        (N._status === 0 || N._status === -1) && (N._status = 1, N._result = Te);
      }, function(Te) {
        (N._status === 0 || N._status === -1) && (N._status = 2, N._result = Te);
      }), N._status === -1 && (N._status = 0, N._result = J);
    }
    if (N._status === 1) return N._result.default;
    throw N._result;
  }
  var Le = { current: null }, I = { transition: null }, ge = { ReactCurrentDispatcher: Le, ReactCurrentBatchConfig: I, ReactCurrentOwner: Ne };
  function pe() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return Ot.Children = { map: we, forEach: function(N, J, Te) {
    we(N, function() {
      J.apply(this, arguments);
    }, Te);
  }, count: function(N) {
    var J = 0;
    return we(N, function() {
      J++;
    }), J;
  }, toArray: function(N) {
    return we(N, function(J) {
      return J;
    }) || [];
  }, only: function(N) {
    if (!jt(N)) throw Error("React.Children.only expected to receive a single React element child.");
    return N;
  } }, Ot.Component = Ae, Ot.Fragment = g, Ot.Profiler = L, Ot.PureComponent = ut, Ot.StrictMode = T, Ot.Suspense = ne, Ot.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ge, Ot.act = pe, Ot.cloneElement = function(N, J, Te) {
    if (N == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + N + ".");
    var We = q({}, N.props), st = N.key, ft = N.ref, St = N._owner;
    if (J != null) {
      if (J.ref !== void 0 && (ft = J.ref, St = Ne.current), J.key !== void 0 && (st = "" + J.key), N.type && N.type.defaultProps) var Et = N.type.defaultProps;
      for (nt in J) Rt.call(J, nt) && !lt.hasOwnProperty(nt) && (We[nt] = J[nt] === void 0 && Et !== void 0 ? Et[nt] : J[nt]);
    }
    var nt = arguments.length - 2;
    if (nt === 1) We.children = Te;
    else if (1 < nt) {
      Et = Array(nt);
      for (var wt = 0; wt < nt; wt++) Et[wt] = arguments[wt + 2];
      We.children = Et;
    }
    return { $$typeof: b, type: N.type, key: st, ref: ft, props: We, _owner: St };
  }, Ot.createContext = function(N) {
    return N = { $$typeof: x, _currentValue: N, _currentValue2: N, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, N.Provider = { $$typeof: U, _context: N }, N.Consumer = N;
  }, Ot.createElement = it, Ot.createFactory = function(N) {
    var J = it.bind(null, N);
    return J.type = N, J;
  }, Ot.createRef = function() {
    return { current: null };
  }, Ot.forwardRef = function(N) {
    return { $$typeof: S, render: N };
  }, Ot.isValidElement = jt, Ot.lazy = function(N) {
    return { $$typeof: Q, _payload: { _status: -1, _result: N }, _init: Ue };
  }, Ot.memo = function(N, J) {
    return { $$typeof: te, type: N, compare: J === void 0 ? null : J };
  }, Ot.startTransition = function(N) {
    var J = I.transition;
    I.transition = {};
    try {
      N();
    } finally {
      I.transition = J;
    }
  }, Ot.unstable_act = pe, Ot.useCallback = function(N, J) {
    return Le.current.useCallback(N, J);
  }, Ot.useContext = function(N) {
    return Le.current.useContext(N);
  }, Ot.useDebugValue = function() {
  }, Ot.useDeferredValue = function(N) {
    return Le.current.useDeferredValue(N);
  }, Ot.useEffect = function(N, J) {
    return Le.current.useEffect(N, J);
  }, Ot.useId = function() {
    return Le.current.useId();
  }, Ot.useImperativeHandle = function(N, J, Te) {
    return Le.current.useImperativeHandle(N, J, Te);
  }, Ot.useInsertionEffect = function(N, J) {
    return Le.current.useInsertionEffect(N, J);
  }, Ot.useLayoutEffect = function(N, J) {
    return Le.current.useLayoutEffect(N, J);
  }, Ot.useMemo = function(N, J) {
    return Le.current.useMemo(N, J);
  }, Ot.useReducer = function(N, J, Te) {
    return Le.current.useReducer(N, J, Te);
  }, Ot.useRef = function(N) {
    return Le.current.useRef(N);
  }, Ot.useState = function(N) {
    return Le.current.useState(N);
  }, Ot.useSyncExternalStore = function(N, J, Te) {
    return Le.current.useSyncExternalStore(N, J, Te);
  }, Ot.useTransition = function() {
    return Le.current.useTransition();
  }, Ot.version = "18.3.1", Ot;
}
var lv = { exports: {} };
lv.exports;
var _T;
function uD() {
  return _T || (_T = 1, function(b, m) {
    var g = {};
    /**
     * @license React
     * react.development.js
     *
     * Copyright (c) Facebook, Inc. and its affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    g.NODE_ENV !== "production" && function() {
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
      var T = "18.3.1", L = Symbol.for("react.element"), U = Symbol.for("react.portal"), x = Symbol.for("react.fragment"), S = Symbol.for("react.strict_mode"), ne = Symbol.for("react.profiler"), te = Symbol.for("react.provider"), Q = Symbol.for("react.context"), Z = Symbol.for("react.forward_ref"), A = Symbol.for("react.suspense"), oe = Symbol.for("react.suspense_list"), q = Symbol.for("react.memo"), ve = Symbol.for("react.lazy"), Ae = Symbol.for("react.offscreen"), Ye = Symbol.iterator, ut = "@@iterator";
      function Ke(h) {
        if (h === null || typeof h != "object")
          return null;
        var w = Ye && h[Ye] || h[ut];
        return typeof w == "function" ? w : null;
      }
      var Ge = {
        /**
         * @internal
         * @type {ReactComponent}
         */
        current: null
      }, Rt = {
        transition: null
      }, Ne = {
        current: null,
        // Used to reproduce behavior of `batchedUpdates` in legacy mode.
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1
      }, lt = {
        /**
         * @internal
         * @type {ReactComponent}
         */
        current: null
      }, it = {}, Jt = null;
      function jt(h) {
        Jt = h;
      }
      it.setExtraStackFrame = function(h) {
        Jt = h;
      }, it.getCurrentStack = null, it.getStackAddendum = function() {
        var h = "";
        Jt && (h += Jt);
        var w = it.getCurrentStack;
        return w && (h += w() || ""), h;
      };
      var Xe = !1, W = !1, X = !1, ae = !1, we = !1, Ue = {
        ReactCurrentDispatcher: Ge,
        ReactCurrentBatchConfig: Rt,
        ReactCurrentOwner: lt
      };
      Ue.ReactDebugCurrentFrame = it, Ue.ReactCurrentActQueue = Ne;
      function Le(h) {
        {
          for (var w = arguments.length, H = new Array(w > 1 ? w - 1 : 0), Y = 1; Y < w; Y++)
            H[Y - 1] = arguments[Y];
          ge("warn", h, H);
        }
      }
      function I(h) {
        {
          for (var w = arguments.length, H = new Array(w > 1 ? w - 1 : 0), Y = 1; Y < w; Y++)
            H[Y - 1] = arguments[Y];
          ge("error", h, H);
        }
      }
      function ge(h, w, H) {
        {
          var Y = Ue.ReactDebugCurrentFrame, he = Y.getStackAddendum();
          he !== "" && (w += "%s", H = H.concat([he]));
          var je = H.map(function(De) {
            return String(De);
          });
          je.unshift("Warning: " + w), Function.prototype.apply.call(console[h], console, je);
        }
      }
      var pe = {};
      function N(h, w) {
        {
          var H = h.constructor, Y = H && (H.displayName || H.name) || "ReactClass", he = Y + "." + w;
          if (pe[he])
            return;
          I("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", w, Y), pe[he] = !0;
        }
      }
      var J = {
        /**
         * Checks whether or not this composite component is mounted.
         * @param {ReactClass} publicInstance The instance we want to test.
         * @return {boolean} True if mounted, false otherwise.
         * @protected
         * @final
         */
        isMounted: function(h) {
          return !1;
        },
        /**
         * Forces an update. This should only be invoked when it is known with
         * certainty that we are **not** in a DOM transaction.
         *
         * You may want to call this when you know that some deeper aspect of the
         * component's state has changed but `setState` was not called.
         *
         * This will not invoke `shouldComponentUpdate`, but it will invoke
         * `componentWillUpdate` and `componentDidUpdate`.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {?function} callback Called after component is updated.
         * @param {?string} callerName name of the calling function in the public API.
         * @internal
         */
        enqueueForceUpdate: function(h, w, H) {
          N(h, "forceUpdate");
        },
        /**
         * Replaces all of the state. Always use this or `setState` to mutate state.
         * You should treat `this.state` as immutable.
         *
         * There is no guarantee that `this.state` will be immediately updated, so
         * accessing `this.state` after calling this method may return the old value.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {object} completeState Next state.
         * @param {?function} callback Called after component is updated.
         * @param {?string} callerName name of the calling function in the public API.
         * @internal
         */
        enqueueReplaceState: function(h, w, H, Y) {
          N(h, "replaceState");
        },
        /**
         * Sets a subset of the state. This only exists because _pendingState is
         * internal. This provides a merging strategy that is not available to deep
         * properties which is confusing. TODO: Expose pendingState or don't use it
         * during the merge.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {object} partialState Next partial state to be merged with state.
         * @param {?function} callback Called after component is updated.
         * @param {?string} Name of the calling function in the public API.
         * @internal
         */
        enqueueSetState: function(h, w, H, Y) {
          N(h, "setState");
        }
      }, Te = Object.assign, We = {};
      Object.freeze(We);
      function st(h, w, H) {
        this.props = h, this.context = w, this.refs = We, this.updater = H || J;
      }
      st.prototype.isReactComponent = {}, st.prototype.setState = function(h, w) {
        if (typeof h != "object" && typeof h != "function" && h != null)
          throw new Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, h, w, "setState");
      }, st.prototype.forceUpdate = function(h) {
        this.updater.enqueueForceUpdate(this, h, "forceUpdate");
      };
      {
        var ft = {
          isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
          replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
        }, St = function(h, w) {
          Object.defineProperty(st.prototype, h, {
            get: function() {
              Le("%s(...) is deprecated in plain JavaScript React classes. %s", w[0], w[1]);
            }
          });
        };
        for (var Et in ft)
          ft.hasOwnProperty(Et) && St(Et, ft[Et]);
      }
      function nt() {
      }
      nt.prototype = st.prototype;
      function wt(h, w, H) {
        this.props = h, this.context = w, this.refs = We, this.updater = H || J;
      }
      var kn = wt.prototype = new nt();
      kn.constructor = wt, Te(kn, st.prototype), kn.isPureReactComponent = !0;
      function Pr() {
        var h = {
          current: null
        };
        return Object.seal(h), h;
      }
      var dr = Array.isArray;
      function bn(h) {
        return dr(h);
      }
      function Jn(h) {
        {
          var w = typeof Symbol == "function" && Symbol.toStringTag, H = w && h[Symbol.toStringTag] || h.constructor.name || "Object";
          return H;
        }
      }
      function Bn(h) {
        try {
          return Dn(h), !1;
        } catch {
          return !0;
        }
      }
      function Dn(h) {
        return "" + h;
      }
      function An(h) {
        if (Bn(h))
          return I("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", Jn(h)), Dn(h);
      }
      function Sr(h, w, H) {
        var Y = h.displayName;
        if (Y)
          return Y;
        var he = w.displayName || w.name || "";
        return he !== "" ? H + "(" + he + ")" : H;
      }
      function pr(h) {
        return h.displayName || "Context";
      }
      function Vn(h) {
        if (h == null)
          return null;
        if (typeof h.tag == "number" && I("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof h == "function")
          return h.displayName || h.name || null;
        if (typeof h == "string")
          return h;
        switch (h) {
          case x:
            return "Fragment";
          case U:
            return "Portal";
          case ne:
            return "Profiler";
          case S:
            return "StrictMode";
          case A:
            return "Suspense";
          case oe:
            return "SuspenseList";
        }
        if (typeof h == "object")
          switch (h.$$typeof) {
            case Q:
              var w = h;
              return pr(w) + ".Consumer";
            case te:
              var H = h;
              return pr(H._context) + ".Provider";
            case Z:
              return Sr(h, h.render, "ForwardRef");
            case q:
              var Y = h.displayName || null;
              return Y !== null ? Y : Vn(h.type) || "Memo";
            case ve: {
              var he = h, je = he._payload, De = he._init;
              try {
                return Vn(De(je));
              } catch {
                return null;
              }
            }
          }
        return null;
      }
      var aa = Object.prototype.hasOwnProperty, ia = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
      }, vr, la, Zn;
      Zn = {};
      function Er(h) {
        if (aa.call(h, "ref")) {
          var w = Object.getOwnPropertyDescriptor(h, "ref").get;
          if (w && w.isReactWarning)
            return !1;
        }
        return h.ref !== void 0;
      }
      function vn(h) {
        if (aa.call(h, "key")) {
          var w = Object.getOwnPropertyDescriptor(h, "key").get;
          if (w && w.isReactWarning)
            return !1;
        }
        return h.key !== void 0;
      }
      function oa(h, w) {
        var H = function() {
          vr || (vr = !0, I("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", w));
        };
        H.isReactWarning = !0, Object.defineProperty(h, "key", {
          get: H,
          configurable: !0
        });
      }
      function ua(h, w) {
        var H = function() {
          la || (la = !0, I("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", w));
        };
        H.isReactWarning = !0, Object.defineProperty(h, "ref", {
          get: H,
          configurable: !0
        });
      }
      function sa(h) {
        if (typeof h.ref == "string" && lt.current && h.__self && lt.current.stateNode !== h.__self) {
          var w = Vn(lt.current.type);
          Zn[w] || (I('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', w, h.ref), Zn[w] = !0);
        }
      }
      var Ee = function(h, w, H, Y, he, je, De) {
        var ot = {
          // This tag allows us to uniquely identify this as a React Element
          $$typeof: L,
          // Built-in properties that belong on the element
          type: h,
          key: w,
          ref: H,
          props: De,
          // Record the component responsible for creating this element.
          _owner: je
        };
        return ot._store = {}, Object.defineProperty(ot._store, "validated", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: !1
        }), Object.defineProperty(ot, "_self", {
          configurable: !1,
          enumerable: !1,
          writable: !1,
          value: Y
        }), Object.defineProperty(ot, "_source", {
          configurable: !1,
          enumerable: !1,
          writable: !1,
          value: he
        }), Object.freeze && (Object.freeze(ot.props), Object.freeze(ot)), ot;
      };
      function Qe(h, w, H) {
        var Y, he = {}, je = null, De = null, ot = null, Tt = null;
        if (w != null) {
          Er(w) && (De = w.ref, sa(w)), vn(w) && (An(w.key), je = "" + w.key), ot = w.__self === void 0 ? null : w.__self, Tt = w.__source === void 0 ? null : w.__source;
          for (Y in w)
            aa.call(w, Y) && !ia.hasOwnProperty(Y) && (he[Y] = w[Y]);
        }
        var Wt = arguments.length - 2;
        if (Wt === 1)
          he.children = H;
        else if (Wt > 1) {
          for (var Kt = Array(Wt), qt = 0; qt < Wt; qt++)
            Kt[qt] = arguments[qt + 2];
          Object.freeze && Object.freeze(Kt), he.children = Kt;
        }
        if (h && h.defaultProps) {
          var Xt = h.defaultProps;
          for (Y in Xt)
            he[Y] === void 0 && (he[Y] = Xt[Y]);
        }
        if (je || De) {
          var cn = typeof h == "function" ? h.displayName || h.name || "Unknown" : h;
          je && oa(he, cn), De && ua(he, cn);
        }
        return Ee(h, je, De, ot, Tt, lt.current, he);
      }
      function Ct(h, w) {
        var H = Ee(h.type, w, h.ref, h._self, h._source, h._owner, h.props);
        return H;
      }
      function $t(h, w, H) {
        if (h == null)
          throw new Error("React.cloneElement(...): The argument must be a React element, but you passed " + h + ".");
        var Y, he = Te({}, h.props), je = h.key, De = h.ref, ot = h._self, Tt = h._source, Wt = h._owner;
        if (w != null) {
          Er(w) && (De = w.ref, Wt = lt.current), vn(w) && (An(w.key), je = "" + w.key);
          var Kt;
          h.type && h.type.defaultProps && (Kt = h.type.defaultProps);
          for (Y in w)
            aa.call(w, Y) && !ia.hasOwnProperty(Y) && (w[Y] === void 0 && Kt !== void 0 ? he[Y] = Kt[Y] : he[Y] = w[Y]);
        }
        var qt = arguments.length - 2;
        if (qt === 1)
          he.children = H;
        else if (qt > 1) {
          for (var Xt = Array(qt), cn = 0; cn < qt; cn++)
            Xt[cn] = arguments[cn + 2];
          he.children = Xt;
        }
        return Ee(h.type, je, De, ot, Tt, Wt, he);
      }
      function Pt(h) {
        return typeof h == "object" && h !== null && h.$$typeof === L;
      }
      var On = ".", yn = ":";
      function hr(h) {
        var w = /[=:]/g, H = {
          "=": "=0",
          ":": "=2"
        }, Y = h.replace(w, function(he) {
          return H[he];
        });
        return "$" + Y;
      }
      var Gt = !1, Wn = /\/+/g;
      function It(h) {
        return h.replace(Wn, "$&/");
      }
      function ln(h, w) {
        return typeof h == "object" && h !== null && h.key != null ? (An(h.key), hr("" + h.key)) : w.toString(36);
      }
      function Ka(h, w, H, Y, he) {
        var je = typeof h;
        (je === "undefined" || je === "boolean") && (h = null);
        var De = !1;
        if (h === null)
          De = !0;
        else
          switch (je) {
            case "string":
            case "number":
              De = !0;
              break;
            case "object":
              switch (h.$$typeof) {
                case L:
                case U:
                  De = !0;
              }
          }
        if (De) {
          var ot = h, Tt = he(ot), Wt = Y === "" ? On + ln(ot, 0) : Y;
          if (bn(Tt)) {
            var Kt = "";
            Wt != null && (Kt = It(Wt) + "/"), Ka(Tt, w, Kt, "", function(Gf) {
              return Gf;
            });
          } else Tt != null && (Pt(Tt) && (Tt.key && (!ot || ot.key !== Tt.key) && An(Tt.key), Tt = Ct(
            Tt,
            // Keep both the (mapped) and old keys if they differ, just as
            // traverseAllChildren used to do for objects as children
            H + // $FlowFixMe Flow incorrectly thinks React.Portal doesn't have a key
            (Tt.key && (!ot || ot.key !== Tt.key) ? (
              // $FlowFixMe Flow incorrectly thinks existing element's key can be a number
              // eslint-disable-next-line react-internal/safe-string-coercion
              It("" + Tt.key) + "/"
            ) : "") + Wt
          )), w.push(Tt));
          return 1;
        }
        var qt, Xt, cn = 0, At = Y === "" ? On : Y + yn;
        if (bn(h))
          for (var xl = 0; xl < h.length; xl++)
            qt = h[xl], Xt = At + ln(qt, xl), cn += Ka(qt, w, H, Xt, he);
        else {
          var ru = Ke(h);
          if (typeof ru == "function") {
            var us = h;
            ru === us.entries && (Gt || Le("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), Gt = !0);
            for (var ss = ru.call(us), $i, cs = 0; !($i = ss.next()).done; )
              qt = $i.value, Xt = At + ln(qt, cs++), cn += Ka(qt, w, H, Xt, he);
          } else if (je === "object") {
            var fs = String(h);
            throw new Error("Objects are not valid as a React child (found: " + (fs === "[object Object]" ? "object with keys {" + Object.keys(h).join(", ") + "}" : fs) + "). If you meant to render a collection of children, use an array instead.");
          }
        }
        return cn;
      }
      function ka(h, w, H) {
        if (h == null)
          return h;
        var Y = [], he = 0;
        return Ka(h, Y, "", "", function(je) {
          return w.call(H, je, he++);
        }), Y;
      }
      function yl(h) {
        var w = 0;
        return ka(h, function() {
          w++;
        }), w;
      }
      function io(h, w, H) {
        ka(h, function() {
          w.apply(this, arguments);
        }, H);
      }
      function lo(h) {
        return ka(h, function(w) {
          return w;
        }) || [];
      }
      function gl(h) {
        if (!Pt(h))
          throw new Error("React.Children.only expected to receive a single React element child.");
        return h;
      }
      function qa(h) {
        var w = {
          $$typeof: Q,
          // As a workaround to support multiple concurrent renderers, we categorize
          // some renderers as primary and others as secondary. We only expect
          // there to be two concurrent renderers at most: React Native (primary) and
          // Fabric (secondary); React DOM (primary) and React ART (secondary).
          // Secondary renderers store their context values on separate fields.
          _currentValue: h,
          _currentValue2: h,
          // Used to track how many concurrent renderers this context currently
          // supports within in a single renderer. Such as parallel server rendering.
          _threadCount: 0,
          // These are circular
          Provider: null,
          Consumer: null,
          // Add these to use same hidden class in VM as ServerContext
          _defaultValue: null,
          _globalName: null
        };
        w.Provider = {
          $$typeof: te,
          _context: w
        };
        var H = !1, Y = !1, he = !1;
        {
          var je = {
            $$typeof: Q,
            _context: w
          };
          Object.defineProperties(je, {
            Provider: {
              get: function() {
                return Y || (Y = !0, I("Rendering <Context.Consumer.Provider> is not supported and will be removed in a future major release. Did you mean to render <Context.Provider> instead?")), w.Provider;
              },
              set: function(De) {
                w.Provider = De;
              }
            },
            _currentValue: {
              get: function() {
                return w._currentValue;
              },
              set: function(De) {
                w._currentValue = De;
              }
            },
            _currentValue2: {
              get: function() {
                return w._currentValue2;
              },
              set: function(De) {
                w._currentValue2 = De;
              }
            },
            _threadCount: {
              get: function() {
                return w._threadCount;
              },
              set: function(De) {
                w._threadCount = De;
              }
            },
            Consumer: {
              get: function() {
                return H || (H = !0, I("Rendering <Context.Consumer.Consumer> is not supported and will be removed in a future major release. Did you mean to render <Context.Consumer> instead?")), w.Consumer;
              }
            },
            displayName: {
              get: function() {
                return w.displayName;
              },
              set: function(De) {
                he || (Le("Setting `displayName` on Context.Consumer has no effect. You should set it directly on the context with Context.displayName = '%s'.", De), he = !0);
              }
            }
          }), w.Consumer = je;
        }
        return w._currentRenderer = null, w._currentRenderer2 = null, w;
      }
      var Xa = -1, Da = 0, Ui = 1, Cr = 2;
      function Hr(h) {
        if (h._status === Xa) {
          var w = h._result, H = w();
          if (H.then(function(je) {
            if (h._status === Da || h._status === Xa) {
              var De = h;
              De._status = Ui, De._result = je;
            }
          }, function(je) {
            if (h._status === Da || h._status === Xa) {
              var De = h;
              De._status = Cr, De._result = je;
            }
          }), h._status === Xa) {
            var Y = h;
            Y._status = Da, Y._result = H;
          }
        }
        if (h._status === Ui) {
          var he = h._result;
          return he === void 0 && I(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`, he), "default" in he || I(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`, he), he.default;
        } else
          throw h._result;
      }
      function ca(h) {
        var w = {
          // We use these fields to store the result.
          _status: Xa,
          _result: h
        }, H = {
          $$typeof: ve,
          _payload: w,
          _init: Hr
        };
        {
          var Y, he;
          Object.defineProperties(H, {
            defaultProps: {
              configurable: !0,
              get: function() {
                return Y;
              },
              set: function(je) {
                I("React.lazy(...): It is not supported to assign `defaultProps` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it."), Y = je, Object.defineProperty(H, "defaultProps", {
                  enumerable: !0
                });
              }
            },
            propTypes: {
              configurable: !0,
              get: function() {
                return he;
              },
              set: function(je) {
                I("React.lazy(...): It is not supported to assign `propTypes` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it."), he = je, Object.defineProperty(H, "propTypes", {
                  enumerable: !0
                });
              }
            }
          });
        }
        return H;
      }
      function zi(h) {
        h != null && h.$$typeof === q ? I("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : typeof h != "function" ? I("forwardRef requires a render function but was given %s.", h === null ? "null" : typeof h) : h.length !== 0 && h.length !== 2 && I("forwardRef render functions accept exactly two parameters: props and ref. %s", h.length === 1 ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined."), h != null && (h.defaultProps != null || h.propTypes != null) && I("forwardRef render functions do not support propTypes or defaultProps. Did you accidentally pass a React component?");
        var w = {
          $$typeof: Z,
          render: h
        };
        {
          var H;
          Object.defineProperty(w, "displayName", {
            enumerable: !1,
            configurable: !0,
            get: function() {
              return H;
            },
            set: function(Y) {
              H = Y, !h.name && !h.displayName && (h.displayName = Y);
            }
          });
        }
        return w;
      }
      var Sl;
      Sl = Symbol.for("react.module.reference");
      function _(h) {
        return !!(typeof h == "string" || typeof h == "function" || h === x || h === ne || we || h === S || h === A || h === oe || ae || h === Ae || Xe || W || X || typeof h == "object" && h !== null && (h.$$typeof === ve || h.$$typeof === q || h.$$typeof === te || h.$$typeof === Q || h.$$typeof === Z || // This needs to include all possible module reference object
        // types supported by any Flight configuration anywhere since
        // we don't know which Flight build this will end up being used
        // with.
        h.$$typeof === Sl || h.getModuleId !== void 0));
      }
      function ue(h, w) {
        _(h) || I("memo: The first argument must be a component. Instead received: %s", h === null ? "null" : typeof h);
        var H = {
          $$typeof: q,
          type: h,
          compare: w === void 0 ? null : w
        };
        {
          var Y;
          Object.defineProperty(H, "displayName", {
            enumerable: !1,
            configurable: !0,
            get: function() {
              return Y;
            },
            set: function(he) {
              Y = he, !h.name && !h.displayName && (h.displayName = he);
            }
          });
        }
        return H;
      }
      function ce() {
        var h = Ge.current;
        return h === null && I(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.`), h;
      }
      function Je(h) {
        var w = ce();
        if (h._context !== void 0) {
          var H = h._context;
          H.Consumer === h ? I("Calling useContext(Context.Consumer) is not supported, may cause bugs, and will be removed in a future major release. Did you mean to call useContext(Context) instead?") : H.Provider === h && I("Calling useContext(Context.Provider) is not supported. Did you mean to call useContext(Context) instead?");
        }
        return w.useContext(h);
      }
      function xt(h) {
        var w = ce();
        return w.useState(h);
      }
      function Mt(h, w, H) {
        var Y = ce();
        return Y.useReducer(h, w, H);
      }
      function tt(h) {
        var w = ce();
        return w.useRef(h);
      }
      function bt(h, w) {
        var H = ce();
        return H.useEffect(h, w);
      }
      function Un(h, w) {
        var H = ce();
        return H.useInsertionEffect(h, w);
      }
      function tn(h, w) {
        var H = ce();
        return H.useLayoutEffect(h, w);
      }
      function hn(h, w) {
        var H = ce();
        return H.useCallback(h, w);
      }
      function mr(h, w) {
        var H = ce();
        return H.useMemo(h, w);
      }
      function Yt(h, w, H) {
        var Y = ce();
        return Y.useImperativeHandle(h, w, H);
      }
      function Oa(h, w) {
        {
          var H = ce();
          return H.useDebugValue(h, w);
        }
      }
      function zn() {
        var h = ce();
        return h.useTransition();
      }
      function Br(h) {
        var w = ce();
        return w.useDeferredValue(h);
      }
      function yt() {
        var h = ce();
        return h.useId();
      }
      function Fi(h, w, H) {
        var Y = ce();
        return Y.useSyncExternalStore(h, w, H);
      }
      var ji = 0, El, Vr, Ju, br, Zu, es, ts;
      function oo() {
      }
      oo.__reactDisabledLog = !0;
      function qo() {
        {
          if (ji === 0) {
            El = console.log, Vr = console.info, Ju = console.warn, br = console.error, Zu = console.group, es = console.groupCollapsed, ts = console.groupEnd;
            var h = {
              configurable: !0,
              enumerable: !0,
              value: oo,
              writable: !0
            };
            Object.defineProperties(console, {
              info: h,
              log: h,
              warn: h,
              error: h,
              group: h,
              groupCollapsed: h,
              groupEnd: h
            });
          }
          ji++;
        }
      }
      function Pi() {
        {
          if (ji--, ji === 0) {
            var h = {
              configurable: !0,
              enumerable: !0,
              writable: !0
            };
            Object.defineProperties(console, {
              log: Te({}, h, {
                value: El
              }),
              info: Te({}, h, {
                value: Vr
              }),
              warn: Te({}, h, {
                value: Ju
              }),
              error: Te({}, h, {
                value: br
              }),
              group: Te({}, h, {
                value: Zu
              }),
              groupCollapsed: Te({}, h, {
                value: es
              }),
              groupEnd: Te({}, h, {
                value: ts
              })
            });
          }
          ji < 0 && I("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
        }
      }
      var di = Ue.ReactCurrentDispatcher, Ma;
      function Cl(h, w, H) {
        {
          if (Ma === void 0)
            try {
              throw Error();
            } catch (he) {
              var Y = he.stack.trim().match(/\n( *(at )?)/);
              Ma = Y && Y[1] || "";
            }
          return `
` + Ma + h;
        }
      }
      var pi = !1, uo;
      {
        var so = typeof WeakMap == "function" ? WeakMap : Map;
        uo = new so();
      }
      function bl(h, w) {
        if (!h || pi)
          return "";
        {
          var H = uo.get(h);
          if (H !== void 0)
            return H;
        }
        var Y;
        pi = !0;
        var he = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        var je;
        je = di.current, di.current = null, qo();
        try {
          if (w) {
            var De = function() {
              throw Error();
            };
            if (Object.defineProperty(De.prototype, "props", {
              set: function() {
                throw Error();
              }
            }), typeof Reflect == "object" && Reflect.construct) {
              try {
                Reflect.construct(De, []);
              } catch (At) {
                Y = At;
              }
              Reflect.construct(h, [], De);
            } else {
              try {
                De.call();
              } catch (At) {
                Y = At;
              }
              h.call(De.prototype);
            }
          } else {
            try {
              throw Error();
            } catch (At) {
              Y = At;
            }
            h();
          }
        } catch (At) {
          if (At && Y && typeof At.stack == "string") {
            for (var ot = At.stack.split(`
`), Tt = Y.stack.split(`
`), Wt = ot.length - 1, Kt = Tt.length - 1; Wt >= 1 && Kt >= 0 && ot[Wt] !== Tt[Kt]; )
              Kt--;
            for (; Wt >= 1 && Kt >= 0; Wt--, Kt--)
              if (ot[Wt] !== Tt[Kt]) {
                if (Wt !== 1 || Kt !== 1)
                  do
                    if (Wt--, Kt--, Kt < 0 || ot[Wt] !== Tt[Kt]) {
                      var qt = `
` + ot[Wt].replace(" at new ", " at ");
                      return h.displayName && qt.includes("<anonymous>") && (qt = qt.replace("<anonymous>", h.displayName)), typeof h == "function" && uo.set(h, qt), qt;
                    }
                  while (Wt >= 1 && Kt >= 0);
                break;
              }
          }
        } finally {
          pi = !1, di.current = je, Pi(), Error.prepareStackTrace = he;
        }
        var Xt = h ? h.displayName || h.name : "", cn = Xt ? Cl(Xt) : "";
        return typeof h == "function" && uo.set(h, cn), cn;
      }
      function ns(h, w, H) {
        return bl(h, !1);
      }
      function rs(h) {
        var w = h.prototype;
        return !!(w && w.isReactComponent);
      }
      function kt(h, w, H) {
        if (h == null)
          return "";
        if (typeof h == "function")
          return bl(h, rs(h));
        if (typeof h == "string")
          return Cl(h);
        switch (h) {
          case A:
            return Cl("Suspense");
          case oe:
            return Cl("SuspenseList");
        }
        if (typeof h == "object")
          switch (h.$$typeof) {
            case Z:
              return ns(h.render);
            case q:
              return kt(h.type, w, H);
            case ve: {
              var Y = h, he = Y._payload, je = Y._init;
              try {
                return kt(je(he), w, H);
              } catch {
              }
            }
          }
        return "";
      }
      var as = {}, Xo = Ue.ReactDebugCurrentFrame;
      function Tl(h) {
        if (h) {
          var w = h._owner, H = kt(h.type, h._source, w ? w.type : null);
          Xo.setExtraStackFrame(H);
        } else
          Xo.setExtraStackFrame(null);
      }
      function is(h, w, H, Y, he) {
        {
          var je = Function.call.bind(aa);
          for (var De in h)
            if (je(h, De)) {
              var ot = void 0;
              try {
                if (typeof h[De] != "function") {
                  var Tt = Error((Y || "React class") + ": " + H + " type `" + De + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof h[De] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                  throw Tt.name = "Invariant Violation", Tt;
                }
                ot = h[De](w, De, Y, H, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
              } catch (Wt) {
                ot = Wt;
              }
              ot && !(ot instanceof Error) && (Tl(he), I("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", Y || "React class", H, De, typeof ot), Tl(null)), ot instanceof Error && !(ot.message in as) && (as[ot.message] = !0, Tl(he), I("Failed %s type: %s", H, ot.message), Tl(null));
            }
        }
      }
      function Dt(h) {
        if (h) {
          var w = h._owner, H = kt(h.type, h._source, w ? w.type : null);
          jt(H);
        } else
          jt(null);
      }
      var Jo;
      Jo = !1;
      function co() {
        if (lt.current) {
          var h = Vn(lt.current.type);
          if (h)
            return `

Check the render method of \`` + h + "`.";
        }
        return "";
      }
      function dt(h) {
        if (h !== void 0) {
          var w = h.fileName.replace(/^.*[\\\/]/, ""), H = h.lineNumber;
          return `

Check your code at ` + w + ":" + H + ".";
        }
        return "";
      }
      function Ja(h) {
        return h != null ? dt(h.__source) : "";
      }
      var gn = {};
      function $r(h) {
        var w = co();
        if (!w) {
          var H = typeof h == "string" ? h : h.displayName || h.name;
          H && (w = `

Check the top-level render call using <` + H + ">.");
        }
        return w;
      }
      function Na(h, w) {
        if (!(!h._store || h._store.validated || h.key != null)) {
          h._store.validated = !0;
          var H = $r(w);
          if (!gn[H]) {
            gn[H] = !0;
            var Y = "";
            h && h._owner && h._owner !== lt.current && (Y = " It was passed a child from " + Vn(h._owner.type) + "."), Dt(h), I('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', H, Y), Dt(null);
          }
        }
      }
      function Rl(h, w) {
        if (typeof h == "object") {
          if (bn(h))
            for (var H = 0; H < h.length; H++) {
              var Y = h[H];
              Pt(Y) && Na(Y, w);
            }
          else if (Pt(h))
            h._store && (h._store.validated = !0);
          else if (h) {
            var he = Ke(h);
            if (typeof he == "function" && he !== h.entries)
              for (var je = he.call(h), De; !(De = je.next()).done; )
                Pt(De.value) && Na(De.value, w);
          }
        }
      }
      function sn(h) {
        {
          var w = h.type;
          if (w == null || typeof w == "string")
            return;
          var H;
          if (typeof w == "function")
            H = w.propTypes;
          else if (typeof w == "object" && (w.$$typeof === Z || // Note: Memo only checks outer props here.
          // Inner props are checked in the reconciler.
          w.$$typeof === q))
            H = w.propTypes;
          else
            return;
          if (H) {
            var Y = Vn(w);
            is(H, h.props, "prop", Y, h);
          } else if (w.PropTypes !== void 0 && !Jo) {
            Jo = !0;
            var he = Vn(w);
            I("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", he || "Unknown");
          }
          typeof w.getDefaultProps == "function" && !w.getDefaultProps.isReactClassApproved && I("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
        }
      }
      function Sn(h) {
        {
          for (var w = Object.keys(h.props), H = 0; H < w.length; H++) {
            var Y = w[H];
            if (Y !== "children" && Y !== "key") {
              Dt(h), I("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", Y), Dt(null);
              break;
            }
          }
          h.ref !== null && (Dt(h), I("Invalid attribute `ref` supplied to `React.Fragment`."), Dt(null));
        }
      }
      function ls(h, w, H) {
        var Y = _(h);
        if (!Y) {
          var he = "";
          (h === void 0 || typeof h == "object" && h !== null && Object.keys(h).length === 0) && (he += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var je = Ja(w);
          je ? he += je : he += co();
          var De;
          h === null ? De = "null" : bn(h) ? De = "array" : h !== void 0 && h.$$typeof === L ? (De = "<" + (Vn(h.type) || "Unknown") + " />", he = " Did you accidentally export a JSX literal instead of a component?") : De = typeof h, I("React.createElement: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", De, he);
        }
        var ot = Qe.apply(this, arguments);
        if (ot == null)
          return ot;
        if (Y)
          for (var Tt = 2; Tt < arguments.length; Tt++)
            Rl(arguments[Tt], h);
        return h === x ? Sn(ot) : sn(ot), ot;
      }
      var er = !1;
      function Ir(h) {
        var w = ls.bind(null, h);
        return w.type = h, er || (er = !0, Le("React.createFactory() is deprecated and will be removed in a future major release. Consider using JSX or use React.createElement() directly instead.")), Object.defineProperty(w, "type", {
          enumerable: !1,
          get: function() {
            return Le("Factory.type is deprecated. Access the class directly before passing it to createFactory."), Object.defineProperty(this, "type", {
              value: h
            }), h;
          }
        }), w;
      }
      function Za(h, w, H) {
        for (var Y = $t.apply(this, arguments), he = 2; he < arguments.length; he++)
          Rl(arguments[he], Y.type);
        return sn(Y), Y;
      }
      function Zo(h, w) {
        var H = Rt.transition;
        Rt.transition = {};
        var Y = Rt.transition;
        Rt.transition._updatedFibers = /* @__PURE__ */ new Set();
        try {
          h();
        } finally {
          if (Rt.transition = H, H === null && Y._updatedFibers) {
            var he = Y._updatedFibers.size;
            he > 10 && Le("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."), Y._updatedFibers.clear();
          }
        }
      }
      var fo = !1, po = null;
      function wl(h) {
        if (po === null)
          try {
            var w = ("require" + Math.random()).slice(0, 7), H = b && b[w];
            po = H.call(b, "timers").setImmediate;
          } catch {
            po = function(he) {
              fo === !1 && (fo = !0, typeof MessageChannel > "u" && I("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
              var je = new MessageChannel();
              je.port1.onmessage = he, je.port2.postMessage(void 0);
            };
          }
        return po(h);
      }
      var La = 0, Hi = !1;
      function vo(h) {
        {
          var w = La;
          La++, Ne.current === null && (Ne.current = []);
          var H = Ne.isBatchingLegacy, Y;
          try {
            if (Ne.isBatchingLegacy = !0, Y = h(), !H && Ne.didScheduleLegacyUpdate) {
              var he = Ne.current;
              he !== null && (Ne.didScheduleLegacyUpdate = !1, Vi(he));
            }
          } catch (Xt) {
            throw Bi(w), Xt;
          } finally {
            Ne.isBatchingLegacy = H;
          }
          if (Y !== null && typeof Y == "object" && typeof Y.then == "function") {
            var je = Y, De = !1, ot = {
              then: function(Xt, cn) {
                De = !0, je.then(function(At) {
                  Bi(w), La === 0 ? eu(At, Xt, cn) : Xt(At);
                }, function(At) {
                  Bi(w), cn(At);
                });
              }
            };
            return !Hi && typeof Promise < "u" && Promise.resolve().then(function() {
            }).then(function() {
              De || (Hi = !0, I("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
            }), ot;
          } else {
            var Tt = Y;
            if (Bi(w), La === 0) {
              var Wt = Ne.current;
              Wt !== null && (Vi(Wt), Ne.current = null);
              var Kt = {
                then: function(Xt, cn) {
                  Ne.current === null ? (Ne.current = [], eu(Tt, Xt, cn)) : Xt(Tt);
                }
              };
              return Kt;
            } else {
              var qt = {
                then: function(Xt, cn) {
                  Xt(Tt);
                }
              };
              return qt;
            }
          }
        }
      }
      function Bi(h) {
        h !== La - 1 && I("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "), La = h;
      }
      function eu(h, w, H) {
        {
          var Y = Ne.current;
          if (Y !== null)
            try {
              Vi(Y), wl(function() {
                Y.length === 0 ? (Ne.current = null, w(h)) : eu(h, w, H);
              });
            } catch (he) {
              H(he);
            }
          else
            w(h);
        }
      }
      var vi = !1;
      function Vi(h) {
        if (!vi) {
          vi = !0;
          var w = 0;
          try {
            for (; w < h.length; w++) {
              var H = h[w];
              do
                H = H(!0);
              while (H !== null);
            }
            h.length = 0;
          } catch (Y) {
            throw h = h.slice(w + 1), Y;
          } finally {
            vi = !1;
          }
        }
      }
      var tu = ls, os = Za, ei = Ir, nu = {
        map: ka,
        forEach: io,
        count: yl,
        toArray: lo,
        only: gl
      };
      m.Children = nu, m.Component = st, m.Fragment = x, m.Profiler = ne, m.PureComponent = wt, m.StrictMode = S, m.Suspense = A, m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Ue, m.act = vo, m.cloneElement = os, m.createContext = qa, m.createElement = tu, m.createFactory = ei, m.createRef = Pr, m.forwardRef = zi, m.isValidElement = Pt, m.lazy = ca, m.memo = ue, m.startTransition = Zo, m.unstable_act = vo, m.useCallback = hn, m.useContext = Je, m.useDebugValue = Oa, m.useDeferredValue = Br, m.useEffect = bt, m.useId = yt, m.useImperativeHandle = Yt, m.useInsertionEffect = Un, m.useLayoutEffect = tn, m.useMemo = mr, m.useReducer = Mt, m.useRef = tt, m.useState = xt, m.useSyncExternalStore = Fi, m.useTransition = zn, m.version = T, typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
    }();
  }(lv, lv.exports)), lv.exports;
}
var sD = {};
sD.NODE_ENV === "production" ? z0.exports = oD() : z0.exports = uD();
var re = z0.exports;
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var kT;
function cD() {
  if (kT) return rv;
  kT = 1;
  var b = re, m = Symbol.for("react.element"), g = Symbol.for("react.fragment"), T = Object.prototype.hasOwnProperty, L = b.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, U = { key: !0, ref: !0, __self: !0, __source: !0 };
  function x(S, ne, te) {
    var Q, Z = {}, A = null, oe = null;
    te !== void 0 && (A = "" + te), ne.key !== void 0 && (A = "" + ne.key), ne.ref !== void 0 && (oe = ne.ref);
    for (Q in ne) T.call(ne, Q) && !U.hasOwnProperty(Q) && (Z[Q] = ne[Q]);
    if (S && S.defaultProps) for (Q in ne = S.defaultProps, ne) Z[Q] === void 0 && (Z[Q] = ne[Q]);
    return { $$typeof: m, type: S, key: A, ref: oe, props: Z, _owner: L.current };
  }
  return rv.Fragment = g, rv.jsx = x, rv.jsxs = x, rv;
}
var av = {}, DT;
function fD() {
  if (DT) return av;
  DT = 1;
  var b = {};
  /**
   * @license React
   * react-jsx-runtime.development.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  return b.NODE_ENV !== "production" && function() {
    var m = re, g = Symbol.for("react.element"), T = Symbol.for("react.portal"), L = Symbol.for("react.fragment"), U = Symbol.for("react.strict_mode"), x = Symbol.for("react.profiler"), S = Symbol.for("react.provider"), ne = Symbol.for("react.context"), te = Symbol.for("react.forward_ref"), Q = Symbol.for("react.suspense"), Z = Symbol.for("react.suspense_list"), A = Symbol.for("react.memo"), oe = Symbol.for("react.lazy"), q = Symbol.for("react.offscreen"), ve = Symbol.iterator, Ae = "@@iterator";
    function Ye(_) {
      if (_ === null || typeof _ != "object")
        return null;
      var ue = ve && _[ve] || _[Ae];
      return typeof ue == "function" ? ue : null;
    }
    var ut = m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    function Ke(_) {
      {
        for (var ue = arguments.length, ce = new Array(ue > 1 ? ue - 1 : 0), Je = 1; Je < ue; Je++)
          ce[Je - 1] = arguments[Je];
        Ge("error", _, ce);
      }
    }
    function Ge(_, ue, ce) {
      {
        var Je = ut.ReactDebugCurrentFrame, xt = Je.getStackAddendum();
        xt !== "" && (ue += "%s", ce = ce.concat([xt]));
        var Mt = ce.map(function(tt) {
          return String(tt);
        });
        Mt.unshift("Warning: " + ue), Function.prototype.apply.call(console[_], console, Mt);
      }
    }
    var Rt = !1, Ne = !1, lt = !1, it = !1, Jt = !1, jt;
    jt = Symbol.for("react.module.reference");
    function Xe(_) {
      return !!(typeof _ == "string" || typeof _ == "function" || _ === L || _ === x || Jt || _ === U || _ === Q || _ === Z || it || _ === q || Rt || Ne || lt || typeof _ == "object" && _ !== null && (_.$$typeof === oe || _.$$typeof === A || _.$$typeof === S || _.$$typeof === ne || _.$$typeof === te || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      _.$$typeof === jt || _.getModuleId !== void 0));
    }
    function W(_, ue, ce) {
      var Je = _.displayName;
      if (Je)
        return Je;
      var xt = ue.displayName || ue.name || "";
      return xt !== "" ? ce + "(" + xt + ")" : ce;
    }
    function X(_) {
      return _.displayName || "Context";
    }
    function ae(_) {
      if (_ == null)
        return null;
      if (typeof _.tag == "number" && Ke("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof _ == "function")
        return _.displayName || _.name || null;
      if (typeof _ == "string")
        return _;
      switch (_) {
        case L:
          return "Fragment";
        case T:
          return "Portal";
        case x:
          return "Profiler";
        case U:
          return "StrictMode";
        case Q:
          return "Suspense";
        case Z:
          return "SuspenseList";
      }
      if (typeof _ == "object")
        switch (_.$$typeof) {
          case ne:
            var ue = _;
            return X(ue) + ".Consumer";
          case S:
            var ce = _;
            return X(ce._context) + ".Provider";
          case te:
            return W(_, _.render, "ForwardRef");
          case A:
            var Je = _.displayName || null;
            return Je !== null ? Je : ae(_.type) || "Memo";
          case oe: {
            var xt = _, Mt = xt._payload, tt = xt._init;
            try {
              return ae(tt(Mt));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    var we = Object.assign, Ue = 0, Le, I, ge, pe, N, J, Te;
    function We() {
    }
    We.__reactDisabledLog = !0;
    function st() {
      {
        if (Ue === 0) {
          Le = console.log, I = console.info, ge = console.warn, pe = console.error, N = console.group, J = console.groupCollapsed, Te = console.groupEnd;
          var _ = {
            configurable: !0,
            enumerable: !0,
            value: We,
            writable: !0
          };
          Object.defineProperties(console, {
            info: _,
            log: _,
            warn: _,
            error: _,
            group: _,
            groupCollapsed: _,
            groupEnd: _
          });
        }
        Ue++;
      }
    }
    function ft() {
      {
        if (Ue--, Ue === 0) {
          var _ = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: we({}, _, {
              value: Le
            }),
            info: we({}, _, {
              value: I
            }),
            warn: we({}, _, {
              value: ge
            }),
            error: we({}, _, {
              value: pe
            }),
            group: we({}, _, {
              value: N
            }),
            groupCollapsed: we({}, _, {
              value: J
            }),
            groupEnd: we({}, _, {
              value: Te
            })
          });
        }
        Ue < 0 && Ke("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var St = ut.ReactCurrentDispatcher, Et;
    function nt(_, ue, ce) {
      {
        if (Et === void 0)
          try {
            throw Error();
          } catch (xt) {
            var Je = xt.stack.trim().match(/\n( *(at )?)/);
            Et = Je && Je[1] || "";
          }
        return `
` + Et + _;
      }
    }
    var wt = !1, kn;
    {
      var Pr = typeof WeakMap == "function" ? WeakMap : Map;
      kn = new Pr();
    }
    function dr(_, ue) {
      if (!_ || wt)
        return "";
      {
        var ce = kn.get(_);
        if (ce !== void 0)
          return ce;
      }
      var Je;
      wt = !0;
      var xt = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var Mt;
      Mt = St.current, St.current = null, st();
      try {
        if (ue) {
          var tt = function() {
            throw Error();
          };
          if (Object.defineProperty(tt.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(tt, []);
            } catch (zn) {
              Je = zn;
            }
            Reflect.construct(_, [], tt);
          } else {
            try {
              tt.call();
            } catch (zn) {
              Je = zn;
            }
            _.call(tt.prototype);
          }
        } else {
          try {
            throw Error();
          } catch (zn) {
            Je = zn;
          }
          _();
        }
      } catch (zn) {
        if (zn && Je && typeof zn.stack == "string") {
          for (var bt = zn.stack.split(`
`), Un = Je.stack.split(`
`), tn = bt.length - 1, hn = Un.length - 1; tn >= 1 && hn >= 0 && bt[tn] !== Un[hn]; )
            hn--;
          for (; tn >= 1 && hn >= 0; tn--, hn--)
            if (bt[tn] !== Un[hn]) {
              if (tn !== 1 || hn !== 1)
                do
                  if (tn--, hn--, hn < 0 || bt[tn] !== Un[hn]) {
                    var mr = `
` + bt[tn].replace(" at new ", " at ");
                    return _.displayName && mr.includes("<anonymous>") && (mr = mr.replace("<anonymous>", _.displayName)), typeof _ == "function" && kn.set(_, mr), mr;
                  }
                while (tn >= 1 && hn >= 0);
              break;
            }
        }
      } finally {
        wt = !1, St.current = Mt, ft(), Error.prepareStackTrace = xt;
      }
      var Yt = _ ? _.displayName || _.name : "", Oa = Yt ? nt(Yt) : "";
      return typeof _ == "function" && kn.set(_, Oa), Oa;
    }
    function bn(_, ue, ce) {
      return dr(_, !1);
    }
    function Jn(_) {
      var ue = _.prototype;
      return !!(ue && ue.isReactComponent);
    }
    function Bn(_, ue, ce) {
      if (_ == null)
        return "";
      if (typeof _ == "function")
        return dr(_, Jn(_));
      if (typeof _ == "string")
        return nt(_);
      switch (_) {
        case Q:
          return nt("Suspense");
        case Z:
          return nt("SuspenseList");
      }
      if (typeof _ == "object")
        switch (_.$$typeof) {
          case te:
            return bn(_.render);
          case A:
            return Bn(_.type, ue, ce);
          case oe: {
            var Je = _, xt = Je._payload, Mt = Je._init;
            try {
              return Bn(Mt(xt), ue, ce);
            } catch {
            }
          }
        }
      return "";
    }
    var Dn = Object.prototype.hasOwnProperty, An = {}, Sr = ut.ReactDebugCurrentFrame;
    function pr(_) {
      if (_) {
        var ue = _._owner, ce = Bn(_.type, _._source, ue ? ue.type : null);
        Sr.setExtraStackFrame(ce);
      } else
        Sr.setExtraStackFrame(null);
    }
    function Vn(_, ue, ce, Je, xt) {
      {
        var Mt = Function.call.bind(Dn);
        for (var tt in _)
          if (Mt(_, tt)) {
            var bt = void 0;
            try {
              if (typeof _[tt] != "function") {
                var Un = Error((Je || "React class") + ": " + ce + " type `" + tt + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof _[tt] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw Un.name = "Invariant Violation", Un;
              }
              bt = _[tt](ue, tt, Je, ce, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (tn) {
              bt = tn;
            }
            bt && !(bt instanceof Error) && (pr(xt), Ke("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", Je || "React class", ce, tt, typeof bt), pr(null)), bt instanceof Error && !(bt.message in An) && (An[bt.message] = !0, pr(xt), Ke("Failed %s type: %s", ce, bt.message), pr(null));
          }
      }
    }
    var aa = Array.isArray;
    function ia(_) {
      return aa(_);
    }
    function vr(_) {
      {
        var ue = typeof Symbol == "function" && Symbol.toStringTag, ce = ue && _[Symbol.toStringTag] || _.constructor.name || "Object";
        return ce;
      }
    }
    function la(_) {
      try {
        return Zn(_), !1;
      } catch {
        return !0;
      }
    }
    function Zn(_) {
      return "" + _;
    }
    function Er(_) {
      if (la(_))
        return Ke("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", vr(_)), Zn(_);
    }
    var vn = ut.ReactCurrentOwner, oa = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    }, ua, sa, Ee;
    Ee = {};
    function Qe(_) {
      if (Dn.call(_, "ref")) {
        var ue = Object.getOwnPropertyDescriptor(_, "ref").get;
        if (ue && ue.isReactWarning)
          return !1;
      }
      return _.ref !== void 0;
    }
    function Ct(_) {
      if (Dn.call(_, "key")) {
        var ue = Object.getOwnPropertyDescriptor(_, "key").get;
        if (ue && ue.isReactWarning)
          return !1;
      }
      return _.key !== void 0;
    }
    function $t(_, ue) {
      if (typeof _.ref == "string" && vn.current && ue && vn.current.stateNode !== ue) {
        var ce = ae(vn.current.type);
        Ee[ce] || (Ke('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', ae(vn.current.type), _.ref), Ee[ce] = !0);
      }
    }
    function Pt(_, ue) {
      {
        var ce = function() {
          ua || (ua = !0, Ke("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", ue));
        };
        ce.isReactWarning = !0, Object.defineProperty(_, "key", {
          get: ce,
          configurable: !0
        });
      }
    }
    function On(_, ue) {
      {
        var ce = function() {
          sa || (sa = !0, Ke("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", ue));
        };
        ce.isReactWarning = !0, Object.defineProperty(_, "ref", {
          get: ce,
          configurable: !0
        });
      }
    }
    var yn = function(_, ue, ce, Je, xt, Mt, tt) {
      var bt = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: g,
        // Built-in properties that belong on the element
        type: _,
        key: ue,
        ref: ce,
        props: tt,
        // Record the component responsible for creating this element.
        _owner: Mt
      };
      return bt._store = {}, Object.defineProperty(bt._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: !1
      }), Object.defineProperty(bt, "_self", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: Je
      }), Object.defineProperty(bt, "_source", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: xt
      }), Object.freeze && (Object.freeze(bt.props), Object.freeze(bt)), bt;
    };
    function hr(_, ue, ce, Je, xt) {
      {
        var Mt, tt = {}, bt = null, Un = null;
        ce !== void 0 && (Er(ce), bt = "" + ce), Ct(ue) && (Er(ue.key), bt = "" + ue.key), Qe(ue) && (Un = ue.ref, $t(ue, xt));
        for (Mt in ue)
          Dn.call(ue, Mt) && !oa.hasOwnProperty(Mt) && (tt[Mt] = ue[Mt]);
        if (_ && _.defaultProps) {
          var tn = _.defaultProps;
          for (Mt in tn)
            tt[Mt] === void 0 && (tt[Mt] = tn[Mt]);
        }
        if (bt || Un) {
          var hn = typeof _ == "function" ? _.displayName || _.name || "Unknown" : _;
          bt && Pt(tt, hn), Un && On(tt, hn);
        }
        return yn(_, bt, Un, xt, Je, vn.current, tt);
      }
    }
    var Gt = ut.ReactCurrentOwner, Wn = ut.ReactDebugCurrentFrame;
    function It(_) {
      if (_) {
        var ue = _._owner, ce = Bn(_.type, _._source, ue ? ue.type : null);
        Wn.setExtraStackFrame(ce);
      } else
        Wn.setExtraStackFrame(null);
    }
    var ln;
    ln = !1;
    function Ka(_) {
      return typeof _ == "object" && _ !== null && _.$$typeof === g;
    }
    function ka() {
      {
        if (Gt.current) {
          var _ = ae(Gt.current.type);
          if (_)
            return `

Check the render method of \`` + _ + "`.";
        }
        return "";
      }
    }
    function yl(_) {
      return "";
    }
    var io = {};
    function lo(_) {
      {
        var ue = ka();
        if (!ue) {
          var ce = typeof _ == "string" ? _ : _.displayName || _.name;
          ce && (ue = `

Check the top-level render call using <` + ce + ">.");
        }
        return ue;
      }
    }
    function gl(_, ue) {
      {
        if (!_._store || _._store.validated || _.key != null)
          return;
        _._store.validated = !0;
        var ce = lo(ue);
        if (io[ce])
          return;
        io[ce] = !0;
        var Je = "";
        _ && _._owner && _._owner !== Gt.current && (Je = " It was passed a child from " + ae(_._owner.type) + "."), It(_), Ke('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', ce, Je), It(null);
      }
    }
    function qa(_, ue) {
      {
        if (typeof _ != "object")
          return;
        if (ia(_))
          for (var ce = 0; ce < _.length; ce++) {
            var Je = _[ce];
            Ka(Je) && gl(Je, ue);
          }
        else if (Ka(_))
          _._store && (_._store.validated = !0);
        else if (_) {
          var xt = Ye(_);
          if (typeof xt == "function" && xt !== _.entries)
            for (var Mt = xt.call(_), tt; !(tt = Mt.next()).done; )
              Ka(tt.value) && gl(tt.value, ue);
        }
      }
    }
    function Xa(_) {
      {
        var ue = _.type;
        if (ue == null || typeof ue == "string")
          return;
        var ce;
        if (typeof ue == "function")
          ce = ue.propTypes;
        else if (typeof ue == "object" && (ue.$$typeof === te || // Note: Memo only checks outer props here.
        // Inner props are checked in the reconciler.
        ue.$$typeof === A))
          ce = ue.propTypes;
        else
          return;
        if (ce) {
          var Je = ae(ue);
          Vn(ce, _.props, "prop", Je, _);
        } else if (ue.PropTypes !== void 0 && !ln) {
          ln = !0;
          var xt = ae(ue);
          Ke("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", xt || "Unknown");
        }
        typeof ue.getDefaultProps == "function" && !ue.getDefaultProps.isReactClassApproved && Ke("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
      }
    }
    function Da(_) {
      {
        for (var ue = Object.keys(_.props), ce = 0; ce < ue.length; ce++) {
          var Je = ue[ce];
          if (Je !== "children" && Je !== "key") {
            It(_), Ke("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", Je), It(null);
            break;
          }
        }
        _.ref !== null && (It(_), Ke("Invalid attribute `ref` supplied to `React.Fragment`."), It(null));
      }
    }
    var Ui = {};
    function Cr(_, ue, ce, Je, xt, Mt) {
      {
        var tt = Xe(_);
        if (!tt) {
          var bt = "";
          (_ === void 0 || typeof _ == "object" && _ !== null && Object.keys(_).length === 0) && (bt += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var Un = yl();
          Un ? bt += Un : bt += ka();
          var tn;
          _ === null ? tn = "null" : ia(_) ? tn = "array" : _ !== void 0 && _.$$typeof === g ? (tn = "<" + (ae(_.type) || "Unknown") + " />", bt = " Did you accidentally export a JSX literal instead of a component?") : tn = typeof _, Ke("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", tn, bt);
        }
        var hn = hr(_, ue, ce, xt, Mt);
        if (hn == null)
          return hn;
        if (tt) {
          var mr = ue.children;
          if (mr !== void 0)
            if (Je)
              if (ia(mr)) {
                for (var Yt = 0; Yt < mr.length; Yt++)
                  qa(mr[Yt], _);
                Object.freeze && Object.freeze(mr);
              } else
                Ke("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
            else
              qa(mr, _);
        }
        if (Dn.call(ue, "key")) {
          var Oa = ae(_), zn = Object.keys(ue).filter(function(Fi) {
            return Fi !== "key";
          }), Br = zn.length > 0 ? "{key: someKey, " + zn.join(": ..., ") + ": ...}" : "{key: someKey}";
          if (!Ui[Oa + Br]) {
            var yt = zn.length > 0 ? "{" + zn.join(": ..., ") + ": ...}" : "{}";
            Ke(`A props object containing a "key" prop is being spread into JSX:
  let props = %s;
  <%s {...props} />
React keys must be passed directly to JSX without using spread:
  let props = %s;
  <%s key={someKey} {...props} />`, Br, Oa, yt, Oa), Ui[Oa + Br] = !0;
          }
        }
        return _ === L ? Da(hn) : Xa(hn), hn;
      }
    }
    function Hr(_, ue, ce) {
      return Cr(_, ue, ce, !0);
    }
    function ca(_, ue, ce) {
      return Cr(_, ue, ce, !1);
    }
    var zi = ca, Sl = Hr;
    av.Fragment = L, av.jsx = zi, av.jsxs = Sl;
  }(), av;
}
var dD = {};
dD.NODE_ENV === "production" ? U0.exports = cD() : U0.exports = fD();
var ye = U0.exports;
const pD = (b) => {
  const { data: m } = b, [g, T] = re.useState(""), L = (U) => {
    T(U.target.value);
  };
  return /* @__PURE__ */ ye.jsx(ye.Fragment, { children: m ? /* @__PURE__ */ ye.jsxs(ye.Fragment, { children: [
    /* @__PURE__ */ ye.jsx("ul", { children: m.filter((U) => U.content.trim() !== "").map((U, x) => /* @__PURE__ */ ye.jsxs(
      "li",
      {
        className: "acms-admin-form-radio",
        style: { listStyle: "none", display: "block" },
        children: [
          /* @__PURE__ */ ye.jsx(
            "input",
            {
              id: `resultPromptRadio${x}`,
              name: "promptRadio",
              type: "radio",
              value: U.content,
              checked: g === U.content,
              onChange: L,
              "data-prompt-result": "radio"
            }
          ),
          /* @__PURE__ */ ye.jsxs("label", { htmlFor: `resultPromptRadio${x}`, children: [
            /* @__PURE__ */ ye.jsx("i", { className: "acms-admin-ico-radio" }),
            U.content
          ] })
        ]
      },
      x
    )) }),
    /* @__PURE__ */ ye.jsx(vD, { data: g })
  ] }) : null });
}, vD = (b) => {
  const { data: m } = b, [g, T] = re.useState(null);
  re.useEffect(() => {
    const U = document.querySelector("#entry-title");
    U && U.tagName.toLowerCase() === "input" && T(U);
  }, []);
  const L = (U) => {
    if (U.preventDefault(), g && g.tagName.toLowerCase() === "input") {
      g.value = m;
      const x = document.getElementById("entryForm");
      x && x.scrollIntoView({
        behavior: "smooth"
      });
    }
  };
  return /* @__PURE__ */ ye.jsx(
    "button",
    {
      type: "button",
      className: "acms-admin-btn acms-admin-inline-block",
      onClick: L,
      children: "適応"
    }
  );
}, H0 = async (b) => {
  const { url: m, data: g, exec: T, formToken: L } = b, U = new FormData();
  U.append("prompt", JSON.stringify(g.prompt)), U.append("mode", g.mode), U.append(T, "exec"), U.append("formToken", L);
  const x = await fetch(m, {
    method: "POST",
    body: U
  });
  return x.ok ? x.json() : null;
}, IT = {
  isPrompt: !0,
  status: "default",
  results: [],
  insertSelector: "",
  mode: ""
}, YT = re.createContext({
  prompt: IT,
  setIsPrompt: () => {
  },
  setStatus: () => {
  },
  setResults: () => {
  },
  addResult: () => {
  },
  putResult: () => null,
  setMode: () => {
  },
  setInsertSelector: () => {
  }
});
function hD({
  children: b,
  prompt: m = IT
}) {
  const [g, T] = re.useState(m), L = (A) => T((oe) => ({ ...oe, isPrompt: A })), U = (A) => T((oe) => ({ ...oe, status: A })), x = (A) => T((oe) => ({ ...oe, mode: A })), S = (A) => T((oe) => ({ ...oe, results: A })), ne = (A) => T((oe) => ({ ...oe, results: [...oe.results, A] })), te = (A) => {
    const oe = g.results.findIndex((q) => q.id === A.id);
    return oe >= 0 ? (T((q) => {
      const ve = [...q.results];
      return ve[oe] = {
        ...ve[oe],
        ...A
      }, { ...q, results: ve };
    }), A) : null;
  }, Q = (A) => T((oe) => ({ ...oe, insertSelector: A })), Z = re.useMemo(() => ({
    prompt: g,
    setIsPrompt: L,
    setStatus: U,
    setMode: x,
    setResults: S,
    addResult: ne,
    putResult: te,
    setInsertSelector: Q
  }), [
    g,
    L,
    U,
    x,
    S,
    ne,
    te,
    Q
  ]);
  return /* @__PURE__ */ ye.jsx(YT.Provider, { value: Z, children: b });
}
const B0 = () => re.useContext(YT), mD = (b) => b.scrollHeight > b.clientHeight || b.scrollWidth > b.clientWidth, WT = () => {
  const b = document.querySelectorAll(".entryFormLiteEditor");
  let m = "";
  return b.forEach((g) => {
    g.closest(".entryFormColumnItem-hidden") || (m += `${g.innerHTML}
`);
  }), m;
}, yD = (b) => b.split(","), gD = (b) => b.join(",");
function QT(...b) {
  const m = [];
  return b.forEach((g) => {
    g && (typeof g == "string" ? m.push(g) : Array.isArray(g) ? m.push(QT(...g)) : typeof g == "object" && Object.entries(g).forEach(([T, L]) => {
      L && m.push(T);
    }));
  }), m.join(" ").trim().replace(/\s+/g, " ");
}
const SD = (b) => {
  const { label: m = "ユニットからタイトルを生成" } = b, [g, T] = re.useState(m), { prompt: { results: L }, setStatus: U, addResult: x, putResult: S, setMode: ne } = B0(), te = re.useCallback(async () => {
    ne("createTitle"), U("loading");
    const A = WT(), oe = document.querySelector("[data-ai-title=prompt]"), ve = {
      mode: "createTitle",
      prompt: [
        {
          role: "user",
          content: `
            Think about the title for this article.

            condition:
            ${oe ? oe.value : `
    - Please give 5 suggestions.
    - Please answer in Japanese.
    `}

            article: """
            ${A}
            """
          `
        }
      ]
    };
    try {
      const Ae = await H0({
        url: window.ACMS.Config.root,
        data: ve,
        exec: "ACMS_POST_AI_Chat",
        formToken: window.csrfToken
      });
      return !Ae || Ae.errorCode && Ae.errorCode === 500 ? null : JSON.parse(Ae);
    } catch {
      return U("default"), null;
    }
  }, []), Q = re.useCallback(async () => {
    const A = await te();
    if (!A)
      return console.error("取得に失敗しました。"), null;
    if (!A[0].content)
      return console.error("生成に失敗しました。"), null;
    const oe = L.filter((q) => q.byMode === "createTitle");
    if (oe.length)
      S({
        id: oe[0].id,
        data: A,
        resultType: "radio",
        byMode: "createTitle"
      });
    else {
      const q = L.length > 0 ? Math.max(...L.map((ve) => ve.id)) + 1 : 1;
      x({
        id: q,
        data: A,
        resultType: "radio",
        byMode: "createTitle"
      }), T("再生成");
    }
    U("result");
  }, [
    te,
    L,
    S,
    x,
    U,
    T
  ]), Z = re.useCallback((A) => {
    A.preventDefault(), A.stopPropagation(), Q();
  }, [Q]);
  return /* @__PURE__ */ ye.jsx(
    "button",
    {
      type: "button",
      className: "acms-admin-btn acms-admin-inline-block",
      onClick: Z,
      children: g
    }
  );
}, ED = (b) => {
  const { addPrompt: m = void 0, label: g = "ユニットからタグを生成" } = b, [T, L] = re.useState(g), { prompt: { results: U }, setStatus: x, addResult: S, setMode: ne } = B0(), te = re.useCallback(async () => {
    ne("createTag"), x("loading");
    const A = WT(), oe = document.querySelector("[data-ai-tag=prompt]"), ve = {
      mode: "createTag",
      prompt: [
        {
          role: "user",
          content: `
            Consider the tags for this article.

            condition:
            ${oe ? oe.value : "Please answer in Japanese."}
            Please generate the linked tag without including the set tag.

            article: """
            ${A}
            """
            ${m && `

            Tags set: """
            ${m}
            """
            `}
          `
        }
      ]
    };
    try {
      const Ae = await H0({
        url: window.ACMS.Config.root,
        data: ve,
        exec: "ACMS_POST_AI_Chat",
        formToken: window.csrfToken
      });
      return Ae ? JSON.parse(Ae) : void 0;
    } catch {
      return x("default"), null;
    }
  }, []), Q = re.useCallback(async () => {
    const A = await te();
    if (!A)
      return console.error("取得に失敗しました。"), null;
    if (!A[0].content)
      return console.error("生成に失敗しました。"), null;
    const oe = U.filter((Ye) => Ye.byMode === "createTag"), q = oe.length;
    let ve = [];
    q > 0 && (ve = oe.reduce((Ye, ut) => [...Ye, ...ut.data], []));
    const Ae = A.filter((Ye) => !ve.includes(Ye.content));
    S({
      id: q + 1,
      data: Ae,
      resultType: "checkbox",
      byMode: "createTag"
    }), L("追加生成"), x("result");
  }, [
    te,
    U,
    S,
    x,
    L
  ]), Z = re.useCallback((A) => {
    A.preventDefault(), A.stopPropagation(), Q();
  }, [Q]);
  return /* @__PURE__ */ ye.jsx(
    "button",
    {
      type: "button",
      className: "acms-admin-btn acms-admin-inline-block",
      onClick: Z,
      children: T
    }
  );
}, GT = {
  ref: null,
  data: []
}, KT = re.createContext({
  entryTag: GT,
  addEntryTagRef: () => {
  },
  addEntryTagData: () => {
  },
  setEntryTagData: () => {
  },
  deleteEntryTagData: () => {
  }
});
function CD({
  children: b,
  entryTag: m = GT
}) {
  const g = re.useRef(null), [T, L] = re.useState(m), U = re.useCallback((Z) => L((A) => ({ ...A, ref: Z })), []), x = re.useCallback((Z) => L((A) => ({ ...A, data: [...A.data, Z] })), []), S = re.useCallback((Z) => L((A) => ({ ...A, data: Z })), []), ne = re.useCallback((Z) => L((A) => ({
    ...A,
    data: A.data.filter((oe) => oe !== Z)
  })), []);
  re.useEffect(() => {
    const Z = () => {
      const A = document.querySelector("#entry-tag-value");
      if (A) {
        g.current = A, U(g);
        const oe = new MutationObserver((q) => {
          q.forEach((ve) => {
            (ve.type === "attributes" || ve.type === "characterData" || A instanceof HTMLInputElement && ve.target === A) && U(g);
          });
        });
        return oe.observe(A, {
          attributes: !0,
          characterData: !0,
          childList: !0,
          subtree: !0,
          attributeFilter: ["value"]
        }), A.addEventListener("input", () => {
          U(g);
        }), oe;
      }
      return null;
    };
    if (document.readyState === "loading")
      document.addEventListener("DOMContentLoaded", () => {
        const A = Z();
        return () => A == null ? void 0 : A.disconnect();
      });
    else {
      const A = Z();
      return () => A == null ? void 0 : A.disconnect();
    }
    return () => {
      g.current = null;
    };
  }, []);
  const te = re.useCallback(() => {
    var A;
    const Z = gD(T.data);
    (A = T.ref) != null && A.current && T.ref.current instanceof HTMLInputElement && (T.ref.current.value = Z);
  }, [T.data, T.ref]);
  re.useEffect(() => {
    te();
  }, [te]);
  const Q = re.useMemo(() => ({
    entryTag: T,
    addEntryTagRef: U,
    addEntryTagData: x,
    setEntryTagData: S,
    deleteEntryTagData: ne
  }), [
    T,
    U,
    x,
    S,
    ne
  ]);
  return /* @__PURE__ */ ye.jsx(KT.Provider, { value: Q, children: b });
}
const qT = () => re.useContext(KT), bD = () => {
  const {
    entryTag: { ref: b },
    setEntryTagData: m
  } = qT(), g = re.useRef(!1);
  return re.useEffect(() => {
    if (b != null && b.current && !g.current) {
      const T = b.current.value;
      if (T) {
        const L = yD(T);
        m(L), g.current = !0;
      }
    }
  }, [b, m]), null;
}, TD = (b) => {
  const { props: { id: m, data: g } } = b, { entryTag: T, addEntryTagData: L, setEntryTagData: U } = qT(), x = (S) => {
    if (S.target.checked)
      L(S.target.value);
    else {
      const ne = T.data.filter((te) => te !== S.target.value);
      U(ne);
    }
  };
  return /* @__PURE__ */ ye.jsx(ye.Fragment, { children: g && /* @__PURE__ */ ye.jsx("ul", { children: g.filter((S) => S.content.trim() !== "").map((S, ne) => /* @__PURE__ */ ye.jsxs("li", { className: "acms-admin-form-checkbox", children: [
    /* @__PURE__ */ ye.jsx(
      "input",
      {
        id: `resultPromptCheckbox-${m}-${ne}`,
        type: "checkbox",
        value: S.content,
        onChange: x,
        "data-prompt-result": "createTag"
      }
    ),
    /* @__PURE__ */ ye.jsxs("label", { htmlFor: `resultPromptCheckbox-${m}-${ne}`, children: [
      /* @__PURE__ */ ye.jsx("i", { className: "acms-admin-ico-checkbox" }),
      S.content
    ] })
  ] }, ne)) }) });
}, RD = () => {
  const {
    prompt: {
      results: b,
      status: m,
      mode: g
    }
  } = B0();
  return /* @__PURE__ */ ye.jsx("table", { className: "entryFormTable acms-admin-table-entry acms-admin-table", children: /* @__PURE__ */ ye.jsxs("tbody", { children: [
    /* @__PURE__ */ ye.jsxs("tr", { children: [
      /* @__PURE__ */ ye.jsx("th", { children: "タイトル候補" }),
      /* @__PURE__ */ ye.jsxs("td", { children: [
        /* @__PURE__ */ ye.jsx(SD, {}),
        g === "createTitle" && m === "loading" && /* @__PURE__ */ ye.jsx("p", { children: "生成中" }),
        /* @__PURE__ */ ye.jsx(ye.Fragment, { children: b.map((T, L) => T.byMode === "createTitle" && /* @__PURE__ */ ye.jsx("div", { children: T.resultType === "radio" && /* @__PURE__ */ ye.jsx(pD, { ...T }) }, L)) })
      ] })
    ] }),
    /* @__PURE__ */ ye.jsxs("tr", { children: [
      /* @__PURE__ */ ye.jsx("th", { children: "タグ候補" }),
      /* @__PURE__ */ ye.jsxs("td", { children: [
        /* @__PURE__ */ ye.jsx(ED, {}),
        /* @__PURE__ */ ye.jsx(bD, {}),
        g === "createTag" && m === "loading" && /* @__PURE__ */ ye.jsx("p", { children: "生成中" }),
        /* @__PURE__ */ ye.jsx(ye.Fragment, { children: b.map((T, L) => T.byMode === "createTag" && /* @__PURE__ */ ye.jsx("div", { children: T.resultType === "checkbox" && /* @__PURE__ */ ye.jsx(TD, { props: T }) }, L)) })
      ] })
    ] })
  ] }) });
};
var F0 = { exports: {} }, Qa = {}, Km = { exports: {} }, M0 = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var OT;
function wD() {
  return OT || (OT = 1, function(b) {
    function m(I, ge) {
      var pe = I.length;
      I.push(ge);
      e: for (; 0 < pe; ) {
        var N = pe - 1 >>> 1, J = I[N];
        if (0 < L(J, ge)) I[N] = ge, I[pe] = J, pe = N;
        else break e;
      }
    }
    function g(I) {
      return I.length === 0 ? null : I[0];
    }
    function T(I) {
      if (I.length === 0) return null;
      var ge = I[0], pe = I.pop();
      if (pe !== ge) {
        I[0] = pe;
        e: for (var N = 0, J = I.length, Te = J >>> 1; N < Te; ) {
          var We = 2 * (N + 1) - 1, st = I[We], ft = We + 1, St = I[ft];
          if (0 > L(st, pe)) ft < J && 0 > L(St, st) ? (I[N] = St, I[ft] = pe, N = ft) : (I[N] = st, I[We] = pe, N = We);
          else if (ft < J && 0 > L(St, pe)) I[N] = St, I[ft] = pe, N = ft;
          else break e;
        }
      }
      return ge;
    }
    function L(I, ge) {
      var pe = I.sortIndex - ge.sortIndex;
      return pe !== 0 ? pe : I.id - ge.id;
    }
    if (typeof performance == "object" && typeof performance.now == "function") {
      var U = performance;
      b.unstable_now = function() {
        return U.now();
      };
    } else {
      var x = Date, S = x.now();
      b.unstable_now = function() {
        return x.now() - S;
      };
    }
    var ne = [], te = [], Q = 1, Z = null, A = 3, oe = !1, q = !1, ve = !1, Ae = typeof setTimeout == "function" ? setTimeout : null, Ye = typeof clearTimeout == "function" ? clearTimeout : null, ut = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
    function Ke(I) {
      for (var ge = g(te); ge !== null; ) {
        if (ge.callback === null) T(te);
        else if (ge.startTime <= I) T(te), ge.sortIndex = ge.expirationTime, m(ne, ge);
        else break;
        ge = g(te);
      }
    }
    function Ge(I) {
      if (ve = !1, Ke(I), !q) if (g(ne) !== null) q = !0, Ue(Rt);
      else {
        var ge = g(te);
        ge !== null && Le(Ge, ge.startTime - I);
      }
    }
    function Rt(I, ge) {
      q = !1, ve && (ve = !1, Ye(it), it = -1), oe = !0;
      var pe = A;
      try {
        for (Ke(ge), Z = g(ne); Z !== null && (!(Z.expirationTime > ge) || I && !Xe()); ) {
          var N = Z.callback;
          if (typeof N == "function") {
            Z.callback = null, A = Z.priorityLevel;
            var J = N(Z.expirationTime <= ge);
            ge = b.unstable_now(), typeof J == "function" ? Z.callback = J : Z === g(ne) && T(ne), Ke(ge);
          } else T(ne);
          Z = g(ne);
        }
        if (Z !== null) var Te = !0;
        else {
          var We = g(te);
          We !== null && Le(Ge, We.startTime - ge), Te = !1;
        }
        return Te;
      } finally {
        Z = null, A = pe, oe = !1;
      }
    }
    var Ne = !1, lt = null, it = -1, Jt = 5, jt = -1;
    function Xe() {
      return !(b.unstable_now() - jt < Jt);
    }
    function W() {
      if (lt !== null) {
        var I = b.unstable_now();
        jt = I;
        var ge = !0;
        try {
          ge = lt(!0, I);
        } finally {
          ge ? X() : (Ne = !1, lt = null);
        }
      } else Ne = !1;
    }
    var X;
    if (typeof ut == "function") X = function() {
      ut(W);
    };
    else if (typeof MessageChannel < "u") {
      var ae = new MessageChannel(), we = ae.port2;
      ae.port1.onmessage = W, X = function() {
        we.postMessage(null);
      };
    } else X = function() {
      Ae(W, 0);
    };
    function Ue(I) {
      lt = I, Ne || (Ne = !0, X());
    }
    function Le(I, ge) {
      it = Ae(function() {
        I(b.unstable_now());
      }, ge);
    }
    b.unstable_IdlePriority = 5, b.unstable_ImmediatePriority = 1, b.unstable_LowPriority = 4, b.unstable_NormalPriority = 3, b.unstable_Profiling = null, b.unstable_UserBlockingPriority = 2, b.unstable_cancelCallback = function(I) {
      I.callback = null;
    }, b.unstable_continueExecution = function() {
      q || oe || (q = !0, Ue(Rt));
    }, b.unstable_forceFrameRate = function(I) {
      0 > I || 125 < I ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : Jt = 0 < I ? Math.floor(1e3 / I) : 5;
    }, b.unstable_getCurrentPriorityLevel = function() {
      return A;
    }, b.unstable_getFirstCallbackNode = function() {
      return g(ne);
    }, b.unstable_next = function(I) {
      switch (A) {
        case 1:
        case 2:
        case 3:
          var ge = 3;
          break;
        default:
          ge = A;
      }
      var pe = A;
      A = ge;
      try {
        return I();
      } finally {
        A = pe;
      }
    }, b.unstable_pauseExecution = function() {
    }, b.unstable_requestPaint = function() {
    }, b.unstable_runWithPriority = function(I, ge) {
      switch (I) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          I = 3;
      }
      var pe = A;
      A = I;
      try {
        return ge();
      } finally {
        A = pe;
      }
    }, b.unstable_scheduleCallback = function(I, ge, pe) {
      var N = b.unstable_now();
      switch (typeof pe == "object" && pe !== null ? (pe = pe.delay, pe = typeof pe == "number" && 0 < pe ? N + pe : N) : pe = N, I) {
        case 1:
          var J = -1;
          break;
        case 2:
          J = 250;
          break;
        case 5:
          J = 1073741823;
          break;
        case 4:
          J = 1e4;
          break;
        default:
          J = 5e3;
      }
      return J = pe + J, I = { id: Q++, callback: ge, priorityLevel: I, startTime: pe, expirationTime: J, sortIndex: -1 }, pe > N ? (I.sortIndex = pe, m(te, I), g(ne) === null && I === g(te) && (ve ? (Ye(it), it = -1) : ve = !0, Le(Ge, pe - N))) : (I.sortIndex = J, m(ne, I), q || oe || (q = !0, Ue(Rt))), I;
    }, b.unstable_shouldYield = Xe, b.unstable_wrapCallback = function(I) {
      var ge = A;
      return function() {
        var pe = A;
        A = ge;
        try {
          return I.apply(this, arguments);
        } finally {
          A = pe;
        }
      };
    };
  }(M0)), M0;
}
var N0 = {}, MT;
function xD() {
  return MT || (MT = 1, function(b) {
    var m = {};
    /**
     * @license React
     * scheduler.development.js
     *
     * Copyright (c) Facebook, Inc. and its affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    m.NODE_ENV !== "production" && function() {
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
      var g = !1, T = !1, L = 5;
      function U(Ee, Qe) {
        var Ct = Ee.length;
        Ee.push(Qe), ne(Ee, Qe, Ct);
      }
      function x(Ee) {
        return Ee.length === 0 ? null : Ee[0];
      }
      function S(Ee) {
        if (Ee.length === 0)
          return null;
        var Qe = Ee[0], Ct = Ee.pop();
        return Ct !== Qe && (Ee[0] = Ct, te(Ee, Ct, 0)), Qe;
      }
      function ne(Ee, Qe, Ct) {
        for (var $t = Ct; $t > 0; ) {
          var Pt = $t - 1 >>> 1, On = Ee[Pt];
          if (Q(On, Qe) > 0)
            Ee[Pt] = Qe, Ee[$t] = On, $t = Pt;
          else
            return;
        }
      }
      function te(Ee, Qe, Ct) {
        for (var $t = Ct, Pt = Ee.length, On = Pt >>> 1; $t < On; ) {
          var yn = ($t + 1) * 2 - 1, hr = Ee[yn], Gt = yn + 1, Wn = Ee[Gt];
          if (Q(hr, Qe) < 0)
            Gt < Pt && Q(Wn, hr) < 0 ? (Ee[$t] = Wn, Ee[Gt] = Qe, $t = Gt) : (Ee[$t] = hr, Ee[yn] = Qe, $t = yn);
          else if (Gt < Pt && Q(Wn, Qe) < 0)
            Ee[$t] = Wn, Ee[Gt] = Qe, $t = Gt;
          else
            return;
        }
      }
      function Q(Ee, Qe) {
        var Ct = Ee.sortIndex - Qe.sortIndex;
        return Ct !== 0 ? Ct : Ee.id - Qe.id;
      }
      var Z = 1, A = 2, oe = 3, q = 4, ve = 5;
      function Ae(Ee, Qe) {
      }
      var Ye = typeof performance == "object" && typeof performance.now == "function";
      if (Ye) {
        var ut = performance;
        b.unstable_now = function() {
          return ut.now();
        };
      } else {
        var Ke = Date, Ge = Ke.now();
        b.unstable_now = function() {
          return Ke.now() - Ge;
        };
      }
      var Rt = 1073741823, Ne = -1, lt = 250, it = 5e3, Jt = 1e4, jt = Rt, Xe = [], W = [], X = 1, ae = null, we = oe, Ue = !1, Le = !1, I = !1, ge = typeof setTimeout == "function" ? setTimeout : null, pe = typeof clearTimeout == "function" ? clearTimeout : null, N = typeof setImmediate < "u" ? setImmediate : null;
      typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
      function J(Ee) {
        for (var Qe = x(W); Qe !== null; ) {
          if (Qe.callback === null)
            S(W);
          else if (Qe.startTime <= Ee)
            S(W), Qe.sortIndex = Qe.expirationTime, U(Xe, Qe);
          else
            return;
          Qe = x(W);
        }
      }
      function Te(Ee) {
        if (I = !1, J(Ee), !Le)
          if (x(Xe) !== null)
            Le = !0, Er(We);
          else {
            var Qe = x(W);
            Qe !== null && vn(Te, Qe.startTime - Ee);
          }
      }
      function We(Ee, Qe) {
        Le = !1, I && (I = !1, oa()), Ue = !0;
        var Ct = we;
        try {
          var $t;
          if (!T) return st(Ee, Qe);
        } finally {
          ae = null, we = Ct, Ue = !1;
        }
      }
      function st(Ee, Qe) {
        var Ct = Qe;
        for (J(Ct), ae = x(Xe); ae !== null && !g && !(ae.expirationTime > Ct && (!Ee || pr())); ) {
          var $t = ae.callback;
          if (typeof $t == "function") {
            ae.callback = null, we = ae.priorityLevel;
            var Pt = ae.expirationTime <= Ct, On = $t(Pt);
            Ct = b.unstable_now(), typeof On == "function" ? ae.callback = On : ae === x(Xe) && S(Xe), J(Ct);
          } else
            S(Xe);
          ae = x(Xe);
        }
        if (ae !== null)
          return !0;
        var yn = x(W);
        return yn !== null && vn(Te, yn.startTime - Ct), !1;
      }
      function ft(Ee, Qe) {
        switch (Ee) {
          case Z:
          case A:
          case oe:
          case q:
          case ve:
            break;
          default:
            Ee = oe;
        }
        var Ct = we;
        we = Ee;
        try {
          return Qe();
        } finally {
          we = Ct;
        }
      }
      function St(Ee) {
        var Qe;
        switch (we) {
          case Z:
          case A:
          case oe:
            Qe = oe;
            break;
          default:
            Qe = we;
            break;
        }
        var Ct = we;
        we = Qe;
        try {
          return Ee();
        } finally {
          we = Ct;
        }
      }
      function Et(Ee) {
        var Qe = we;
        return function() {
          var Ct = we;
          we = Qe;
          try {
            return Ee.apply(this, arguments);
          } finally {
            we = Ct;
          }
        };
      }
      function nt(Ee, Qe, Ct) {
        var $t = b.unstable_now(), Pt;
        if (typeof Ct == "object" && Ct !== null) {
          var On = Ct.delay;
          typeof On == "number" && On > 0 ? Pt = $t + On : Pt = $t;
        } else
          Pt = $t;
        var yn;
        switch (Ee) {
          case Z:
            yn = Ne;
            break;
          case A:
            yn = lt;
            break;
          case ve:
            yn = jt;
            break;
          case q:
            yn = Jt;
            break;
          case oe:
          default:
            yn = it;
            break;
        }
        var hr = Pt + yn, Gt = {
          id: X++,
          callback: Qe,
          priorityLevel: Ee,
          startTime: Pt,
          expirationTime: hr,
          sortIndex: -1
        };
        return Pt > $t ? (Gt.sortIndex = Pt, U(W, Gt), x(Xe) === null && Gt === x(W) && (I ? oa() : I = !0, vn(Te, Pt - $t))) : (Gt.sortIndex = hr, U(Xe, Gt), !Le && !Ue && (Le = !0, Er(We))), Gt;
      }
      function wt() {
      }
      function kn() {
        !Le && !Ue && (Le = !0, Er(We));
      }
      function Pr() {
        return x(Xe);
      }
      function dr(Ee) {
        Ee.callback = null;
      }
      function bn() {
        return we;
      }
      var Jn = !1, Bn = null, Dn = -1, An = L, Sr = -1;
      function pr() {
        var Ee = b.unstable_now() - Sr;
        return !(Ee < An);
      }
      function Vn() {
      }
      function aa(Ee) {
        if (Ee < 0 || Ee > 125) {
          console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported");
          return;
        }
        Ee > 0 ? An = Math.floor(1e3 / Ee) : An = L;
      }
      var ia = function() {
        if (Bn !== null) {
          var Ee = b.unstable_now();
          Sr = Ee;
          var Qe = !0, Ct = !0;
          try {
            Ct = Bn(Qe, Ee);
          } finally {
            Ct ? vr() : (Jn = !1, Bn = null);
          }
        } else
          Jn = !1;
      }, vr;
      if (typeof N == "function")
        vr = function() {
          N(ia);
        };
      else if (typeof MessageChannel < "u") {
        var la = new MessageChannel(), Zn = la.port2;
        la.port1.onmessage = ia, vr = function() {
          Zn.postMessage(null);
        };
      } else
        vr = function() {
          ge(ia, 0);
        };
      function Er(Ee) {
        Bn = Ee, Jn || (Jn = !0, vr());
      }
      function vn(Ee, Qe) {
        Dn = ge(function() {
          Ee(b.unstable_now());
        }, Qe);
      }
      function oa() {
        pe(Dn), Dn = -1;
      }
      var ua = Vn, sa = null;
      b.unstable_IdlePriority = ve, b.unstable_ImmediatePriority = Z, b.unstable_LowPriority = q, b.unstable_NormalPriority = oe, b.unstable_Profiling = sa, b.unstable_UserBlockingPriority = A, b.unstable_cancelCallback = dr, b.unstable_continueExecution = kn, b.unstable_forceFrameRate = aa, b.unstable_getCurrentPriorityLevel = bn, b.unstable_getFirstCallbackNode = Pr, b.unstable_next = St, b.unstable_pauseExecution = wt, b.unstable_requestPaint = ua, b.unstable_runWithPriority = ft, b.unstable_scheduleCallback = nt, b.unstable_shouldYield = pr, b.unstable_wrapCallback = Et, typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
    }();
  }(N0)), N0;
}
var NT;
function XT() {
  if (NT) return Km.exports;
  NT = 1;
  var b = {};
  return b.NODE_ENV === "production" ? Km.exports = wD() : Km.exports = xD(), Km.exports;
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var LT;
function _D() {
  if (LT) return Qa;
  LT = 1;
  var b = re, m = XT();
  function g(n) {
    for (var r = "https://reactjs.org/docs/error-decoder.html?invariant=" + n, l = 1; l < arguments.length; l++) r += "&args[]=" + encodeURIComponent(arguments[l]);
    return "Minified React error #" + n + "; visit " + r + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  var T = /* @__PURE__ */ new Set(), L = {};
  function U(n, r) {
    x(n, r), x(n + "Capture", r);
  }
  function x(n, r) {
    for (L[n] = r, n = 0; n < r.length; n++) T.add(r[n]);
  }
  var S = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), ne = Object.prototype.hasOwnProperty, te = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, Q = {}, Z = {};
  function A(n) {
    return ne.call(Z, n) ? !0 : ne.call(Q, n) ? !1 : te.test(n) ? Z[n] = !0 : (Q[n] = !0, !1);
  }
  function oe(n, r, l, u) {
    if (l !== null && l.type === 0) return !1;
    switch (typeof r) {
      case "function":
      case "symbol":
        return !0;
      case "boolean":
        return u ? !1 : l !== null ? !l.acceptsBooleans : (n = n.toLowerCase().slice(0, 5), n !== "data-" && n !== "aria-");
      default:
        return !1;
    }
  }
  function q(n, r, l, u) {
    if (r === null || typeof r > "u" || oe(n, r, l, u)) return !0;
    if (u) return !1;
    if (l !== null) switch (l.type) {
      case 3:
        return !r;
      case 4:
        return r === !1;
      case 5:
        return isNaN(r);
      case 6:
        return isNaN(r) || 1 > r;
    }
    return !1;
  }
  function ve(n, r, l, u, c, d, y) {
    this.acceptsBooleans = r === 2 || r === 3 || r === 4, this.attributeName = u, this.attributeNamespace = c, this.mustUseProperty = l, this.propertyName = n, this.type = r, this.sanitizeURL = d, this.removeEmptyString = y;
  }
  var Ae = {};
  "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(n) {
    Ae[n] = new ve(n, 0, !1, n, null, !1, !1);
  }), [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(n) {
    var r = n[0];
    Ae[r] = new ve(r, 1, !1, n[1], null, !1, !1);
  }), ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(n) {
    Ae[n] = new ve(n, 2, !1, n.toLowerCase(), null, !1, !1);
  }), ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(n) {
    Ae[n] = new ve(n, 2, !1, n, null, !1, !1);
  }), "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(n) {
    Ae[n] = new ve(n, 3, !1, n.toLowerCase(), null, !1, !1);
  }), ["checked", "multiple", "muted", "selected"].forEach(function(n) {
    Ae[n] = new ve(n, 3, !0, n, null, !1, !1);
  }), ["capture", "download"].forEach(function(n) {
    Ae[n] = new ve(n, 4, !1, n, null, !1, !1);
  }), ["cols", "rows", "size", "span"].forEach(function(n) {
    Ae[n] = new ve(n, 6, !1, n, null, !1, !1);
  }), ["rowSpan", "start"].forEach(function(n) {
    Ae[n] = new ve(n, 5, !1, n.toLowerCase(), null, !1, !1);
  });
  var Ye = /[\-:]([a-z])/g;
  function ut(n) {
    return n[1].toUpperCase();
  }
  "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(n) {
    var r = n.replace(
      Ye,
      ut
    );
    Ae[r] = new ve(r, 1, !1, n, null, !1, !1);
  }), "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(n) {
    var r = n.replace(Ye, ut);
    Ae[r] = new ve(r, 1, !1, n, "http://www.w3.org/1999/xlink", !1, !1);
  }), ["xml:base", "xml:lang", "xml:space"].forEach(function(n) {
    var r = n.replace(Ye, ut);
    Ae[r] = new ve(r, 1, !1, n, "http://www.w3.org/XML/1998/namespace", !1, !1);
  }), ["tabIndex", "crossOrigin"].forEach(function(n) {
    Ae[n] = new ve(n, 1, !1, n.toLowerCase(), null, !1, !1);
  }), Ae.xlinkHref = new ve("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1), ["src", "href", "action", "formAction"].forEach(function(n) {
    Ae[n] = new ve(n, 1, !1, n.toLowerCase(), null, !0, !0);
  });
  function Ke(n, r, l, u) {
    var c = Ae.hasOwnProperty(r) ? Ae[r] : null;
    (c !== null ? c.type !== 0 : u || !(2 < r.length) || r[0] !== "o" && r[0] !== "O" || r[1] !== "n" && r[1] !== "N") && (q(r, l, c, u) && (l = null), u || c === null ? A(r) && (l === null ? n.removeAttribute(r) : n.setAttribute(r, "" + l)) : c.mustUseProperty ? n[c.propertyName] = l === null ? c.type === 3 ? !1 : "" : l : (r = c.attributeName, u = c.attributeNamespace, l === null ? n.removeAttribute(r) : (c = c.type, l = c === 3 || c === 4 && l === !0 ? "" : "" + l, u ? n.setAttributeNS(u, r, l) : n.setAttribute(r, l))));
  }
  var Ge = b.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, Rt = Symbol.for("react.element"), Ne = Symbol.for("react.portal"), lt = Symbol.for("react.fragment"), it = Symbol.for("react.strict_mode"), Jt = Symbol.for("react.profiler"), jt = Symbol.for("react.provider"), Xe = Symbol.for("react.context"), W = Symbol.for("react.forward_ref"), X = Symbol.for("react.suspense"), ae = Symbol.for("react.suspense_list"), we = Symbol.for("react.memo"), Ue = Symbol.for("react.lazy"), Le = Symbol.for("react.offscreen"), I = Symbol.iterator;
  function ge(n) {
    return n === null || typeof n != "object" ? null : (n = I && n[I] || n["@@iterator"], typeof n == "function" ? n : null);
  }
  var pe = Object.assign, N;
  function J(n) {
    if (N === void 0) try {
      throw Error();
    } catch (l) {
      var r = l.stack.trim().match(/\n( *(at )?)/);
      N = r && r[1] || "";
    }
    return `
` + N + n;
  }
  var Te = !1;
  function We(n, r) {
    if (!n || Te) return "";
    Te = !0;
    var l = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (r) if (r = function() {
        throw Error();
      }, Object.defineProperty(r.prototype, "props", { set: function() {
        throw Error();
      } }), typeof Reflect == "object" && Reflect.construct) {
        try {
          Reflect.construct(r, []);
        } catch (V) {
          var u = V;
        }
        Reflect.construct(n, [], r);
      } else {
        try {
          r.call();
        } catch (V) {
          u = V;
        }
        n.call(r.prototype);
      }
      else {
        try {
          throw Error();
        } catch (V) {
          u = V;
        }
        n();
      }
    } catch (V) {
      if (V && u && typeof V.stack == "string") {
        for (var c = V.stack.split(`
`), d = u.stack.split(`
`), y = c.length - 1, R = d.length - 1; 1 <= y && 0 <= R && c[y] !== d[R]; ) R--;
        for (; 1 <= y && 0 <= R; y--, R--) if (c[y] !== d[R]) {
          if (y !== 1 || R !== 1)
            do
              if (y--, R--, 0 > R || c[y] !== d[R]) {
                var k = `
` + c[y].replace(" at new ", " at ");
                return n.displayName && k.includes("<anonymous>") && (k = k.replace("<anonymous>", n.displayName)), k;
              }
            while (1 <= y && 0 <= R);
          break;
        }
      }
    } finally {
      Te = !1, Error.prepareStackTrace = l;
    }
    return (n = n ? n.displayName || n.name : "") ? J(n) : "";
  }
  function st(n) {
    switch (n.tag) {
      case 5:
        return J(n.type);
      case 16:
        return J("Lazy");
      case 13:
        return J("Suspense");
      case 19:
        return J("SuspenseList");
      case 0:
      case 2:
      case 15:
        return n = We(n.type, !1), n;
      case 11:
        return n = We(n.type.render, !1), n;
      case 1:
        return n = We(n.type, !0), n;
      default:
        return "";
    }
  }
  function ft(n) {
    if (n == null) return null;
    if (typeof n == "function") return n.displayName || n.name || null;
    if (typeof n == "string") return n;
    switch (n) {
      case lt:
        return "Fragment";
      case Ne:
        return "Portal";
      case Jt:
        return "Profiler";
      case it:
        return "StrictMode";
      case X:
        return "Suspense";
      case ae:
        return "SuspenseList";
    }
    if (typeof n == "object") switch (n.$$typeof) {
      case Xe:
        return (n.displayName || "Context") + ".Consumer";
      case jt:
        return (n._context.displayName || "Context") + ".Provider";
      case W:
        var r = n.render;
        return n = n.displayName, n || (n = r.displayName || r.name || "", n = n !== "" ? "ForwardRef(" + n + ")" : "ForwardRef"), n;
      case we:
        return r = n.displayName || null, r !== null ? r : ft(n.type) || "Memo";
      case Ue:
        r = n._payload, n = n._init;
        try {
          return ft(n(r));
        } catch {
        }
    }
    return null;
  }
  function St(n) {
    var r = n.type;
    switch (n.tag) {
      case 24:
        return "Cache";
      case 9:
        return (r.displayName || "Context") + ".Consumer";
      case 10:
        return (r._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return n = r.render, n = n.displayName || n.name || "", r.displayName || (n !== "" ? "ForwardRef(" + n + ")" : "ForwardRef");
      case 7:
        return "Fragment";
      case 5:
        return r;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return ft(r);
      case 8:
        return r === it ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if (typeof r == "function") return r.displayName || r.name || null;
        if (typeof r == "string") return r;
    }
    return null;
  }
  function Et(n) {
    switch (typeof n) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return n;
      case "object":
        return n;
      default:
        return "";
    }
  }
  function nt(n) {
    var r = n.type;
    return (n = n.nodeName) && n.toLowerCase() === "input" && (r === "checkbox" || r === "radio");
  }
  function wt(n) {
    var r = nt(n) ? "checked" : "value", l = Object.getOwnPropertyDescriptor(n.constructor.prototype, r), u = "" + n[r];
    if (!n.hasOwnProperty(r) && typeof l < "u" && typeof l.get == "function" && typeof l.set == "function") {
      var c = l.get, d = l.set;
      return Object.defineProperty(n, r, { configurable: !0, get: function() {
        return c.call(this);
      }, set: function(y) {
        u = "" + y, d.call(this, y);
      } }), Object.defineProperty(n, r, { enumerable: l.enumerable }), { getValue: function() {
        return u;
      }, setValue: function(y) {
        u = "" + y;
      }, stopTracking: function() {
        n._valueTracker = null, delete n[r];
      } };
    }
  }
  function kn(n) {
    n._valueTracker || (n._valueTracker = wt(n));
  }
  function Pr(n) {
    if (!n) return !1;
    var r = n._valueTracker;
    if (!r) return !0;
    var l = r.getValue(), u = "";
    return n && (u = nt(n) ? n.checked ? "true" : "false" : n.value), n = u, n !== l ? (r.setValue(n), !0) : !1;
  }
  function dr(n) {
    if (n = n || (typeof document < "u" ? document : void 0), typeof n > "u") return null;
    try {
      return n.activeElement || n.body;
    } catch {
      return n.body;
    }
  }
  function bn(n, r) {
    var l = r.checked;
    return pe({}, r, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: l ?? n._wrapperState.initialChecked });
  }
  function Jn(n, r) {
    var l = r.defaultValue == null ? "" : r.defaultValue, u = r.checked != null ? r.checked : r.defaultChecked;
    l = Et(r.value != null ? r.value : l), n._wrapperState = { initialChecked: u, initialValue: l, controlled: r.type === "checkbox" || r.type === "radio" ? r.checked != null : r.value != null };
  }
  function Bn(n, r) {
    r = r.checked, r != null && Ke(n, "checked", r, !1);
  }
  function Dn(n, r) {
    Bn(n, r);
    var l = Et(r.value), u = r.type;
    if (l != null) u === "number" ? (l === 0 && n.value === "" || n.value != l) && (n.value = "" + l) : n.value !== "" + l && (n.value = "" + l);
    else if (u === "submit" || u === "reset") {
      n.removeAttribute("value");
      return;
    }
    r.hasOwnProperty("value") ? Sr(n, r.type, l) : r.hasOwnProperty("defaultValue") && Sr(n, r.type, Et(r.defaultValue)), r.checked == null && r.defaultChecked != null && (n.defaultChecked = !!r.defaultChecked);
  }
  function An(n, r, l) {
    if (r.hasOwnProperty("value") || r.hasOwnProperty("defaultValue")) {
      var u = r.type;
      if (!(u !== "submit" && u !== "reset" || r.value !== void 0 && r.value !== null)) return;
      r = "" + n._wrapperState.initialValue, l || r === n.value || (n.value = r), n.defaultValue = r;
    }
    l = n.name, l !== "" && (n.name = ""), n.defaultChecked = !!n._wrapperState.initialChecked, l !== "" && (n.name = l);
  }
  function Sr(n, r, l) {
    (r !== "number" || dr(n.ownerDocument) !== n) && (l == null ? n.defaultValue = "" + n._wrapperState.initialValue : n.defaultValue !== "" + l && (n.defaultValue = "" + l));
  }
  var pr = Array.isArray;
  function Vn(n, r, l, u) {
    if (n = n.options, r) {
      r = {};
      for (var c = 0; c < l.length; c++) r["$" + l[c]] = !0;
      for (l = 0; l < n.length; l++) c = r.hasOwnProperty("$" + n[l].value), n[l].selected !== c && (n[l].selected = c), c && u && (n[l].defaultSelected = !0);
    } else {
      for (l = "" + Et(l), r = null, c = 0; c < n.length; c++) {
        if (n[c].value === l) {
          n[c].selected = !0, u && (n[c].defaultSelected = !0);
          return;
        }
        r !== null || n[c].disabled || (r = n[c]);
      }
      r !== null && (r.selected = !0);
    }
  }
  function aa(n, r) {
    if (r.dangerouslySetInnerHTML != null) throw Error(g(91));
    return pe({}, r, { value: void 0, defaultValue: void 0, children: "" + n._wrapperState.initialValue });
  }
  function ia(n, r) {
    var l = r.value;
    if (l == null) {
      if (l = r.children, r = r.defaultValue, l != null) {
        if (r != null) throw Error(g(92));
        if (pr(l)) {
          if (1 < l.length) throw Error(g(93));
          l = l[0];
        }
        r = l;
      }
      r == null && (r = ""), l = r;
    }
    n._wrapperState = { initialValue: Et(l) };
  }
  function vr(n, r) {
    var l = Et(r.value), u = Et(r.defaultValue);
    l != null && (l = "" + l, l !== n.value && (n.value = l), r.defaultValue == null && n.defaultValue !== l && (n.defaultValue = l)), u != null && (n.defaultValue = "" + u);
  }
  function la(n) {
    var r = n.textContent;
    r === n._wrapperState.initialValue && r !== "" && r !== null && (n.value = r);
  }
  function Zn(n) {
    switch (n) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function Er(n, r) {
    return n == null || n === "http://www.w3.org/1999/xhtml" ? Zn(r) : n === "http://www.w3.org/2000/svg" && r === "foreignObject" ? "http://www.w3.org/1999/xhtml" : n;
  }
  var vn, oa = function(n) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(r, l, u, c) {
      MSApp.execUnsafeLocalFunction(function() {
        return n(r, l, u, c);
      });
    } : n;
  }(function(n, r) {
    if (n.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in n) n.innerHTML = r;
    else {
      for (vn = vn || document.createElement("div"), vn.innerHTML = "<svg>" + r.valueOf().toString() + "</svg>", r = vn.firstChild; n.firstChild; ) n.removeChild(n.firstChild);
      for (; r.firstChild; ) n.appendChild(r.firstChild);
    }
  });
  function ua(n, r) {
    if (r) {
      var l = n.firstChild;
      if (l && l === n.lastChild && l.nodeType === 3) {
        l.nodeValue = r;
        return;
      }
    }
    n.textContent = r;
  }
  var sa = {
    animationIterationCount: !0,
    aspectRatio: !0,
    borderImageOutset: !0,
    borderImageSlice: !0,
    borderImageWidth: !0,
    boxFlex: !0,
    boxFlexGroup: !0,
    boxOrdinalGroup: !0,
    columnCount: !0,
    columns: !0,
    flex: !0,
    flexGrow: !0,
    flexPositive: !0,
    flexShrink: !0,
    flexNegative: !0,
    flexOrder: !0,
    gridArea: !0,
    gridRow: !0,
    gridRowEnd: !0,
    gridRowSpan: !0,
    gridRowStart: !0,
    gridColumn: !0,
    gridColumnEnd: !0,
    gridColumnSpan: !0,
    gridColumnStart: !0,
    fontWeight: !0,
    lineClamp: !0,
    lineHeight: !0,
    opacity: !0,
    order: !0,
    orphans: !0,
    tabSize: !0,
    widows: !0,
    zIndex: !0,
    zoom: !0,
    fillOpacity: !0,
    floodOpacity: !0,
    stopOpacity: !0,
    strokeDasharray: !0,
    strokeDashoffset: !0,
    strokeMiterlimit: !0,
    strokeOpacity: !0,
    strokeWidth: !0
  }, Ee = ["Webkit", "ms", "Moz", "O"];
  Object.keys(sa).forEach(function(n) {
    Ee.forEach(function(r) {
      r = r + n.charAt(0).toUpperCase() + n.substring(1), sa[r] = sa[n];
    });
  });
  function Qe(n, r, l) {
    return r == null || typeof r == "boolean" || r === "" ? "" : l || typeof r != "number" || r === 0 || sa.hasOwnProperty(n) && sa[n] ? ("" + r).trim() : r + "px";
  }
  function Ct(n, r) {
    n = n.style;
    for (var l in r) if (r.hasOwnProperty(l)) {
      var u = l.indexOf("--") === 0, c = Qe(l, r[l], u);
      l === "float" && (l = "cssFloat"), u ? n.setProperty(l, c) : n[l] = c;
    }
  }
  var $t = pe({ menuitem: !0 }, { area: !0, base: !0, br: !0, col: !0, embed: !0, hr: !0, img: !0, input: !0, keygen: !0, link: !0, meta: !0, param: !0, source: !0, track: !0, wbr: !0 });
  function Pt(n, r) {
    if (r) {
      if ($t[n] && (r.children != null || r.dangerouslySetInnerHTML != null)) throw Error(g(137, n));
      if (r.dangerouslySetInnerHTML != null) {
        if (r.children != null) throw Error(g(60));
        if (typeof r.dangerouslySetInnerHTML != "object" || !("__html" in r.dangerouslySetInnerHTML)) throw Error(g(61));
      }
      if (r.style != null && typeof r.style != "object") throw Error(g(62));
    }
  }
  function On(n, r) {
    if (n.indexOf("-") === -1) return typeof r.is == "string";
    switch (n) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var yn = null;
  function hr(n) {
    return n = n.target || n.srcElement || window, n.correspondingUseElement && (n = n.correspondingUseElement), n.nodeType === 3 ? n.parentNode : n;
  }
  var Gt = null, Wn = null, It = null;
  function ln(n) {
    if (n = mi(n)) {
      if (typeof Gt != "function") throw Error(g(280));
      var r = n.stateNode;
      r && (r = Oc(r), Gt(n.stateNode, n.type, r));
    }
  }
  function Ka(n) {
    Wn ? It ? It.push(n) : It = [n] : Wn = n;
  }
  function ka() {
    if (Wn) {
      var n = Wn, r = It;
      if (It = Wn = null, ln(n), r) for (n = 0; n < r.length; n++) ln(r[n]);
    }
  }
  function yl(n, r) {
    return n(r);
  }
  function io() {
  }
  var lo = !1;
  function gl(n, r, l) {
    if (lo) return n(r, l);
    lo = !0;
    try {
      return yl(n, r, l);
    } finally {
      lo = !1, (Wn !== null || It !== null) && (io(), ka());
    }
  }
  function qa(n, r) {
    var l = n.stateNode;
    if (l === null) return null;
    var u = Oc(l);
    if (u === null) return null;
    l = u[r];
    e: switch (r) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (u = !u.disabled) || (n = n.type, u = !(n === "button" || n === "input" || n === "select" || n === "textarea")), n = !u;
        break e;
      default:
        n = !1;
    }
    if (n) return null;
    if (l && typeof l != "function") throw Error(g(231, r, typeof l));
    return l;
  }
  var Xa = !1;
  if (S) try {
    var Da = {};
    Object.defineProperty(Da, "passive", { get: function() {
      Xa = !0;
    } }), window.addEventListener("test", Da, Da), window.removeEventListener("test", Da, Da);
  } catch {
    Xa = !1;
  }
  function Ui(n, r, l, u, c, d, y, R, k) {
    var V = Array.prototype.slice.call(arguments, 3);
    try {
      r.apply(l, V);
    } catch (se) {
      this.onError(se);
    }
  }
  var Cr = !1, Hr = null, ca = !1, zi = null, Sl = { onError: function(n) {
    Cr = !0, Hr = n;
  } };
  function _(n, r, l, u, c, d, y, R, k) {
    Cr = !1, Hr = null, Ui.apply(Sl, arguments);
  }
  function ue(n, r, l, u, c, d, y, R, k) {
    if (_.apply(this, arguments), Cr) {
      if (Cr) {
        var V = Hr;
        Cr = !1, Hr = null;
      } else throw Error(g(198));
      ca || (ca = !0, zi = V);
    }
  }
  function ce(n) {
    var r = n, l = n;
    if (n.alternate) for (; r.return; ) r = r.return;
    else {
      n = r;
      do
        r = n, r.flags & 4098 && (l = r.return), n = r.return;
      while (n);
    }
    return r.tag === 3 ? l : null;
  }
  function Je(n) {
    if (n.tag === 13) {
      var r = n.memoizedState;
      if (r === null && (n = n.alternate, n !== null && (r = n.memoizedState)), r !== null) return r.dehydrated;
    }
    return null;
  }
  function xt(n) {
    if (ce(n) !== n) throw Error(g(188));
  }
  function Mt(n) {
    var r = n.alternate;
    if (!r) {
      if (r = ce(n), r === null) throw Error(g(188));
      return r !== n ? null : n;
    }
    for (var l = n, u = r; ; ) {
      var c = l.return;
      if (c === null) break;
      var d = c.alternate;
      if (d === null) {
        if (u = c.return, u !== null) {
          l = u;
          continue;
        }
        break;
      }
      if (c.child === d.child) {
        for (d = c.child; d; ) {
          if (d === l) return xt(c), n;
          if (d === u) return xt(c), r;
          d = d.sibling;
        }
        throw Error(g(188));
      }
      if (l.return !== u.return) l = c, u = d;
      else {
        for (var y = !1, R = c.child; R; ) {
          if (R === l) {
            y = !0, l = c, u = d;
            break;
          }
          if (R === u) {
            y = !0, u = c, l = d;
            break;
          }
          R = R.sibling;
        }
        if (!y) {
          for (R = d.child; R; ) {
            if (R === l) {
              y = !0, l = d, u = c;
              break;
            }
            if (R === u) {
              y = !0, u = d, l = c;
              break;
            }
            R = R.sibling;
          }
          if (!y) throw Error(g(189));
        }
      }
      if (l.alternate !== u) throw Error(g(190));
    }
    if (l.tag !== 3) throw Error(g(188));
    return l.stateNode.current === l ? n : r;
  }
  function tt(n) {
    return n = Mt(n), n !== null ? bt(n) : null;
  }
  function bt(n) {
    if (n.tag === 5 || n.tag === 6) return n;
    for (n = n.child; n !== null; ) {
      var r = bt(n);
      if (r !== null) return r;
      n = n.sibling;
    }
    return null;
  }
  var Un = m.unstable_scheduleCallback, tn = m.unstable_cancelCallback, hn = m.unstable_shouldYield, mr = m.unstable_requestPaint, Yt = m.unstable_now, Oa = m.unstable_getCurrentPriorityLevel, zn = m.unstable_ImmediatePriority, Br = m.unstable_UserBlockingPriority, yt = m.unstable_NormalPriority, Fi = m.unstable_LowPriority, ji = m.unstable_IdlePriority, El = null, Vr = null;
  function Ju(n) {
    if (Vr && typeof Vr.onCommitFiberRoot == "function") try {
      Vr.onCommitFiberRoot(El, n, void 0, (n.current.flags & 128) === 128);
    } catch {
    }
  }
  var br = Math.clz32 ? Math.clz32 : ts, Zu = Math.log, es = Math.LN2;
  function ts(n) {
    return n >>>= 0, n === 0 ? 32 : 31 - (Zu(n) / es | 0) | 0;
  }
  var oo = 64, qo = 4194304;
  function Pi(n) {
    switch (n & -n) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return n & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return n & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return n;
    }
  }
  function di(n, r) {
    var l = n.pendingLanes;
    if (l === 0) return 0;
    var u = 0, c = n.suspendedLanes, d = n.pingedLanes, y = l & 268435455;
    if (y !== 0) {
      var R = y & ~c;
      R !== 0 ? u = Pi(R) : (d &= y, d !== 0 && (u = Pi(d)));
    } else y = l & ~c, y !== 0 ? u = Pi(y) : d !== 0 && (u = Pi(d));
    if (u === 0) return 0;
    if (r !== 0 && r !== u && !(r & c) && (c = u & -u, d = r & -r, c >= d || c === 16 && (d & 4194240) !== 0)) return r;
    if (u & 4 && (u |= l & 16), r = n.entangledLanes, r !== 0) for (n = n.entanglements, r &= u; 0 < r; ) l = 31 - br(r), c = 1 << l, u |= n[l], r &= ~c;
    return u;
  }
  function Ma(n, r) {
    switch (n) {
      case 1:
      case 2:
      case 4:
        return r + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return r + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function Cl(n, r) {
    for (var l = n.suspendedLanes, u = n.pingedLanes, c = n.expirationTimes, d = n.pendingLanes; 0 < d; ) {
      var y = 31 - br(d), R = 1 << y, k = c[y];
      k === -1 ? (!(R & l) || R & u) && (c[y] = Ma(R, r)) : k <= r && (n.expiredLanes |= R), d &= ~R;
    }
  }
  function pi(n) {
    return n = n.pendingLanes & -1073741825, n !== 0 ? n : n & 1073741824 ? 1073741824 : 0;
  }
  function uo() {
    var n = oo;
    return oo <<= 1, !(oo & 4194240) && (oo = 64), n;
  }
  function so(n) {
    for (var r = [], l = 0; 31 > l; l++) r.push(n);
    return r;
  }
  function bl(n, r, l) {
    n.pendingLanes |= r, r !== 536870912 && (n.suspendedLanes = 0, n.pingedLanes = 0), n = n.eventTimes, r = 31 - br(r), n[r] = l;
  }
  function ns(n, r) {
    var l = n.pendingLanes & ~r;
    n.pendingLanes = r, n.suspendedLanes = 0, n.pingedLanes = 0, n.expiredLanes &= r, n.mutableReadLanes &= r, n.entangledLanes &= r, r = n.entanglements;
    var u = n.eventTimes;
    for (n = n.expirationTimes; 0 < l; ) {
      var c = 31 - br(l), d = 1 << c;
      r[c] = 0, u[c] = -1, n[c] = -1, l &= ~d;
    }
  }
  function rs(n, r) {
    var l = n.entangledLanes |= r;
    for (n = n.entanglements; l; ) {
      var u = 31 - br(l), c = 1 << u;
      c & r | n[u] & r && (n[u] |= r), l &= ~c;
    }
  }
  var kt = 0;
  function as(n) {
    return n &= -n, 1 < n ? 4 < n ? n & 268435455 ? 16 : 536870912 : 4 : 1;
  }
  var Xo, Tl, is, Dt, Jo, co = !1, dt = [], Ja = null, gn = null, $r = null, Na = /* @__PURE__ */ new Map(), Rl = /* @__PURE__ */ new Map(), sn = [], Sn = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
  function ls(n, r) {
    switch (n) {
      case "focusin":
      case "focusout":
        Ja = null;
        break;
      case "dragenter":
      case "dragleave":
        gn = null;
        break;
      case "mouseover":
      case "mouseout":
        $r = null;
        break;
      case "pointerover":
      case "pointerout":
        Na.delete(r.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Rl.delete(r.pointerId);
    }
  }
  function er(n, r, l, u, c, d) {
    return n === null || n.nativeEvent !== d ? (n = { blockedOn: r, domEventName: l, eventSystemFlags: u, nativeEvent: d, targetContainers: [c] }, r !== null && (r = mi(r), r !== null && Tl(r)), n) : (n.eventSystemFlags |= u, r = n.targetContainers, c !== null && r.indexOf(c) === -1 && r.push(c), n);
  }
  function Ir(n, r, l, u, c) {
    switch (r) {
      case "focusin":
        return Ja = er(Ja, n, r, l, u, c), !0;
      case "dragenter":
        return gn = er(gn, n, r, l, u, c), !0;
      case "mouseover":
        return $r = er($r, n, r, l, u, c), !0;
      case "pointerover":
        var d = c.pointerId;
        return Na.set(d, er(Na.get(d) || null, n, r, l, u, c)), !0;
      case "gotpointercapture":
        return d = c.pointerId, Rl.set(d, er(Rl.get(d) || null, n, r, l, u, c)), !0;
    }
    return !1;
  }
  function Za(n) {
    var r = qi(n.target);
    if (r !== null) {
      var l = ce(r);
      if (l !== null) {
        if (r = l.tag, r === 13) {
          if (r = Je(l), r !== null) {
            n.blockedOn = r, Jo(n.priority, function() {
              is(l);
            });
            return;
          }
        } else if (r === 3 && l.stateNode.current.memoizedState.isDehydrated) {
          n.blockedOn = l.tag === 3 ? l.stateNode.containerInfo : null;
          return;
        }
      }
    }
    n.blockedOn = null;
  }
  function Zo(n) {
    if (n.blockedOn !== null) return !1;
    for (var r = n.targetContainers; 0 < r.length; ) {
      var l = tu(n.domEventName, n.eventSystemFlags, r[0], n.nativeEvent);
      if (l === null) {
        l = n.nativeEvent;
        var u = new l.constructor(l.type, l);
        yn = u, l.target.dispatchEvent(u), yn = null;
      } else return r = mi(l), r !== null && Tl(r), n.blockedOn = l, !1;
      r.shift();
    }
    return !0;
  }
  function fo(n, r, l) {
    Zo(n) && l.delete(r);
  }
  function po() {
    co = !1, Ja !== null && Zo(Ja) && (Ja = null), gn !== null && Zo(gn) && (gn = null), $r !== null && Zo($r) && ($r = null), Na.forEach(fo), Rl.forEach(fo);
  }
  function wl(n, r) {
    n.blockedOn === r && (n.blockedOn = null, co || (co = !0, m.unstable_scheduleCallback(m.unstable_NormalPriority, po)));
  }
  function La(n) {
    function r(c) {
      return wl(c, n);
    }
    if (0 < dt.length) {
      wl(dt[0], n);
      for (var l = 1; l < dt.length; l++) {
        var u = dt[l];
        u.blockedOn === n && (u.blockedOn = null);
      }
    }
    for (Ja !== null && wl(Ja, n), gn !== null && wl(gn, n), $r !== null && wl($r, n), Na.forEach(r), Rl.forEach(r), l = 0; l < sn.length; l++) u = sn[l], u.blockedOn === n && (u.blockedOn = null);
    for (; 0 < sn.length && (l = sn[0], l.blockedOn === null); ) Za(l), l.blockedOn === null && sn.shift();
  }
  var Hi = Ge.ReactCurrentBatchConfig, vo = !0;
  function Bi(n, r, l, u) {
    var c = kt, d = Hi.transition;
    Hi.transition = null;
    try {
      kt = 1, vi(n, r, l, u);
    } finally {
      kt = c, Hi.transition = d;
    }
  }
  function eu(n, r, l, u) {
    var c = kt, d = Hi.transition;
    Hi.transition = null;
    try {
      kt = 4, vi(n, r, l, u);
    } finally {
      kt = c, Hi.transition = d;
    }
  }
  function vi(n, r, l, u) {
    if (vo) {
      var c = tu(n, r, l, u);
      if (c === null) ld(n, r, u, Vi, l), ls(n, u);
      else if (Ir(c, n, r, l, u)) u.stopPropagation();
      else if (ls(n, u), r & 4 && -1 < Sn.indexOf(n)) {
        for (; c !== null; ) {
          var d = mi(c);
          if (d !== null && Xo(d), d = tu(n, r, l, u), d === null && ld(n, r, u, Vi, l), d === c) break;
          c = d;
        }
        c !== null && u.stopPropagation();
      } else ld(n, r, u, null, l);
    }
  }
  var Vi = null;
  function tu(n, r, l, u) {
    if (Vi = null, n = hr(u), n = qi(n), n !== null) if (r = ce(n), r === null) n = null;
    else if (l = r.tag, l === 13) {
      if (n = Je(r), n !== null) return n;
      n = null;
    } else if (l === 3) {
      if (r.stateNode.current.memoizedState.isDehydrated) return r.tag === 3 ? r.stateNode.containerInfo : null;
      n = null;
    } else r !== n && (n = null);
    return Vi = n, null;
  }
  function os(n) {
    switch (n) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (Oa()) {
          case zn:
            return 1;
          case Br:
            return 4;
          case yt:
          case Fi:
            return 16;
          case ji:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var ei = null, nu = null, h = null;
  function w() {
    if (h) return h;
    var n, r = nu, l = r.length, u, c = "value" in ei ? ei.value : ei.textContent, d = c.length;
    for (n = 0; n < l && r[n] === c[n]; n++) ;
    var y = l - n;
    for (u = 1; u <= y && r[l - u] === c[d - u]; u++) ;
    return h = c.slice(n, 1 < u ? 1 - u : void 0);
  }
  function H(n) {
    var r = n.keyCode;
    return "charCode" in n ? (n = n.charCode, n === 0 && r === 13 && (n = 13)) : n = r, n === 10 && (n = 13), 32 <= n || n === 13 ? n : 0;
  }
  function Y() {
    return !0;
  }
  function he() {
    return !1;
  }
  function je(n) {
    function r(l, u, c, d, y) {
      this._reactName = l, this._targetInst = c, this.type = u, this.nativeEvent = d, this.target = y, this.currentTarget = null;
      for (var R in n) n.hasOwnProperty(R) && (l = n[R], this[R] = l ? l(d) : d[R]);
      return this.isDefaultPrevented = (d.defaultPrevented != null ? d.defaultPrevented : d.returnValue === !1) ? Y : he, this.isPropagationStopped = he, this;
    }
    return pe(r.prototype, { preventDefault: function() {
      this.defaultPrevented = !0;
      var l = this.nativeEvent;
      l && (l.preventDefault ? l.preventDefault() : typeof l.returnValue != "unknown" && (l.returnValue = !1), this.isDefaultPrevented = Y);
    }, stopPropagation: function() {
      var l = this.nativeEvent;
      l && (l.stopPropagation ? l.stopPropagation() : typeof l.cancelBubble != "unknown" && (l.cancelBubble = !0), this.isPropagationStopped = Y);
    }, persist: function() {
    }, isPersistent: Y }), r;
  }
  var De = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(n) {
    return n.timeStamp || Date.now();
  }, defaultPrevented: 0, isTrusted: 0 }, ot = je(De), Tt = pe({}, De, { view: 0, detail: 0 }), Wt = je(Tt), Kt, qt, Xt, cn = pe({}, Tt, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: Ec, button: 0, buttons: 0, relatedTarget: function(n) {
    return n.relatedTarget === void 0 ? n.fromElement === n.srcElement ? n.toElement : n.fromElement : n.relatedTarget;
  }, movementX: function(n) {
    return "movementX" in n ? n.movementX : (n !== Xt && (Xt && n.type === "mousemove" ? (Kt = n.screenX - Xt.screenX, qt = n.screenY - Xt.screenY) : qt = Kt = 0, Xt = n), Kt);
  }, movementY: function(n) {
    return "movementY" in n ? n.movementY : qt;
  } }), At = je(cn), xl = pe({}, cn, { dataTransfer: 0 }), ru = je(xl), us = pe({}, Tt, { relatedTarget: 0 }), ss = je(us), $i = pe({}, De, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), cs = je($i), fs = pe({}, De, { clipboardData: function(n) {
    return "clipboardData" in n ? n.clipboardData : window.clipboardData;
  } }), Gf = je(fs), ly = pe({}, De, { data: 0 }), fv = je(ly), dv = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, Kf = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, pv = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
  function vv(n) {
    var r = this.nativeEvent;
    return r.getModifierState ? r.getModifierState(n) : (n = pv[n]) ? !!r[n] : !1;
  }
  function Ec() {
    return vv;
  }
  var oy = pe({}, Tt, { key: function(n) {
    if (n.key) {
      var r = dv[n.key] || n.key;
      if (r !== "Unidentified") return r;
    }
    return n.type === "keypress" ? (n = H(n), n === 13 ? "Enter" : String.fromCharCode(n)) : n.type === "keydown" || n.type === "keyup" ? Kf[n.keyCode] || "Unidentified" : "";
  }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: Ec, charCode: function(n) {
    return n.type === "keypress" ? H(n) : 0;
  }, keyCode: function(n) {
    return n.type === "keydown" || n.type === "keyup" ? n.keyCode : 0;
  }, which: function(n) {
    return n.type === "keypress" ? H(n) : n.type === "keydown" || n.type === "keyup" ? n.keyCode : 0;
  } }), Ii = je(oy), uy = pe({}, cn, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), Cc = je(uy), qf = pe({}, Tt, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: Ec }), Xf = je(qf), sy = pe({}, De, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), bc = je(sy), hv = pe({}, cn, {
    deltaX: function(n) {
      return "deltaX" in n ? n.deltaX : "wheelDeltaX" in n ? -n.wheelDeltaX : 0;
    },
    deltaY: function(n) {
      return "deltaY" in n ? n.deltaY : "wheelDeltaY" in n ? -n.wheelDeltaY : "wheelDelta" in n ? -n.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), Yr = je(hv), Yi = [9, 13, 27, 32], Tn = S && "CompositionEvent" in window, fa = null;
  S && "documentMode" in document && (fa = document.documentMode);
  var Jf = S && "TextEvent" in window && !fa, ds = S && (!Tn || fa && 8 < fa && 11 >= fa), mv = " ", au = !1;
  function yv(n, r) {
    switch (n) {
      case "keyup":
        return Yi.indexOf(r.keyCode) !== -1;
      case "keydown":
        return r.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function gv(n) {
    return n = n.detail, typeof n == "object" && "data" in n ? n.data : null;
  }
  var _l = !1;
  function cy(n, r) {
    switch (n) {
      case "compositionend":
        return gv(r);
      case "keypress":
        return r.which !== 32 ? null : (au = !0, mv);
      case "textInput":
        return n = r.data, n === mv && au ? null : n;
      default:
        return null;
    }
  }
  function fy(n, r) {
    if (_l) return n === "compositionend" || !Tn && yv(n, r) ? (n = w(), h = nu = ei = null, _l = !1, n) : null;
    switch (n) {
      case "paste":
        return null;
      case "keypress":
        if (!(r.ctrlKey || r.altKey || r.metaKey) || r.ctrlKey && r.altKey) {
          if (r.char && 1 < r.char.length) return r.char;
          if (r.which) return String.fromCharCode(r.which);
        }
        return null;
      case "compositionend":
        return ds && r.locale !== "ko" ? null : r.data;
      default:
        return null;
    }
  }
  var dy = { color: !0, date: !0, datetime: !0, "datetime-local": !0, email: !0, month: !0, number: !0, password: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0 };
  function Zf(n) {
    var r = n && n.nodeName && n.nodeName.toLowerCase();
    return r === "input" ? !!dy[n.type] : r === "textarea";
  }
  function Sv(n, r, l, u) {
    Ka(u), r = kc(r, "onChange"), 0 < r.length && (l = new ot("onChange", "change", null, l, u), n.push({ event: l, listeners: r }));
  }
  var ps = null, vs = null;
  function Ev(n) {
    zv(n, 0);
  }
  function Wi(n) {
    var r = uu(n);
    if (Pr(r)) return n;
  }
  function ed(n, r) {
    if (n === "change") return r;
  }
  var td = !1;
  if (S) {
    var Tc;
    if (S) {
      var nd = "oninput" in document;
      if (!nd) {
        var Cv = document.createElement("div");
        Cv.setAttribute("oninput", "return;"), nd = typeof Cv.oninput == "function";
      }
      Tc = nd;
    } else Tc = !1;
    td = Tc && (!document.documentMode || 9 < document.documentMode);
  }
  function bv() {
    ps && (ps.detachEvent("onpropertychange", Tv), vs = ps = null);
  }
  function Tv(n) {
    if (n.propertyName === "value" && Wi(vs)) {
      var r = [];
      Sv(r, vs, n, hr(n)), gl(Ev, r);
    }
  }
  function py(n, r, l) {
    n === "focusin" ? (bv(), ps = r, vs = l, ps.attachEvent("onpropertychange", Tv)) : n === "focusout" && bv();
  }
  function vy(n) {
    if (n === "selectionchange" || n === "keyup" || n === "keydown") return Wi(vs);
  }
  function hy(n, r) {
    if (n === "click") return Wi(r);
  }
  function my(n, r) {
    if (n === "input" || n === "change") return Wi(r);
  }
  function Rv(n, r) {
    return n === r && (n !== 0 || 1 / n === 1 / r) || n !== n && r !== r;
  }
  var ti = typeof Object.is == "function" ? Object.is : Rv;
  function iu(n, r) {
    if (ti(n, r)) return !0;
    if (typeof n != "object" || n === null || typeof r != "object" || r === null) return !1;
    var l = Object.keys(n), u = Object.keys(r);
    if (l.length !== u.length) return !1;
    for (u = 0; u < l.length; u++) {
      var c = l[u];
      if (!ne.call(r, c) || !ti(n[c], r[c])) return !1;
    }
    return !0;
  }
  function wv(n) {
    for (; n && n.firstChild; ) n = n.firstChild;
    return n;
  }
  function xv(n, r) {
    var l = wv(n);
    n = 0;
    for (var u; l; ) {
      if (l.nodeType === 3) {
        if (u = n + l.textContent.length, n <= r && u >= r) return { node: l, offset: r - n };
        n = u;
      }
      e: {
        for (; l; ) {
          if (l.nextSibling) {
            l = l.nextSibling;
            break e;
          }
          l = l.parentNode;
        }
        l = void 0;
      }
      l = wv(l);
    }
  }
  function _v(n, r) {
    return n && r ? n === r ? !0 : n && n.nodeType === 3 ? !1 : r && r.nodeType === 3 ? _v(n, r.parentNode) : "contains" in n ? n.contains(r) : n.compareDocumentPosition ? !!(n.compareDocumentPosition(r) & 16) : !1 : !1;
  }
  function kv() {
    for (var n = window, r = dr(); r instanceof n.HTMLIFrameElement; ) {
      try {
        var l = typeof r.contentWindow.location.href == "string";
      } catch {
        l = !1;
      }
      if (l) n = r.contentWindow;
      else break;
      r = dr(n.document);
    }
    return r;
  }
  function hs(n) {
    var r = n && n.nodeName && n.nodeName.toLowerCase();
    return r && (r === "input" && (n.type === "text" || n.type === "search" || n.type === "tel" || n.type === "url" || n.type === "password") || r === "textarea" || n.contentEditable === "true");
  }
  function ho(n) {
    var r = kv(), l = n.focusedElem, u = n.selectionRange;
    if (r !== l && l && l.ownerDocument && _v(l.ownerDocument.documentElement, l)) {
      if (u !== null && hs(l)) {
        if (r = u.start, n = u.end, n === void 0 && (n = r), "selectionStart" in l) l.selectionStart = r, l.selectionEnd = Math.min(n, l.value.length);
        else if (n = (r = l.ownerDocument || document) && r.defaultView || window, n.getSelection) {
          n = n.getSelection();
          var c = l.textContent.length, d = Math.min(u.start, c);
          u = u.end === void 0 ? d : Math.min(u.end, c), !n.extend && d > u && (c = u, u = d, d = c), c = xv(l, d);
          var y = xv(
            l,
            u
          );
          c && y && (n.rangeCount !== 1 || n.anchorNode !== c.node || n.anchorOffset !== c.offset || n.focusNode !== y.node || n.focusOffset !== y.offset) && (r = r.createRange(), r.setStart(c.node, c.offset), n.removeAllRanges(), d > u ? (n.addRange(r), n.extend(y.node, y.offset)) : (r.setEnd(y.node, y.offset), n.addRange(r)));
        }
      }
      for (r = [], n = l; n = n.parentNode; ) n.nodeType === 1 && r.push({ element: n, left: n.scrollLeft, top: n.scrollTop });
      for (typeof l.focus == "function" && l.focus(), l = 0; l < r.length; l++) n = r[l], n.element.scrollLeft = n.left, n.element.scrollTop = n.top;
    }
  }
  var Rc = S && "documentMode" in document && 11 >= document.documentMode, mo = null, kl = null, ms = null, rd = !1;
  function Dv(n, r, l) {
    var u = l.window === l ? l.document : l.nodeType === 9 ? l : l.ownerDocument;
    rd || mo == null || mo !== dr(u) || (u = mo, "selectionStart" in u && hs(u) ? u = { start: u.selectionStart, end: u.selectionEnd } : (u = (u.ownerDocument && u.ownerDocument.defaultView || window).getSelection(), u = { anchorNode: u.anchorNode, anchorOffset: u.anchorOffset, focusNode: u.focusNode, focusOffset: u.focusOffset }), ms && iu(ms, u) || (ms = u, u = kc(kl, "onSelect"), 0 < u.length && (r = new ot("onSelect", "select", null, r, l), n.push({ event: r, listeners: u }), r.target = mo)));
  }
  function wc(n, r) {
    var l = {};
    return l[n.toLowerCase()] = r.toLowerCase(), l["Webkit" + n] = "webkit" + r, l["Moz" + n] = "moz" + r, l;
  }
  var lu = { animationend: wc("Animation", "AnimationEnd"), animationiteration: wc("Animation", "AnimationIteration"), animationstart: wc("Animation", "AnimationStart"), transitionend: wc("Transition", "TransitionEnd") }, xc = {}, Ov = {};
  S && (Ov = document.createElement("div").style, "AnimationEvent" in window || (delete lu.animationend.animation, delete lu.animationiteration.animation, delete lu.animationstart.animation), "TransitionEvent" in window || delete lu.transitionend.transition);
  function ys(n) {
    if (xc[n]) return xc[n];
    if (!lu[n]) return n;
    var r = lu[n], l;
    for (l in r) if (r.hasOwnProperty(l) && l in Ov) return xc[n] = r[l];
    return n;
  }
  var yr = ys("animationend"), ad = ys("animationiteration"), Mv = ys("animationstart"), Nv = ys("transitionend"), Lv = /* @__PURE__ */ new Map(), Av = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
  function Dl(n, r) {
    Lv.set(n, r), U(r, [n]);
  }
  for (var _c = 0; _c < Av.length; _c++) {
    var gs = Av[_c], Ss = gs.toLowerCase(), yy = gs[0].toUpperCase() + gs.slice(1);
    Dl(Ss, "on" + yy);
  }
  Dl(yr, "onAnimationEnd"), Dl(ad, "onAnimationIteration"), Dl(Mv, "onAnimationStart"), Dl("dblclick", "onDoubleClick"), Dl("focusin", "onFocus"), Dl("focusout", "onBlur"), Dl(Nv, "onTransitionEnd"), x("onMouseEnter", ["mouseout", "mouseover"]), x("onMouseLeave", ["mouseout", "mouseover"]), x("onPointerEnter", ["pointerout", "pointerover"]), x("onPointerLeave", ["pointerout", "pointerover"]), U("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), U("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), U("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), U("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), U("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), U("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
  var Qi = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), gy = new Set("cancel close invalid load scroll toggle".split(" ").concat(Qi));
  function Uv(n, r, l) {
    var u = n.type || "unknown-event";
    n.currentTarget = l, ue(u, r, void 0, n), n.currentTarget = null;
  }
  function zv(n, r) {
    r = (r & 4) !== 0;
    for (var l = 0; l < n.length; l++) {
      var u = n[l], c = u.event;
      u = u.listeners;
      e: {
        var d = void 0;
        if (r) for (var y = u.length - 1; 0 <= y; y--) {
          var R = u[y], k = R.instance, V = R.currentTarget;
          if (R = R.listener, k !== d && c.isPropagationStopped()) break e;
          Uv(c, R, V), d = k;
        }
        else for (y = 0; y < u.length; y++) {
          if (R = u[y], k = R.instance, V = R.currentTarget, R = R.listener, k !== d && c.isPropagationStopped()) break e;
          Uv(c, R, V), d = k;
        }
      }
    }
    if (ca) throw n = zi, ca = !1, zi = null, n;
  }
  function nn(n, r) {
    var l = r[vd];
    l === void 0 && (l = r[vd] = /* @__PURE__ */ new Set());
    var u = n + "__bubble";
    l.has(u) || (id(r, n, 2, !1), l.add(u));
  }
  function Es(n, r, l) {
    var u = 0;
    r && (u |= 4), id(l, n, u, r);
  }
  var Gi = "_reactListening" + Math.random().toString(36).slice(2);
  function hi(n) {
    if (!n[Gi]) {
      n[Gi] = !0, T.forEach(function(l) {
        l !== "selectionchange" && (gy.has(l) || Es(l, !1, n), Es(l, !0, n));
      });
      var r = n.nodeType === 9 ? n : n.ownerDocument;
      r === null || r[Gi] || (r[Gi] = !0, Es("selectionchange", !1, r));
    }
  }
  function id(n, r, l, u) {
    switch (os(r)) {
      case 1:
        var c = Bi;
        break;
      case 4:
        c = eu;
        break;
      default:
        c = vi;
    }
    l = c.bind(null, r, l, n), c = void 0, !Xa || r !== "touchstart" && r !== "touchmove" && r !== "wheel" || (c = !0), u ? c !== void 0 ? n.addEventListener(r, l, { capture: !0, passive: c }) : n.addEventListener(r, l, !0) : c !== void 0 ? n.addEventListener(r, l, { passive: c }) : n.addEventListener(r, l, !1);
  }
  function ld(n, r, l, u, c) {
    var d = u;
    if (!(r & 1) && !(r & 2) && u !== null) e: for (; ; ) {
      if (u === null) return;
      var y = u.tag;
      if (y === 3 || y === 4) {
        var R = u.stateNode.containerInfo;
        if (R === c || R.nodeType === 8 && R.parentNode === c) break;
        if (y === 4) for (y = u.return; y !== null; ) {
          var k = y.tag;
          if ((k === 3 || k === 4) && (k = y.stateNode.containerInfo, k === c || k.nodeType === 8 && k.parentNode === c)) return;
          y = y.return;
        }
        for (; R !== null; ) {
          if (y = qi(R), y === null) return;
          if (k = y.tag, k === 5 || k === 6) {
            u = d = y;
            continue e;
          }
          R = R.parentNode;
        }
      }
      u = u.return;
    }
    gl(function() {
      var V = d, se = hr(l), fe = [];
      e: {
        var le = Lv.get(n);
        if (le !== void 0) {
          var _e = ot, ze = n;
          switch (n) {
            case "keypress":
              if (H(l) === 0) break e;
            case "keydown":
            case "keyup":
              _e = Ii;
              break;
            case "focusin":
              ze = "focus", _e = ss;
              break;
            case "focusout":
              ze = "blur", _e = ss;
              break;
            case "beforeblur":
            case "afterblur":
              _e = ss;
              break;
            case "click":
              if (l.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              _e = At;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              _e = ru;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              _e = Xf;
              break;
            case yr:
            case ad:
            case Mv:
              _e = cs;
              break;
            case Nv:
              _e = bc;
              break;
            case "scroll":
              _e = Wt;
              break;
            case "wheel":
              _e = Yr;
              break;
            case "copy":
            case "cut":
            case "paste":
              _e = Gf;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              _e = Cc;
          }
          var Pe = (r & 4) !== 0, Nn = !Pe && n === "scroll", z = Pe ? le !== null ? le + "Capture" : null : le;
          Pe = [];
          for (var O = V, P; O !== null; ) {
            P = O;
            var me = P.stateNode;
            if (P.tag === 5 && me !== null && (P = me, z !== null && (me = qa(O, z), me != null && Pe.push(ou(O, me, P)))), Nn) break;
            O = O.return;
          }
          0 < Pe.length && (le = new _e(le, ze, null, l, se), fe.push({ event: le, listeners: Pe }));
        }
      }
      if (!(r & 7)) {
        e: {
          if (le = n === "mouseover" || n === "pointerover", _e = n === "mouseout" || n === "pointerout", le && l !== yn && (ze = l.relatedTarget || l.fromElement) && (qi(ze) || ze[ni])) break e;
          if ((_e || le) && (le = se.window === se ? se : (le = se.ownerDocument) ? le.defaultView || le.parentWindow : window, _e ? (ze = l.relatedTarget || l.toElement, _e = V, ze = ze ? qi(ze) : null, ze !== null && (Nn = ce(ze), ze !== Nn || ze.tag !== 5 && ze.tag !== 6) && (ze = null)) : (_e = null, ze = V), _e !== ze)) {
            if (Pe = At, me = "onMouseLeave", z = "onMouseEnter", O = "mouse", (n === "pointerout" || n === "pointerover") && (Pe = Cc, me = "onPointerLeave", z = "onPointerEnter", O = "pointer"), Nn = _e == null ? le : uu(_e), P = ze == null ? le : uu(ze), le = new Pe(me, O + "leave", _e, l, se), le.target = Nn, le.relatedTarget = P, me = null, qi(se) === V && (Pe = new Pe(z, O + "enter", ze, l, se), Pe.target = P, Pe.relatedTarget = Nn, me = Pe), Nn = me, _e && ze) t: {
              for (Pe = _e, z = ze, O = 0, P = Pe; P; P = yo(P)) O++;
              for (P = 0, me = z; me; me = yo(me)) P++;
              for (; 0 < O - P; ) Pe = yo(Pe), O--;
              for (; 0 < P - O; ) z = yo(z), P--;
              for (; O--; ) {
                if (Pe === z || z !== null && Pe === z.alternate) break t;
                Pe = yo(Pe), z = yo(z);
              }
              Pe = null;
            }
            else Pe = null;
            _e !== null && od(fe, le, _e, Pe, !1), ze !== null && Nn !== null && od(fe, Nn, ze, Pe, !0);
          }
        }
        e: {
          if (le = V ? uu(V) : window, _e = le.nodeName && le.nodeName.toLowerCase(), _e === "select" || _e === "input" && le.type === "file") var Be = ed;
          else if (Zf(le)) if (td) Be = my;
          else {
            Be = vy;
            var rt = py;
          }
          else (_e = le.nodeName) && _e.toLowerCase() === "input" && (le.type === "checkbox" || le.type === "radio") && (Be = hy);
          if (Be && (Be = Be(n, V))) {
            Sv(fe, Be, l, se);
            break e;
          }
          rt && rt(n, le, V), n === "focusout" && (rt = le._wrapperState) && rt.controlled && le.type === "number" && Sr(le, "number", le.value);
        }
        switch (rt = V ? uu(V) : window, n) {
          case "focusin":
            (Zf(rt) || rt.contentEditable === "true") && (mo = rt, kl = V, ms = null);
            break;
          case "focusout":
            ms = kl = mo = null;
            break;
          case "mousedown":
            rd = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            rd = !1, Dv(fe, l, se);
            break;
          case "selectionchange":
            if (Rc) break;
          case "keydown":
          case "keyup":
            Dv(fe, l, se);
        }
        var at;
        if (Tn) e: {
          switch (n) {
            case "compositionstart":
              var $e = "onCompositionStart";
              break e;
            case "compositionend":
              $e = "onCompositionEnd";
              break e;
            case "compositionupdate":
              $e = "onCompositionUpdate";
              break e;
          }
          $e = void 0;
        }
        else _l ? yv(n, l) && ($e = "onCompositionEnd") : n === "keydown" && l.keyCode === 229 && ($e = "onCompositionStart");
        $e && (ds && l.locale !== "ko" && (_l || $e !== "onCompositionStart" ? $e === "onCompositionEnd" && _l && (at = w()) : (ei = se, nu = "value" in ei ? ei.value : ei.textContent, _l = !0)), rt = kc(V, $e), 0 < rt.length && ($e = new fv($e, n, null, l, se), fe.push({ event: $e, listeners: rt }), at ? $e.data = at : (at = gv(l), at !== null && ($e.data = at)))), (at = Jf ? cy(n, l) : fy(n, l)) && (V = kc(V, "onBeforeInput"), 0 < V.length && (se = new fv("onBeforeInput", "beforeinput", null, l, se), fe.push({ event: se, listeners: V }), se.data = at));
      }
      zv(fe, r);
    });
  }
  function ou(n, r, l) {
    return { instance: n, listener: r, currentTarget: l };
  }
  function kc(n, r) {
    for (var l = r + "Capture", u = []; n !== null; ) {
      var c = n, d = c.stateNode;
      c.tag === 5 && d !== null && (c = d, d = qa(n, l), d != null && u.unshift(ou(n, d, c)), d = qa(n, r), d != null && u.push(ou(n, d, c))), n = n.return;
    }
    return u;
  }
  function yo(n) {
    if (n === null) return null;
    do
      n = n.return;
    while (n && n.tag !== 5);
    return n || null;
  }
  function od(n, r, l, u, c) {
    for (var d = r._reactName, y = []; l !== null && l !== u; ) {
      var R = l, k = R.alternate, V = R.stateNode;
      if (k !== null && k === u) break;
      R.tag === 5 && V !== null && (R = V, c ? (k = qa(l, d), k != null && y.unshift(ou(l, k, R))) : c || (k = qa(l, d), k != null && y.push(ou(l, k, R)))), l = l.return;
    }
    y.length !== 0 && n.push({ event: r, listeners: y });
  }
  var Fv = /\r\n?/g, ud = /\u0000|\uFFFD/g;
  function jv(n) {
    return (typeof n == "string" ? n : "" + n).replace(Fv, `
`).replace(ud, "");
  }
  function Cs(n, r, l) {
    if (r = jv(r), jv(n) !== r && l) throw Error(g(425));
  }
  function Dc() {
  }
  var sd = null, cd = null;
  function go(n, r) {
    return n === "textarea" || n === "noscript" || typeof r.children == "string" || typeof r.children == "number" || typeof r.dangerouslySetInnerHTML == "object" && r.dangerouslySetInnerHTML !== null && r.dangerouslySetInnerHTML.__html != null;
  }
  var bs = typeof setTimeout == "function" ? setTimeout : void 0, Ts = typeof clearTimeout == "function" ? clearTimeout : void 0, fd = typeof Promise == "function" ? Promise : void 0, Pv = typeof queueMicrotask == "function" ? queueMicrotask : typeof fd < "u" ? function(n) {
    return fd.resolve(null).then(n).catch(dd);
  } : bs;
  function dd(n) {
    setTimeout(function() {
      throw n;
    });
  }
  function pd(n, r) {
    var l = r, u = 0;
    do {
      var c = l.nextSibling;
      if (n.removeChild(l), c && c.nodeType === 8) if (l = c.data, l === "/$") {
        if (u === 0) {
          n.removeChild(c), La(r);
          return;
        }
        u--;
      } else l !== "$" && l !== "$?" && l !== "$!" || u++;
      l = c;
    } while (l);
    La(r);
  }
  function da(n) {
    for (; n != null; n = n.nextSibling) {
      var r = n.nodeType;
      if (r === 1 || r === 3) break;
      if (r === 8) {
        if (r = n.data, r === "$" || r === "$!" || r === "$?") break;
        if (r === "/$") return null;
      }
    }
    return n;
  }
  function Rs(n) {
    n = n.previousSibling;
    for (var r = 0; n; ) {
      if (n.nodeType === 8) {
        var l = n.data;
        if (l === "$" || l === "$!" || l === "$?") {
          if (r === 0) return n;
          r--;
        } else l === "/$" && r++;
      }
      n = n.previousSibling;
    }
    return null;
  }
  var Ki = Math.random().toString(36).slice(2), Aa = "__reactFiber$" + Ki, ws = "__reactProps$" + Ki, ni = "__reactContainer$" + Ki, vd = "__reactEvents$" + Ki, Sy = "__reactListeners$" + Ki, Ey = "__reactHandles$" + Ki;
  function qi(n) {
    var r = n[Aa];
    if (r) return r;
    for (var l = n.parentNode; l; ) {
      if (r = l[ni] || l[Aa]) {
        if (l = r.alternate, r.child !== null || l !== null && l.child !== null) for (n = Rs(n); n !== null; ) {
          if (l = n[Aa]) return l;
          n = Rs(n);
        }
        return r;
      }
      n = l, l = n.parentNode;
    }
    return null;
  }
  function mi(n) {
    return n = n[Aa] || n[ni], !n || n.tag !== 5 && n.tag !== 6 && n.tag !== 13 && n.tag !== 3 ? null : n;
  }
  function uu(n) {
    if (n.tag === 5 || n.tag === 6) return n.stateNode;
    throw Error(g(33));
  }
  function Oc(n) {
    return n[ws] || null;
  }
  var Ze = [], ri = -1;
  function rn(n) {
    return { current: n };
  }
  function He(n) {
    0 > ri || (n.current = Ze[ri], Ze[ri] = null, ri--);
  }
  function Ht(n, r) {
    ri++, Ze[ri] = n.current, n.current = r;
  }
  var Ua = {}, Qn = rn(Ua), vt = rn(!1), Tr = Ua;
  function pa(n, r) {
    var l = n.type.contextTypes;
    if (!l) return Ua;
    var u = n.stateNode;
    if (u && u.__reactInternalMemoizedUnmaskedChildContext === r) return u.__reactInternalMemoizedMaskedChildContext;
    var c = {}, d;
    for (d in l) c[d] = r[d];
    return u && (n = n.stateNode, n.__reactInternalMemoizedUnmaskedChildContext = r, n.__reactInternalMemoizedMaskedChildContext = c), c;
  }
  function Fn(n) {
    return n = n.childContextTypes, n != null;
  }
  function Wr() {
    He(vt), He(Qn);
  }
  function yi(n, r, l) {
    if (Qn.current !== Ua) throw Error(g(168));
    Ht(Qn, r), Ht(vt, l);
  }
  function Ol(n, r, l) {
    var u = n.stateNode;
    if (r = r.childContextTypes, typeof u.getChildContext != "function") return l;
    u = u.getChildContext();
    for (var c in u) if (!(c in r)) throw Error(g(108, St(n) || "Unknown", c));
    return pe({}, l, u);
  }
  function So(n) {
    return n = (n = n.stateNode) && n.__reactInternalMemoizedMergedChildContext || Ua, Tr = Qn.current, Ht(Qn, n), Ht(vt, vt.current), !0;
  }
  function Hv(n, r, l) {
    var u = n.stateNode;
    if (!u) throw Error(g(169));
    l ? (n = Ol(n, r, Tr), u.__reactInternalMemoizedMergedChildContext = n, He(vt), He(Qn), Ht(Qn, n)) : He(vt), Ht(vt, l);
  }
  var Xi = null, Ml = !1, tr = !1;
  function Mc(n) {
    Xi === null ? Xi = [n] : Xi.push(n);
  }
  function Bv(n) {
    Ml = !0, Mc(n);
  }
  function gi() {
    if (!tr && Xi !== null) {
      tr = !0;
      var n = 0, r = kt;
      try {
        var l = Xi;
        for (kt = 1; n < l.length; n++) {
          var u = l[n];
          do
            u = u(!0);
          while (u !== null);
        }
        Xi = null, Ml = !1;
      } catch (c) {
        throw Xi !== null && (Xi = Xi.slice(n + 1)), Un(zn, gi), c;
      } finally {
        kt = r, tr = !1;
      }
    }
    return null;
  }
  var za = [], Nl = 0, Fa = null, Eo = 0, Qr = [], Gr = 0, ai = null, Kr = 1, nr = "";
  function Co(n, r) {
    za[Nl++] = Eo, za[Nl++] = Fa, Fa = n, Eo = r;
  }
  function Ll(n, r, l) {
    Qr[Gr++] = Kr, Qr[Gr++] = nr, Qr[Gr++] = ai, ai = n;
    var u = Kr;
    n = nr;
    var c = 32 - br(u) - 1;
    u &= ~(1 << c), l += 1;
    var d = 32 - br(r) + c;
    if (30 < d) {
      var y = c - c % 5;
      d = (u & (1 << y) - 1).toString(32), u >>= y, c -= y, Kr = 1 << 32 - br(r) + c | l << c | u, nr = d + n;
    } else Kr = 1 << d | l << c | u, nr = n;
  }
  function Nc(n) {
    n.return !== null && (Co(n, 1), Ll(n, 1, 0));
  }
  function Lc(n) {
    for (; n === Fa; ) Fa = za[--Nl], za[Nl] = null, Eo = za[--Nl], za[Nl] = null;
    for (; n === ai; ) ai = Qr[--Gr], Qr[Gr] = null, nr = Qr[--Gr], Qr[Gr] = null, Kr = Qr[--Gr], Qr[Gr] = null;
  }
  var va = null, ha = null, fn = !1, ja = null;
  function hd(n, r) {
    var l = ba(5, null, null, 0);
    l.elementType = "DELETED", l.stateNode = r, l.return = n, r = n.deletions, r === null ? (n.deletions = [l], n.flags |= 16) : r.push(l);
  }
  function md(n, r) {
    switch (n.tag) {
      case 5:
        var l = n.type;
        return r = r.nodeType !== 1 || l.toLowerCase() !== r.nodeName.toLowerCase() ? null : r, r !== null ? (n.stateNode = r, va = n, ha = da(r.firstChild), !0) : !1;
      case 6:
        return r = n.pendingProps === "" || r.nodeType !== 3 ? null : r, r !== null ? (n.stateNode = r, va = n, ha = null, !0) : !1;
      case 13:
        return r = r.nodeType !== 8 ? null : r, r !== null ? (l = ai !== null ? { id: Kr, overflow: nr } : null, n.memoizedState = { dehydrated: r, treeContext: l, retryLane: 1073741824 }, l = ba(18, null, null, 0), l.stateNode = r, l.return = n, n.child = l, va = n, ha = null, !0) : !1;
      default:
        return !1;
    }
  }
  function yd(n) {
    return (n.mode & 1) !== 0 && (n.flags & 128) === 0;
  }
  function Ac(n) {
    if (fn) {
      var r = ha;
      if (r) {
        var l = r;
        if (!md(n, r)) {
          if (yd(n)) throw Error(g(418));
          r = da(l.nextSibling);
          var u = va;
          r && md(n, r) ? hd(u, l) : (n.flags = n.flags & -4097 | 2, fn = !1, va = n);
        }
      } else {
        if (yd(n)) throw Error(g(418));
        n.flags = n.flags & -4097 | 2, fn = !1, va = n;
      }
    }
  }
  function gd(n) {
    for (n = n.return; n !== null && n.tag !== 5 && n.tag !== 3 && n.tag !== 13; ) n = n.return;
    va = n;
  }
  function Uc(n) {
    if (n !== va) return !1;
    if (!fn) return gd(n), fn = !0, !1;
    var r;
    if ((r = n.tag !== 3) && !(r = n.tag !== 5) && (r = n.type, r = r !== "head" && r !== "body" && !go(n.type, n.memoizedProps)), r && (r = ha)) {
      if (yd(n)) throw Vv(), Error(g(418));
      for (; r; ) hd(n, r), r = da(r.nextSibling);
    }
    if (gd(n), n.tag === 13) {
      if (n = n.memoizedState, n = n !== null ? n.dehydrated : null, !n) throw Error(g(317));
      e: {
        for (n = n.nextSibling, r = 0; n; ) {
          if (n.nodeType === 8) {
            var l = n.data;
            if (l === "/$") {
              if (r === 0) {
                ha = da(n.nextSibling);
                break e;
              }
              r--;
            } else l !== "$" && l !== "$!" && l !== "$?" || r++;
          }
          n = n.nextSibling;
        }
        ha = null;
      }
    } else ha = va ? da(n.stateNode.nextSibling) : null;
    return !0;
  }
  function Vv() {
    for (var n = ha; n; ) n = da(n.nextSibling);
  }
  function su() {
    ha = va = null, fn = !1;
  }
  function jn(n) {
    ja === null ? ja = [n] : ja.push(n);
  }
  var Cy = Ge.ReactCurrentBatchConfig;
  function Al(n, r, l) {
    if (n = l.ref, n !== null && typeof n != "function" && typeof n != "object") {
      if (l._owner) {
        if (l = l._owner, l) {
          if (l.tag !== 1) throw Error(g(309));
          var u = l.stateNode;
        }
        if (!u) throw Error(g(147, n));
        var c = u, d = "" + n;
        return r !== null && r.ref !== null && typeof r.ref == "function" && r.ref._stringRef === d ? r.ref : (r = function(y) {
          var R = c.refs;
          y === null ? delete R[d] : R[d] = y;
        }, r._stringRef = d, r);
      }
      if (typeof n != "string") throw Error(g(284));
      if (!l._owner) throw Error(g(290, n));
    }
    return n;
  }
  function cu(n, r) {
    throw n = Object.prototype.toString.call(r), Error(g(31, n === "[object Object]" ? "object with keys {" + Object.keys(r).join(", ") + "}" : n));
  }
  function Ul(n) {
    var r = n._init;
    return r(n._payload);
  }
  function $v(n) {
    function r(z, O) {
      if (n) {
        var P = z.deletions;
        P === null ? (z.deletions = [O], z.flags |= 16) : P.push(O);
      }
    }
    function l(z, O) {
      if (!n) return null;
      for (; O !== null; ) r(z, O), O = O.sibling;
      return null;
    }
    function u(z, O) {
      for (z = /* @__PURE__ */ new Map(); O !== null; ) O.key !== null ? z.set(O.key, O) : z.set(O.index, O), O = O.sibling;
      return z;
    }
    function c(z, O) {
      return z = Wl(z, O), z.index = 0, z.sibling = null, z;
    }
    function d(z, O, P) {
      return z.index = P, n ? (P = z.alternate, P !== null ? (P = P.index, P < O ? (z.flags |= 2, O) : P) : (z.flags |= 2, O)) : (z.flags |= 1048576, O);
    }
    function y(z) {
      return n && z.alternate === null && (z.flags |= 2), z;
    }
    function R(z, O, P, me) {
      return O === null || O.tag !== 6 ? (O = Jd(P, z.mode, me), O.return = z, O) : (O = c(O, P), O.return = z, O);
    }
    function k(z, O, P, me) {
      var Be = P.type;
      return Be === lt ? se(z, O, P.props.children, me, P.key) : O !== null && (O.elementType === Be || typeof Be == "object" && Be !== null && Be.$$typeof === Ue && Ul(Be) === O.type) ? (me = c(O, P.props), me.ref = Al(z, O, P), me.return = z, me) : (me = of(P.type, P.key, P.props, null, z.mode, me), me.ref = Al(z, O, P), me.return = z, me);
    }
    function V(z, O, P, me) {
      return O === null || O.tag !== 4 || O.stateNode.containerInfo !== P.containerInfo || O.stateNode.implementation !== P.implementation ? (O = sf(P, z.mode, me), O.return = z, O) : (O = c(O, P.children || []), O.return = z, O);
    }
    function se(z, O, P, me, Be) {
      return O === null || O.tag !== 7 ? (O = zo(P, z.mode, me, Be), O.return = z, O) : (O = c(O, P), O.return = z, O);
    }
    function fe(z, O, P) {
      if (typeof O == "string" && O !== "" || typeof O == "number") return O = Jd("" + O, z.mode, P), O.return = z, O;
      if (typeof O == "object" && O !== null) {
        switch (O.$$typeof) {
          case Rt:
            return P = of(O.type, O.key, O.props, null, z.mode, P), P.ref = Al(z, null, O), P.return = z, P;
          case Ne:
            return O = sf(O, z.mode, P), O.return = z, O;
          case Ue:
            var me = O._init;
            return fe(z, me(O._payload), P);
        }
        if (pr(O) || ge(O)) return O = zo(O, z.mode, P, null), O.return = z, O;
        cu(z, O);
      }
      return null;
    }
    function le(z, O, P, me) {
      var Be = O !== null ? O.key : null;
      if (typeof P == "string" && P !== "" || typeof P == "number") return Be !== null ? null : R(z, O, "" + P, me);
      if (typeof P == "object" && P !== null) {
        switch (P.$$typeof) {
          case Rt:
            return P.key === Be ? k(z, O, P, me) : null;
          case Ne:
            return P.key === Be ? V(z, O, P, me) : null;
          case Ue:
            return Be = P._init, le(
              z,
              O,
              Be(P._payload),
              me
            );
        }
        if (pr(P) || ge(P)) return Be !== null ? null : se(z, O, P, me, null);
        cu(z, P);
      }
      return null;
    }
    function _e(z, O, P, me, Be) {
      if (typeof me == "string" && me !== "" || typeof me == "number") return z = z.get(P) || null, R(O, z, "" + me, Be);
      if (typeof me == "object" && me !== null) {
        switch (me.$$typeof) {
          case Rt:
            return z = z.get(me.key === null ? P : me.key) || null, k(O, z, me, Be);
          case Ne:
            return z = z.get(me.key === null ? P : me.key) || null, V(O, z, me, Be);
          case Ue:
            var rt = me._init;
            return _e(z, O, P, rt(me._payload), Be);
        }
        if (pr(me) || ge(me)) return z = z.get(P) || null, se(O, z, me, Be, null);
        cu(O, me);
      }
      return null;
    }
    function ze(z, O, P, me) {
      for (var Be = null, rt = null, at = O, $e = O = 0, _n = null; at !== null && $e < P.length; $e++) {
        at.index > $e ? (_n = at, at = null) : _n = at.sibling;
        var Ft = le(z, at, P[$e], me);
        if (Ft === null) {
          at === null && (at = _n);
          break;
        }
        n && at && Ft.alternate === null && r(z, at), O = d(Ft, O, $e), rt === null ? Be = Ft : rt.sibling = Ft, rt = Ft, at = _n;
      }
      if ($e === P.length) return l(z, at), fn && Co(z, $e), Be;
      if (at === null) {
        for (; $e < P.length; $e++) at = fe(z, P[$e], me), at !== null && (O = d(at, O, $e), rt === null ? Be = at : rt.sibling = at, rt = at);
        return fn && Co(z, $e), Be;
      }
      for (at = u(z, at); $e < P.length; $e++) _n = _e(at, z, $e, P[$e], me), _n !== null && (n && _n.alternate !== null && at.delete(_n.key === null ? $e : _n.key), O = d(_n, O, $e), rt === null ? Be = _n : rt.sibling = _n, rt = _n);
      return n && at.forEach(function(Ql) {
        return r(z, Ql);
      }), fn && Co(z, $e), Be;
    }
    function Pe(z, O, P, me) {
      var Be = ge(P);
      if (typeof Be != "function") throw Error(g(150));
      if (P = Be.call(P), P == null) throw Error(g(151));
      for (var rt = Be = null, at = O, $e = O = 0, _n = null, Ft = P.next(); at !== null && !Ft.done; $e++, Ft = P.next()) {
        at.index > $e ? (_n = at, at = null) : _n = at.sibling;
        var Ql = le(z, at, Ft.value, me);
        if (Ql === null) {
          at === null && (at = _n);
          break;
        }
        n && at && Ql.alternate === null && r(z, at), O = d(Ql, O, $e), rt === null ? Be = Ql : rt.sibling = Ql, rt = Ql, at = _n;
      }
      if (Ft.done) return l(
        z,
        at
      ), fn && Co(z, $e), Be;
      if (at === null) {
        for (; !Ft.done; $e++, Ft = P.next()) Ft = fe(z, Ft.value, me), Ft !== null && (O = d(Ft, O, $e), rt === null ? Be = Ft : rt.sibling = Ft, rt = Ft);
        return fn && Co(z, $e), Be;
      }
      for (at = u(z, at); !Ft.done; $e++, Ft = P.next()) Ft = _e(at, z, $e, Ft.value, me), Ft !== null && (n && Ft.alternate !== null && at.delete(Ft.key === null ? $e : Ft.key), O = d(Ft, O, $e), rt === null ? Be = Ft : rt.sibling = Ft, rt = Ft);
      return n && at.forEach(function(gh) {
        return r(z, gh);
      }), fn && Co(z, $e), Be;
    }
    function Nn(z, O, P, me) {
      if (typeof P == "object" && P !== null && P.type === lt && P.key === null && (P = P.props.children), typeof P == "object" && P !== null) {
        switch (P.$$typeof) {
          case Rt:
            e: {
              for (var Be = P.key, rt = O; rt !== null; ) {
                if (rt.key === Be) {
                  if (Be = P.type, Be === lt) {
                    if (rt.tag === 7) {
                      l(z, rt.sibling), O = c(rt, P.props.children), O.return = z, z = O;
                      break e;
                    }
                  } else if (rt.elementType === Be || typeof Be == "object" && Be !== null && Be.$$typeof === Ue && Ul(Be) === rt.type) {
                    l(z, rt.sibling), O = c(rt, P.props), O.ref = Al(z, rt, P), O.return = z, z = O;
                    break e;
                  }
                  l(z, rt);
                  break;
                } else r(z, rt);
                rt = rt.sibling;
              }
              P.type === lt ? (O = zo(P.props.children, z.mode, me, P.key), O.return = z, z = O) : (me = of(P.type, P.key, P.props, null, z.mode, me), me.ref = Al(z, O, P), me.return = z, z = me);
            }
            return y(z);
          case Ne:
            e: {
              for (rt = P.key; O !== null; ) {
                if (O.key === rt) if (O.tag === 4 && O.stateNode.containerInfo === P.containerInfo && O.stateNode.implementation === P.implementation) {
                  l(z, O.sibling), O = c(O, P.children || []), O.return = z, z = O;
                  break e;
                } else {
                  l(z, O);
                  break;
                }
                else r(z, O);
                O = O.sibling;
              }
              O = sf(P, z.mode, me), O.return = z, z = O;
            }
            return y(z);
          case Ue:
            return rt = P._init, Nn(z, O, rt(P._payload), me);
        }
        if (pr(P)) return ze(z, O, P, me);
        if (ge(P)) return Pe(z, O, P, me);
        cu(z, P);
      }
      return typeof P == "string" && P !== "" || typeof P == "number" ? (P = "" + P, O !== null && O.tag === 6 ? (l(z, O.sibling), O = c(O, P), O.return = z, z = O) : (l(z, O), O = Jd(P, z.mode, me), O.return = z, z = O), y(z)) : l(z, O);
    }
    return Nn;
  }
  var zl = $v(!0), Iv = $v(!1), zc = rn(null), Ji = null, Mn = null, be = null;
  function Pa() {
    be = Mn = Ji = null;
  }
  function ma(n) {
    var r = zc.current;
    He(zc), n._currentValue = r;
  }
  function Sd(n, r, l) {
    for (; n !== null; ) {
      var u = n.alternate;
      if ((n.childLanes & r) !== r ? (n.childLanes |= r, u !== null && (u.childLanes |= r)) : u !== null && (u.childLanes & r) !== r && (u.childLanes |= r), n === l) break;
      n = n.return;
    }
  }
  function fu(n, r) {
    Ji = n, be = Mn = null, n = n.dependencies, n !== null && n.firstContext !== null && (n.lanes & r && (Rr = !0), n.firstContext = null);
  }
  function Ha(n) {
    var r = n._currentValue;
    if (be !== n) if (n = { context: n, memoizedValue: r, next: null }, Mn === null) {
      if (Ji === null) throw Error(g(308));
      Mn = n, Ji.dependencies = { lanes: 0, firstContext: n };
    } else Mn = Mn.next = n;
    return r;
  }
  var bo = null;
  function Ed(n) {
    bo === null ? bo = [n] : bo.push(n);
  }
  function $n(n, r, l, u) {
    var c = r.interleaved;
    return c === null ? (l.next = l, Ed(r)) : (l.next = c.next, c.next = l), r.interleaved = l, Zi(n, u);
  }
  function Zi(n, r) {
    n.lanes |= r;
    var l = n.alternate;
    for (l !== null && (l.lanes |= r), l = n, n = n.return; n !== null; ) n.childLanes |= r, l = n.alternate, l !== null && (l.childLanes |= r), l = n, n = n.return;
    return l.tag === 3 ? l.stateNode : null;
  }
  var Fl = !1;
  function Cd(n) {
    n.updateQueue = { baseState: n.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
  }
  function bd(n, r) {
    n = n.updateQueue, r.updateQueue === n && (r.updateQueue = { baseState: n.baseState, firstBaseUpdate: n.firstBaseUpdate, lastBaseUpdate: n.lastBaseUpdate, shared: n.shared, effects: n.effects });
  }
  function ya(n, r) {
    return { eventTime: n, lane: r, tag: 0, payload: null, callback: null, next: null };
  }
  function ga(n, r, l) {
    var u = n.updateQueue;
    if (u === null) return null;
    if (u = u.shared, zt & 2) {
      var c = u.pending;
      return c === null ? r.next = r : (r.next = c.next, c.next = r), u.pending = r, Zi(n, l);
    }
    return c = u.interleaved, c === null ? (r.next = r, Ed(u)) : (r.next = c.next, c.next = r), u.interleaved = r, Zi(n, l);
  }
  function Fc(n, r, l) {
    if (r = r.updateQueue, r !== null && (r = r.shared, (l & 4194240) !== 0)) {
      var u = r.lanes;
      u &= n.pendingLanes, l |= u, r.lanes = l, rs(n, l);
    }
  }
  function Yv(n, r) {
    var l = n.updateQueue, u = n.alternate;
    if (u !== null && (u = u.updateQueue, l === u)) {
      var c = null, d = null;
      if (l = l.firstBaseUpdate, l !== null) {
        do {
          var y = { eventTime: l.eventTime, lane: l.lane, tag: l.tag, payload: l.payload, callback: l.callback, next: null };
          d === null ? c = d = y : d = d.next = y, l = l.next;
        } while (l !== null);
        d === null ? c = d = r : d = d.next = r;
      } else c = d = r;
      l = { baseState: u.baseState, firstBaseUpdate: c, lastBaseUpdate: d, shared: u.shared, effects: u.effects }, n.updateQueue = l;
      return;
    }
    n = l.lastBaseUpdate, n === null ? l.firstBaseUpdate = r : n.next = r, l.lastBaseUpdate = r;
  }
  function jc(n, r, l, u) {
    var c = n.updateQueue;
    Fl = !1;
    var d = c.firstBaseUpdate, y = c.lastBaseUpdate, R = c.shared.pending;
    if (R !== null) {
      c.shared.pending = null;
      var k = R, V = k.next;
      k.next = null, y === null ? d = V : y.next = V, y = k;
      var se = n.alternate;
      se !== null && (se = se.updateQueue, R = se.lastBaseUpdate, R !== y && (R === null ? se.firstBaseUpdate = V : R.next = V, se.lastBaseUpdate = k));
    }
    if (d !== null) {
      var fe = c.baseState;
      y = 0, se = V = k = null, R = d;
      do {
        var le = R.lane, _e = R.eventTime;
        if ((u & le) === le) {
          se !== null && (se = se.next = {
            eventTime: _e,
            lane: 0,
            tag: R.tag,
            payload: R.payload,
            callback: R.callback,
            next: null
          });
          e: {
            var ze = n, Pe = R;
            switch (le = r, _e = l, Pe.tag) {
              case 1:
                if (ze = Pe.payload, typeof ze == "function") {
                  fe = ze.call(_e, fe, le);
                  break e;
                }
                fe = ze;
                break e;
              case 3:
                ze.flags = ze.flags & -65537 | 128;
              case 0:
                if (ze = Pe.payload, le = typeof ze == "function" ? ze.call(_e, fe, le) : ze, le == null) break e;
                fe = pe({}, fe, le);
                break e;
              case 2:
                Fl = !0;
            }
          }
          R.callback !== null && R.lane !== 0 && (n.flags |= 64, le = c.effects, le === null ? c.effects = [R] : le.push(R));
        } else _e = { eventTime: _e, lane: le, tag: R.tag, payload: R.payload, callback: R.callback, next: null }, se === null ? (V = se = _e, k = fe) : se = se.next = _e, y |= le;
        if (R = R.next, R === null) {
          if (R = c.shared.pending, R === null) break;
          le = R, R = le.next, le.next = null, c.lastBaseUpdate = le, c.shared.pending = null;
        }
      } while (!0);
      if (se === null && (k = fe), c.baseState = k, c.firstBaseUpdate = V, c.lastBaseUpdate = se, r = c.shared.interleaved, r !== null) {
        c = r;
        do
          y |= c.lane, c = c.next;
        while (c !== r);
      } else d === null && (c.shared.lanes = 0);
      Do |= y, n.lanes = y, n.memoizedState = fe;
    }
  }
  function Wv(n, r, l) {
    if (n = r.effects, r.effects = null, n !== null) for (r = 0; r < n.length; r++) {
      var u = n[r], c = u.callback;
      if (c !== null) {
        if (u.callback = null, u = l, typeof c != "function") throw Error(g(191, c));
        c.call(u);
      }
    }
  }
  var xs = {}, Si = rn(xs), du = rn(xs), pu = rn(xs);
  function To(n) {
    if (n === xs) throw Error(g(174));
    return n;
  }
  function Td(n, r) {
    switch (Ht(pu, r), Ht(du, n), Ht(Si, xs), n = r.nodeType, n) {
      case 9:
      case 11:
        r = (r = r.documentElement) ? r.namespaceURI : Er(null, "");
        break;
      default:
        n = n === 8 ? r.parentNode : r, r = n.namespaceURI || null, n = n.tagName, r = Er(r, n);
    }
    He(Si), Ht(Si, r);
  }
  function vu() {
    He(Si), He(du), He(pu);
  }
  function Qv(n) {
    To(pu.current);
    var r = To(Si.current), l = Er(r, n.type);
    r !== l && (Ht(du, n), Ht(Si, l));
  }
  function Rd(n) {
    du.current === n && (He(Si), He(du));
  }
  var En = rn(0);
  function _s(n) {
    for (var r = n; r !== null; ) {
      if (r.tag === 13) {
        var l = r.memoizedState;
        if (l !== null && (l = l.dehydrated, l === null || l.data === "$?" || l.data === "$!")) return r;
      } else if (r.tag === 19 && r.memoizedProps.revealOrder !== void 0) {
        if (r.flags & 128) return r;
      } else if (r.child !== null) {
        r.child.return = r, r = r.child;
        continue;
      }
      if (r === n) break;
      for (; r.sibling === null; ) {
        if (r.return === null || r.return === n) return null;
        r = r.return;
      }
      r.sibling.return = r.return, r = r.sibling;
    }
    return null;
  }
  var wd = [];
  function Pc() {
    for (var n = 0; n < wd.length; n++) wd[n]._workInProgressVersionPrimary = null;
    wd.length = 0;
  }
  var Hc = Ge.ReactCurrentDispatcher, xd = Ge.ReactCurrentBatchConfig, el = 0, Ce = null, qe = null, pt = null, dn = !1, qr = !1, hu = 0, by = 0;
  function gr() {
    throw Error(g(321));
  }
  function _d(n, r) {
    if (r === null) return !1;
    for (var l = 0; l < r.length && l < n.length; l++) if (!ti(n[l], r[l])) return !1;
    return !0;
  }
  function ks(n, r, l, u, c, d) {
    if (el = d, Ce = r, r.memoizedState = null, r.updateQueue = null, r.lanes = 0, Hc.current = n === null || n.memoizedState === null ? Sa : Ty, n = l(u, c), qr) {
      d = 0;
      do {
        if (qr = !1, hu = 0, 25 <= d) throw Error(g(301));
        d += 1, pt = qe = null, r.updateQueue = null, Hc.current = on, n = l(u, c);
      } while (qr);
    }
    if (Hc.current = Ci, r = qe !== null && qe.next !== null, el = 0, pt = qe = Ce = null, dn = !1, r) throw Error(g(300));
    return n;
  }
  function ie() {
    var n = hu !== 0;
    return hu = 0, n;
  }
  function an() {
    var n = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
    return pt === null ? Ce.memoizedState = pt = n : pt = pt.next = n, pt;
  }
  function Ve() {
    if (qe === null) {
      var n = Ce.alternate;
      n = n !== null ? n.memoizedState : null;
    } else n = qe.next;
    var r = pt === null ? Ce.memoizedState : pt.next;
    if (r !== null) pt = r, qe = n;
    else {
      if (n === null) throw Error(g(310));
      qe = n, n = { memoizedState: qe.memoizedState, baseState: qe.baseState, baseQueue: qe.baseQueue, queue: qe.queue, next: null }, pt === null ? Ce.memoizedState = pt = n : pt = pt.next = n;
    }
    return pt;
  }
  function Ei(n, r) {
    return typeof r == "function" ? r(n) : r;
  }
  function ii(n) {
    var r = Ve(), l = r.queue;
    if (l === null) throw Error(g(311));
    l.lastRenderedReducer = n;
    var u = qe, c = u.baseQueue, d = l.pending;
    if (d !== null) {
      if (c !== null) {
        var y = c.next;
        c.next = d.next, d.next = y;
      }
      u.baseQueue = c = d, l.pending = null;
    }
    if (c !== null) {
      d = c.next, u = u.baseState;
      var R = y = null, k = null, V = d;
      do {
        var se = V.lane;
        if ((el & se) === se) k !== null && (k = k.next = { lane: 0, action: V.action, hasEagerState: V.hasEagerState, eagerState: V.eagerState, next: null }), u = V.hasEagerState ? V.eagerState : n(u, V.action);
        else {
          var fe = {
            lane: se,
            action: V.action,
            hasEagerState: V.hasEagerState,
            eagerState: V.eagerState,
            next: null
          };
          k === null ? (R = k = fe, y = u) : k = k.next = fe, Ce.lanes |= se, Do |= se;
        }
        V = V.next;
      } while (V !== null && V !== d);
      k === null ? y = u : k.next = R, ti(u, r.memoizedState) || (Rr = !0), r.memoizedState = u, r.baseState = y, r.baseQueue = k, l.lastRenderedState = u;
    }
    if (n = l.interleaved, n !== null) {
      c = n;
      do
        d = c.lane, Ce.lanes |= d, Do |= d, c = c.next;
      while (c !== n);
    } else c === null && (l.lanes = 0);
    return [r.memoizedState, l.dispatch];
  }
  function tl(n) {
    var r = Ve(), l = r.queue;
    if (l === null) throw Error(g(311));
    l.lastRenderedReducer = n;
    var u = l.dispatch, c = l.pending, d = r.memoizedState;
    if (c !== null) {
      l.pending = null;
      var y = c = c.next;
      do
        d = n(d, y.action), y = y.next;
      while (y !== c);
      ti(d, r.memoizedState) || (Rr = !0), r.memoizedState = d, r.baseQueue === null && (r.baseState = d), l.lastRenderedState = d;
    }
    return [d, u];
  }
  function li() {
  }
  function mu(n, r) {
    var l = Ce, u = Ve(), c = r(), d = !ti(u.memoizedState, c);
    if (d && (u.memoizedState = c, Rr = !0), u = u.queue, Ds(Bc.bind(null, l, u, n), [n]), u.getSnapshot !== r || d || pt !== null && pt.memoizedState.tag & 1) {
      if (l.flags |= 2048, wo(9, yu.bind(null, l, u, c, r), void 0, null), Rn === null) throw Error(g(349));
      el & 30 || Ro(l, r, c);
    }
    return c;
  }
  function Ro(n, r, l) {
    n.flags |= 16384, n = { getSnapshot: r, value: l }, r = Ce.updateQueue, r === null ? (r = { lastEffect: null, stores: null }, Ce.updateQueue = r, r.stores = [n]) : (l = r.stores, l === null ? r.stores = [n] : l.push(n));
  }
  function yu(n, r, l, u) {
    r.value = l, r.getSnapshot = u, Vc(r) && $c(n);
  }
  function Bc(n, r, l) {
    return l(function() {
      Vc(r) && $c(n);
    });
  }
  function Vc(n) {
    var r = n.getSnapshot;
    n = n.value;
    try {
      var l = r();
      return !ti(n, l);
    } catch {
      return !0;
    }
  }
  function $c(n) {
    var r = Zi(n, 1);
    r !== null && Ba(r, n, 1, -1);
  }
  function Ic(n) {
    var r = an();
    return typeof n == "function" && (n = n()), r.memoizedState = r.baseState = n, n = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: Ei, lastRenderedState: n }, r.queue = n, n = n.dispatch = Gv.bind(null, Ce, n), [r.memoizedState, n];
  }
  function wo(n, r, l, u) {
    return n = { tag: n, create: r, destroy: l, deps: u, next: null }, r = Ce.updateQueue, r === null ? (r = { lastEffect: null, stores: null }, Ce.updateQueue = r, r.lastEffect = n.next = n) : (l = r.lastEffect, l === null ? r.lastEffect = n.next = n : (u = l.next, l.next = n, n.next = u, r.lastEffect = n)), n;
  }
  function Yc() {
    return Ve().memoizedState;
  }
  function gu(n, r, l, u) {
    var c = an();
    Ce.flags |= n, c.memoizedState = wo(1 | r, l, void 0, u === void 0 ? null : u);
  }
  function Su(n, r, l, u) {
    var c = Ve();
    u = u === void 0 ? null : u;
    var d = void 0;
    if (qe !== null) {
      var y = qe.memoizedState;
      if (d = y.destroy, u !== null && _d(u, y.deps)) {
        c.memoizedState = wo(r, l, d, u);
        return;
      }
    }
    Ce.flags |= n, c.memoizedState = wo(1 | r, l, d, u);
  }
  function Wc(n, r) {
    return gu(8390656, 8, n, r);
  }
  function Ds(n, r) {
    return Su(2048, 8, n, r);
  }
  function Qc(n, r) {
    return Su(4, 2, n, r);
  }
  function Gc(n, r) {
    return Su(4, 4, n, r);
  }
  function Kc(n, r) {
    if (typeof r == "function") return n = n(), r(n), function() {
      r(null);
    };
    if (r != null) return n = n(), r.current = n, function() {
      r.current = null;
    };
  }
  function qc(n, r, l) {
    return l = l != null ? l.concat([n]) : null, Su(4, 4, Kc.bind(null, r, n), l);
  }
  function Os() {
  }
  function Ms(n, r) {
    var l = Ve();
    r = r === void 0 ? null : r;
    var u = l.memoizedState;
    return u !== null && r !== null && _d(r, u[1]) ? u[0] : (l.memoizedState = [n, r], n);
  }
  function xo(n, r) {
    var l = Ve();
    r = r === void 0 ? null : r;
    var u = l.memoizedState;
    return u !== null && r !== null && _d(r, u[1]) ? u[0] : (n = n(), l.memoizedState = [n, r], n);
  }
  function Xc(n, r, l) {
    return el & 21 ? (ti(l, r) || (l = uo(), Ce.lanes |= l, Do |= l, n.baseState = !0), r) : (n.baseState && (n.baseState = !1, Rr = !0), n.memoizedState = l);
  }
  function kd(n, r) {
    var l = kt;
    kt = l !== 0 && 4 > l ? l : 4, n(!0);
    var u = xd.transition;
    xd.transition = {};
    try {
      n(!1), r();
    } finally {
      kt = l, xd.transition = u;
    }
  }
  function Jc() {
    return Ve().memoizedState;
  }
  function Dd(n, r, l) {
    var u = ui(n);
    if (l = { lane: u, action: l, hasEagerState: !1, eagerState: null, next: null }, Eu(n)) Od(r, l);
    else if (l = $n(n, r, l, u), l !== null) {
      var c = qn();
      Ba(l, n, u, c), Cu(l, r, u);
    }
  }
  function Gv(n, r, l) {
    var u = ui(n), c = { lane: u, action: l, hasEagerState: !1, eagerState: null, next: null };
    if (Eu(n)) Od(r, c);
    else {
      var d = n.alternate;
      if (n.lanes === 0 && (d === null || d.lanes === 0) && (d = r.lastRenderedReducer, d !== null)) try {
        var y = r.lastRenderedState, R = d(y, l);
        if (c.hasEagerState = !0, c.eagerState = R, ti(R, y)) {
          var k = r.interleaved;
          k === null ? (c.next = c, Ed(r)) : (c.next = k.next, k.next = c), r.interleaved = c;
          return;
        }
      } catch {
      } finally {
      }
      l = $n(n, r, c, u), l !== null && (c = qn(), Ba(l, n, u, c), Cu(l, r, u));
    }
  }
  function Eu(n) {
    var r = n.alternate;
    return n === Ce || r !== null && r === Ce;
  }
  function Od(n, r) {
    qr = dn = !0;
    var l = n.pending;
    l === null ? r.next = r : (r.next = l.next, l.next = r), n.pending = r;
  }
  function Cu(n, r, l) {
    if (l & 4194240) {
      var u = r.lanes;
      u &= n.pendingLanes, l |= u, r.lanes = l, rs(n, l);
    }
  }
  var Ci = { readContext: Ha, useCallback: gr, useContext: gr, useEffect: gr, useImperativeHandle: gr, useInsertionEffect: gr, useLayoutEffect: gr, useMemo: gr, useReducer: gr, useRef: gr, useState: gr, useDebugValue: gr, useDeferredValue: gr, useTransition: gr, useMutableSource: gr, useSyncExternalStore: gr, useId: gr, unstable_isNewReconciler: !1 }, Sa = { readContext: Ha, useCallback: function(n, r) {
    return an().memoizedState = [n, r === void 0 ? null : r], n;
  }, useContext: Ha, useEffect: Wc, useImperativeHandle: function(n, r, l) {
    return l = l != null ? l.concat([n]) : null, gu(
      4194308,
      4,
      Kc.bind(null, r, n),
      l
    );
  }, useLayoutEffect: function(n, r) {
    return gu(4194308, 4, n, r);
  }, useInsertionEffect: function(n, r) {
    return gu(4, 2, n, r);
  }, useMemo: function(n, r) {
    var l = an();
    return r = r === void 0 ? null : r, n = n(), l.memoizedState = [n, r], n;
  }, useReducer: function(n, r, l) {
    var u = an();
    return r = l !== void 0 ? l(r) : r, u.memoizedState = u.baseState = r, n = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: n, lastRenderedState: r }, u.queue = n, n = n.dispatch = Dd.bind(null, Ce, n), [u.memoizedState, n];
  }, useRef: function(n) {
    var r = an();
    return n = { current: n }, r.memoizedState = n;
  }, useState: Ic, useDebugValue: Os, useDeferredValue: function(n) {
    return an().memoizedState = n;
  }, useTransition: function() {
    var n = Ic(!1), r = n[0];
    return n = kd.bind(null, n[1]), an().memoizedState = n, [r, n];
  }, useMutableSource: function() {
  }, useSyncExternalStore: function(n, r, l) {
    var u = Ce, c = an();
    if (fn) {
      if (l === void 0) throw Error(g(407));
      l = l();
    } else {
      if (l = r(), Rn === null) throw Error(g(349));
      el & 30 || Ro(u, r, l);
    }
    c.memoizedState = l;
    var d = { value: l, getSnapshot: r };
    return c.queue = d, Wc(Bc.bind(
      null,
      u,
      d,
      n
    ), [n]), u.flags |= 2048, wo(9, yu.bind(null, u, d, l, r), void 0, null), l;
  }, useId: function() {
    var n = an(), r = Rn.identifierPrefix;
    if (fn) {
      var l = nr, u = Kr;
      l = (u & ~(1 << 32 - br(u) - 1)).toString(32) + l, r = ":" + r + "R" + l, l = hu++, 0 < l && (r += "H" + l.toString(32)), r += ":";
    } else l = by++, r = ":" + r + "r" + l.toString(32) + ":";
    return n.memoizedState = r;
  }, unstable_isNewReconciler: !1 }, Ty = {
    readContext: Ha,
    useCallback: Ms,
    useContext: Ha,
    useEffect: Ds,
    useImperativeHandle: qc,
    useInsertionEffect: Qc,
    useLayoutEffect: Gc,
    useMemo: xo,
    useReducer: ii,
    useRef: Yc,
    useState: function() {
      return ii(Ei);
    },
    useDebugValue: Os,
    useDeferredValue: function(n) {
      var r = Ve();
      return Xc(r, qe.memoizedState, n);
    },
    useTransition: function() {
      var n = ii(Ei)[0], r = Ve().memoizedState;
      return [n, r];
    },
    useMutableSource: li,
    useSyncExternalStore: mu,
    useId: Jc,
    unstable_isNewReconciler: !1
  }, on = { readContext: Ha, useCallback: Ms, useContext: Ha, useEffect: Ds, useImperativeHandle: qc, useInsertionEffect: Qc, useLayoutEffect: Gc, useMemo: xo, useReducer: tl, useRef: Yc, useState: function() {
    return tl(Ei);
  }, useDebugValue: Os, useDeferredValue: function(n) {
    var r = Ve();
    return qe === null ? r.memoizedState = n : Xc(r, qe.memoizedState, n);
  }, useTransition: function() {
    var n = tl(Ei)[0], r = Ve().memoizedState;
    return [n, r];
  }, useMutableSource: li, useSyncExternalStore: mu, useId: Jc, unstable_isNewReconciler: !1 };
  function Xr(n, r) {
    if (n && n.defaultProps) {
      r = pe({}, r), n = n.defaultProps;
      for (var l in n) r[l] === void 0 && (r[l] = n[l]);
      return r;
    }
    return r;
  }
  function bu(n, r, l, u) {
    r = n.memoizedState, l = l(u, r), l = l == null ? r : pe({}, r, l), n.memoizedState = l, n.lanes === 0 && (n.updateQueue.baseState = l);
  }
  var jl = { isMounted: function(n) {
    return (n = n._reactInternals) ? ce(n) === n : !1;
  }, enqueueSetState: function(n, r, l) {
    n = n._reactInternals;
    var u = qn(), c = ui(n), d = ya(u, c);
    d.payload = r, l != null && (d.callback = l), r = ga(n, d, c), r !== null && (Ba(r, n, c, u), Fc(r, n, c));
  }, enqueueReplaceState: function(n, r, l) {
    n = n._reactInternals;
    var u = qn(), c = ui(n), d = ya(u, c);
    d.tag = 1, d.payload = r, l != null && (d.callback = l), r = ga(n, d, c), r !== null && (Ba(r, n, c, u), Fc(r, n, c));
  }, enqueueForceUpdate: function(n, r) {
    n = n._reactInternals;
    var l = qn(), u = ui(n), c = ya(l, u);
    c.tag = 2, r != null && (c.callback = r), r = ga(n, c, u), r !== null && (Ba(r, n, u, l), Fc(r, n, u));
  } };
  function Ns(n, r, l, u, c, d, y) {
    return n = n.stateNode, typeof n.shouldComponentUpdate == "function" ? n.shouldComponentUpdate(u, d, y) : r.prototype && r.prototype.isPureReactComponent ? !iu(l, u) || !iu(c, d) : !0;
  }
  function Kv(n, r, l) {
    var u = !1, c = Ua, d = r.contextType;
    return typeof d == "object" && d !== null ? d = Ha(d) : (c = Fn(r) ? Tr : Qn.current, u = r.contextTypes, d = (u = u != null) ? pa(n, c) : Ua), r = new r(l, d), n.memoizedState = r.state !== null && r.state !== void 0 ? r.state : null, r.updater = jl, n.stateNode = r, r._reactInternals = n, u && (n = n.stateNode, n.__reactInternalMemoizedUnmaskedChildContext = c, n.__reactInternalMemoizedMaskedChildContext = d), r;
  }
  function qv(n, r, l, u) {
    n = r.state, typeof r.componentWillReceiveProps == "function" && r.componentWillReceiveProps(l, u), typeof r.UNSAFE_componentWillReceiveProps == "function" && r.UNSAFE_componentWillReceiveProps(l, u), r.state !== n && jl.enqueueReplaceState(r, r.state, null);
  }
  function Md(n, r, l, u) {
    var c = n.stateNode;
    c.props = l, c.state = n.memoizedState, c.refs = {}, Cd(n);
    var d = r.contextType;
    typeof d == "object" && d !== null ? c.context = Ha(d) : (d = Fn(r) ? Tr : Qn.current, c.context = pa(n, d)), c.state = n.memoizedState, d = r.getDerivedStateFromProps, typeof d == "function" && (bu(n, r, d, l), c.state = n.memoizedState), typeof r.getDerivedStateFromProps == "function" || typeof c.getSnapshotBeforeUpdate == "function" || typeof c.UNSAFE_componentWillMount != "function" && typeof c.componentWillMount != "function" || (r = c.state, typeof c.componentWillMount == "function" && c.componentWillMount(), typeof c.UNSAFE_componentWillMount == "function" && c.UNSAFE_componentWillMount(), r !== c.state && jl.enqueueReplaceState(c, c.state, null), jc(n, l, c, u), c.state = n.memoizedState), typeof c.componentDidMount == "function" && (n.flags |= 4194308);
  }
  function Tu(n, r) {
    try {
      var l = "", u = r;
      do
        l += st(u), u = u.return;
      while (u);
      var c = l;
    } catch (d) {
      c = `
Error generating stack: ` + d.message + `
` + d.stack;
    }
    return { value: n, source: r, stack: c, digest: null };
  }
  function Ls(n, r, l) {
    return { value: n, source: null, stack: l ?? null, digest: r ?? null };
  }
  function Nd(n, r) {
    try {
      console.error(r.value);
    } catch (l) {
      setTimeout(function() {
        throw l;
      });
    }
  }
  var Ld = typeof WeakMap == "function" ? WeakMap : Map;
  function Ad(n, r, l) {
    l = ya(-1, l), l.tag = 3, l.payload = { element: null };
    var u = r.value;
    return l.callback = function() {
      af || (af = !0, Qd = u), Nd(n, r);
    }, l;
  }
  function Xv(n, r, l) {
    l = ya(-1, l), l.tag = 3;
    var u = n.type.getDerivedStateFromError;
    if (typeof u == "function") {
      var c = r.value;
      l.payload = function() {
        return u(c);
      }, l.callback = function() {
        Nd(n, r);
      };
    }
    var d = n.stateNode;
    return d !== null && typeof d.componentDidCatch == "function" && (l.callback = function() {
      Nd(n, r), typeof u != "function" && (Vl === null ? Vl = /* @__PURE__ */ new Set([this]) : Vl.add(this));
      var y = r.stack;
      this.componentDidCatch(r.value, { componentStack: y !== null ? y : "" });
    }), l;
  }
  function Jv(n, r, l) {
    var u = n.pingCache;
    if (u === null) {
      u = n.pingCache = new Ld();
      var c = /* @__PURE__ */ new Set();
      u.set(r, c);
    } else c = u.get(r), c === void 0 && (c = /* @__PURE__ */ new Set(), u.set(r, c));
    c.has(l) || (c.add(l), n = Ny.bind(null, n, r, l), r.then(n, n));
  }
  function As(n) {
    do {
      var r;
      if ((r = n.tag === 13) && (r = n.memoizedState, r = r !== null ? r.dehydrated !== null : !0), r) return n;
      n = n.return;
    } while (n !== null);
    return null;
  }
  function Zv(n, r, l, u, c) {
    return n.mode & 1 ? (n.flags |= 65536, n.lanes = c, n) : (n === r ? n.flags |= 65536 : (n.flags |= 128, l.flags |= 131072, l.flags &= -52805, l.tag === 1 && (l.alternate === null ? l.tag = 17 : (r = ya(-1, 1), r.tag = 2, ga(l, r, 1))), l.lanes |= 1), n);
  }
  var eh = Ge.ReactCurrentOwner, Rr = !1;
  function wr(n, r, l, u) {
    r.child = n === null ? Iv(r, null, l, u) : zl(r, n.child, l, u);
  }
  function Pl(n, r, l, u, c) {
    l = l.render;
    var d = r.ref;
    return fu(r, c), u = ks(n, r, l, u, d, c), l = ie(), n !== null && !Rr ? (r.updateQueue = n.updateQueue, r.flags &= -2053, n.lanes &= ~c, bi(n, r, c)) : (fn && l && Nc(r), r.flags |= 1, wr(n, r, u, c), r.child);
  }
  function Ru(n, r, l, u, c) {
    if (n === null) {
      var d = l.type;
      return typeof d == "function" && !Xd(d) && d.defaultProps === void 0 && l.compare === null && l.defaultProps === void 0 ? (r.tag = 15, r.type = d, Hl(n, r, d, u, c)) : (n = of(l.type, null, u, r, r.mode, c), n.ref = r.ref, n.return = r, r.child = n);
    }
    if (d = n.child, !(n.lanes & c)) {
      var y = d.memoizedProps;
      if (l = l.compare, l = l !== null ? l : iu, l(y, u) && n.ref === r.ref) return bi(n, r, c);
    }
    return r.flags |= 1, n = Wl(d, u), n.ref = r.ref, n.return = r, r.child = n;
  }
  function Hl(n, r, l, u, c) {
    if (n !== null) {
      var d = n.memoizedProps;
      if (iu(d, u) && n.ref === r.ref) if (Rr = !1, r.pendingProps = u = d, (n.lanes & c) !== 0) n.flags & 131072 && (Rr = !0);
      else return r.lanes = n.lanes, bi(n, r, c);
    }
    return Bl(n, r, l, u, c);
  }
  function Zc(n, r, l) {
    var u = r.pendingProps, c = u.children, d = n !== null ? n.memoizedState : null;
    if (u.mode === "hidden") if (!(r.mode & 1)) r.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, Ht(ko, Dr), Dr |= l;
    else {
      if (!(l & 1073741824)) return n = d !== null ? d.baseLanes | l : l, r.lanes = r.childLanes = 1073741824, r.memoizedState = { baseLanes: n, cachePool: null, transitions: null }, r.updateQueue = null, Ht(ko, Dr), Dr |= n, null;
      r.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, u = d !== null ? d.baseLanes : l, Ht(ko, Dr), Dr |= u;
    }
    else d !== null ? (u = d.baseLanes | l, r.memoizedState = null) : u = l, Ht(ko, Dr), Dr |= u;
    return wr(n, r, c, l), r.child;
  }
  function Jr(n, r) {
    var l = r.ref;
    (n === null && l !== null || n !== null && n.ref !== l) && (r.flags |= 512, r.flags |= 2097152);
  }
  function Bl(n, r, l, u, c) {
    var d = Fn(l) ? Tr : Qn.current;
    return d = pa(r, d), fu(r, c), l = ks(n, r, l, u, d, c), u = ie(), n !== null && !Rr ? (r.updateQueue = n.updateQueue, r.flags &= -2053, n.lanes &= ~c, bi(n, r, c)) : (fn && u && Nc(r), r.flags |= 1, wr(n, r, l, c), r.child);
  }
  function gt(n, r, l, u, c) {
    if (Fn(l)) {
      var d = !0;
      So(r);
    } else d = !1;
    if (fu(r, c), r.stateNode === null) Fs(n, r), Kv(r, l, u), Md(r, l, u, c), u = !0;
    else if (n === null) {
      var y = r.stateNode, R = r.memoizedProps;
      y.props = R;
      var k = y.context, V = l.contextType;
      typeof V == "object" && V !== null ? V = Ha(V) : (V = Fn(l) ? Tr : Qn.current, V = pa(r, V));
      var se = l.getDerivedStateFromProps, fe = typeof se == "function" || typeof y.getSnapshotBeforeUpdate == "function";
      fe || typeof y.UNSAFE_componentWillReceiveProps != "function" && typeof y.componentWillReceiveProps != "function" || (R !== u || k !== V) && qv(r, y, u, V), Fl = !1;
      var le = r.memoizedState;
      y.state = le, jc(r, u, y, c), k = r.memoizedState, R !== u || le !== k || vt.current || Fl ? (typeof se == "function" && (bu(r, l, se, u), k = r.memoizedState), (R = Fl || Ns(r, l, R, u, le, k, V)) ? (fe || typeof y.UNSAFE_componentWillMount != "function" && typeof y.componentWillMount != "function" || (typeof y.componentWillMount == "function" && y.componentWillMount(), typeof y.UNSAFE_componentWillMount == "function" && y.UNSAFE_componentWillMount()), typeof y.componentDidMount == "function" && (r.flags |= 4194308)) : (typeof y.componentDidMount == "function" && (r.flags |= 4194308), r.memoizedProps = u, r.memoizedState = k), y.props = u, y.state = k, y.context = V, u = R) : (typeof y.componentDidMount == "function" && (r.flags |= 4194308), u = !1);
    } else {
      y = r.stateNode, bd(n, r), R = r.memoizedProps, V = r.type === r.elementType ? R : Xr(r.type, R), y.props = V, fe = r.pendingProps, le = y.context, k = l.contextType, typeof k == "object" && k !== null ? k = Ha(k) : (k = Fn(l) ? Tr : Qn.current, k = pa(r, k));
      var _e = l.getDerivedStateFromProps;
      (se = typeof _e == "function" || typeof y.getSnapshotBeforeUpdate == "function") || typeof y.UNSAFE_componentWillReceiveProps != "function" && typeof y.componentWillReceiveProps != "function" || (R !== fe || le !== k) && qv(r, y, u, k), Fl = !1, le = r.memoizedState, y.state = le, jc(r, u, y, c);
      var ze = r.memoizedState;
      R !== fe || le !== ze || vt.current || Fl ? (typeof _e == "function" && (bu(r, l, _e, u), ze = r.memoizedState), (V = Fl || Ns(r, l, V, u, le, ze, k) || !1) ? (se || typeof y.UNSAFE_componentWillUpdate != "function" && typeof y.componentWillUpdate != "function" || (typeof y.componentWillUpdate == "function" && y.componentWillUpdate(u, ze, k), typeof y.UNSAFE_componentWillUpdate == "function" && y.UNSAFE_componentWillUpdate(u, ze, k)), typeof y.componentDidUpdate == "function" && (r.flags |= 4), typeof y.getSnapshotBeforeUpdate == "function" && (r.flags |= 1024)) : (typeof y.componentDidUpdate != "function" || R === n.memoizedProps && le === n.memoizedState || (r.flags |= 4), typeof y.getSnapshotBeforeUpdate != "function" || R === n.memoizedProps && le === n.memoizedState || (r.flags |= 1024), r.memoizedProps = u, r.memoizedState = ze), y.props = u, y.state = ze, y.context = k, u = V) : (typeof y.componentDidUpdate != "function" || R === n.memoizedProps && le === n.memoizedState || (r.flags |= 4), typeof y.getSnapshotBeforeUpdate != "function" || R === n.memoizedProps && le === n.memoizedState || (r.flags |= 1024), u = !1);
    }
    return wu(n, r, l, u, d, c);
  }
  function wu(n, r, l, u, c, d) {
    Jr(n, r);
    var y = (r.flags & 128) !== 0;
    if (!u && !y) return c && Hv(r, l, !1), bi(n, r, d);
    u = r.stateNode, eh.current = r;
    var R = y && typeof l.getDerivedStateFromError != "function" ? null : u.render();
    return r.flags |= 1, n !== null && y ? (r.child = zl(r, n.child, null, d), r.child = zl(r, null, R, d)) : wr(n, r, R, d), r.memoizedState = u.state, c && Hv(r, l, !0), r.child;
  }
  function Ud(n) {
    var r = n.stateNode;
    r.pendingContext ? yi(n, r.pendingContext, r.pendingContext !== r.context) : r.context && yi(n, r.context, !1), Td(n, r.containerInfo);
  }
  function Ry(n, r, l, u, c) {
    return su(), jn(c), r.flags |= 256, wr(n, r, l, u), r.child;
  }
  var zd = { dehydrated: null, treeContext: null, retryLane: 0 };
  function Us(n) {
    return { baseLanes: n, cachePool: null, transitions: null };
  }
  function xu(n, r, l) {
    var u = r.pendingProps, c = En.current, d = !1, y = (r.flags & 128) !== 0, R;
    if ((R = y) || (R = n !== null && n.memoizedState === null ? !1 : (c & 2) !== 0), R ? (d = !0, r.flags &= -129) : (n === null || n.memoizedState !== null) && (c |= 1), Ht(En, c & 1), n === null)
      return Ac(r), n = r.memoizedState, n !== null && (n = n.dehydrated, n !== null) ? (r.mode & 1 ? n.data === "$!" ? r.lanes = 8 : r.lanes = 1073741824 : r.lanes = 1, null) : (y = u.children, n = u.fallback, d ? (u = r.mode, d = r.child, y = { mode: "hidden", children: y }, !(u & 1) && d !== null ? (d.childLanes = 0, d.pendingProps = y) : d = uf(y, u, 0, null), n = zo(n, u, l, null), d.return = r, n.return = r, d.sibling = n, r.child = d, r.child.memoizedState = Us(l), r.memoizedState = zd, n) : Fd(r, y));
    if (c = n.memoizedState, c !== null && (R = c.dehydrated, R !== null)) return wy(n, r, y, u, R, c, l);
    if (d) {
      d = u.fallback, y = r.mode, c = n.child, R = c.sibling;
      var k = { mode: "hidden", children: u.children };
      return !(y & 1) && r.child !== c ? (u = r.child, u.childLanes = 0, u.pendingProps = k, r.deletions = null) : (u = Wl(c, k), u.subtreeFlags = c.subtreeFlags & 14680064), R !== null ? d = Wl(R, d) : (d = zo(d, y, l, null), d.flags |= 2), d.return = r, u.return = r, u.sibling = d, r.child = u, u = d, d = r.child, y = n.child.memoizedState, y = y === null ? Us(l) : { baseLanes: y.baseLanes | l, cachePool: null, transitions: y.transitions }, d.memoizedState = y, d.childLanes = n.childLanes & ~l, r.memoizedState = zd, u;
    }
    return d = n.child, n = d.sibling, u = Wl(d, { mode: "visible", children: u.children }), !(r.mode & 1) && (u.lanes = l), u.return = r, u.sibling = null, n !== null && (l = r.deletions, l === null ? (r.deletions = [n], r.flags |= 16) : l.push(n)), r.child = u, r.memoizedState = null, u;
  }
  function Fd(n, r) {
    return r = uf({ mode: "visible", children: r }, n.mode, 0, null), r.return = n, n.child = r;
  }
  function zs(n, r, l, u) {
    return u !== null && jn(u), zl(r, n.child, null, l), n = Fd(r, r.pendingProps.children), n.flags |= 2, r.memoizedState = null, n;
  }
  function wy(n, r, l, u, c, d, y) {
    if (l)
      return r.flags & 256 ? (r.flags &= -257, u = Ls(Error(g(422))), zs(n, r, y, u)) : r.memoizedState !== null ? (r.child = n.child, r.flags |= 128, null) : (d = u.fallback, c = r.mode, u = uf({ mode: "visible", children: u.children }, c, 0, null), d = zo(d, c, y, null), d.flags |= 2, u.return = r, d.return = r, u.sibling = d, r.child = u, r.mode & 1 && zl(r, n.child, null, y), r.child.memoizedState = Us(y), r.memoizedState = zd, d);
    if (!(r.mode & 1)) return zs(n, r, y, null);
    if (c.data === "$!") {
      if (u = c.nextSibling && c.nextSibling.dataset, u) var R = u.dgst;
      return u = R, d = Error(g(419)), u = Ls(d, u, void 0), zs(n, r, y, u);
    }
    if (R = (y & n.childLanes) !== 0, Rr || R) {
      if (u = Rn, u !== null) {
        switch (y & -y) {
          case 4:
            c = 2;
            break;
          case 16:
            c = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            c = 32;
            break;
          case 536870912:
            c = 268435456;
            break;
          default:
            c = 0;
        }
        c = c & (u.suspendedLanes | y) ? 0 : c, c !== 0 && c !== d.retryLane && (d.retryLane = c, Zi(n, c), Ba(u, n, c, -1));
      }
      return Kd(), u = Ls(Error(g(421))), zs(n, r, y, u);
    }
    return c.data === "$?" ? (r.flags |= 128, r.child = n.child, r = Ly.bind(null, n), c._reactRetry = r, null) : (n = d.treeContext, ha = da(c.nextSibling), va = r, fn = !0, ja = null, n !== null && (Qr[Gr++] = Kr, Qr[Gr++] = nr, Qr[Gr++] = ai, Kr = n.id, nr = n.overflow, ai = r), r = Fd(r, u.children), r.flags |= 4096, r);
  }
  function ef(n, r, l) {
    n.lanes |= r;
    var u = n.alternate;
    u !== null && (u.lanes |= r), Sd(n.return, r, l);
  }
  function jd(n, r, l, u, c) {
    var d = n.memoizedState;
    d === null ? n.memoizedState = { isBackwards: r, rendering: null, renderingStartTime: 0, last: u, tail: l, tailMode: c } : (d.isBackwards = r, d.rendering = null, d.renderingStartTime = 0, d.last = u, d.tail = l, d.tailMode = c);
  }
  function Pd(n, r, l) {
    var u = r.pendingProps, c = u.revealOrder, d = u.tail;
    if (wr(n, r, u.children, l), u = En.current, u & 2) u = u & 1 | 2, r.flags |= 128;
    else {
      if (n !== null && n.flags & 128) e: for (n = r.child; n !== null; ) {
        if (n.tag === 13) n.memoizedState !== null && ef(n, l, r);
        else if (n.tag === 19) ef(n, l, r);
        else if (n.child !== null) {
          n.child.return = n, n = n.child;
          continue;
        }
        if (n === r) break e;
        for (; n.sibling === null; ) {
          if (n.return === null || n.return === r) break e;
          n = n.return;
        }
        n.sibling.return = n.return, n = n.sibling;
      }
      u &= 1;
    }
    if (Ht(En, u), !(r.mode & 1)) r.memoizedState = null;
    else switch (c) {
      case "forwards":
        for (l = r.child, c = null; l !== null; ) n = l.alternate, n !== null && _s(n) === null && (c = l), l = l.sibling;
        l = c, l === null ? (c = r.child, r.child = null) : (c = l.sibling, l.sibling = null), jd(r, !1, c, l, d);
        break;
      case "backwards":
        for (l = null, c = r.child, r.child = null; c !== null; ) {
          if (n = c.alternate, n !== null && _s(n) === null) {
            r.child = c;
            break;
          }
          n = c.sibling, c.sibling = l, l = c, c = n;
        }
        jd(r, !0, l, null, d);
        break;
      case "together":
        jd(r, !1, null, null, void 0);
        break;
      default:
        r.memoizedState = null;
    }
    return r.child;
  }
  function Fs(n, r) {
    !(r.mode & 1) && n !== null && (n.alternate = null, r.alternate = null, r.flags |= 2);
  }
  function bi(n, r, l) {
    if (n !== null && (r.dependencies = n.dependencies), Do |= r.lanes, !(l & r.childLanes)) return null;
    if (n !== null && r.child !== n.child) throw Error(g(153));
    if (r.child !== null) {
      for (n = r.child, l = Wl(n, n.pendingProps), r.child = l, l.return = r; n.sibling !== null; ) n = n.sibling, l = l.sibling = Wl(n, n.pendingProps), l.return = r;
      l.sibling = null;
    }
    return r.child;
  }
  function Ea(n, r, l) {
    switch (r.tag) {
      case 3:
        Ud(r), su();
        break;
      case 5:
        Qv(r);
        break;
      case 1:
        Fn(r.type) && So(r);
        break;
      case 4:
        Td(r, r.stateNode.containerInfo);
        break;
      case 10:
        var u = r.type._context, c = r.memoizedProps.value;
        Ht(zc, u._currentValue), u._currentValue = c;
        break;
      case 13:
        if (u = r.memoizedState, u !== null)
          return u.dehydrated !== null ? (Ht(En, En.current & 1), r.flags |= 128, null) : l & r.child.childLanes ? xu(n, r, l) : (Ht(En, En.current & 1), n = bi(n, r, l), n !== null ? n.sibling : null);
        Ht(En, En.current & 1);
        break;
      case 19:
        if (u = (l & r.childLanes) !== 0, n.flags & 128) {
          if (u) return Pd(n, r, l);
          r.flags |= 128;
        }
        if (c = r.memoizedState, c !== null && (c.rendering = null, c.tail = null, c.lastEffect = null), Ht(En, En.current), u) break;
        return null;
      case 22:
      case 23:
        return r.lanes = 0, Zc(n, r, l);
    }
    return bi(n, r, l);
  }
  var Ti, oi, js, _u;
  Ti = function(n, r) {
    for (var l = r.child; l !== null; ) {
      if (l.tag === 5 || l.tag === 6) n.appendChild(l.stateNode);
      else if (l.tag !== 4 && l.child !== null) {
        l.child.return = l, l = l.child;
        continue;
      }
      if (l === r) break;
      for (; l.sibling === null; ) {
        if (l.return === null || l.return === r) return;
        l = l.return;
      }
      l.sibling.return = l.return, l = l.sibling;
    }
  }, oi = function() {
  }, js = function(n, r, l, u) {
    var c = n.memoizedProps;
    if (c !== u) {
      n = r.stateNode, To(Si.current);
      var d = null;
      switch (l) {
        case "input":
          c = bn(n, c), u = bn(n, u), d = [];
          break;
        case "select":
          c = pe({}, c, { value: void 0 }), u = pe({}, u, { value: void 0 }), d = [];
          break;
        case "textarea":
          c = aa(n, c), u = aa(n, u), d = [];
          break;
        default:
          typeof c.onClick != "function" && typeof u.onClick == "function" && (n.onclick = Dc);
      }
      Pt(l, u);
      var y;
      l = null;
      for (V in c) if (!u.hasOwnProperty(V) && c.hasOwnProperty(V) && c[V] != null) if (V === "style") {
        var R = c[V];
        for (y in R) R.hasOwnProperty(y) && (l || (l = {}), l[y] = "");
      } else V !== "dangerouslySetInnerHTML" && V !== "children" && V !== "suppressContentEditableWarning" && V !== "suppressHydrationWarning" && V !== "autoFocus" && (L.hasOwnProperty(V) ? d || (d = []) : (d = d || []).push(V, null));
      for (V in u) {
        var k = u[V];
        if (R = c != null ? c[V] : void 0, u.hasOwnProperty(V) && k !== R && (k != null || R != null)) if (V === "style") if (R) {
          for (y in R) !R.hasOwnProperty(y) || k && k.hasOwnProperty(y) || (l || (l = {}), l[y] = "");
          for (y in k) k.hasOwnProperty(y) && R[y] !== k[y] && (l || (l = {}), l[y] = k[y]);
        } else l || (d || (d = []), d.push(
          V,
          l
        )), l = k;
        else V === "dangerouslySetInnerHTML" ? (k = k ? k.__html : void 0, R = R ? R.__html : void 0, k != null && R !== k && (d = d || []).push(V, k)) : V === "children" ? typeof k != "string" && typeof k != "number" || (d = d || []).push(V, "" + k) : V !== "suppressContentEditableWarning" && V !== "suppressHydrationWarning" && (L.hasOwnProperty(V) ? (k != null && V === "onScroll" && nn("scroll", n), d || R === k || (d = [])) : (d = d || []).push(V, k));
      }
      l && (d = d || []).push("style", l);
      var V = d;
      (r.updateQueue = V) && (r.flags |= 4);
    }
  }, _u = function(n, r, l, u) {
    l !== u && (r.flags |= 4);
  };
  function xr(n, r) {
    if (!fn) switch (n.tailMode) {
      case "hidden":
        r = n.tail;
        for (var l = null; r !== null; ) r.alternate !== null && (l = r), r = r.sibling;
        l === null ? n.tail = null : l.sibling = null;
        break;
      case "collapsed":
        l = n.tail;
        for (var u = null; l !== null; ) l.alternate !== null && (u = l), l = l.sibling;
        u === null ? r || n.tail === null ? n.tail = null : n.tail.sibling = null : u.sibling = null;
    }
  }
  function Ut(n) {
    var r = n.alternate !== null && n.alternate.child === n.child, l = 0, u = 0;
    if (r) for (var c = n.child; c !== null; ) l |= c.lanes | c.childLanes, u |= c.subtreeFlags & 14680064, u |= c.flags & 14680064, c.return = n, c = c.sibling;
    else for (c = n.child; c !== null; ) l |= c.lanes | c.childLanes, u |= c.subtreeFlags, u |= c.flags, c.return = n, c = c.sibling;
    return n.subtreeFlags |= u, n.childLanes = l, r;
  }
  function xy(n, r, l) {
    var u = r.pendingProps;
    switch (Lc(r), r.tag) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return Ut(r), null;
      case 1:
        return Fn(r.type) && Wr(), Ut(r), null;
      case 3:
        return u = r.stateNode, vu(), He(vt), He(Qn), Pc(), u.pendingContext && (u.context = u.pendingContext, u.pendingContext = null), (n === null || n.child === null) && (Uc(r) ? r.flags |= 4 : n === null || n.memoizedState.isDehydrated && !(r.flags & 256) || (r.flags |= 1024, ja !== null && (No(ja), ja = null))), oi(n, r), Ut(r), null;
      case 5:
        Rd(r);
        var c = To(pu.current);
        if (l = r.type, n !== null && r.stateNode != null) js(n, r, l, u, c), n.ref !== r.ref && (r.flags |= 512, r.flags |= 2097152);
        else {
          if (!u) {
            if (r.stateNode === null) throw Error(g(166));
            return Ut(r), null;
          }
          if (n = To(Si.current), Uc(r)) {
            u = r.stateNode, l = r.type;
            var d = r.memoizedProps;
            switch (u[Aa] = r, u[ws] = d, n = (r.mode & 1) !== 0, l) {
              case "dialog":
                nn("cancel", u), nn("close", u);
                break;
              case "iframe":
              case "object":
              case "embed":
                nn("load", u);
                break;
              case "video":
              case "audio":
                for (c = 0; c < Qi.length; c++) nn(Qi[c], u);
                break;
              case "source":
                nn("error", u);
                break;
              case "img":
              case "image":
              case "link":
                nn(
                  "error",
                  u
                ), nn("load", u);
                break;
              case "details":
                nn("toggle", u);
                break;
              case "input":
                Jn(u, d), nn("invalid", u);
                break;
              case "select":
                u._wrapperState = { wasMultiple: !!d.multiple }, nn("invalid", u);
                break;
              case "textarea":
                ia(u, d), nn("invalid", u);
            }
            Pt(l, d), c = null;
            for (var y in d) if (d.hasOwnProperty(y)) {
              var R = d[y];
              y === "children" ? typeof R == "string" ? u.textContent !== R && (d.suppressHydrationWarning !== !0 && Cs(u.textContent, R, n), c = ["children", R]) : typeof R == "number" && u.textContent !== "" + R && (d.suppressHydrationWarning !== !0 && Cs(
                u.textContent,
                R,
                n
              ), c = ["children", "" + R]) : L.hasOwnProperty(y) && R != null && y === "onScroll" && nn("scroll", u);
            }
            switch (l) {
              case "input":
                kn(u), An(u, d, !0);
                break;
              case "textarea":
                kn(u), la(u);
                break;
              case "select":
              case "option":
                break;
              default:
                typeof d.onClick == "function" && (u.onclick = Dc);
            }
            u = c, r.updateQueue = u, u !== null && (r.flags |= 4);
          } else {
            y = c.nodeType === 9 ? c : c.ownerDocument, n === "http://www.w3.org/1999/xhtml" && (n = Zn(l)), n === "http://www.w3.org/1999/xhtml" ? l === "script" ? (n = y.createElement("div"), n.innerHTML = "<script><\/script>", n = n.removeChild(n.firstChild)) : typeof u.is == "string" ? n = y.createElement(l, { is: u.is }) : (n = y.createElement(l), l === "select" && (y = n, u.multiple ? y.multiple = !0 : u.size && (y.size = u.size))) : n = y.createElementNS(n, l), n[Aa] = r, n[ws] = u, Ti(n, r, !1, !1), r.stateNode = n;
            e: {
              switch (y = On(l, u), l) {
                case "dialog":
                  nn("cancel", n), nn("close", n), c = u;
                  break;
                case "iframe":
                case "object":
                case "embed":
                  nn("load", n), c = u;
                  break;
                case "video":
                case "audio":
                  for (c = 0; c < Qi.length; c++) nn(Qi[c], n);
                  c = u;
                  break;
                case "source":
                  nn("error", n), c = u;
                  break;
                case "img":
                case "image":
                case "link":
                  nn(
                    "error",
                    n
                  ), nn("load", n), c = u;
                  break;
                case "details":
                  nn("toggle", n), c = u;
                  break;
                case "input":
                  Jn(n, u), c = bn(n, u), nn("invalid", n);
                  break;
                case "option":
                  c = u;
                  break;
                case "select":
                  n._wrapperState = { wasMultiple: !!u.multiple }, c = pe({}, u, { value: void 0 }), nn("invalid", n);
                  break;
                case "textarea":
                  ia(n, u), c = aa(n, u), nn("invalid", n);
                  break;
                default:
                  c = u;
              }
              Pt(l, c), R = c;
              for (d in R) if (R.hasOwnProperty(d)) {
                var k = R[d];
                d === "style" ? Ct(n, k) : d === "dangerouslySetInnerHTML" ? (k = k ? k.__html : void 0, k != null && oa(n, k)) : d === "children" ? typeof k == "string" ? (l !== "textarea" || k !== "") && ua(n, k) : typeof k == "number" && ua(n, "" + k) : d !== "suppressContentEditableWarning" && d !== "suppressHydrationWarning" && d !== "autoFocus" && (L.hasOwnProperty(d) ? k != null && d === "onScroll" && nn("scroll", n) : k != null && Ke(n, d, k, y));
              }
              switch (l) {
                case "input":
                  kn(n), An(n, u, !1);
                  break;
                case "textarea":
                  kn(n), la(n);
                  break;
                case "option":
                  u.value != null && n.setAttribute("value", "" + Et(u.value));
                  break;
                case "select":
                  n.multiple = !!u.multiple, d = u.value, d != null ? Vn(n, !!u.multiple, d, !1) : u.defaultValue != null && Vn(
                    n,
                    !!u.multiple,
                    u.defaultValue,
                    !0
                  );
                  break;
                default:
                  typeof c.onClick == "function" && (n.onclick = Dc);
              }
              switch (l) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  u = !!u.autoFocus;
                  break e;
                case "img":
                  u = !0;
                  break e;
                default:
                  u = !1;
              }
            }
            u && (r.flags |= 4);
          }
          r.ref !== null && (r.flags |= 512, r.flags |= 2097152);
        }
        return Ut(r), null;
      case 6:
        if (n && r.stateNode != null) _u(n, r, n.memoizedProps, u);
        else {
          if (typeof u != "string" && r.stateNode === null) throw Error(g(166));
          if (l = To(pu.current), To(Si.current), Uc(r)) {
            if (u = r.stateNode, l = r.memoizedProps, u[Aa] = r, (d = u.nodeValue !== l) && (n = va, n !== null)) switch (n.tag) {
              case 3:
                Cs(u.nodeValue, l, (n.mode & 1) !== 0);
                break;
              case 5:
                n.memoizedProps.suppressHydrationWarning !== !0 && Cs(u.nodeValue, l, (n.mode & 1) !== 0);
            }
            d && (r.flags |= 4);
          } else u = (l.nodeType === 9 ? l : l.ownerDocument).createTextNode(u), u[Aa] = r, r.stateNode = u;
        }
        return Ut(r), null;
      case 13:
        if (He(En), u = r.memoizedState, n === null || n.memoizedState !== null && n.memoizedState.dehydrated !== null) {
          if (fn && ha !== null && r.mode & 1 && !(r.flags & 128)) Vv(), su(), r.flags |= 98560, d = !1;
          else if (d = Uc(r), u !== null && u.dehydrated !== null) {
            if (n === null) {
              if (!d) throw Error(g(318));
              if (d = r.memoizedState, d = d !== null ? d.dehydrated : null, !d) throw Error(g(317));
              d[Aa] = r;
            } else su(), !(r.flags & 128) && (r.memoizedState = null), r.flags |= 4;
            Ut(r), d = !1;
          } else ja !== null && (No(ja), ja = null), d = !0;
          if (!d) return r.flags & 65536 ? r : null;
        }
        return r.flags & 128 ? (r.lanes = l, r) : (u = u !== null, u !== (n !== null && n.memoizedState !== null) && u && (r.child.flags |= 8192, r.mode & 1 && (n === null || En.current & 1 ? In === 0 && (In = 3) : Kd())), r.updateQueue !== null && (r.flags |= 4), Ut(r), null);
      case 4:
        return vu(), oi(n, r), n === null && hi(r.stateNode.containerInfo), Ut(r), null;
      case 10:
        return ma(r.type._context), Ut(r), null;
      case 17:
        return Fn(r.type) && Wr(), Ut(r), null;
      case 19:
        if (He(En), d = r.memoizedState, d === null) return Ut(r), null;
        if (u = (r.flags & 128) !== 0, y = d.rendering, y === null) if (u) xr(d, !1);
        else {
          if (In !== 0 || n !== null && n.flags & 128) for (n = r.child; n !== null; ) {
            if (y = _s(n), y !== null) {
              for (r.flags |= 128, xr(d, !1), u = y.updateQueue, u !== null && (r.updateQueue = u, r.flags |= 4), r.subtreeFlags = 0, u = l, l = r.child; l !== null; ) d = l, n = u, d.flags &= 14680066, y = d.alternate, y === null ? (d.childLanes = 0, d.lanes = n, d.child = null, d.subtreeFlags = 0, d.memoizedProps = null, d.memoizedState = null, d.updateQueue = null, d.dependencies = null, d.stateNode = null) : (d.childLanes = y.childLanes, d.lanes = y.lanes, d.child = y.child, d.subtreeFlags = 0, d.deletions = null, d.memoizedProps = y.memoizedProps, d.memoizedState = y.memoizedState, d.updateQueue = y.updateQueue, d.type = y.type, n = y.dependencies, d.dependencies = n === null ? null : { lanes: n.lanes, firstContext: n.firstContext }), l = l.sibling;
              return Ht(En, En.current & 1 | 2), r.child;
            }
            n = n.sibling;
          }
          d.tail !== null && Yt() > Oo && (r.flags |= 128, u = !0, xr(d, !1), r.lanes = 4194304);
        }
        else {
          if (!u) if (n = _s(y), n !== null) {
            if (r.flags |= 128, u = !0, l = n.updateQueue, l !== null && (r.updateQueue = l, r.flags |= 4), xr(d, !0), d.tail === null && d.tailMode === "hidden" && !y.alternate && !fn) return Ut(r), null;
          } else 2 * Yt() - d.renderingStartTime > Oo && l !== 1073741824 && (r.flags |= 128, u = !0, xr(d, !1), r.lanes = 4194304);
          d.isBackwards ? (y.sibling = r.child, r.child = y) : (l = d.last, l !== null ? l.sibling = y : r.child = y, d.last = y);
        }
        return d.tail !== null ? (r = d.tail, d.rendering = r, d.tail = r.sibling, d.renderingStartTime = Yt(), r.sibling = null, l = En.current, Ht(En, u ? l & 1 | 2 : l & 1), r) : (Ut(r), null);
      case 22:
      case 23:
        return Mu(), u = r.memoizedState !== null, n !== null && n.memoizedState !== null !== u && (r.flags |= 8192), u && r.mode & 1 ? Dr & 1073741824 && (Ut(r), r.subtreeFlags & 6 && (r.flags |= 8192)) : Ut(r), null;
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(g(156, r.tag));
  }
  function _y(n, r) {
    switch (Lc(r), r.tag) {
      case 1:
        return Fn(r.type) && Wr(), n = r.flags, n & 65536 ? (r.flags = n & -65537 | 128, r) : null;
      case 3:
        return vu(), He(vt), He(Qn), Pc(), n = r.flags, n & 65536 && !(n & 128) ? (r.flags = n & -65537 | 128, r) : null;
      case 5:
        return Rd(r), null;
      case 13:
        if (He(En), n = r.memoizedState, n !== null && n.dehydrated !== null) {
          if (r.alternate === null) throw Error(g(340));
          su();
        }
        return n = r.flags, n & 65536 ? (r.flags = n & -65537 | 128, r) : null;
      case 19:
        return He(En), null;
      case 4:
        return vu(), null;
      case 10:
        return ma(r.type._context), null;
      case 22:
      case 23:
        return Mu(), null;
      case 24:
        return null;
      default:
        return null;
    }
  }
  var tf = !1, Gn = !1, th = typeof WeakSet == "function" ? WeakSet : Set, Oe = null;
  function _o(n, r) {
    var l = n.ref;
    if (l !== null) if (typeof l == "function") try {
      l(null);
    } catch (u) {
      xn(n, r, u);
    }
    else l.current = null;
  }
  function Hd(n, r, l) {
    try {
      l();
    } catch (u) {
      xn(n, r, u);
    }
  }
  var nh = !1;
  function Bd(n, r) {
    if (sd = vo, n = kv(), hs(n)) {
      if ("selectionStart" in n) var l = { start: n.selectionStart, end: n.selectionEnd };
      else e: {
        l = (l = n.ownerDocument) && l.defaultView || window;
        var u = l.getSelection && l.getSelection();
        if (u && u.rangeCount !== 0) {
          l = u.anchorNode;
          var c = u.anchorOffset, d = u.focusNode;
          u = u.focusOffset;
          try {
            l.nodeType, d.nodeType;
          } catch {
            l = null;
            break e;
          }
          var y = 0, R = -1, k = -1, V = 0, se = 0, fe = n, le = null;
          t: for (; ; ) {
            for (var _e; fe !== l || c !== 0 && fe.nodeType !== 3 || (R = y + c), fe !== d || u !== 0 && fe.nodeType !== 3 || (k = y + u), fe.nodeType === 3 && (y += fe.nodeValue.length), (_e = fe.firstChild) !== null; )
              le = fe, fe = _e;
            for (; ; ) {
              if (fe === n) break t;
              if (le === l && ++V === c && (R = y), le === d && ++se === u && (k = y), (_e = fe.nextSibling) !== null) break;
              fe = le, le = fe.parentNode;
            }
            fe = _e;
          }
          l = R === -1 || k === -1 ? null : { start: R, end: k };
        } else l = null;
      }
      l = l || { start: 0, end: 0 };
    } else l = null;
    for (cd = { focusedElem: n, selectionRange: l }, vo = !1, Oe = r; Oe !== null; ) if (r = Oe, n = r.child, (r.subtreeFlags & 1028) !== 0 && n !== null) n.return = r, Oe = n;
    else for (; Oe !== null; ) {
      r = Oe;
      try {
        var ze = r.alternate;
        if (r.flags & 1024) switch (r.tag) {
          case 0:
          case 11:
          case 15:
            break;
          case 1:
            if (ze !== null) {
              var Pe = ze.memoizedProps, Nn = ze.memoizedState, z = r.stateNode, O = z.getSnapshotBeforeUpdate(r.elementType === r.type ? Pe : Xr(r.type, Pe), Nn);
              z.__reactInternalSnapshotBeforeUpdate = O;
            }
            break;
          case 3:
            var P = r.stateNode.containerInfo;
            P.nodeType === 1 ? P.textContent = "" : P.nodeType === 9 && P.documentElement && P.removeChild(P.documentElement);
            break;
          case 5:
          case 6:
          case 4:
          case 17:
            break;
          default:
            throw Error(g(163));
        }
      } catch (me) {
        xn(r, r.return, me);
      }
      if (n = r.sibling, n !== null) {
        n.return = r.return, Oe = n;
        break;
      }
      Oe = r.return;
    }
    return ze = nh, nh = !1, ze;
  }
  function Ps(n, r, l) {
    var u = r.updateQueue;
    if (u = u !== null ? u.lastEffect : null, u !== null) {
      var c = u = u.next;
      do {
        if ((c.tag & n) === n) {
          var d = c.destroy;
          c.destroy = void 0, d !== void 0 && Hd(r, l, d);
        }
        c = c.next;
      } while (c !== u);
    }
  }
  function Hs(n, r) {
    if (r = r.updateQueue, r = r !== null ? r.lastEffect : null, r !== null) {
      var l = r = r.next;
      do {
        if ((l.tag & n) === n) {
          var u = l.create;
          l.destroy = u();
        }
        l = l.next;
      } while (l !== r);
    }
  }
  function Vd(n) {
    var r = n.ref;
    if (r !== null) {
      var l = n.stateNode;
      switch (n.tag) {
        case 5:
          n = l;
          break;
        default:
          n = l;
      }
      typeof r == "function" ? r(n) : r.current = n;
    }
  }
  function $d(n) {
    var r = n.alternate;
    r !== null && (n.alternate = null, $d(r)), n.child = null, n.deletions = null, n.sibling = null, n.tag === 5 && (r = n.stateNode, r !== null && (delete r[Aa], delete r[ws], delete r[vd], delete r[Sy], delete r[Ey])), n.stateNode = null, n.return = null, n.dependencies = null, n.memoizedProps = null, n.memoizedState = null, n.pendingProps = null, n.stateNode = null, n.updateQueue = null;
  }
  function rh(n) {
    return n.tag === 5 || n.tag === 3 || n.tag === 4;
  }
  function Id(n) {
    e: for (; ; ) {
      for (; n.sibling === null; ) {
        if (n.return === null || rh(n.return)) return null;
        n = n.return;
      }
      for (n.sibling.return = n.return, n = n.sibling; n.tag !== 5 && n.tag !== 6 && n.tag !== 18; ) {
        if (n.flags & 2 || n.child === null || n.tag === 4) continue e;
        n.child.return = n, n = n.child;
      }
      if (!(n.flags & 2)) return n.stateNode;
    }
  }
  function Yd(n, r, l) {
    var u = n.tag;
    if (u === 5 || u === 6) n = n.stateNode, r ? l.nodeType === 8 ? l.parentNode.insertBefore(n, r) : l.insertBefore(n, r) : (l.nodeType === 8 ? (r = l.parentNode, r.insertBefore(n, l)) : (r = l, r.appendChild(n)), l = l._reactRootContainer, l != null || r.onclick !== null || (r.onclick = Dc));
    else if (u !== 4 && (n = n.child, n !== null)) for (Yd(n, r, l), n = n.sibling; n !== null; ) Yd(n, r, l), n = n.sibling;
  }
  function Bs(n, r, l) {
    var u = n.tag;
    if (u === 5 || u === 6) n = n.stateNode, r ? l.insertBefore(n, r) : l.appendChild(n);
    else if (u !== 4 && (n = n.child, n !== null)) for (Bs(n, r, l), n = n.sibling; n !== null; ) Bs(n, r, l), n = n.sibling;
  }
  var Pn = null, Kn = !1;
  function _r(n, r, l) {
    for (l = l.child; l !== null; ) nl(n, r, l), l = l.sibling;
  }
  function nl(n, r, l) {
    if (Vr && typeof Vr.onCommitFiberUnmount == "function") try {
      Vr.onCommitFiberUnmount(El, l);
    } catch {
    }
    switch (l.tag) {
      case 5:
        Gn || _o(l, r);
      case 6:
        var u = Pn, c = Kn;
        Pn = null, _r(n, r, l), Pn = u, Kn = c, Pn !== null && (Kn ? (n = Pn, l = l.stateNode, n.nodeType === 8 ? n.parentNode.removeChild(l) : n.removeChild(l)) : Pn.removeChild(l.stateNode));
        break;
      case 18:
        Pn !== null && (Kn ? (n = Pn, l = l.stateNode, n.nodeType === 8 ? pd(n.parentNode, l) : n.nodeType === 1 && pd(n, l), La(n)) : pd(Pn, l.stateNode));
        break;
      case 4:
        u = Pn, c = Kn, Pn = l.stateNode.containerInfo, Kn = !0, _r(n, r, l), Pn = u, Kn = c;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (!Gn && (u = l.updateQueue, u !== null && (u = u.lastEffect, u !== null))) {
          c = u = u.next;
          do {
            var d = c, y = d.destroy;
            d = d.tag, y !== void 0 && (d & 2 || d & 4) && Hd(l, r, y), c = c.next;
          } while (c !== u);
        }
        _r(n, r, l);
        break;
      case 1:
        if (!Gn && (_o(l, r), u = l.stateNode, typeof u.componentWillUnmount == "function")) try {
          u.props = l.memoizedProps, u.state = l.memoizedState, u.componentWillUnmount();
        } catch (R) {
          xn(l, r, R);
        }
        _r(n, r, l);
        break;
      case 21:
        _r(n, r, l);
        break;
      case 22:
        l.mode & 1 ? (Gn = (u = Gn) || l.memoizedState !== null, _r(n, r, l), Gn = u) : _r(n, r, l);
        break;
      default:
        _r(n, r, l);
    }
  }
  function ku(n) {
    var r = n.updateQueue;
    if (r !== null) {
      n.updateQueue = null;
      var l = n.stateNode;
      l === null && (l = n.stateNode = new th()), r.forEach(function(u) {
        var c = qd.bind(null, n, u);
        l.has(u) || (l.add(u), u.then(c, c));
      });
    }
  }
  function kr(n, r) {
    var l = r.deletions;
    if (l !== null) for (var u = 0; u < l.length; u++) {
      var c = l[u];
      try {
        var d = n, y = r, R = y;
        e: for (; R !== null; ) {
          switch (R.tag) {
            case 5:
              Pn = R.stateNode, Kn = !1;
              break e;
            case 3:
              Pn = R.stateNode.containerInfo, Kn = !0;
              break e;
            case 4:
              Pn = R.stateNode.containerInfo, Kn = !0;
              break e;
          }
          R = R.return;
        }
        if (Pn === null) throw Error(g(160));
        nl(d, y, c), Pn = null, Kn = !1;
        var k = c.alternate;
        k !== null && (k.return = null), c.return = null;
      } catch (V) {
        xn(c, r, V);
      }
    }
    if (r.subtreeFlags & 12854) for (r = r.child; r !== null; ) rl(r, n), r = r.sibling;
  }
  function rl(n, r) {
    var l = n.alternate, u = n.flags;
    switch (n.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if (kr(r, n), Ri(n), u & 4) {
          try {
            Ps(3, n, n.return), Hs(3, n);
          } catch (Pe) {
            xn(n, n.return, Pe);
          }
          try {
            Ps(5, n, n.return);
          } catch (Pe) {
            xn(n, n.return, Pe);
          }
        }
        break;
      case 1:
        kr(r, n), Ri(n), u & 512 && l !== null && _o(l, l.return);
        break;
      case 5:
        if (kr(r, n), Ri(n), u & 512 && l !== null && _o(l, l.return), n.flags & 32) {
          var c = n.stateNode;
          try {
            ua(c, "");
          } catch (Pe) {
            xn(n, n.return, Pe);
          }
        }
        if (u & 4 && (c = n.stateNode, c != null)) {
          var d = n.memoizedProps, y = l !== null ? l.memoizedProps : d, R = n.type, k = n.updateQueue;
          if (n.updateQueue = null, k !== null) try {
            R === "input" && d.type === "radio" && d.name != null && Bn(c, d), On(R, y);
            var V = On(R, d);
            for (y = 0; y < k.length; y += 2) {
              var se = k[y], fe = k[y + 1];
              se === "style" ? Ct(c, fe) : se === "dangerouslySetInnerHTML" ? oa(c, fe) : se === "children" ? ua(c, fe) : Ke(c, se, fe, V);
            }
            switch (R) {
              case "input":
                Dn(c, d);
                break;
              case "textarea":
                vr(c, d);
                break;
              case "select":
                var le = c._wrapperState.wasMultiple;
                c._wrapperState.wasMultiple = !!d.multiple;
                var _e = d.value;
                _e != null ? Vn(c, !!d.multiple, _e, !1) : le !== !!d.multiple && (d.defaultValue != null ? Vn(
                  c,
                  !!d.multiple,
                  d.defaultValue,
                  !0
                ) : Vn(c, !!d.multiple, d.multiple ? [] : "", !1));
            }
            c[ws] = d;
          } catch (Pe) {
            xn(n, n.return, Pe);
          }
        }
        break;
      case 6:
        if (kr(r, n), Ri(n), u & 4) {
          if (n.stateNode === null) throw Error(g(162));
          c = n.stateNode, d = n.memoizedProps;
          try {
            c.nodeValue = d;
          } catch (Pe) {
            xn(n, n.return, Pe);
          }
        }
        break;
      case 3:
        if (kr(r, n), Ri(n), u & 4 && l !== null && l.memoizedState.isDehydrated) try {
          La(r.containerInfo);
        } catch (Pe) {
          xn(n, n.return, Pe);
        }
        break;
      case 4:
        kr(r, n), Ri(n);
        break;
      case 13:
        kr(r, n), Ri(n), c = n.child, c.flags & 8192 && (d = c.memoizedState !== null, c.stateNode.isHidden = d, !d || c.alternate !== null && c.alternate.memoizedState !== null || (Ys = Yt())), u & 4 && ku(n);
        break;
      case 22:
        if (se = l !== null && l.memoizedState !== null, n.mode & 1 ? (Gn = (V = Gn) || se, kr(r, n), Gn = V) : kr(r, n), Ri(n), u & 8192) {
          if (V = n.memoizedState !== null, (n.stateNode.isHidden = V) && !se && n.mode & 1) for (Oe = n, se = n.child; se !== null; ) {
            for (fe = Oe = se; Oe !== null; ) {
              switch (le = Oe, _e = le.child, le.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                  Ps(4, le, le.return);
                  break;
                case 1:
                  _o(le, le.return);
                  var ze = le.stateNode;
                  if (typeof ze.componentWillUnmount == "function") {
                    u = le, l = le.return;
                    try {
                      r = u, ze.props = r.memoizedProps, ze.state = r.memoizedState, ze.componentWillUnmount();
                    } catch (Pe) {
                      xn(u, l, Pe);
                    }
                  }
                  break;
                case 5:
                  _o(le, le.return);
                  break;
                case 22:
                  if (le.memoizedState !== null) {
                    Du(fe);
                    continue;
                  }
              }
              _e !== null ? (_e.return = le, Oe = _e) : Du(fe);
            }
            se = se.sibling;
          }
          e: for (se = null, fe = n; ; ) {
            if (fe.tag === 5) {
              if (se === null) {
                se = fe;
                try {
                  c = fe.stateNode, V ? (d = c.style, typeof d.setProperty == "function" ? d.setProperty("display", "none", "important") : d.display = "none") : (R = fe.stateNode, k = fe.memoizedProps.style, y = k != null && k.hasOwnProperty("display") ? k.display : null, R.style.display = Qe("display", y));
                } catch (Pe) {
                  xn(n, n.return, Pe);
                }
              }
            } else if (fe.tag === 6) {
              if (se === null) try {
                fe.stateNode.nodeValue = V ? "" : fe.memoizedProps;
              } catch (Pe) {
                xn(n, n.return, Pe);
              }
            } else if ((fe.tag !== 22 && fe.tag !== 23 || fe.memoizedState === null || fe === n) && fe.child !== null) {
              fe.child.return = fe, fe = fe.child;
              continue;
            }
            if (fe === n) break e;
            for (; fe.sibling === null; ) {
              if (fe.return === null || fe.return === n) break e;
              se === fe && (se = null), fe = fe.return;
            }
            se === fe && (se = null), fe.sibling.return = fe.return, fe = fe.sibling;
          }
        }
        break;
      case 19:
        kr(r, n), Ri(n), u & 4 && ku(n);
        break;
      case 21:
        break;
      default:
        kr(
          r,
          n
        ), Ri(n);
    }
  }
  function Ri(n) {
    var r = n.flags;
    if (r & 2) {
      try {
        e: {
          for (var l = n.return; l !== null; ) {
            if (rh(l)) {
              var u = l;
              break e;
            }
            l = l.return;
          }
          throw Error(g(160));
        }
        switch (u.tag) {
          case 5:
            var c = u.stateNode;
            u.flags & 32 && (ua(c, ""), u.flags &= -33);
            var d = Id(n);
            Bs(n, d, c);
            break;
          case 3:
          case 4:
            var y = u.stateNode.containerInfo, R = Id(n);
            Yd(n, R, y);
            break;
          default:
            throw Error(g(161));
        }
      } catch (k) {
        xn(n, n.return, k);
      }
      n.flags &= -3;
    }
    r & 4096 && (n.flags &= -4097);
  }
  function ky(n, r, l) {
    Oe = n, ah(n);
  }
  function ah(n, r, l) {
    for (var u = (n.mode & 1) !== 0; Oe !== null; ) {
      var c = Oe, d = c.child;
      if (c.tag === 22 && u) {
        var y = c.memoizedState !== null || tf;
        if (!y) {
          var R = c.alternate, k = R !== null && R.memoizedState !== null || Gn;
          R = tf;
          var V = Gn;
          if (tf = y, (Gn = k) && !V) for (Oe = c; Oe !== null; ) y = Oe, k = y.child, y.tag === 22 && y.memoizedState !== null ? ih(c) : k !== null ? (k.return = y, Oe = k) : ih(c);
          for (; d !== null; ) Oe = d, ah(d), d = d.sibling;
          Oe = c, tf = R, Gn = V;
        }
        Wd(n);
      } else c.subtreeFlags & 8772 && d !== null ? (d.return = c, Oe = d) : Wd(n);
    }
  }
  function Wd(n) {
    for (; Oe !== null; ) {
      var r = Oe;
      if (r.flags & 8772) {
        var l = r.alternate;
        try {
          if (r.flags & 8772) switch (r.tag) {
            case 0:
            case 11:
            case 15:
              Gn || Hs(5, r);
              break;
            case 1:
              var u = r.stateNode;
              if (r.flags & 4 && !Gn) if (l === null) u.componentDidMount();
              else {
                var c = r.elementType === r.type ? l.memoizedProps : Xr(r.type, l.memoizedProps);
                u.componentDidUpdate(c, l.memoizedState, u.__reactInternalSnapshotBeforeUpdate);
              }
              var d = r.updateQueue;
              d !== null && Wv(r, d, u);
              break;
            case 3:
              var y = r.updateQueue;
              if (y !== null) {
                if (l = null, r.child !== null) switch (r.child.tag) {
                  case 5:
                    l = r.child.stateNode;
                    break;
                  case 1:
                    l = r.child.stateNode;
                }
                Wv(r, y, l);
              }
              break;
            case 5:
              var R = r.stateNode;
              if (l === null && r.flags & 4) {
                l = R;
                var k = r.memoizedProps;
                switch (r.type) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    k.autoFocus && l.focus();
                    break;
                  case "img":
                    k.src && (l.src = k.src);
                }
              }
              break;
            case 6:
              break;
            case 4:
              break;
            case 12:
              break;
            case 13:
              if (r.memoizedState === null) {
                var V = r.alternate;
                if (V !== null) {
                  var se = V.memoizedState;
                  if (se !== null) {
                    var fe = se.dehydrated;
                    fe !== null && La(fe);
                  }
                }
              }
              break;
            case 19:
            case 17:
            case 21:
            case 22:
            case 23:
            case 25:
              break;
            default:
              throw Error(g(163));
          }
          Gn || r.flags & 512 && Vd(r);
        } catch (le) {
          xn(r, r.return, le);
        }
      }
      if (r === n) {
        Oe = null;
        break;
      }
      if (l = r.sibling, l !== null) {
        l.return = r.return, Oe = l;
        break;
      }
      Oe = r.return;
    }
  }
  function Du(n) {
    for (; Oe !== null; ) {
      var r = Oe;
      if (r === n) {
        Oe = null;
        break;
      }
      var l = r.sibling;
      if (l !== null) {
        l.return = r.return, Oe = l;
        break;
      }
      Oe = r.return;
    }
  }
  function ih(n) {
    for (; Oe !== null; ) {
      var r = Oe;
      try {
        switch (r.tag) {
          case 0:
          case 11:
          case 15:
            var l = r.return;
            try {
              Hs(4, r);
            } catch (k) {
              xn(r, l, k);
            }
            break;
          case 1:
            var u = r.stateNode;
            if (typeof u.componentDidMount == "function") {
              var c = r.return;
              try {
                u.componentDidMount();
              } catch (k) {
                xn(r, c, k);
              }
            }
            var d = r.return;
            try {
              Vd(r);
            } catch (k) {
              xn(r, d, k);
            }
            break;
          case 5:
            var y = r.return;
            try {
              Vd(r);
            } catch (k) {
              xn(r, y, k);
            }
        }
      } catch (k) {
        xn(r, r.return, k);
      }
      if (r === n) {
        Oe = null;
        break;
      }
      var R = r.sibling;
      if (R !== null) {
        R.return = r.return, Oe = R;
        break;
      }
      Oe = r.return;
    }
  }
  var lh = Math.ceil, nf = Ge.ReactCurrentDispatcher, Ou = Ge.ReactCurrentOwner, Ca = Ge.ReactCurrentBatchConfig, zt = 0, Rn = null, mn = null, wn = 0, Dr = 0, ko = rn(0), In = 0, Vs = null, Do = 0, rf = 0, $s = 0, Is = null, rr = null, Ys = 0, Oo = 1 / 0, al = null, af = !1, Qd = null, Vl = null, $l = !1, wi = null, Il = 0, Ws = 0, Gd = null, Qs = -1, Gs = 0;
  function qn() {
    return zt & 6 ? Yt() : Qs !== -1 ? Qs : Qs = Yt();
  }
  function ui(n) {
    return n.mode & 1 ? zt & 2 && wn !== 0 ? wn & -wn : Cy.transition !== null ? (Gs === 0 && (Gs = uo()), Gs) : (n = kt, n !== 0 || (n = window.event, n = n === void 0 ? 16 : os(n.type)), n) : 1;
  }
  function Ba(n, r, l, u) {
    if (50 < Ws) throw Ws = 0, Gd = null, Error(g(185));
    bl(n, l, u), (!(zt & 2) || n !== Rn) && (n === Rn && (!(zt & 2) && (rf |= l), In === 4 && xi(n, wn)), un(n, u), l === 1 && zt === 0 && !(r.mode & 1) && (Oo = Yt() + 500, Ml && gi()));
  }
  function un(n, r) {
    var l = n.callbackNode;
    Cl(n, r);
    var u = di(n, n === Rn ? wn : 0);
    if (u === 0) l !== null && tn(l), n.callbackNode = null, n.callbackPriority = 0;
    else if (r = u & -u, n.callbackPriority !== r) {
      if (l != null && tn(l), r === 1) n.tag === 0 ? Bv(lf.bind(null, n)) : Mc(lf.bind(null, n)), Pv(function() {
        !(zt & 6) && gi();
      }), l = null;
      else {
        switch (as(u)) {
          case 1:
            l = zn;
            break;
          case 4:
            l = Br;
            break;
          case 16:
            l = yt;
            break;
          case 536870912:
            l = ji;
            break;
          default:
            l = yt;
        }
        l = hh(l, Mo.bind(null, n));
      }
      n.callbackPriority = r, n.callbackNode = l;
    }
  }
  function Mo(n, r) {
    if (Qs = -1, Gs = 0, zt & 6) throw Error(g(327));
    var l = n.callbackNode;
    if (Lu() && n.callbackNode !== l) return null;
    var u = di(n, n === Rn ? wn : 0);
    if (u === 0) return null;
    if (u & 30 || u & n.expiredLanes || r) r = Nu(n, u);
    else {
      r = u;
      var c = zt;
      zt |= 2;
      var d = uh();
      (Rn !== n || wn !== r) && (al = null, Oo = Yt() + 500, Yl(n, r));
      do
        try {
          My();
          break;
        } catch (R) {
          oh(n, R);
        }
      while (!0);
      Pa(), nf.current = d, zt = c, mn !== null ? r = 0 : (Rn = null, wn = 0, r = In);
    }
    if (r !== 0) {
      if (r === 2 && (c = pi(n), c !== 0 && (u = c, r = Ks(n, c))), r === 1) throw l = Vs, Yl(n, 0), xi(n, u), un(n, Yt()), l;
      if (r === 6) xi(n, u);
      else {
        if (c = n.current.alternate, !(u & 30) && !Dy(c) && (r = Nu(n, u), r === 2 && (d = pi(n), d !== 0 && (u = d, r = Ks(n, d))), r === 1)) throw l = Vs, Yl(n, 0), xi(n, u), un(n, Yt()), l;
        switch (n.finishedWork = c, n.finishedLanes = u, r) {
          case 0:
          case 1:
            throw Error(g(345));
          case 2:
            Uo(n, rr, al);
            break;
          case 3:
            if (xi(n, u), (u & 130023424) === u && (r = Ys + 500 - Yt(), 10 < r)) {
              if (di(n, 0) !== 0) break;
              if (c = n.suspendedLanes, (c & u) !== u) {
                qn(), n.pingedLanes |= n.suspendedLanes & c;
                break;
              }
              n.timeoutHandle = bs(Uo.bind(null, n, rr, al), r);
              break;
            }
            Uo(n, rr, al);
            break;
          case 4:
            if (xi(n, u), (u & 4194240) === u) break;
            for (r = n.eventTimes, c = -1; 0 < u; ) {
              var y = 31 - br(u);
              d = 1 << y, y = r[y], y > c && (c = y), u &= ~d;
            }
            if (u = c, u = Yt() - u, u = (120 > u ? 120 : 480 > u ? 480 : 1080 > u ? 1080 : 1920 > u ? 1920 : 3e3 > u ? 3e3 : 4320 > u ? 4320 : 1960 * lh(u / 1960)) - u, 10 < u) {
              n.timeoutHandle = bs(Uo.bind(null, n, rr, al), u);
              break;
            }
            Uo(n, rr, al);
            break;
          case 5:
            Uo(n, rr, al);
            break;
          default:
            throw Error(g(329));
        }
      }
    }
    return un(n, Yt()), n.callbackNode === l ? Mo.bind(null, n) : null;
  }
  function Ks(n, r) {
    var l = Is;
    return n.current.memoizedState.isDehydrated && (Yl(n, r).flags |= 256), n = Nu(n, r), n !== 2 && (r = rr, rr = l, r !== null && No(r)), n;
  }
  function No(n) {
    rr === null ? rr = n : rr.push.apply(rr, n);
  }
  function Dy(n) {
    for (var r = n; ; ) {
      if (r.flags & 16384) {
        var l = r.updateQueue;
        if (l !== null && (l = l.stores, l !== null)) for (var u = 0; u < l.length; u++) {
          var c = l[u], d = c.getSnapshot;
          c = c.value;
          try {
            if (!ti(d(), c)) return !1;
          } catch {
            return !1;
          }
        }
      }
      if (l = r.child, r.subtreeFlags & 16384 && l !== null) l.return = r, r = l;
      else {
        if (r === n) break;
        for (; r.sibling === null; ) {
          if (r.return === null || r.return === n) return !0;
          r = r.return;
        }
        r.sibling.return = r.return, r = r.sibling;
      }
    }
    return !0;
  }
  function xi(n, r) {
    for (r &= ~$s, r &= ~rf, n.suspendedLanes |= r, n.pingedLanes &= ~r, n = n.expirationTimes; 0 < r; ) {
      var l = 31 - br(r), u = 1 << l;
      n[l] = -1, r &= ~u;
    }
  }
  function lf(n) {
    if (zt & 6) throw Error(g(327));
    Lu();
    var r = di(n, 0);
    if (!(r & 1)) return un(n, Yt()), null;
    var l = Nu(n, r);
    if (n.tag !== 0 && l === 2) {
      var u = pi(n);
      u !== 0 && (r = u, l = Ks(n, u));
    }
    if (l === 1) throw l = Vs, Yl(n, 0), xi(n, r), un(n, Yt()), l;
    if (l === 6) throw Error(g(345));
    return n.finishedWork = n.current.alternate, n.finishedLanes = r, Uo(n, rr, al), un(n, Yt()), null;
  }
  function Lo(n, r) {
    var l = zt;
    zt |= 1;
    try {
      return n(r);
    } finally {
      zt = l, zt === 0 && (Oo = Yt() + 500, Ml && gi());
    }
  }
  function Ao(n) {
    wi !== null && wi.tag === 0 && !(zt & 6) && Lu();
    var r = zt;
    zt |= 1;
    var l = Ca.transition, u = kt;
    try {
      if (Ca.transition = null, kt = 1, n) return n();
    } finally {
      kt = u, Ca.transition = l, zt = r, !(zt & 6) && gi();
    }
  }
  function Mu() {
    Dr = ko.current, He(ko);
  }
  function Yl(n, r) {
    n.finishedWork = null, n.finishedLanes = 0;
    var l = n.timeoutHandle;
    if (l !== -1 && (n.timeoutHandle = -1, Ts(l)), mn !== null) for (l = mn.return; l !== null; ) {
      var u = l;
      switch (Lc(u), u.tag) {
        case 1:
          u = u.type.childContextTypes, u != null && Wr();
          break;
        case 3:
          vu(), He(vt), He(Qn), Pc();
          break;
        case 5:
          Rd(u);
          break;
        case 4:
          vu();
          break;
        case 13:
          He(En);
          break;
        case 19:
          He(En);
          break;
        case 10:
          ma(u.type._context);
          break;
        case 22:
        case 23:
          Mu();
      }
      l = l.return;
    }
    if (Rn = n, mn = n = Wl(n.current, null), wn = Dr = r, In = 0, Vs = null, $s = rf = Do = 0, rr = Is = null, bo !== null) {
      for (r = 0; r < bo.length; r++) if (l = bo[r], u = l.interleaved, u !== null) {
        l.interleaved = null;
        var c = u.next, d = l.pending;
        if (d !== null) {
          var y = d.next;
          d.next = c, u.next = y;
        }
        l.pending = u;
      }
      bo = null;
    }
    return n;
  }
  function oh(n, r) {
    do {
      var l = mn;
      try {
        if (Pa(), Hc.current = Ci, dn) {
          for (var u = Ce.memoizedState; u !== null; ) {
            var c = u.queue;
            c !== null && (c.pending = null), u = u.next;
          }
          dn = !1;
        }
        if (el = 0, pt = qe = Ce = null, qr = !1, hu = 0, Ou.current = null, l === null || l.return === null) {
          In = 1, Vs = r, mn = null;
          break;
        }
        e: {
          var d = n, y = l.return, R = l, k = r;
          if (r = wn, R.flags |= 32768, k !== null && typeof k == "object" && typeof k.then == "function") {
            var V = k, se = R, fe = se.tag;
            if (!(se.mode & 1) && (fe === 0 || fe === 11 || fe === 15)) {
              var le = se.alternate;
              le ? (se.updateQueue = le.updateQueue, se.memoizedState = le.memoizedState, se.lanes = le.lanes) : (se.updateQueue = null, se.memoizedState = null);
            }
            var _e = As(y);
            if (_e !== null) {
              _e.flags &= -257, Zv(_e, y, R, d, r), _e.mode & 1 && Jv(d, V, r), r = _e, k = V;
              var ze = r.updateQueue;
              if (ze === null) {
                var Pe = /* @__PURE__ */ new Set();
                Pe.add(k), r.updateQueue = Pe;
              } else ze.add(k);
              break e;
            } else {
              if (!(r & 1)) {
                Jv(d, V, r), Kd();
                break e;
              }
              k = Error(g(426));
            }
          } else if (fn && R.mode & 1) {
            var Nn = As(y);
            if (Nn !== null) {
              !(Nn.flags & 65536) && (Nn.flags |= 256), Zv(Nn, y, R, d, r), jn(Tu(k, R));
              break e;
            }
          }
          d = k = Tu(k, R), In !== 4 && (In = 2), Is === null ? Is = [d] : Is.push(d), d = y;
          do {
            switch (d.tag) {
              case 3:
                d.flags |= 65536, r &= -r, d.lanes |= r;
                var z = Ad(d, k, r);
                Yv(d, z);
                break e;
              case 1:
                R = k;
                var O = d.type, P = d.stateNode;
                if (!(d.flags & 128) && (typeof O.getDerivedStateFromError == "function" || P !== null && typeof P.componentDidCatch == "function" && (Vl === null || !Vl.has(P)))) {
                  d.flags |= 65536, r &= -r, d.lanes |= r;
                  var me = Xv(d, R, r);
                  Yv(d, me);
                  break e;
                }
            }
            d = d.return;
          } while (d !== null);
        }
        ch(l);
      } catch (Be) {
        r = Be, mn === l && l !== null && (mn = l = l.return);
        continue;
      }
      break;
    } while (!0);
  }
  function uh() {
    var n = nf.current;
    return nf.current = Ci, n === null ? Ci : n;
  }
  function Kd() {
    (In === 0 || In === 3 || In === 2) && (In = 4), Rn === null || !(Do & 268435455) && !(rf & 268435455) || xi(Rn, wn);
  }
  function Nu(n, r) {
    var l = zt;
    zt |= 2;
    var u = uh();
    (Rn !== n || wn !== r) && (al = null, Yl(n, r));
    do
      try {
        Oy();
        break;
      } catch (c) {
        oh(n, c);
      }
    while (!0);
    if (Pa(), zt = l, nf.current = u, mn !== null) throw Error(g(261));
    return Rn = null, wn = 0, In;
  }
  function Oy() {
    for (; mn !== null; ) sh(mn);
  }
  function My() {
    for (; mn !== null && !hn(); ) sh(mn);
  }
  function sh(n) {
    var r = vh(n.alternate, n, Dr);
    n.memoizedProps = n.pendingProps, r === null ? ch(n) : mn = r, Ou.current = null;
  }
  function ch(n) {
    var r = n;
    do {
      var l = r.alternate;
      if (n = r.return, r.flags & 32768) {
        if (l = _y(l, r), l !== null) {
          l.flags &= 32767, mn = l;
          return;
        }
        if (n !== null) n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null;
        else {
          In = 6, mn = null;
          return;
        }
      } else if (l = xy(l, r, Dr), l !== null) {
        mn = l;
        return;
      }
      if (r = r.sibling, r !== null) {
        mn = r;
        return;
      }
      mn = r = n;
    } while (r !== null);
    In === 0 && (In = 5);
  }
  function Uo(n, r, l) {
    var u = kt, c = Ca.transition;
    try {
      Ca.transition = null, kt = 1, fh(n, r, l, u);
    } finally {
      Ca.transition = c, kt = u;
    }
    return null;
  }
  function fh(n, r, l, u) {
    do
      Lu();
    while (wi !== null);
    if (zt & 6) throw Error(g(327));
    l = n.finishedWork;
    var c = n.finishedLanes;
    if (l === null) return null;
    if (n.finishedWork = null, n.finishedLanes = 0, l === n.current) throw Error(g(177));
    n.callbackNode = null, n.callbackPriority = 0;
    var d = l.lanes | l.childLanes;
    if (ns(n, d), n === Rn && (mn = Rn = null, wn = 0), !(l.subtreeFlags & 2064) && !(l.flags & 2064) || $l || ($l = !0, hh(yt, function() {
      return Lu(), null;
    })), d = (l.flags & 15990) !== 0, l.subtreeFlags & 15990 || d) {
      d = Ca.transition, Ca.transition = null;
      var y = kt;
      kt = 1;
      var R = zt;
      zt |= 4, Ou.current = null, Bd(n, l), rl(l, n), ho(cd), vo = !!sd, cd = sd = null, n.current = l, ky(l), mr(), zt = R, kt = y, Ca.transition = d;
    } else n.current = l;
    if ($l && ($l = !1, wi = n, Il = c), d = n.pendingLanes, d === 0 && (Vl = null), Ju(l.stateNode), un(n, Yt()), r !== null) for (u = n.onRecoverableError, l = 0; l < r.length; l++) c = r[l], u(c.value, { componentStack: c.stack, digest: c.digest });
    if (af) throw af = !1, n = Qd, Qd = null, n;
    return Il & 1 && n.tag !== 0 && Lu(), d = n.pendingLanes, d & 1 ? n === Gd ? Ws++ : (Ws = 0, Gd = n) : Ws = 0, gi(), null;
  }
  function Lu() {
    if (wi !== null) {
      var n = as(Il), r = Ca.transition, l = kt;
      try {
        if (Ca.transition = null, kt = 16 > n ? 16 : n, wi === null) var u = !1;
        else {
          if (n = wi, wi = null, Il = 0, zt & 6) throw Error(g(331));
          var c = zt;
          for (zt |= 4, Oe = n.current; Oe !== null; ) {
            var d = Oe, y = d.child;
            if (Oe.flags & 16) {
              var R = d.deletions;
              if (R !== null) {
                for (var k = 0; k < R.length; k++) {
                  var V = R[k];
                  for (Oe = V; Oe !== null; ) {
                    var se = Oe;
                    switch (se.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Ps(8, se, d);
                    }
                    var fe = se.child;
                    if (fe !== null) fe.return = se, Oe = fe;
                    else for (; Oe !== null; ) {
                      se = Oe;
                      var le = se.sibling, _e = se.return;
                      if ($d(se), se === V) {
                        Oe = null;
                        break;
                      }
                      if (le !== null) {
                        le.return = _e, Oe = le;
                        break;
                      }
                      Oe = _e;
                    }
                  }
                }
                var ze = d.alternate;
                if (ze !== null) {
                  var Pe = ze.child;
                  if (Pe !== null) {
                    ze.child = null;
                    do {
                      var Nn = Pe.sibling;
                      Pe.sibling = null, Pe = Nn;
                    } while (Pe !== null);
                  }
                }
                Oe = d;
              }
            }
            if (d.subtreeFlags & 2064 && y !== null) y.return = d, Oe = y;
            else e: for (; Oe !== null; ) {
              if (d = Oe, d.flags & 2048) switch (d.tag) {
                case 0:
                case 11:
                case 15:
                  Ps(9, d, d.return);
              }
              var z = d.sibling;
              if (z !== null) {
                z.return = d.return, Oe = z;
                break e;
              }
              Oe = d.return;
            }
          }
          var O = n.current;
          for (Oe = O; Oe !== null; ) {
            y = Oe;
            var P = y.child;
            if (y.subtreeFlags & 2064 && P !== null) P.return = y, Oe = P;
            else e: for (y = O; Oe !== null; ) {
              if (R = Oe, R.flags & 2048) try {
                switch (R.tag) {
                  case 0:
                  case 11:
                  case 15:
                    Hs(9, R);
                }
              } catch (Be) {
                xn(R, R.return, Be);
              }
              if (R === y) {
                Oe = null;
                break e;
              }
              var me = R.sibling;
              if (me !== null) {
                me.return = R.return, Oe = me;
                break e;
              }
              Oe = R.return;
            }
          }
          if (zt = c, gi(), Vr && typeof Vr.onPostCommitFiberRoot == "function") try {
            Vr.onPostCommitFiberRoot(El, n);
          } catch {
          }
          u = !0;
        }
        return u;
      } finally {
        kt = l, Ca.transition = r;
      }
    }
    return !1;
  }
  function dh(n, r, l) {
    r = Tu(l, r), r = Ad(n, r, 1), n = ga(n, r, 1), r = qn(), n !== null && (bl(n, 1, r), un(n, r));
  }
  function xn(n, r, l) {
    if (n.tag === 3) dh(n, n, l);
    else for (; r !== null; ) {
      if (r.tag === 3) {
        dh(r, n, l);
        break;
      } else if (r.tag === 1) {
        var u = r.stateNode;
        if (typeof r.type.getDerivedStateFromError == "function" || typeof u.componentDidCatch == "function" && (Vl === null || !Vl.has(u))) {
          n = Tu(l, n), n = Xv(r, n, 1), r = ga(r, n, 1), n = qn(), r !== null && (bl(r, 1, n), un(r, n));
          break;
        }
      }
      r = r.return;
    }
  }
  function Ny(n, r, l) {
    var u = n.pingCache;
    u !== null && u.delete(r), r = qn(), n.pingedLanes |= n.suspendedLanes & l, Rn === n && (wn & l) === l && (In === 4 || In === 3 && (wn & 130023424) === wn && 500 > Yt() - Ys ? Yl(n, 0) : $s |= l), un(n, r);
  }
  function ph(n, r) {
    r === 0 && (n.mode & 1 ? (r = qo, qo <<= 1, !(qo & 130023424) && (qo = 4194304)) : r = 1);
    var l = qn();
    n = Zi(n, r), n !== null && (bl(n, r, l), un(n, l));
  }
  function Ly(n) {
    var r = n.memoizedState, l = 0;
    r !== null && (l = r.retryLane), ph(n, l);
  }
  function qd(n, r) {
    var l = 0;
    switch (n.tag) {
      case 13:
        var u = n.stateNode, c = n.memoizedState;
        c !== null && (l = c.retryLane);
        break;
      case 19:
        u = n.stateNode;
        break;
      default:
        throw Error(g(314));
    }
    u !== null && u.delete(r), ph(n, l);
  }
  var vh;
  vh = function(n, r, l) {
    if (n !== null) if (n.memoizedProps !== r.pendingProps || vt.current) Rr = !0;
    else {
      if (!(n.lanes & l) && !(r.flags & 128)) return Rr = !1, Ea(n, r, l);
      Rr = !!(n.flags & 131072);
    }
    else Rr = !1, fn && r.flags & 1048576 && Ll(r, Eo, r.index);
    switch (r.lanes = 0, r.tag) {
      case 2:
        var u = r.type;
        Fs(n, r), n = r.pendingProps;
        var c = pa(r, Qn.current);
        fu(r, l), c = ks(null, r, u, n, c, l);
        var d = ie();
        return r.flags |= 1, typeof c == "object" && c !== null && typeof c.render == "function" && c.$$typeof === void 0 ? (r.tag = 1, r.memoizedState = null, r.updateQueue = null, Fn(u) ? (d = !0, So(r)) : d = !1, r.memoizedState = c.state !== null && c.state !== void 0 ? c.state : null, Cd(r), c.updater = jl, r.stateNode = c, c._reactInternals = r, Md(r, u, n, l), r = wu(null, r, u, !0, d, l)) : (r.tag = 0, fn && d && Nc(r), wr(null, r, c, l), r = r.child), r;
      case 16:
        u = r.elementType;
        e: {
          switch (Fs(n, r), n = r.pendingProps, c = u._init, u = c(u._payload), r.type = u, c = r.tag = Uy(u), n = Xr(u, n), c) {
            case 0:
              r = Bl(null, r, u, n, l);
              break e;
            case 1:
              r = gt(null, r, u, n, l);
              break e;
            case 11:
              r = Pl(null, r, u, n, l);
              break e;
            case 14:
              r = Ru(null, r, u, Xr(u.type, n), l);
              break e;
          }
          throw Error(g(
            306,
            u,
            ""
          ));
        }
        return r;
      case 0:
        return u = r.type, c = r.pendingProps, c = r.elementType === u ? c : Xr(u, c), Bl(n, r, u, c, l);
      case 1:
        return u = r.type, c = r.pendingProps, c = r.elementType === u ? c : Xr(u, c), gt(n, r, u, c, l);
      case 3:
        e: {
          if (Ud(r), n === null) throw Error(g(387));
          u = r.pendingProps, d = r.memoizedState, c = d.element, bd(n, r), jc(r, u, null, l);
          var y = r.memoizedState;
          if (u = y.element, d.isDehydrated) if (d = { element: u, isDehydrated: !1, cache: y.cache, pendingSuspenseBoundaries: y.pendingSuspenseBoundaries, transitions: y.transitions }, r.updateQueue.baseState = d, r.memoizedState = d, r.flags & 256) {
            c = Tu(Error(g(423)), r), r = Ry(n, r, u, l, c);
            break e;
          } else if (u !== c) {
            c = Tu(Error(g(424)), r), r = Ry(n, r, u, l, c);
            break e;
          } else for (ha = da(r.stateNode.containerInfo.firstChild), va = r, fn = !0, ja = null, l = Iv(r, null, u, l), r.child = l; l; ) l.flags = l.flags & -3 | 4096, l = l.sibling;
          else {
            if (su(), u === c) {
              r = bi(n, r, l);
              break e;
            }
            wr(n, r, u, l);
          }
          r = r.child;
        }
        return r;
      case 5:
        return Qv(r), n === null && Ac(r), u = r.type, c = r.pendingProps, d = n !== null ? n.memoizedProps : null, y = c.children, go(u, c) ? y = null : d !== null && go(u, d) && (r.flags |= 32), Jr(n, r), wr(n, r, y, l), r.child;
      case 6:
        return n === null && Ac(r), null;
      case 13:
        return xu(n, r, l);
      case 4:
        return Td(r, r.stateNode.containerInfo), u = r.pendingProps, n === null ? r.child = zl(r, null, u, l) : wr(n, r, u, l), r.child;
      case 11:
        return u = r.type, c = r.pendingProps, c = r.elementType === u ? c : Xr(u, c), Pl(n, r, u, c, l);
      case 7:
        return wr(n, r, r.pendingProps, l), r.child;
      case 8:
        return wr(n, r, r.pendingProps.children, l), r.child;
      case 12:
        return wr(n, r, r.pendingProps.children, l), r.child;
      case 10:
        e: {
          if (u = r.type._context, c = r.pendingProps, d = r.memoizedProps, y = c.value, Ht(zc, u._currentValue), u._currentValue = y, d !== null) if (ti(d.value, y)) {
            if (d.children === c.children && !vt.current) {
              r = bi(n, r, l);
              break e;
            }
          } else for (d = r.child, d !== null && (d.return = r); d !== null; ) {
            var R = d.dependencies;
            if (R !== null) {
              y = d.child;
              for (var k = R.firstContext; k !== null; ) {
                if (k.context === u) {
                  if (d.tag === 1) {
                    k = ya(-1, l & -l), k.tag = 2;
                    var V = d.updateQueue;
                    if (V !== null) {
                      V = V.shared;
                      var se = V.pending;
                      se === null ? k.next = k : (k.next = se.next, se.next = k), V.pending = k;
                    }
                  }
                  d.lanes |= l, k = d.alternate, k !== null && (k.lanes |= l), Sd(
                    d.return,
                    l,
                    r
                  ), R.lanes |= l;
                  break;
                }
                k = k.next;
              }
            } else if (d.tag === 10) y = d.type === r.type ? null : d.child;
            else if (d.tag === 18) {
              if (y = d.return, y === null) throw Error(g(341));
              y.lanes |= l, R = y.alternate, R !== null && (R.lanes |= l), Sd(y, l, r), y = d.sibling;
            } else y = d.child;
            if (y !== null) y.return = d;
            else for (y = d; y !== null; ) {
              if (y === r) {
                y = null;
                break;
              }
              if (d = y.sibling, d !== null) {
                d.return = y.return, y = d;
                break;
              }
              y = y.return;
            }
            d = y;
          }
          wr(n, r, c.children, l), r = r.child;
        }
        return r;
      case 9:
        return c = r.type, u = r.pendingProps.children, fu(r, l), c = Ha(c), u = u(c), r.flags |= 1, wr(n, r, u, l), r.child;
      case 14:
        return u = r.type, c = Xr(u, r.pendingProps), c = Xr(u.type, c), Ru(n, r, u, c, l);
      case 15:
        return Hl(n, r, r.type, r.pendingProps, l);
      case 17:
        return u = r.type, c = r.pendingProps, c = r.elementType === u ? c : Xr(u, c), Fs(n, r), r.tag = 1, Fn(u) ? (n = !0, So(r)) : n = !1, fu(r, l), Kv(r, u, c), Md(r, u, c, l), wu(null, r, u, !0, n, l);
      case 19:
        return Pd(n, r, l);
      case 22:
        return Zc(n, r, l);
    }
    throw Error(g(156, r.tag));
  };
  function hh(n, r) {
    return Un(n, r);
  }
  function Ay(n, r, l, u) {
    this.tag = n, this.key = l, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = r, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = u, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function ba(n, r, l, u) {
    return new Ay(n, r, l, u);
  }
  function Xd(n) {
    return n = n.prototype, !(!n || !n.isReactComponent);
  }
  function Uy(n) {
    if (typeof n == "function") return Xd(n) ? 1 : 0;
    if (n != null) {
      if (n = n.$$typeof, n === W) return 11;
      if (n === we) return 14;
    }
    return 2;
  }
  function Wl(n, r) {
    var l = n.alternate;
    return l === null ? (l = ba(n.tag, r, n.key, n.mode), l.elementType = n.elementType, l.type = n.type, l.stateNode = n.stateNode, l.alternate = n, n.alternate = l) : (l.pendingProps = r, l.type = n.type, l.flags = 0, l.subtreeFlags = 0, l.deletions = null), l.flags = n.flags & 14680064, l.childLanes = n.childLanes, l.lanes = n.lanes, l.child = n.child, l.memoizedProps = n.memoizedProps, l.memoizedState = n.memoizedState, l.updateQueue = n.updateQueue, r = n.dependencies, l.dependencies = r === null ? null : { lanes: r.lanes, firstContext: r.firstContext }, l.sibling = n.sibling, l.index = n.index, l.ref = n.ref, l;
  }
  function of(n, r, l, u, c, d) {
    var y = 2;
    if (u = n, typeof n == "function") Xd(n) && (y = 1);
    else if (typeof n == "string") y = 5;
    else e: switch (n) {
      case lt:
        return zo(l.children, c, d, r);
      case it:
        y = 8, c |= 8;
        break;
      case Jt:
        return n = ba(12, l, r, c | 2), n.elementType = Jt, n.lanes = d, n;
      case X:
        return n = ba(13, l, r, c), n.elementType = X, n.lanes = d, n;
      case ae:
        return n = ba(19, l, r, c), n.elementType = ae, n.lanes = d, n;
      case Le:
        return uf(l, c, d, r);
      default:
        if (typeof n == "object" && n !== null) switch (n.$$typeof) {
          case jt:
            y = 10;
            break e;
          case Xe:
            y = 9;
            break e;
          case W:
            y = 11;
            break e;
          case we:
            y = 14;
            break e;
          case Ue:
            y = 16, u = null;
            break e;
        }
        throw Error(g(130, n == null ? n : typeof n, ""));
    }
    return r = ba(y, l, r, c), r.elementType = n, r.type = u, r.lanes = d, r;
  }
  function zo(n, r, l, u) {
    return n = ba(7, n, u, r), n.lanes = l, n;
  }
  function uf(n, r, l, u) {
    return n = ba(22, n, u, r), n.elementType = Le, n.lanes = l, n.stateNode = { isHidden: !1 }, n;
  }
  function Jd(n, r, l) {
    return n = ba(6, n, null, r), n.lanes = l, n;
  }
  function sf(n, r, l) {
    return r = ba(4, n.children !== null ? n.children : [], n.key, r), r.lanes = l, r.stateNode = { containerInfo: n.containerInfo, pendingChildren: null, implementation: n.implementation }, r;
  }
  function Zd(n, r, l, u, c) {
    this.tag = r, this.containerInfo = n, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = so(0), this.expirationTimes = so(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = so(0), this.identifierPrefix = u, this.onRecoverableError = c, this.mutableSourceEagerHydrationData = null;
  }
  function Fo(n, r, l, u, c, d, y, R, k) {
    return n = new Zd(n, r, l, R, k), r === 1 ? (r = 1, d === !0 && (r |= 8)) : r = 0, d = ba(3, null, null, r), n.current = d, d.stateNode = n, d.memoizedState = { element: u, isDehydrated: l, cache: null, transitions: null, pendingSuspenseBoundaries: null }, Cd(d), n;
  }
  function zy(n, r, l) {
    var u = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return { $$typeof: Ne, key: u == null ? null : "" + u, children: n, containerInfo: r, implementation: l };
  }
  function ep(n) {
    if (!n) return Ua;
    n = n._reactInternals;
    e: {
      if (ce(n) !== n || n.tag !== 1) throw Error(g(170));
      var r = n;
      do {
        switch (r.tag) {
          case 3:
            r = r.stateNode.context;
            break e;
          case 1:
            if (Fn(r.type)) {
              r = r.stateNode.__reactInternalMemoizedMergedChildContext;
              break e;
            }
        }
        r = r.return;
      } while (r !== null);
      throw Error(g(171));
    }
    if (n.tag === 1) {
      var l = n.type;
      if (Fn(l)) return Ol(n, l, r);
    }
    return r;
  }
  function tp(n, r, l, u, c, d, y, R, k) {
    return n = Fo(l, u, !0, n, c, d, y, R, k), n.context = ep(null), l = n.current, u = qn(), c = ui(l), d = ya(u, c), d.callback = r ?? null, ga(l, d, c), n.current.lanes = c, bl(n, c, u), un(n, u), n;
  }
  function qs(n, r, l, u) {
    var c = r.current, d = qn(), y = ui(c);
    return l = ep(l), r.context === null ? r.context = l : r.pendingContext = l, r = ya(d, y), r.payload = { element: n }, u = u === void 0 ? null : u, u !== null && (r.callback = u), n = ga(c, r, y), n !== null && (Ba(n, c, y, d), Fc(n, c, y)), y;
  }
  function cf(n) {
    if (n = n.current, !n.child) return null;
    switch (n.child.tag) {
      case 5:
        return n.child.stateNode;
      default:
        return n.child.stateNode;
    }
  }
  function np(n, r) {
    if (n = n.memoizedState, n !== null && n.dehydrated !== null) {
      var l = n.retryLane;
      n.retryLane = l !== 0 && l < r ? l : r;
    }
  }
  function rp(n, r) {
    np(n, r), (n = n.alternate) && np(n, r);
  }
  function Fy() {
    return null;
  }
  var mh = typeof reportError == "function" ? reportError : function(n) {
    console.error(n);
  };
  function ff(n) {
    this._internalRoot = n;
  }
  Xs.prototype.render = ff.prototype.render = function(n) {
    var r = this._internalRoot;
    if (r === null) throw Error(g(409));
    qs(n, r, null, null);
  }, Xs.prototype.unmount = ff.prototype.unmount = function() {
    var n = this._internalRoot;
    if (n !== null) {
      this._internalRoot = null;
      var r = n.containerInfo;
      Ao(function() {
        qs(null, n, null, null);
      }), r[ni] = null;
    }
  };
  function Xs(n) {
    this._internalRoot = n;
  }
  Xs.prototype.unstable_scheduleHydration = function(n) {
    if (n) {
      var r = Dt();
      n = { blockedOn: null, target: n, priority: r };
      for (var l = 0; l < sn.length && r !== 0 && r < sn[l].priority; l++) ;
      sn.splice(l, 0, n), l === 0 && Za(n);
    }
  };
  function df(n) {
    return !(!n || n.nodeType !== 1 && n.nodeType !== 9 && n.nodeType !== 11);
  }
  function il(n) {
    return !(!n || n.nodeType !== 1 && n.nodeType !== 9 && n.nodeType !== 11 && (n.nodeType !== 8 || n.nodeValue !== " react-mount-point-unstable "));
  }
  function yh() {
  }
  function jy(n, r, l, u, c) {
    if (c) {
      if (typeof u == "function") {
        var d = u;
        u = function() {
          var V = cf(y);
          d.call(V);
        };
      }
      var y = tp(r, u, n, 0, null, !1, !1, "", yh);
      return n._reactRootContainer = y, n[ni] = y.current, hi(n.nodeType === 8 ? n.parentNode : n), Ao(), y;
    }
    for (; c = n.lastChild; ) n.removeChild(c);
    if (typeof u == "function") {
      var R = u;
      u = function() {
        var V = cf(k);
        R.call(V);
      };
    }
    var k = Fo(n, 0, !1, null, null, !1, !1, "", yh);
    return n._reactRootContainer = k, n[ni] = k.current, hi(n.nodeType === 8 ? n.parentNode : n), Ao(function() {
      qs(r, k, l, u);
    }), k;
  }
  function pf(n, r, l, u, c) {
    var d = l._reactRootContainer;
    if (d) {
      var y = d;
      if (typeof c == "function") {
        var R = c;
        c = function() {
          var k = cf(y);
          R.call(k);
        };
      }
      qs(r, y, n, c);
    } else y = jy(l, r, n, c, u);
    return cf(y);
  }
  Xo = function(n) {
    switch (n.tag) {
      case 3:
        var r = n.stateNode;
        if (r.current.memoizedState.isDehydrated) {
          var l = Pi(r.pendingLanes);
          l !== 0 && (rs(r, l | 1), un(r, Yt()), !(zt & 6) && (Oo = Yt() + 500, gi()));
        }
        break;
      case 13:
        Ao(function() {
          var u = Zi(n, 1);
          if (u !== null) {
            var c = qn();
            Ba(u, n, 1, c);
          }
        }), rp(n, 1);
    }
  }, Tl = function(n) {
    if (n.tag === 13) {
      var r = Zi(n, 134217728);
      if (r !== null) {
        var l = qn();
        Ba(r, n, 134217728, l);
      }
      rp(n, 134217728);
    }
  }, is = function(n) {
    if (n.tag === 13) {
      var r = ui(n), l = Zi(n, r);
      if (l !== null) {
        var u = qn();
        Ba(l, n, r, u);
      }
      rp(n, r);
    }
  }, Dt = function() {
    return kt;
  }, Jo = function(n, r) {
    var l = kt;
    try {
      return kt = n, r();
    } finally {
      kt = l;
    }
  }, Gt = function(n, r, l) {
    switch (r) {
      case "input":
        if (Dn(n, l), r = l.name, l.type === "radio" && r != null) {
          for (l = n; l.parentNode; ) l = l.parentNode;
          for (l = l.querySelectorAll("input[name=" + JSON.stringify("" + r) + '][type="radio"]'), r = 0; r < l.length; r++) {
            var u = l[r];
            if (u !== n && u.form === n.form) {
              var c = Oc(u);
              if (!c) throw Error(g(90));
              Pr(u), Dn(u, c);
            }
          }
        }
        break;
      case "textarea":
        vr(n, l);
        break;
      case "select":
        r = l.value, r != null && Vn(n, !!l.multiple, r, !1);
    }
  }, yl = Lo, io = Ao;
  var Py = { usingClientEntryPoint: !1, Events: [mi, uu, Oc, Ka, ka, Lo] }, Js = { findFiberByHostInstance: qi, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" }, Hy = { bundleType: Js.bundleType, version: Js.version, rendererPackageName: Js.rendererPackageName, rendererConfig: Js.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: Ge.ReactCurrentDispatcher, findHostInstanceByFiber: function(n) {
    return n = tt(n), n === null ? null : n.stateNode;
  }, findFiberByHostInstance: Js.findFiberByHostInstance || Fy, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Zs = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Zs.isDisabled && Zs.supportsFiber) try {
      El = Zs.inject(Hy), Vr = Zs;
    } catch {
    }
  }
  return Qa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Py, Qa.createPortal = function(n, r) {
    var l = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!df(r)) throw Error(g(200));
    return zy(n, r, null, l);
  }, Qa.createRoot = function(n, r) {
    if (!df(n)) throw Error(g(299));
    var l = !1, u = "", c = mh;
    return r != null && (r.unstable_strictMode === !0 && (l = !0), r.identifierPrefix !== void 0 && (u = r.identifierPrefix), r.onRecoverableError !== void 0 && (c = r.onRecoverableError)), r = Fo(n, 1, !1, null, null, l, !1, u, c), n[ni] = r.current, hi(n.nodeType === 8 ? n.parentNode : n), new ff(r);
  }, Qa.findDOMNode = function(n) {
    if (n == null) return null;
    if (n.nodeType === 1) return n;
    var r = n._reactInternals;
    if (r === void 0)
      throw typeof n.render == "function" ? Error(g(188)) : (n = Object.keys(n).join(","), Error(g(268, n)));
    return n = tt(r), n = n === null ? null : n.stateNode, n;
  }, Qa.flushSync = function(n) {
    return Ao(n);
  }, Qa.hydrate = function(n, r, l) {
    if (!il(r)) throw Error(g(200));
    return pf(null, n, r, !0, l);
  }, Qa.hydrateRoot = function(n, r, l) {
    if (!df(n)) throw Error(g(405));
    var u = l != null && l.hydratedSources || null, c = !1, d = "", y = mh;
    if (l != null && (l.unstable_strictMode === !0 && (c = !0), l.identifierPrefix !== void 0 && (d = l.identifierPrefix), l.onRecoverableError !== void 0 && (y = l.onRecoverableError)), r = tp(r, null, n, 1, l ?? null, c, !1, d, y), n[ni] = r.current, hi(n), u) for (n = 0; n < u.length; n++) l = u[n], c = l._getVersion, c = c(l._source), r.mutableSourceEagerHydrationData == null ? r.mutableSourceEagerHydrationData = [l, c] : r.mutableSourceEagerHydrationData.push(
      l,
      c
    );
    return new Xs(r);
  }, Qa.render = function(n, r, l) {
    if (!il(r)) throw Error(g(200));
    return pf(null, n, r, !1, l);
  }, Qa.unmountComponentAtNode = function(n) {
    if (!il(n)) throw Error(g(40));
    return n._reactRootContainer ? (Ao(function() {
      pf(null, null, n, !1, function() {
        n._reactRootContainer = null, n[ni] = null;
      });
    }), !0) : !1;
  }, Qa.unstable_batchedUpdates = Lo, Qa.unstable_renderSubtreeIntoContainer = function(n, r, l, u) {
    if (!il(l)) throw Error(g(200));
    if (n == null || n._reactInternals === void 0) throw Error(g(38));
    return pf(n, r, l, !1, u);
  }, Qa.version = "18.3.1-next-f1338f8080-20240426", Qa;
}
var Ga = {}, AT;
function kD() {
  if (AT) return Ga;
  AT = 1;
  var b = {};
  /**
   * @license React
   * react-dom.development.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  return b.NODE_ENV !== "production" && function() {
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
    var m = re, g = XT(), T = m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, L = !1;
    function U(e) {
      L = e;
    }
    function x(e) {
      if (!L) {
        for (var t = arguments.length, a = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
          a[i - 1] = arguments[i];
        ne("warn", e, a);
      }
    }
    function S(e) {
      if (!L) {
        for (var t = arguments.length, a = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++)
          a[i - 1] = arguments[i];
        ne("error", e, a);
      }
    }
    function ne(e, t, a) {
      {
        var i = T.ReactDebugCurrentFrame, o = i.getStackAddendum();
        o !== "" && (t += "%s", a = a.concat([o]));
        var s = a.map(function(f) {
          return String(f);
        });
        s.unshift("Warning: " + t), Function.prototype.apply.call(console[e], console, s);
      }
    }
    var te = 0, Q = 1, Z = 2, A = 3, oe = 4, q = 5, ve = 6, Ae = 7, Ye = 8, ut = 9, Ke = 10, Ge = 11, Rt = 12, Ne = 13, lt = 14, it = 15, Jt = 16, jt = 17, Xe = 18, W = 19, X = 21, ae = 22, we = 23, Ue = 24, Le = 25, I = !0, ge = !1, pe = !1, N = !1, J = !1, Te = !0, We = !1, st = !0, ft = !0, St = !0, Et = !0, nt = /* @__PURE__ */ new Set(), wt = {}, kn = {};
    function Pr(e, t) {
      dr(e, t), dr(e + "Capture", t);
    }
    function dr(e, t) {
      wt[e] && S("EventRegistry: More than one plugin attempted to publish the same registration name, `%s`.", e), wt[e] = t;
      {
        var a = e.toLowerCase();
        kn[a] = e, e === "onDoubleClick" && (kn.ondblclick = e);
      }
      for (var i = 0; i < t.length; i++)
        nt.add(t[i]);
    }
    var bn = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u", Jn = Object.prototype.hasOwnProperty;
    function Bn(e) {
      {
        var t = typeof Symbol == "function" && Symbol.toStringTag, a = t && e[Symbol.toStringTag] || e.constructor.name || "Object";
        return a;
      }
    }
    function Dn(e) {
      try {
        return An(e), !1;
      } catch {
        return !0;
      }
    }
    function An(e) {
      return "" + e;
    }
    function Sr(e, t) {
      if (Dn(e))
        return S("The provided `%s` attribute is an unsupported type %s. This value must be coerced to a string before before using it here.", t, Bn(e)), An(e);
    }
    function pr(e) {
      if (Dn(e))
        return S("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", Bn(e)), An(e);
    }
    function Vn(e, t) {
      if (Dn(e))
        return S("The provided `%s` prop is an unsupported type %s. This value must be coerced to a string before before using it here.", t, Bn(e)), An(e);
    }
    function aa(e, t) {
      if (Dn(e))
        return S("The provided `%s` CSS property is an unsupported type %s. This value must be coerced to a string before before using it here.", t, Bn(e)), An(e);
    }
    function ia(e) {
      if (Dn(e))
        return S("The provided HTML markup uses a value of unsupported type %s. This value must be coerced to a string before before using it here.", Bn(e)), An(e);
    }
    function vr(e) {
      if (Dn(e))
        return S("Form field values (value, checked, defaultValue, or defaultChecked props) must be strings, not %s. This value must be coerced to a string before before using it here.", Bn(e)), An(e);
    }
    var la = 0, Zn = 1, Er = 2, vn = 3, oa = 4, ua = 5, sa = 6, Ee = ":A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD", Qe = Ee + "\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040", Ct = new RegExp("^[" + Ee + "][" + Qe + "]*$"), $t = {}, Pt = {};
    function On(e) {
      return Jn.call(Pt, e) ? !0 : Jn.call($t, e) ? !1 : Ct.test(e) ? (Pt[e] = !0, !0) : ($t[e] = !0, S("Invalid attribute name: `%s`", e), !1);
    }
    function yn(e, t, a) {
      return t !== null ? t.type === la : a ? !1 : e.length > 2 && (e[0] === "o" || e[0] === "O") && (e[1] === "n" || e[1] === "N");
    }
    function hr(e, t, a, i) {
      if (a !== null && a.type === la)
        return !1;
      switch (typeof t) {
        case "function":
        case "symbol":
          return !0;
        case "boolean": {
          if (i)
            return !1;
          if (a !== null)
            return !a.acceptsBooleans;
          var o = e.toLowerCase().slice(0, 5);
          return o !== "data-" && o !== "aria-";
        }
        default:
          return !1;
      }
    }
    function Gt(e, t, a, i) {
      if (t === null || typeof t > "u" || hr(e, t, a, i))
        return !0;
      if (i)
        return !1;
      if (a !== null)
        switch (a.type) {
          case vn:
            return !t;
          case oa:
            return t === !1;
          case ua:
            return isNaN(t);
          case sa:
            return isNaN(t) || t < 1;
        }
      return !1;
    }
    function Wn(e) {
      return ln.hasOwnProperty(e) ? ln[e] : null;
    }
    function It(e, t, a, i, o, s, f) {
      this.acceptsBooleans = t === Er || t === vn || t === oa, this.attributeName = i, this.attributeNamespace = o, this.mustUseProperty = a, this.propertyName = e, this.type = t, this.sanitizeURL = s, this.removeEmptyString = f;
    }
    var ln = {}, Ka = [
      "children",
      "dangerouslySetInnerHTML",
      // TODO: This prevents the assignment of defaultValue to regular
      // elements (not just inputs). Now that ReactDOMInput assigns to the
      // defaultValue property -- do we need this?
      "defaultValue",
      "defaultChecked",
      "innerHTML",
      "suppressContentEditableWarning",
      "suppressHydrationWarning",
      "style"
    ];
    Ka.forEach(function(e) {
      ln[e] = new It(
        e,
        la,
        !1,
        // mustUseProperty
        e,
        // attributeName
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    }), [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(e) {
      var t = e[0], a = e[1];
      ln[t] = new It(
        t,
        Zn,
        !1,
        // mustUseProperty
        a,
        // attributeName
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    }), ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
      ln[e] = new It(
        e,
        Er,
        !1,
        // mustUseProperty
        e.toLowerCase(),
        // attributeName
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    }), ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
      ln[e] = new It(
        e,
        Er,
        !1,
        // mustUseProperty
        e,
        // attributeName
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    }), [
      "allowFullScreen",
      "async",
      // Note: there is a special case that prevents it from being written to the DOM
      // on the client side because the browsers are inconsistent. Instead we call focus().
      "autoFocus",
      "autoPlay",
      "controls",
      "default",
      "defer",
      "disabled",
      "disablePictureInPicture",
      "disableRemotePlayback",
      "formNoValidate",
      "hidden",
      "loop",
      "noModule",
      "noValidate",
      "open",
      "playsInline",
      "readOnly",
      "required",
      "reversed",
      "scoped",
      "seamless",
      // Microdata
      "itemScope"
    ].forEach(function(e) {
      ln[e] = new It(
        e,
        vn,
        !1,
        // mustUseProperty
        e.toLowerCase(),
        // attributeName
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    }), [
      "checked",
      // Note: `option.selected` is not updated if `select.multiple` is
      // disabled with `removeAttribute`. We have special logic for handling this.
      "multiple",
      "muted",
      "selected"
      // NOTE: if you add a camelCased prop to this list,
      // you'll need to set attributeName to name.toLowerCase()
      // instead in the assignment below.
    ].forEach(function(e) {
      ln[e] = new It(
        e,
        vn,
        !0,
        // mustUseProperty
        e,
        // attributeName
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    }), [
      "capture",
      "download"
      // NOTE: if you add a camelCased prop to this list,
      // you'll need to set attributeName to name.toLowerCase()
      // instead in the assignment below.
    ].forEach(function(e) {
      ln[e] = new It(
        e,
        oa,
        !1,
        // mustUseProperty
        e,
        // attributeName
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    }), [
      "cols",
      "rows",
      "size",
      "span"
      // NOTE: if you add a camelCased prop to this list,
      // you'll need to set attributeName to name.toLowerCase()
      // instead in the assignment below.
    ].forEach(function(e) {
      ln[e] = new It(
        e,
        sa,
        !1,
        // mustUseProperty
        e,
        // attributeName
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    }), ["rowSpan", "start"].forEach(function(e) {
      ln[e] = new It(
        e,
        ua,
        !1,
        // mustUseProperty
        e.toLowerCase(),
        // attributeName
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    });
    var ka = /[\-\:]([a-z])/g, yl = function(e) {
      return e[1].toUpperCase();
    };
    [
      "accent-height",
      "alignment-baseline",
      "arabic-form",
      "baseline-shift",
      "cap-height",
      "clip-path",
      "clip-rule",
      "color-interpolation",
      "color-interpolation-filters",
      "color-profile",
      "color-rendering",
      "dominant-baseline",
      "enable-background",
      "fill-opacity",
      "fill-rule",
      "flood-color",
      "flood-opacity",
      "font-family",
      "font-size",
      "font-size-adjust",
      "font-stretch",
      "font-style",
      "font-variant",
      "font-weight",
      "glyph-name",
      "glyph-orientation-horizontal",
      "glyph-orientation-vertical",
      "horiz-adv-x",
      "horiz-origin-x",
      "image-rendering",
      "letter-spacing",
      "lighting-color",
      "marker-end",
      "marker-mid",
      "marker-start",
      "overline-position",
      "overline-thickness",
      "paint-order",
      "panose-1",
      "pointer-events",
      "rendering-intent",
      "shape-rendering",
      "stop-color",
      "stop-opacity",
      "strikethrough-position",
      "strikethrough-thickness",
      "stroke-dasharray",
      "stroke-dashoffset",
      "stroke-linecap",
      "stroke-linejoin",
      "stroke-miterlimit",
      "stroke-opacity",
      "stroke-width",
      "text-anchor",
      "text-decoration",
      "text-rendering",
      "underline-position",
      "underline-thickness",
      "unicode-bidi",
      "unicode-range",
      "units-per-em",
      "v-alphabetic",
      "v-hanging",
      "v-ideographic",
      "v-mathematical",
      "vector-effect",
      "vert-adv-y",
      "vert-origin-x",
      "vert-origin-y",
      "word-spacing",
      "writing-mode",
      "xmlns:xlink",
      "x-height"
      // NOTE: if you add a camelCased prop to this list,
      // you'll need to set attributeName to name.toLowerCase()
      // instead in the assignment below.
    ].forEach(function(e) {
      var t = e.replace(ka, yl);
      ln[t] = new It(
        t,
        Zn,
        !1,
        // mustUseProperty
        e,
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    }), [
      "xlink:actuate",
      "xlink:arcrole",
      "xlink:role",
      "xlink:show",
      "xlink:title",
      "xlink:type"
      // NOTE: if you add a camelCased prop to this list,
      // you'll need to set attributeName to name.toLowerCase()
      // instead in the assignment below.
    ].forEach(function(e) {
      var t = e.replace(ka, yl);
      ln[t] = new It(
        t,
        Zn,
        !1,
        // mustUseProperty
        e,
        "http://www.w3.org/1999/xlink",
        !1,
        // sanitizeURL
        !1
      );
    }), [
      "xml:base",
      "xml:lang",
      "xml:space"
      // NOTE: if you add a camelCased prop to this list,
      // you'll need to set attributeName to name.toLowerCase()
      // instead in the assignment below.
    ].forEach(function(e) {
      var t = e.replace(ka, yl);
      ln[t] = new It(
        t,
        Zn,
        !1,
        // mustUseProperty
        e,
        "http://www.w3.org/XML/1998/namespace",
        !1,
        // sanitizeURL
        !1
      );
    }), ["tabIndex", "crossOrigin"].forEach(function(e) {
      ln[e] = new It(
        e,
        Zn,
        !1,
        // mustUseProperty
        e.toLowerCase(),
        // attributeName
        null,
        // attributeNamespace
        !1,
        // sanitizeURL
        !1
      );
    });
    var io = "xlinkHref";
    ln[io] = new It(
      "xlinkHref",
      Zn,
      !1,
      // mustUseProperty
      "xlink:href",
      "http://www.w3.org/1999/xlink",
      !0,
      // sanitizeURL
      !1
    ), ["src", "href", "action", "formAction"].forEach(function(e) {
      ln[e] = new It(
        e,
        Zn,
        !1,
        // mustUseProperty
        e.toLowerCase(),
        // attributeName
        null,
        // attributeNamespace
        !0,
        // sanitizeURL
        !0
      );
    });
    var lo = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*\:/i, gl = !1;
    function qa(e) {
      !gl && lo.test(e) && (gl = !0, S("A future version of React will block javascript: URLs as a security precaution. Use event handlers instead if you can. If you need to generate unsafe HTML try using dangerouslySetInnerHTML instead. React was passed %s.", JSON.stringify(e)));
    }
    function Xa(e, t, a, i) {
      if (i.mustUseProperty) {
        var o = i.propertyName;
        return e[o];
      } else {
        Sr(a, t), i.sanitizeURL && qa("" + a);
        var s = i.attributeName, f = null;
        if (i.type === oa) {
          if (e.hasAttribute(s)) {
            var p = e.getAttribute(s);
            return p === "" ? !0 : Gt(t, a, i, !1) ? p : p === "" + a ? a : p;
          }
        } else if (e.hasAttribute(s)) {
          if (Gt(t, a, i, !1))
            return e.getAttribute(s);
          if (i.type === vn)
            return a;
          f = e.getAttribute(s);
        }
        return Gt(t, a, i, !1) ? f === null ? a : f : f === "" + a ? a : f;
      }
    }
    function Da(e, t, a, i) {
      {
        if (!On(t))
          return;
        if (!e.hasAttribute(t))
          return a === void 0 ? void 0 : null;
        var o = e.getAttribute(t);
        return Sr(a, t), o === "" + a ? a : o;
      }
    }
    function Ui(e, t, a, i) {
      var o = Wn(t);
      if (!yn(t, o, i)) {
        if (Gt(t, a, o, i) && (a = null), i || o === null) {
          if (On(t)) {
            var s = t;
            a === null ? e.removeAttribute(s) : (Sr(a, t), e.setAttribute(s, "" + a));
          }
          return;
        }
        var f = o.mustUseProperty;
        if (f) {
          var p = o.propertyName;
          if (a === null) {
            var v = o.type;
            e[p] = v === vn ? !1 : "";
          } else
            e[p] = a;
          return;
        }
        var E = o.attributeName, C = o.attributeNamespace;
        if (a === null)
          e.removeAttribute(E);
        else {
          var M = o.type, D;
          M === vn || M === oa && a === !0 ? D = "" : (Sr(a, E), D = "" + a, o.sanitizeURL && qa(D.toString())), C ? e.setAttributeNS(C, E, D) : e.setAttribute(E, D);
        }
      }
    }
    var Cr = Symbol.for("react.element"), Hr = Symbol.for("react.portal"), ca = Symbol.for("react.fragment"), zi = Symbol.for("react.strict_mode"), Sl = Symbol.for("react.profiler"), _ = Symbol.for("react.provider"), ue = Symbol.for("react.context"), ce = Symbol.for("react.forward_ref"), Je = Symbol.for("react.suspense"), xt = Symbol.for("react.suspense_list"), Mt = Symbol.for("react.memo"), tt = Symbol.for("react.lazy"), bt = Symbol.for("react.scope"), Un = Symbol.for("react.debug_trace_mode"), tn = Symbol.for("react.offscreen"), hn = Symbol.for("react.legacy_hidden"), mr = Symbol.for("react.cache"), Yt = Symbol.for("react.tracing_marker"), Oa = Symbol.iterator, zn = "@@iterator";
    function Br(e) {
      if (e === null || typeof e != "object")
        return null;
      var t = Oa && e[Oa] || e[zn];
      return typeof t == "function" ? t : null;
    }
    var yt = Object.assign, Fi = 0, ji, El, Vr, Ju, br, Zu, es;
    function ts() {
    }
    ts.__reactDisabledLog = !0;
    function oo() {
      {
        if (Fi === 0) {
          ji = console.log, El = console.info, Vr = console.warn, Ju = console.error, br = console.group, Zu = console.groupCollapsed, es = console.groupEnd;
          var e = {
            configurable: !0,
            enumerable: !0,
            value: ts,
            writable: !0
          };
          Object.defineProperties(console, {
            info: e,
            log: e,
            warn: e,
            error: e,
            group: e,
            groupCollapsed: e,
            groupEnd: e
          });
        }
        Fi++;
      }
    }
    function qo() {
      {
        if (Fi--, Fi === 0) {
          var e = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: yt({}, e, {
              value: ji
            }),
            info: yt({}, e, {
              value: El
            }),
            warn: yt({}, e, {
              value: Vr
            }),
            error: yt({}, e, {
              value: Ju
            }),
            group: yt({}, e, {
              value: br
            }),
            groupCollapsed: yt({}, e, {
              value: Zu
            }),
            groupEnd: yt({}, e, {
              value: es
            })
          });
        }
        Fi < 0 && S("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var Pi = T.ReactCurrentDispatcher, di;
    function Ma(e, t, a) {
      {
        if (di === void 0)
          try {
            throw Error();
          } catch (o) {
            var i = o.stack.trim().match(/\n( *(at )?)/);
            di = i && i[1] || "";
          }
        return `
` + di + e;
      }
    }
    var Cl = !1, pi;
    {
      var uo = typeof WeakMap == "function" ? WeakMap : Map;
      pi = new uo();
    }
    function so(e, t) {
      if (!e || Cl)
        return "";
      {
        var a = pi.get(e);
        if (a !== void 0)
          return a;
      }
      var i;
      Cl = !0;
      var o = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var s;
      s = Pi.current, Pi.current = null, oo();
      try {
        if (t) {
          var f = function() {
            throw Error();
          };
          if (Object.defineProperty(f.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(f, []);
            } catch ($) {
              i = $;
            }
            Reflect.construct(e, [], f);
          } else {
            try {
              f.call();
            } catch ($) {
              i = $;
            }
            e.call(f.prototype);
          }
        } else {
          try {
            throw Error();
          } catch ($) {
            i = $;
          }
          e();
        }
      } catch ($) {
        if ($ && i && typeof $.stack == "string") {
          for (var p = $.stack.split(`
`), v = i.stack.split(`
`), E = p.length - 1, C = v.length - 1; E >= 1 && C >= 0 && p[E] !== v[C]; )
            C--;
          for (; E >= 1 && C >= 0; E--, C--)
            if (p[E] !== v[C]) {
              if (E !== 1 || C !== 1)
                do
                  if (E--, C--, C < 0 || p[E] !== v[C]) {
                    var M = `
` + p[E].replace(" at new ", " at ");
                    return e.displayName && M.includes("<anonymous>") && (M = M.replace("<anonymous>", e.displayName)), typeof e == "function" && pi.set(e, M), M;
                  }
                while (E >= 1 && C >= 0);
              break;
            }
        }
      } finally {
        Cl = !1, Pi.current = s, qo(), Error.prepareStackTrace = o;
      }
      var D = e ? e.displayName || e.name : "", B = D ? Ma(D) : "";
      return typeof e == "function" && pi.set(e, B), B;
    }
    function bl(e, t, a) {
      return so(e, !0);
    }
    function ns(e, t, a) {
      return so(e, !1);
    }
    function rs(e) {
      var t = e.prototype;
      return !!(t && t.isReactComponent);
    }
    function kt(e, t, a) {
      if (e == null)
        return "";
      if (typeof e == "function")
        return so(e, rs(e));
      if (typeof e == "string")
        return Ma(e);
      switch (e) {
        case Je:
          return Ma("Suspense");
        case xt:
          return Ma("SuspenseList");
      }
      if (typeof e == "object")
        switch (e.$$typeof) {
          case ce:
            return ns(e.render);
          case Mt:
            return kt(e.type, t, a);
          case tt: {
            var i = e, o = i._payload, s = i._init;
            try {
              return kt(s(o), t, a);
            } catch {
            }
          }
        }
      return "";
    }
    function as(e) {
      switch (e._debugOwner && e._debugOwner.type, e._debugSource, e.tag) {
        case q:
          return Ma(e.type);
        case Jt:
          return Ma("Lazy");
        case Ne:
          return Ma("Suspense");
        case W:
          return Ma("SuspenseList");
        case te:
        case Z:
        case it:
          return ns(e.type);
        case Ge:
          return ns(e.type.render);
        case Q:
          return bl(e.type);
        default:
          return "";
      }
    }
    function Xo(e) {
      try {
        var t = "", a = e;
        do
          t += as(a), a = a.return;
        while (a);
        return t;
      } catch (i) {
        return `
Error generating stack: ` + i.message + `
` + i.stack;
      }
    }
    function Tl(e, t, a) {
      var i = e.displayName;
      if (i)
        return i;
      var o = t.displayName || t.name || "";
      return o !== "" ? a + "(" + o + ")" : a;
    }
    function is(e) {
      return e.displayName || "Context";
    }
    function Dt(e) {
      if (e == null)
        return null;
      if (typeof e.tag == "number" && S("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof e == "function")
        return e.displayName || e.name || null;
      if (typeof e == "string")
        return e;
      switch (e) {
        case ca:
          return "Fragment";
        case Hr:
          return "Portal";
        case Sl:
          return "Profiler";
        case zi:
          return "StrictMode";
        case Je:
          return "Suspense";
        case xt:
          return "SuspenseList";
      }
      if (typeof e == "object")
        switch (e.$$typeof) {
          case ue:
            var t = e;
            return is(t) + ".Consumer";
          case _:
            var a = e;
            return is(a._context) + ".Provider";
          case ce:
            return Tl(e, e.render, "ForwardRef");
          case Mt:
            var i = e.displayName || null;
            return i !== null ? i : Dt(e.type) || "Memo";
          case tt: {
            var o = e, s = o._payload, f = o._init;
            try {
              return Dt(f(s));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    function Jo(e, t, a) {
      var i = t.displayName || t.name || "";
      return e.displayName || (i !== "" ? a + "(" + i + ")" : a);
    }
    function co(e) {
      return e.displayName || "Context";
    }
    function dt(e) {
      var t = e.tag, a = e.type;
      switch (t) {
        case Ue:
          return "Cache";
        case ut:
          var i = a;
          return co(i) + ".Consumer";
        case Ke:
          var o = a;
          return co(o._context) + ".Provider";
        case Xe:
          return "DehydratedFragment";
        case Ge:
          return Jo(a, a.render, "ForwardRef");
        case Ae:
          return "Fragment";
        case q:
          return a;
        case oe:
          return "Portal";
        case A:
          return "Root";
        case ve:
          return "Text";
        case Jt:
          return Dt(a);
        case Ye:
          return a === zi ? "StrictMode" : "Mode";
        case ae:
          return "Offscreen";
        case Rt:
          return "Profiler";
        case X:
          return "Scope";
        case Ne:
          return "Suspense";
        case W:
          return "SuspenseList";
        case Le:
          return "TracingMarker";
        case Q:
        case te:
        case jt:
        case Z:
        case lt:
        case it:
          if (typeof a == "function")
            return a.displayName || a.name || null;
          if (typeof a == "string")
            return a;
          break;
      }
      return null;
    }
    var Ja = T.ReactDebugCurrentFrame, gn = null, $r = !1;
    function Na() {
      {
        if (gn === null)
          return null;
        var e = gn._debugOwner;
        if (e !== null && typeof e < "u")
          return dt(e);
      }
      return null;
    }
    function Rl() {
      return gn === null ? "" : Xo(gn);
    }
    function sn() {
      Ja.getCurrentStack = null, gn = null, $r = !1;
    }
    function Sn(e) {
      Ja.getCurrentStack = e === null ? null : Rl, gn = e, $r = !1;
    }
    function ls() {
      return gn;
    }
    function er(e) {
      $r = e;
    }
    function Ir(e) {
      return "" + e;
    }
    function Za(e) {
      switch (typeof e) {
        case "boolean":
        case "number":
        case "string":
        case "undefined":
          return e;
        case "object":
          return vr(e), e;
        default:
          return "";
      }
    }
    var Zo = {
      button: !0,
      checkbox: !0,
      image: !0,
      hidden: !0,
      radio: !0,
      reset: !0,
      submit: !0
    };
    function fo(e, t) {
      Zo[t.type] || t.onChange || t.onInput || t.readOnly || t.disabled || t.value == null || S("You provided a `value` prop to a form field without an `onChange` handler. This will render a read-only field. If the field should be mutable use `defaultValue`. Otherwise, set either `onChange` or `readOnly`."), t.onChange || t.readOnly || t.disabled || t.checked == null || S("You provided a `checked` prop to a form field without an `onChange` handler. This will render a read-only field. If the field should be mutable use `defaultChecked`. Otherwise, set either `onChange` or `readOnly`.");
    }
    function po(e) {
      var t = e.type, a = e.nodeName;
      return a && a.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
    }
    function wl(e) {
      return e._valueTracker;
    }
    function La(e) {
      e._valueTracker = null;
    }
    function Hi(e) {
      var t = "";
      return e && (po(e) ? t = e.checked ? "true" : "false" : t = e.value), t;
    }
    function vo(e) {
      var t = po(e) ? "checked" : "value", a = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
      vr(e[t]);
      var i = "" + e[t];
      if (!(e.hasOwnProperty(t) || typeof a > "u" || typeof a.get != "function" || typeof a.set != "function")) {
        var o = a.get, s = a.set;
        Object.defineProperty(e, t, {
          configurable: !0,
          get: function() {
            return o.call(this);
          },
          set: function(p) {
            vr(p), i = "" + p, s.call(this, p);
          }
        }), Object.defineProperty(e, t, {
          enumerable: a.enumerable
        });
        var f = {
          getValue: function() {
            return i;
          },
          setValue: function(p) {
            vr(p), i = "" + p;
          },
          stopTracking: function() {
            La(e), delete e[t];
          }
        };
        return f;
      }
    }
    function Bi(e) {
      wl(e) || (e._valueTracker = vo(e));
    }
    function eu(e) {
      if (!e)
        return !1;
      var t = wl(e);
      if (!t)
        return !0;
      var a = t.getValue(), i = Hi(e);
      return i !== a ? (t.setValue(i), !0) : !1;
    }
    function vi(e) {
      if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u")
        return null;
      try {
        return e.activeElement || e.body;
      } catch {
        return e.body;
      }
    }
    var Vi = !1, tu = !1, os = !1, ei = !1;
    function nu(e) {
      var t = e.type === "checkbox" || e.type === "radio";
      return t ? e.checked != null : e.value != null;
    }
    function h(e, t) {
      var a = e, i = t.checked, o = yt({}, t, {
        defaultChecked: void 0,
        defaultValue: void 0,
        value: void 0,
        checked: i ?? a._wrapperState.initialChecked
      });
      return o;
    }
    function w(e, t) {
      fo("input", t), t.checked !== void 0 && t.defaultChecked !== void 0 && !tu && (S("%s contains an input of type %s with both checked and defaultChecked props. Input elements must be either controlled or uncontrolled (specify either the checked prop, or the defaultChecked prop, but not both). Decide between using a controlled or uncontrolled input element and remove one of these props. More info: https://reactjs.org/link/controlled-components", Na() || "A component", t.type), tu = !0), t.value !== void 0 && t.defaultValue !== void 0 && !Vi && (S("%s contains an input of type %s with both value and defaultValue props. Input elements must be either controlled or uncontrolled (specify either the value prop, or the defaultValue prop, but not both). Decide between using a controlled or uncontrolled input element and remove one of these props. More info: https://reactjs.org/link/controlled-components", Na() || "A component", t.type), Vi = !0);
      var a = e, i = t.defaultValue == null ? "" : t.defaultValue;
      a._wrapperState = {
        initialChecked: t.checked != null ? t.checked : t.defaultChecked,
        initialValue: Za(t.value != null ? t.value : i),
        controlled: nu(t)
      };
    }
    function H(e, t) {
      var a = e, i = t.checked;
      i != null && Ui(a, "checked", i, !1);
    }
    function Y(e, t) {
      var a = e;
      {
        var i = nu(t);
        !a._wrapperState.controlled && i && !ei && (S("A component is changing an uncontrolled input to be controlled. This is likely caused by the value changing from undefined to a defined value, which should not happen. Decide between using a controlled or uncontrolled input element for the lifetime of the component. More info: https://reactjs.org/link/controlled-components"), ei = !0), a._wrapperState.controlled && !i && !os && (S("A component is changing a controlled input to be uncontrolled. This is likely caused by the value changing from a defined to undefined, which should not happen. Decide between using a controlled or uncontrolled input element for the lifetime of the component. More info: https://reactjs.org/link/controlled-components"), os = !0);
      }
      H(e, t);
      var o = Za(t.value), s = t.type;
      if (o != null)
        s === "number" ? (o === 0 && a.value === "" || // We explicitly want to coerce to number here if possible.
        // eslint-disable-next-line
        a.value != o) && (a.value = Ir(o)) : a.value !== Ir(o) && (a.value = Ir(o));
      else if (s === "submit" || s === "reset") {
        a.removeAttribute("value");
        return;
      }
      t.hasOwnProperty("value") ? ot(a, t.type, o) : t.hasOwnProperty("defaultValue") && ot(a, t.type, Za(t.defaultValue)), t.checked == null && t.defaultChecked != null && (a.defaultChecked = !!t.defaultChecked);
    }
    function he(e, t, a) {
      var i = e;
      if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
        var o = t.type, s = o === "submit" || o === "reset";
        if (s && (t.value === void 0 || t.value === null))
          return;
        var f = Ir(i._wrapperState.initialValue);
        a || f !== i.value && (i.value = f), i.defaultValue = f;
      }
      var p = i.name;
      p !== "" && (i.name = ""), i.defaultChecked = !i.defaultChecked, i.defaultChecked = !!i._wrapperState.initialChecked, p !== "" && (i.name = p);
    }
    function je(e, t) {
      var a = e;
      Y(a, t), De(a, t);
    }
    function De(e, t) {
      var a = t.name;
      if (t.type === "radio" && a != null) {
        for (var i = e; i.parentNode; )
          i = i.parentNode;
        Sr(a, "name");
        for (var o = i.querySelectorAll("input[name=" + JSON.stringify("" + a) + '][type="radio"]'), s = 0; s < o.length; s++) {
          var f = o[s];
          if (!(f === e || f.form !== e.form)) {
            var p = Uh(f);
            if (!p)
              throw new Error("ReactDOMInput: Mixing React and non-React radio inputs with the same `name` is not supported.");
            eu(f), Y(f, p);
          }
        }
      }
    }
    function ot(e, t, a) {
      // Focused number inputs synchronize on blur. See ChangeEventPlugin.js
      (t !== "number" || vi(e.ownerDocument) !== e) && (a == null ? e.defaultValue = Ir(e._wrapperState.initialValue) : e.defaultValue !== Ir(a) && (e.defaultValue = Ir(a)));
    }
    var Tt = !1, Wt = !1, Kt = !1;
    function qt(e, t) {
      t.value == null && (typeof t.children == "object" && t.children !== null ? m.Children.forEach(t.children, function(a) {
        a != null && (typeof a == "string" || typeof a == "number" || Wt || (Wt = !0, S("Cannot infer the option value of complex children. Pass a `value` prop or use a plain string as children to <option>.")));
      }) : t.dangerouslySetInnerHTML != null && (Kt || (Kt = !0, S("Pass a `value` prop if you set dangerouslyInnerHTML so React knows which value should be selected.")))), t.selected != null && !Tt && (S("Use the `defaultValue` or `value` props on <select> instead of setting `selected` on <option>."), Tt = !0);
    }
    function Xt(e, t) {
      t.value != null && e.setAttribute("value", Ir(Za(t.value)));
    }
    var cn = Array.isArray;
    function At(e) {
      return cn(e);
    }
    var xl;
    xl = !1;
    function ru() {
      var e = Na();
      return e ? `

Check the render method of \`` + e + "`." : "";
    }
    var us = ["value", "defaultValue"];
    function ss(e) {
      {
        fo("select", e);
        for (var t = 0; t < us.length; t++) {
          var a = us[t];
          if (e[a] != null) {
            var i = At(e[a]);
            e.multiple && !i ? S("The `%s` prop supplied to <select> must be an array if `multiple` is true.%s", a, ru()) : !e.multiple && i && S("The `%s` prop supplied to <select> must be a scalar value if `multiple` is false.%s", a, ru());
          }
        }
      }
    }
    function $i(e, t, a, i) {
      var o = e.options;
      if (t) {
        for (var s = a, f = {}, p = 0; p < s.length; p++)
          f["$" + s[p]] = !0;
        for (var v = 0; v < o.length; v++) {
          var E = f.hasOwnProperty("$" + o[v].value);
          o[v].selected !== E && (o[v].selected = E), E && i && (o[v].defaultSelected = !0);
        }
      } else {
        for (var C = Ir(Za(a)), M = null, D = 0; D < o.length; D++) {
          if (o[D].value === C) {
            o[D].selected = !0, i && (o[D].defaultSelected = !0);
            return;
          }
          M === null && !o[D].disabled && (M = o[D]);
        }
        M !== null && (M.selected = !0);
      }
    }
    function cs(e, t) {
      return yt({}, t, {
        value: void 0
      });
    }
    function fs(e, t) {
      var a = e;
      ss(t), a._wrapperState = {
        wasMultiple: !!t.multiple
      }, t.value !== void 0 && t.defaultValue !== void 0 && !xl && (S("Select elements must be either controlled or uncontrolled (specify either the value prop, or the defaultValue prop, but not both). Decide between using a controlled or uncontrolled select element and remove one of these props. More info: https://reactjs.org/link/controlled-components"), xl = !0);
    }
    function Gf(e, t) {
      var a = e;
      a.multiple = !!t.multiple;
      var i = t.value;
      i != null ? $i(a, !!t.multiple, i, !1) : t.defaultValue != null && $i(a, !!t.multiple, t.defaultValue, !0);
    }
    function ly(e, t) {
      var a = e, i = a._wrapperState.wasMultiple;
      a._wrapperState.wasMultiple = !!t.multiple;
      var o = t.value;
      o != null ? $i(a, !!t.multiple, o, !1) : i !== !!t.multiple && (t.defaultValue != null ? $i(a, !!t.multiple, t.defaultValue, !0) : $i(a, !!t.multiple, t.multiple ? [] : "", !1));
    }
    function fv(e, t) {
      var a = e, i = t.value;
      i != null && $i(a, !!t.multiple, i, !1);
    }
    var dv = !1;
    function Kf(e, t) {
      var a = e;
      if (t.dangerouslySetInnerHTML != null)
        throw new Error("`dangerouslySetInnerHTML` does not make sense on <textarea>.");
      var i = yt({}, t, {
        value: void 0,
        defaultValue: void 0,
        children: Ir(a._wrapperState.initialValue)
      });
      return i;
    }
    function pv(e, t) {
      var a = e;
      fo("textarea", t), t.value !== void 0 && t.defaultValue !== void 0 && !dv && (S("%s contains a textarea with both value and defaultValue props. Textarea elements must be either controlled or uncontrolled (specify either the value prop, or the defaultValue prop, but not both). Decide between using a controlled or uncontrolled textarea and remove one of these props. More info: https://reactjs.org/link/controlled-components", Na() || "A component"), dv = !0);
      var i = t.value;
      if (i == null) {
        var o = t.children, s = t.defaultValue;
        if (o != null) {
          S("Use the `defaultValue` or `value` props instead of setting children on <textarea>.");
          {
            if (s != null)
              throw new Error("If you supply `defaultValue` on a <textarea>, do not pass children.");
            if (At(o)) {
              if (o.length > 1)
                throw new Error("<textarea> can only have at most one child.");
              o = o[0];
            }
            s = o;
          }
        }
        s == null && (s = ""), i = s;
      }
      a._wrapperState = {
        initialValue: Za(i)
      };
    }
    function vv(e, t) {
      var a = e, i = Za(t.value), o = Za(t.defaultValue);
      if (i != null) {
        var s = Ir(i);
        s !== a.value && (a.value = s), t.defaultValue == null && a.defaultValue !== s && (a.defaultValue = s);
      }
      o != null && (a.defaultValue = Ir(o));
    }
    function Ec(e, t) {
      var a = e, i = a.textContent;
      i === a._wrapperState.initialValue && i !== "" && i !== null && (a.value = i);
    }
    function oy(e, t) {
      vv(e, t);
    }
    var Ii = "http://www.w3.org/1999/xhtml", uy = "http://www.w3.org/1998/Math/MathML", Cc = "http://www.w3.org/2000/svg";
    function qf(e) {
      switch (e) {
        case "svg":
          return Cc;
        case "math":
          return uy;
        default:
          return Ii;
      }
    }
    function Xf(e, t) {
      return e == null || e === Ii ? qf(t) : e === Cc && t === "foreignObject" ? Ii : e;
    }
    var sy = function(e) {
      return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, a, i, o) {
        MSApp.execUnsafeLocalFunction(function() {
          return e(t, a, i, o);
        });
      } : e;
    }, bc, hv = sy(function(e, t) {
      if (e.namespaceURI === Cc && !("innerHTML" in e)) {
        bc = bc || document.createElement("div"), bc.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>";
        for (var a = bc.firstChild; e.firstChild; )
          e.removeChild(e.firstChild);
        for (; a.firstChild; )
          e.appendChild(a.firstChild);
        return;
      }
      e.innerHTML = t;
    }), Yr = 1, Yi = 3, Tn = 8, fa = 9, Jf = 11, ds = function(e, t) {
      if (t) {
        var a = e.firstChild;
        if (a && a === e.lastChild && a.nodeType === Yi) {
          a.nodeValue = t;
          return;
        }
      }
      e.textContent = t;
    }, mv = {
      animation: ["animationDelay", "animationDirection", "animationDuration", "animationFillMode", "animationIterationCount", "animationName", "animationPlayState", "animationTimingFunction"],
      background: ["backgroundAttachment", "backgroundClip", "backgroundColor", "backgroundImage", "backgroundOrigin", "backgroundPositionX", "backgroundPositionY", "backgroundRepeat", "backgroundSize"],
      backgroundPosition: ["backgroundPositionX", "backgroundPositionY"],
      border: ["borderBottomColor", "borderBottomStyle", "borderBottomWidth", "borderImageOutset", "borderImageRepeat", "borderImageSlice", "borderImageSource", "borderImageWidth", "borderLeftColor", "borderLeftStyle", "borderLeftWidth", "borderRightColor", "borderRightStyle", "borderRightWidth", "borderTopColor", "borderTopStyle", "borderTopWidth"],
      borderBlockEnd: ["borderBlockEndColor", "borderBlockEndStyle", "borderBlockEndWidth"],
      borderBlockStart: ["borderBlockStartColor", "borderBlockStartStyle", "borderBlockStartWidth"],
      borderBottom: ["borderBottomColor", "borderBottomStyle", "borderBottomWidth"],
      borderColor: ["borderBottomColor", "borderLeftColor", "borderRightColor", "borderTopColor"],
      borderImage: ["borderImageOutset", "borderImageRepeat", "borderImageSlice", "borderImageSource", "borderImageWidth"],
      borderInlineEnd: ["borderInlineEndColor", "borderInlineEndStyle", "borderInlineEndWidth"],
      borderInlineStart: ["borderInlineStartColor", "borderInlineStartStyle", "borderInlineStartWidth"],
      borderLeft: ["borderLeftColor", "borderLeftStyle", "borderLeftWidth"],
      borderRadius: ["borderBottomLeftRadius", "borderBottomRightRadius", "borderTopLeftRadius", "borderTopRightRadius"],
      borderRight: ["borderRightColor", "borderRightStyle", "borderRightWidth"],
      borderStyle: ["borderBottomStyle", "borderLeftStyle", "borderRightStyle", "borderTopStyle"],
      borderTop: ["borderTopColor", "borderTopStyle", "borderTopWidth"],
      borderWidth: ["borderBottomWidth", "borderLeftWidth", "borderRightWidth", "borderTopWidth"],
      columnRule: ["columnRuleColor", "columnRuleStyle", "columnRuleWidth"],
      columns: ["columnCount", "columnWidth"],
      flex: ["flexBasis", "flexGrow", "flexShrink"],
      flexFlow: ["flexDirection", "flexWrap"],
      font: ["fontFamily", "fontFeatureSettings", "fontKerning", "fontLanguageOverride", "fontSize", "fontSizeAdjust", "fontStretch", "fontStyle", "fontVariant", "fontVariantAlternates", "fontVariantCaps", "fontVariantEastAsian", "fontVariantLigatures", "fontVariantNumeric", "fontVariantPosition", "fontWeight", "lineHeight"],
      fontVariant: ["fontVariantAlternates", "fontVariantCaps", "fontVariantEastAsian", "fontVariantLigatures", "fontVariantNumeric", "fontVariantPosition"],
      gap: ["columnGap", "rowGap"],
      grid: ["gridAutoColumns", "gridAutoFlow", "gridAutoRows", "gridTemplateAreas", "gridTemplateColumns", "gridTemplateRows"],
      gridArea: ["gridColumnEnd", "gridColumnStart", "gridRowEnd", "gridRowStart"],
      gridColumn: ["gridColumnEnd", "gridColumnStart"],
      gridColumnGap: ["columnGap"],
      gridGap: ["columnGap", "rowGap"],
      gridRow: ["gridRowEnd", "gridRowStart"],
      gridRowGap: ["rowGap"],
      gridTemplate: ["gridTemplateAreas", "gridTemplateColumns", "gridTemplateRows"],
      listStyle: ["listStyleImage", "listStylePosition", "listStyleType"],
      margin: ["marginBottom", "marginLeft", "marginRight", "marginTop"],
      marker: ["markerEnd", "markerMid", "markerStart"],
      mask: ["maskClip", "maskComposite", "maskImage", "maskMode", "maskOrigin", "maskPositionX", "maskPositionY", "maskRepeat", "maskSize"],
      maskPosition: ["maskPositionX", "maskPositionY"],
      outline: ["outlineColor", "outlineStyle", "outlineWidth"],
      overflow: ["overflowX", "overflowY"],
      padding: ["paddingBottom", "paddingLeft", "paddingRight", "paddingTop"],
      placeContent: ["alignContent", "justifyContent"],
      placeItems: ["alignItems", "justifyItems"],
      placeSelf: ["alignSelf", "justifySelf"],
      textDecoration: ["textDecorationColor", "textDecorationLine", "textDecorationStyle"],
      textEmphasis: ["textEmphasisColor", "textEmphasisStyle"],
      transition: ["transitionDelay", "transitionDuration", "transitionProperty", "transitionTimingFunction"],
      wordWrap: ["overflowWrap"]
    }, au = {
      animationIterationCount: !0,
      aspectRatio: !0,
      borderImageOutset: !0,
      borderImageSlice: !0,
      borderImageWidth: !0,
      boxFlex: !0,
      boxFlexGroup: !0,
      boxOrdinalGroup: !0,
      columnCount: !0,
      columns: !0,
      flex: !0,
      flexGrow: !0,
      flexPositive: !0,
      flexShrink: !0,
      flexNegative: !0,
      flexOrder: !0,
      gridArea: !0,
      gridRow: !0,
      gridRowEnd: !0,
      gridRowSpan: !0,
      gridRowStart: !0,
      gridColumn: !0,
      gridColumnEnd: !0,
      gridColumnSpan: !0,
      gridColumnStart: !0,
      fontWeight: !0,
      lineClamp: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      tabSize: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0,
      // SVG-related properties
      fillOpacity: !0,
      floodOpacity: !0,
      stopOpacity: !0,
      strokeDasharray: !0,
      strokeDashoffset: !0,
      strokeMiterlimit: !0,
      strokeOpacity: !0,
      strokeWidth: !0
    };
    function yv(e, t) {
      return e + t.charAt(0).toUpperCase() + t.substring(1);
    }
    var gv = ["Webkit", "ms", "Moz", "O"];
    Object.keys(au).forEach(function(e) {
      gv.forEach(function(t) {
        au[yv(t, e)] = au[e];
      });
    });
    function _l(e, t, a) {
      var i = t == null || typeof t == "boolean" || t === "";
      return i ? "" : !a && typeof t == "number" && t !== 0 && !(au.hasOwnProperty(e) && au[e]) ? t + "px" : (aa(t, e), ("" + t).trim());
    }
    var cy = /([A-Z])/g, fy = /^ms-/;
    function dy(e) {
      return e.replace(cy, "-$1").toLowerCase().replace(fy, "-ms-");
    }
    var Zf = function() {
    };
    {
      var Sv = /^(?:webkit|moz|o)[A-Z]/, ps = /^-ms-/, vs = /-(.)/g, Ev = /;\s*$/, Wi = {}, ed = {}, td = !1, Tc = !1, nd = function(e) {
        return e.replace(vs, function(t, a) {
          return a.toUpperCase();
        });
      }, Cv = function(e) {
        Wi.hasOwnProperty(e) && Wi[e] || (Wi[e] = !0, S(
          "Unsupported style property %s. Did you mean %s?",
          e,
          // As Andi Smith suggests
          // (http://www.andismith.com/blog/2012/02/modernizr-prefixed/), an `-ms` prefix
          // is converted to lowercase `ms`.
          nd(e.replace(ps, "ms-"))
        ));
      }, bv = function(e) {
        Wi.hasOwnProperty(e) && Wi[e] || (Wi[e] = !0, S("Unsupported vendor-prefixed style property %s. Did you mean %s?", e, e.charAt(0).toUpperCase() + e.slice(1)));
      }, Tv = function(e, t) {
        ed.hasOwnProperty(t) && ed[t] || (ed[t] = !0, S(`Style property values shouldn't contain a semicolon. Try "%s: %s" instead.`, e, t.replace(Ev, "")));
      }, py = function(e, t) {
        td || (td = !0, S("`NaN` is an invalid value for the `%s` css style property.", e));
      }, vy = function(e, t) {
        Tc || (Tc = !0, S("`Infinity` is an invalid value for the `%s` css style property.", e));
      };
      Zf = function(e, t) {
        e.indexOf("-") > -1 ? Cv(e) : Sv.test(e) ? bv(e) : Ev.test(t) && Tv(e, t), typeof t == "number" && (isNaN(t) ? py(e, t) : isFinite(t) || vy(e, t));
      };
    }
    var hy = Zf;
    function my(e) {
      {
        var t = "", a = "";
        for (var i in e)
          if (e.hasOwnProperty(i)) {
            var o = e[i];
            if (o != null) {
              var s = i.indexOf("--") === 0;
              t += a + (s ? i : dy(i)) + ":", t += _l(i, o, s), a = ";";
            }
          }
        return t || null;
      }
    }
    function Rv(e, t) {
      var a = e.style;
      for (var i in t)
        if (t.hasOwnProperty(i)) {
          var o = i.indexOf("--") === 0;
          o || hy(i, t[i]);
          var s = _l(i, t[i], o);
          i === "float" && (i = "cssFloat"), o ? a.setProperty(i, s) : a[i] = s;
        }
    }
    function ti(e) {
      return e == null || typeof e == "boolean" || e === "";
    }
    function iu(e) {
      var t = {};
      for (var a in e)
        for (var i = mv[a] || [a], o = 0; o < i.length; o++)
          t[i[o]] = a;
      return t;
    }
    function wv(e, t) {
      {
        if (!t)
          return;
        var a = iu(e), i = iu(t), o = {};
        for (var s in a) {
          var f = a[s], p = i[s];
          if (p && f !== p) {
            var v = f + "," + p;
            if (o[v])
              continue;
            o[v] = !0, S("%s a style property during rerender (%s) when a conflicting property is set (%s) can lead to styling bugs. To avoid this, don't mix shorthand and non-shorthand properties for the same value; instead, replace the shorthand with separate values.", ti(e[f]) ? "Removing" : "Updating", f, p);
          }
        }
      }
    }
    var xv = {
      area: !0,
      base: !0,
      br: !0,
      col: !0,
      embed: !0,
      hr: !0,
      img: !0,
      input: !0,
      keygen: !0,
      link: !0,
      meta: !0,
      param: !0,
      source: !0,
      track: !0,
      wbr: !0
      // NOTE: menuitem's close tag should be omitted, but that causes problems.
    }, _v = yt({
      menuitem: !0
    }, xv), kv = "__html";
    function hs(e, t) {
      if (t) {
        if (_v[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
          throw new Error(e + " is a void element tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");
        if (t.dangerouslySetInnerHTML != null) {
          if (t.children != null)
            throw new Error("Can only set one of `children` or `props.dangerouslySetInnerHTML`.");
          if (typeof t.dangerouslySetInnerHTML != "object" || !(kv in t.dangerouslySetInnerHTML))
            throw new Error("`props.dangerouslySetInnerHTML` must be in the form `{__html: ...}`. Please visit https://reactjs.org/link/dangerously-set-inner-html for more information.");
        }
        if (!t.suppressContentEditableWarning && t.contentEditable && t.children != null && S("A component is `contentEditable` and contains `children` managed by React. It is now your responsibility to guarantee that none of those nodes are unexpectedly modified or duplicated. This is probably not intentional."), t.style != null && typeof t.style != "object")
          throw new Error("The `style` prop expects a mapping from style properties to values, not a string. For example, style={{marginRight: spacing + 'em'}} when using JSX.");
      }
    }
    function ho(e, t) {
      if (e.indexOf("-") === -1)
        return typeof t.is == "string";
      switch (e) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
          return !1;
        default:
          return !0;
      }
    }
    var Rc = {
      // HTML
      accept: "accept",
      acceptcharset: "acceptCharset",
      "accept-charset": "acceptCharset",
      accesskey: "accessKey",
      action: "action",
      allowfullscreen: "allowFullScreen",
      alt: "alt",
      as: "as",
      async: "async",
      autocapitalize: "autoCapitalize",
      autocomplete: "autoComplete",
      autocorrect: "autoCorrect",
      autofocus: "autoFocus",
      autoplay: "autoPlay",
      autosave: "autoSave",
      capture: "capture",
      cellpadding: "cellPadding",
      cellspacing: "cellSpacing",
      challenge: "challenge",
      charset: "charSet",
      checked: "checked",
      children: "children",
      cite: "cite",
      class: "className",
      classid: "classID",
      classname: "className",
      cols: "cols",
      colspan: "colSpan",
      content: "content",
      contenteditable: "contentEditable",
      contextmenu: "contextMenu",
      controls: "controls",
      controlslist: "controlsList",
      coords: "coords",
      crossorigin: "crossOrigin",
      dangerouslysetinnerhtml: "dangerouslySetInnerHTML",
      data: "data",
      datetime: "dateTime",
      default: "default",
      defaultchecked: "defaultChecked",
      defaultvalue: "defaultValue",
      defer: "defer",
      dir: "dir",
      disabled: "disabled",
      disablepictureinpicture: "disablePictureInPicture",
      disableremoteplayback: "disableRemotePlayback",
      download: "download",
      draggable: "draggable",
      enctype: "encType",
      enterkeyhint: "enterKeyHint",
      for: "htmlFor",
      form: "form",
      formmethod: "formMethod",
      formaction: "formAction",
      formenctype: "formEncType",
      formnovalidate: "formNoValidate",
      formtarget: "formTarget",
      frameborder: "frameBorder",
      headers: "headers",
      height: "height",
      hidden: "hidden",
      high: "high",
      href: "href",
      hreflang: "hrefLang",
      htmlfor: "htmlFor",
      httpequiv: "httpEquiv",
      "http-equiv": "httpEquiv",
      icon: "icon",
      id: "id",
      imagesizes: "imageSizes",
      imagesrcset: "imageSrcSet",
      innerhtml: "innerHTML",
      inputmode: "inputMode",
      integrity: "integrity",
      is: "is",
      itemid: "itemID",
      itemprop: "itemProp",
      itemref: "itemRef",
      itemscope: "itemScope",
      itemtype: "itemType",
      keyparams: "keyParams",
      keytype: "keyType",
      kind: "kind",
      label: "label",
      lang: "lang",
      list: "list",
      loop: "loop",
      low: "low",
      manifest: "manifest",
      marginwidth: "marginWidth",
      marginheight: "marginHeight",
      max: "max",
      maxlength: "maxLength",
      media: "media",
      mediagroup: "mediaGroup",
      method: "method",
      min: "min",
      minlength: "minLength",
      multiple: "multiple",
      muted: "muted",
      name: "name",
      nomodule: "noModule",
      nonce: "nonce",
      novalidate: "noValidate",
      open: "open",
      optimum: "optimum",
      pattern: "pattern",
      placeholder: "placeholder",
      playsinline: "playsInline",
      poster: "poster",
      preload: "preload",
      profile: "profile",
      radiogroup: "radioGroup",
      readonly: "readOnly",
      referrerpolicy: "referrerPolicy",
      rel: "rel",
      required: "required",
      reversed: "reversed",
      role: "role",
      rows: "rows",
      rowspan: "rowSpan",
      sandbox: "sandbox",
      scope: "scope",
      scoped: "scoped",
      scrolling: "scrolling",
      seamless: "seamless",
      selected: "selected",
      shape: "shape",
      size: "size",
      sizes: "sizes",
      span: "span",
      spellcheck: "spellCheck",
      src: "src",
      srcdoc: "srcDoc",
      srclang: "srcLang",
      srcset: "srcSet",
      start: "start",
      step: "step",
      style: "style",
      summary: "summary",
      tabindex: "tabIndex",
      target: "target",
      title: "title",
      type: "type",
      usemap: "useMap",
      value: "value",
      width: "width",
      wmode: "wmode",
      wrap: "wrap",
      // SVG
      about: "about",
      accentheight: "accentHeight",
      "accent-height": "accentHeight",
      accumulate: "accumulate",
      additive: "additive",
      alignmentbaseline: "alignmentBaseline",
      "alignment-baseline": "alignmentBaseline",
      allowreorder: "allowReorder",
      alphabetic: "alphabetic",
      amplitude: "amplitude",
      arabicform: "arabicForm",
      "arabic-form": "arabicForm",
      ascent: "ascent",
      attributename: "attributeName",
      attributetype: "attributeType",
      autoreverse: "autoReverse",
      azimuth: "azimuth",
      basefrequency: "baseFrequency",
      baselineshift: "baselineShift",
      "baseline-shift": "baselineShift",
      baseprofile: "baseProfile",
      bbox: "bbox",
      begin: "begin",
      bias: "bias",
      by: "by",
      calcmode: "calcMode",
      capheight: "capHeight",
      "cap-height": "capHeight",
      clip: "clip",
      clippath: "clipPath",
      "clip-path": "clipPath",
      clippathunits: "clipPathUnits",
      cliprule: "clipRule",
      "clip-rule": "clipRule",
      color: "color",
      colorinterpolation: "colorInterpolation",
      "color-interpolation": "colorInterpolation",
      colorinterpolationfilters: "colorInterpolationFilters",
      "color-interpolation-filters": "colorInterpolationFilters",
      colorprofile: "colorProfile",
      "color-profile": "colorProfile",
      colorrendering: "colorRendering",
      "color-rendering": "colorRendering",
      contentscripttype: "contentScriptType",
      contentstyletype: "contentStyleType",
      cursor: "cursor",
      cx: "cx",
      cy: "cy",
      d: "d",
      datatype: "datatype",
      decelerate: "decelerate",
      descent: "descent",
      diffuseconstant: "diffuseConstant",
      direction: "direction",
      display: "display",
      divisor: "divisor",
      dominantbaseline: "dominantBaseline",
      "dominant-baseline": "dominantBaseline",
      dur: "dur",
      dx: "dx",
      dy: "dy",
      edgemode: "edgeMode",
      elevation: "elevation",
      enablebackground: "enableBackground",
      "enable-background": "enableBackground",
      end: "end",
      exponent: "exponent",
      externalresourcesrequired: "externalResourcesRequired",
      fill: "fill",
      fillopacity: "fillOpacity",
      "fill-opacity": "fillOpacity",
      fillrule: "fillRule",
      "fill-rule": "fillRule",
      filter: "filter",
      filterres: "filterRes",
      filterunits: "filterUnits",
      floodopacity: "floodOpacity",
      "flood-opacity": "floodOpacity",
      floodcolor: "floodColor",
      "flood-color": "floodColor",
      focusable: "focusable",
      fontfamily: "fontFamily",
      "font-family": "fontFamily",
      fontsize: "fontSize",
      "font-size": "fontSize",
      fontsizeadjust: "fontSizeAdjust",
      "font-size-adjust": "fontSizeAdjust",
      fontstretch: "fontStretch",
      "font-stretch": "fontStretch",
      fontstyle: "fontStyle",
      "font-style": "fontStyle",
      fontvariant: "fontVariant",
      "font-variant": "fontVariant",
      fontweight: "fontWeight",
      "font-weight": "fontWeight",
      format: "format",
      from: "from",
      fx: "fx",
      fy: "fy",
      g1: "g1",
      g2: "g2",
      glyphname: "glyphName",
      "glyph-name": "glyphName",
      glyphorientationhorizontal: "glyphOrientationHorizontal",
      "glyph-orientation-horizontal": "glyphOrientationHorizontal",
      glyphorientationvertical: "glyphOrientationVertical",
      "glyph-orientation-vertical": "glyphOrientationVertical",
      glyphref: "glyphRef",
      gradienttransform: "gradientTransform",
      gradientunits: "gradientUnits",
      hanging: "hanging",
      horizadvx: "horizAdvX",
      "horiz-adv-x": "horizAdvX",
      horizoriginx: "horizOriginX",
      "horiz-origin-x": "horizOriginX",
      ideographic: "ideographic",
      imagerendering: "imageRendering",
      "image-rendering": "imageRendering",
      in2: "in2",
      in: "in",
      inlist: "inlist",
      intercept: "intercept",
      k1: "k1",
      k2: "k2",
      k3: "k3",
      k4: "k4",
      k: "k",
      kernelmatrix: "kernelMatrix",
      kernelunitlength: "kernelUnitLength",
      kerning: "kerning",
      keypoints: "keyPoints",
      keysplines: "keySplines",
      keytimes: "keyTimes",
      lengthadjust: "lengthAdjust",
      letterspacing: "letterSpacing",
      "letter-spacing": "letterSpacing",
      lightingcolor: "lightingColor",
      "lighting-color": "lightingColor",
      limitingconeangle: "limitingConeAngle",
      local: "local",
      markerend: "markerEnd",
      "marker-end": "markerEnd",
      markerheight: "markerHeight",
      markermid: "markerMid",
      "marker-mid": "markerMid",
      markerstart: "markerStart",
      "marker-start": "markerStart",
      markerunits: "markerUnits",
      markerwidth: "markerWidth",
      mask: "mask",
      maskcontentunits: "maskContentUnits",
      maskunits: "maskUnits",
      mathematical: "mathematical",
      mode: "mode",
      numoctaves: "numOctaves",
      offset: "offset",
      opacity: "opacity",
      operator: "operator",
      order: "order",
      orient: "orient",
      orientation: "orientation",
      origin: "origin",
      overflow: "overflow",
      overlineposition: "overlinePosition",
      "overline-position": "overlinePosition",
      overlinethickness: "overlineThickness",
      "overline-thickness": "overlineThickness",
      paintorder: "paintOrder",
      "paint-order": "paintOrder",
      panose1: "panose1",
      "panose-1": "panose1",
      pathlength: "pathLength",
      patterncontentunits: "patternContentUnits",
      patterntransform: "patternTransform",
      patternunits: "patternUnits",
      pointerevents: "pointerEvents",
      "pointer-events": "pointerEvents",
      points: "points",
      pointsatx: "pointsAtX",
      pointsaty: "pointsAtY",
      pointsatz: "pointsAtZ",
      prefix: "prefix",
      preservealpha: "preserveAlpha",
      preserveaspectratio: "preserveAspectRatio",
      primitiveunits: "primitiveUnits",
      property: "property",
      r: "r",
      radius: "radius",
      refx: "refX",
      refy: "refY",
      renderingintent: "renderingIntent",
      "rendering-intent": "renderingIntent",
      repeatcount: "repeatCount",
      repeatdur: "repeatDur",
      requiredextensions: "requiredExtensions",
      requiredfeatures: "requiredFeatures",
      resource: "resource",
      restart: "restart",
      result: "result",
      results: "results",
      rotate: "rotate",
      rx: "rx",
      ry: "ry",
      scale: "scale",
      security: "security",
      seed: "seed",
      shaperendering: "shapeRendering",
      "shape-rendering": "shapeRendering",
      slope: "slope",
      spacing: "spacing",
      specularconstant: "specularConstant",
      specularexponent: "specularExponent",
      speed: "speed",
      spreadmethod: "spreadMethod",
      startoffset: "startOffset",
      stddeviation: "stdDeviation",
      stemh: "stemh",
      stemv: "stemv",
      stitchtiles: "stitchTiles",
      stopcolor: "stopColor",
      "stop-color": "stopColor",
      stopopacity: "stopOpacity",
      "stop-opacity": "stopOpacity",
      strikethroughposition: "strikethroughPosition",
      "strikethrough-position": "strikethroughPosition",
      strikethroughthickness: "strikethroughThickness",
      "strikethrough-thickness": "strikethroughThickness",
      string: "string",
      stroke: "stroke",
      strokedasharray: "strokeDasharray",
      "stroke-dasharray": "strokeDasharray",
      strokedashoffset: "strokeDashoffset",
      "stroke-dashoffset": "strokeDashoffset",
      strokelinecap: "strokeLinecap",
      "stroke-linecap": "strokeLinecap",
      strokelinejoin: "strokeLinejoin",
      "stroke-linejoin": "strokeLinejoin",
      strokemiterlimit: "strokeMiterlimit",
      "stroke-miterlimit": "strokeMiterlimit",
      strokewidth: "strokeWidth",
      "stroke-width": "strokeWidth",
      strokeopacity: "strokeOpacity",
      "stroke-opacity": "strokeOpacity",
      suppresscontenteditablewarning: "suppressContentEditableWarning",
      suppresshydrationwarning: "suppressHydrationWarning",
      surfacescale: "surfaceScale",
      systemlanguage: "systemLanguage",
      tablevalues: "tableValues",
      targetx: "targetX",
      targety: "targetY",
      textanchor: "textAnchor",
      "text-anchor": "textAnchor",
      textdecoration: "textDecoration",
      "text-decoration": "textDecoration",
      textlength: "textLength",
      textrendering: "textRendering",
      "text-rendering": "textRendering",
      to: "to",
      transform: "transform",
      typeof: "typeof",
      u1: "u1",
      u2: "u2",
      underlineposition: "underlinePosition",
      "underline-position": "underlinePosition",
      underlinethickness: "underlineThickness",
      "underline-thickness": "underlineThickness",
      unicode: "unicode",
      unicodebidi: "unicodeBidi",
      "unicode-bidi": "unicodeBidi",
      unicoderange: "unicodeRange",
      "unicode-range": "unicodeRange",
      unitsperem: "unitsPerEm",
      "units-per-em": "unitsPerEm",
      unselectable: "unselectable",
      valphabetic: "vAlphabetic",
      "v-alphabetic": "vAlphabetic",
      values: "values",
      vectoreffect: "vectorEffect",
      "vector-effect": "vectorEffect",
      version: "version",
      vertadvy: "vertAdvY",
      "vert-adv-y": "vertAdvY",
      vertoriginx: "vertOriginX",
      "vert-origin-x": "vertOriginX",
      vertoriginy: "vertOriginY",
      "vert-origin-y": "vertOriginY",
      vhanging: "vHanging",
      "v-hanging": "vHanging",
      videographic: "vIdeographic",
      "v-ideographic": "vIdeographic",
      viewbox: "viewBox",
      viewtarget: "viewTarget",
      visibility: "visibility",
      vmathematical: "vMathematical",
      "v-mathematical": "vMathematical",
      vocab: "vocab",
      widths: "widths",
      wordspacing: "wordSpacing",
      "word-spacing": "wordSpacing",
      writingmode: "writingMode",
      "writing-mode": "writingMode",
      x1: "x1",
      x2: "x2",
      x: "x",
      xchannelselector: "xChannelSelector",
      xheight: "xHeight",
      "x-height": "xHeight",
      xlinkactuate: "xlinkActuate",
      "xlink:actuate": "xlinkActuate",
      xlinkarcrole: "xlinkArcrole",
      "xlink:arcrole": "xlinkArcrole",
      xlinkhref: "xlinkHref",
      "xlink:href": "xlinkHref",
      xlinkrole: "xlinkRole",
      "xlink:role": "xlinkRole",
      xlinkshow: "xlinkShow",
      "xlink:show": "xlinkShow",
      xlinktitle: "xlinkTitle",
      "xlink:title": "xlinkTitle",
      xlinktype: "xlinkType",
      "xlink:type": "xlinkType",
      xmlbase: "xmlBase",
      "xml:base": "xmlBase",
      xmllang: "xmlLang",
      "xml:lang": "xmlLang",
      xmlns: "xmlns",
      "xml:space": "xmlSpace",
      xmlnsxlink: "xmlnsXlink",
      "xmlns:xlink": "xmlnsXlink",
      xmlspace: "xmlSpace",
      y1: "y1",
      y2: "y2",
      y: "y",
      ychannelselector: "yChannelSelector",
      z: "z",
      zoomandpan: "zoomAndPan"
    }, mo = {
      "aria-current": 0,
      // state
      "aria-description": 0,
      "aria-details": 0,
      "aria-disabled": 0,
      // state
      "aria-hidden": 0,
      // state
      "aria-invalid": 0,
      // state
      "aria-keyshortcuts": 0,
      "aria-label": 0,
      "aria-roledescription": 0,
      // Widget Attributes
      "aria-autocomplete": 0,
      "aria-checked": 0,
      "aria-expanded": 0,
      "aria-haspopup": 0,
      "aria-level": 0,
      "aria-modal": 0,
      "aria-multiline": 0,
      "aria-multiselectable": 0,
      "aria-orientation": 0,
      "aria-placeholder": 0,
      "aria-pressed": 0,
      "aria-readonly": 0,
      "aria-required": 0,
      "aria-selected": 0,
      "aria-sort": 0,
      "aria-valuemax": 0,
      "aria-valuemin": 0,
      "aria-valuenow": 0,
      "aria-valuetext": 0,
      // Live Region Attributes
      "aria-atomic": 0,
      "aria-busy": 0,
      "aria-live": 0,
      "aria-relevant": 0,
      // Drag-and-Drop Attributes
      "aria-dropeffect": 0,
      "aria-grabbed": 0,
      // Relationship Attributes
      "aria-activedescendant": 0,
      "aria-colcount": 0,
      "aria-colindex": 0,
      "aria-colspan": 0,
      "aria-controls": 0,
      "aria-describedby": 0,
      "aria-errormessage": 0,
      "aria-flowto": 0,
      "aria-labelledby": 0,
      "aria-owns": 0,
      "aria-posinset": 0,
      "aria-rowcount": 0,
      "aria-rowindex": 0,
      "aria-rowspan": 0,
      "aria-setsize": 0
    }, kl = {}, ms = new RegExp("^(aria)-[" + Qe + "]*$"), rd = new RegExp("^(aria)[A-Z][" + Qe + "]*$");
    function Dv(e, t) {
      {
        if (Jn.call(kl, t) && kl[t])
          return !0;
        if (rd.test(t)) {
          var a = "aria-" + t.slice(4).toLowerCase(), i = mo.hasOwnProperty(a) ? a : null;
          if (i == null)
            return S("Invalid ARIA attribute `%s`. ARIA attributes follow the pattern aria-* and must be lowercase.", t), kl[t] = !0, !0;
          if (t !== i)
            return S("Invalid ARIA attribute `%s`. Did you mean `%s`?", t, i), kl[t] = !0, !0;
        }
        if (ms.test(t)) {
          var o = t.toLowerCase(), s = mo.hasOwnProperty(o) ? o : null;
          if (s == null)
            return kl[t] = !0, !1;
          if (t !== s)
            return S("Unknown ARIA attribute `%s`. Did you mean `%s`?", t, s), kl[t] = !0, !0;
        }
      }
      return !0;
    }
    function wc(e, t) {
      {
        var a = [];
        for (var i in t) {
          var o = Dv(e, i);
          o || a.push(i);
        }
        var s = a.map(function(f) {
          return "`" + f + "`";
        }).join(", ");
        a.length === 1 ? S("Invalid aria prop %s on <%s> tag. For details, see https://reactjs.org/link/invalid-aria-props", s, e) : a.length > 1 && S("Invalid aria props %s on <%s> tag. For details, see https://reactjs.org/link/invalid-aria-props", s, e);
      }
    }
    function lu(e, t) {
      ho(e, t) || wc(e, t);
    }
    var xc = !1;
    function Ov(e, t) {
      {
        if (e !== "input" && e !== "textarea" && e !== "select")
          return;
        t != null && t.value === null && !xc && (xc = !0, e === "select" && t.multiple ? S("`value` prop on `%s` should not be null. Consider using an empty array when `multiple` is set to `true` to clear the component or `undefined` for uncontrolled components.", e) : S("`value` prop on `%s` should not be null. Consider using an empty string to clear the component or `undefined` for uncontrolled components.", e));
      }
    }
    var ys = function() {
    };
    {
      var yr = {}, ad = /^on./, Mv = /^on[^A-Z]/, Nv = new RegExp("^(aria)-[" + Qe + "]*$"), Lv = new RegExp("^(aria)[A-Z][" + Qe + "]*$");
      ys = function(e, t, a, i) {
        if (Jn.call(yr, t) && yr[t])
          return !0;
        var o = t.toLowerCase();
        if (o === "onfocusin" || o === "onfocusout")
          return S("React uses onFocus and onBlur instead of onFocusIn and onFocusOut. All React events are normalized to bubble, so onFocusIn and onFocusOut are not needed/supported by React."), yr[t] = !0, !0;
        if (i != null) {
          var s = i.registrationNameDependencies, f = i.possibleRegistrationNames;
          if (s.hasOwnProperty(t))
            return !0;
          var p = f.hasOwnProperty(o) ? f[o] : null;
          if (p != null)
            return S("Invalid event handler property `%s`. Did you mean `%s`?", t, p), yr[t] = !0, !0;
          if (ad.test(t))
            return S("Unknown event handler property `%s`. It will be ignored.", t), yr[t] = !0, !0;
        } else if (ad.test(t))
          return Mv.test(t) && S("Invalid event handler property `%s`. React events use the camelCase naming convention, for example `onClick`.", t), yr[t] = !0, !0;
        if (Nv.test(t) || Lv.test(t))
          return !0;
        if (o === "innerhtml")
          return S("Directly setting property `innerHTML` is not permitted. For more information, lookup documentation on `dangerouslySetInnerHTML`."), yr[t] = !0, !0;
        if (o === "aria")
          return S("The `aria` attribute is reserved for future use in React. Pass individual `aria-` attributes instead."), yr[t] = !0, !0;
        if (o === "is" && a !== null && a !== void 0 && typeof a != "string")
          return S("Received a `%s` for a string attribute `is`. If this is expected, cast the value to a string.", typeof a), yr[t] = !0, !0;
        if (typeof a == "number" && isNaN(a))
          return S("Received NaN for the `%s` attribute. If this is expected, cast the value to a string.", t), yr[t] = !0, !0;
        var v = Wn(t), E = v !== null && v.type === la;
        if (Rc.hasOwnProperty(o)) {
          var C = Rc[o];
          if (C !== t)
            return S("Invalid DOM property `%s`. Did you mean `%s`?", t, C), yr[t] = !0, !0;
        } else if (!E && t !== o)
          return S("React does not recognize the `%s` prop on a DOM element. If you intentionally want it to appear in the DOM as a custom attribute, spell it as lowercase `%s` instead. If you accidentally passed it from a parent component, remove it from the DOM element.", t, o), yr[t] = !0, !0;
        return typeof a == "boolean" && hr(t, a, v, !1) ? (a ? S('Received `%s` for a non-boolean attribute `%s`.\n\nIf you want to write it to the DOM, pass a string instead: %s="%s" or %s={value.toString()}.', a, t, t, a, t) : S('Received `%s` for a non-boolean attribute `%s`.\n\nIf you want to write it to the DOM, pass a string instead: %s="%s" or %s={value.toString()}.\n\nIf you used to conditionally omit it with %s={condition && value}, pass %s={condition ? value : undefined} instead.', a, t, t, a, t, t, t), yr[t] = !0, !0) : E ? !0 : hr(t, a, v, !1) ? (yr[t] = !0, !1) : ((a === "false" || a === "true") && v !== null && v.type === vn && (S("Received the string `%s` for the boolean attribute `%s`. %s Did you mean %s={%s}?", a, t, a === "false" ? "The browser will interpret it as a truthy value." : 'Although this works, it will not work as expected if you pass the string "false".', t, a), yr[t] = !0), !0);
      };
    }
    var Av = function(e, t, a) {
      {
        var i = [];
        for (var o in t) {
          var s = ys(e, o, t[o], a);
          s || i.push(o);
        }
        var f = i.map(function(p) {
          return "`" + p + "`";
        }).join(", ");
        i.length === 1 ? S("Invalid value for prop %s on <%s> tag. Either remove it from the element, or pass a string or number value to keep it in the DOM. For details, see https://reactjs.org/link/attribute-behavior ", f, e) : i.length > 1 && S("Invalid values for props %s on <%s> tag. Either remove them from the element, or pass a string or number value to keep them in the DOM. For details, see https://reactjs.org/link/attribute-behavior ", f, e);
      }
    };
    function Dl(e, t, a) {
      ho(e, t) || Av(e, t, a);
    }
    var _c = 1, gs = 2, Ss = 4, yy = _c | gs | Ss, Qi = null;
    function gy(e) {
      Qi !== null && S("Expected currently replaying event to be null. This error is likely caused by a bug in React. Please file an issue."), Qi = e;
    }
    function Uv() {
      Qi === null && S("Expected currently replaying event to not be null. This error is likely caused by a bug in React. Please file an issue."), Qi = null;
    }
    function zv(e) {
      return e === Qi;
    }
    function nn(e) {
      var t = e.target || e.srcElement || window;
      return t.correspondingUseElement && (t = t.correspondingUseElement), t.nodeType === Yi ? t.parentNode : t;
    }
    var Es = null, Gi = null, hi = null;
    function id(e) {
      var t = zu(e);
      if (t) {
        if (typeof Es != "function")
          throw new Error("setRestoreImplementation() needs to be called to handle a target for controlled events. This error is likely caused by a bug in React. Please file an issue.");
        var a = t.stateNode;
        if (a) {
          var i = Uh(a);
          Es(t.stateNode, t.type, i);
        }
      }
    }
    function ld(e) {
      Es = e;
    }
    function ou(e) {
      Gi ? hi ? hi.push(e) : hi = [e] : Gi = e;
    }
    function kc() {
      return Gi !== null || hi !== null;
    }
    function yo() {
      if (Gi) {
        var e = Gi, t = hi;
        if (Gi = null, hi = null, id(e), t)
          for (var a = 0; a < t.length; a++)
            id(t[a]);
      }
    }
    var od = function(e, t) {
      return e(t);
    }, Fv = function() {
    }, ud = !1;
    function jv() {
      var e = kc();
      e && (Fv(), yo());
    }
    function Cs(e, t, a) {
      if (ud)
        return e(t, a);
      ud = !0;
      try {
        return od(e, t, a);
      } finally {
        ud = !1, jv();
      }
    }
    function Dc(e, t, a) {
      od = e, Fv = a;
    }
    function sd(e) {
      return e === "button" || e === "input" || e === "select" || e === "textarea";
    }
    function cd(e, t, a) {
      switch (e) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
          return !!(a.disabled && sd(t));
        default:
          return !1;
      }
    }
    function go(e, t) {
      var a = e.stateNode;
      if (a === null)
        return null;
      var i = Uh(a);
      if (i === null)
        return null;
      var o = i[t];
      if (cd(t, e.type, i))
        return null;
      if (o && typeof o != "function")
        throw new Error("Expected `" + t + "` listener to be a function, instead got a value of `" + typeof o + "` type.");
      return o;
    }
    var bs = !1;
    if (bn)
      try {
        var Ts = {};
        Object.defineProperty(Ts, "passive", {
          get: function() {
            bs = !0;
          }
        }), window.addEventListener("test", Ts, Ts), window.removeEventListener("test", Ts, Ts);
      } catch {
        bs = !1;
      }
    function fd(e, t, a, i, o, s, f, p, v) {
      var E = Array.prototype.slice.call(arguments, 3);
      try {
        t.apply(a, E);
      } catch (C) {
        this.onError(C);
      }
    }
    var Pv = fd;
    if (typeof window < "u" && typeof window.dispatchEvent == "function" && typeof document < "u" && typeof document.createEvent == "function") {
      var dd = document.createElement("react");
      Pv = function(t, a, i, o, s, f, p, v, E) {
        if (typeof document > "u" || document === null)
          throw new Error("The `document` global was defined when React was initialized, but is not defined anymore. This can happen in a test environment if a component schedules an update from an asynchronous callback, but the test has already finished running. To solve this, you can either unmount the component at the end of your test (and ensure that any asynchronous operations get canceled in `componentWillUnmount`), or you can change the test itself to be asynchronous.");
        var C = document.createEvent("Event"), M = !1, D = !0, B = window.event, $ = Object.getOwnPropertyDescriptor(window, "event");
        function G() {
          dd.removeEventListener(K, et, !1), typeof window.event < "u" && window.hasOwnProperty("event") && (window.event = B);
        }
        var Re = Array.prototype.slice.call(arguments, 3);
        function et() {
          M = !0, G(), a.apply(i, Re), D = !1;
        }
        var Ie, Lt = !1, _t = !1;
        function F(j) {
          if (Ie = j.error, Lt = !0, Ie === null && j.colno === 0 && j.lineno === 0 && (_t = !0), j.defaultPrevented && Ie != null && typeof Ie == "object")
            try {
              Ie._suppressLogging = !0;
            } catch {
            }
        }
        var K = "react-" + (t || "invokeguardedcallback");
        if (window.addEventListener("error", F), dd.addEventListener(K, et, !1), C.initEvent(K, !1, !1), dd.dispatchEvent(C), $ && Object.defineProperty(window, "event", $), M && D && (Lt ? _t && (Ie = new Error("A cross-origin error was thrown. React doesn't have access to the actual error object in development. See https://reactjs.org/link/crossorigin-error for more information.")) : Ie = new Error(`An error was thrown inside one of your components, but React doesn't know what it was. This is likely due to browser flakiness. React does its best to preserve the "Pause on exceptions" behavior of the DevTools, which requires some DEV-mode only tricks. It's possible that these don't work in your browser. Try triggering the error in production mode, or switching to a modern browser. If you suspect that this is actually an issue with React, please file an issue.`), this.onError(Ie)), window.removeEventListener("error", F), !M)
          return G(), fd.apply(this, arguments);
      };
    }
    var pd = Pv, da = !1, Rs = null, Ki = !1, Aa = null, ws = {
      onError: function(e) {
        da = !0, Rs = e;
      }
    };
    function ni(e, t, a, i, o, s, f, p, v) {
      da = !1, Rs = null, pd.apply(ws, arguments);
    }
    function vd(e, t, a, i, o, s, f, p, v) {
      if (ni.apply(this, arguments), da) {
        var E = qi();
        Ki || (Ki = !0, Aa = E);
      }
    }
    function Sy() {
      if (Ki) {
        var e = Aa;
        throw Ki = !1, Aa = null, e;
      }
    }
    function Ey() {
      return da;
    }
    function qi() {
      if (da) {
        var e = Rs;
        return da = !1, Rs = null, e;
      } else
        throw new Error("clearCaughtError was called but no error was captured. This error is likely caused by a bug in React. Please file an issue.");
    }
    function mi(e) {
      return e._reactInternals;
    }
    function uu(e) {
      return e._reactInternals !== void 0;
    }
    function Oc(e, t) {
      e._reactInternals = t;
    }
    var Ze = (
      /*                      */
      0
    ), ri = (
      /*                */
      1
    ), rn = (
      /*                    */
      2
    ), He = (
      /*                       */
      4
    ), Ht = (
      /*                */
      16
    ), Ua = (
      /*                 */
      32
    ), Qn = (
      /*                     */
      64
    ), vt = (
      /*                   */
      128
    ), Tr = (
      /*            */
      256
    ), pa = (
      /*                          */
      512
    ), Fn = (
      /*                     */
      1024
    ), Wr = (
      /*                      */
      2048
    ), yi = (
      /*                    */
      4096
    ), Ol = (
      /*                   */
      8192
    ), So = (
      /*             */
      16384
    ), Hv = Wr | He | Qn | pa | Fn | So, Xi = (
      /*               */
      32767
    ), Ml = (
      /*                   */
      32768
    ), tr = (
      /*                */
      65536
    ), Mc = (
      /* */
      131072
    ), Bv = (
      /*                       */
      1048576
    ), gi = (
      /*                    */
      2097152
    ), za = (
      /*                 */
      4194304
    ), Nl = (
      /*                */
      8388608
    ), Fa = (
      /*               */
      16777216
    ), Eo = (
      /*              */
      33554432
    ), Qr = (
      // TODO: Remove Update flag from before mutation phase by re-landing Visibility
      // flag logic (see #20043)
      He | Fn | 0
    ), Gr = rn | He | Ht | Ua | pa | yi | Ol, ai = He | Qn | pa | Ol, Kr = Wr | Ht, nr = za | Nl | gi, Co = T.ReactCurrentOwner;
    function Ll(e) {
      var t = e, a = e;
      if (e.alternate)
        for (; t.return; )
          t = t.return;
      else {
        var i = t;
        do
          t = i, (t.flags & (rn | yi)) !== Ze && (a = t.return), i = t.return;
        while (i);
      }
      return t.tag === A ? a : null;
    }
    function Nc(e) {
      if (e.tag === Ne) {
        var t = e.memoizedState;
        if (t === null) {
          var a = e.alternate;
          a !== null && (t = a.memoizedState);
        }
        if (t !== null)
          return t.dehydrated;
      }
      return null;
    }
    function Lc(e) {
      return e.tag === A ? e.stateNode.containerInfo : null;
    }
    function va(e) {
      return Ll(e) === e;
    }
    function ha(e) {
      {
        var t = Co.current;
        if (t !== null && t.tag === Q) {
          var a = t, i = a.stateNode;
          i._warnedAboutRefsInRender || S("%s is accessing isMounted inside its render() function. render() should be a pure function of props and state. It should never access something that requires stale data from the previous render, such as refs. Move this logic to componentDidMount and componentDidUpdate instead.", dt(a) || "A component"), i._warnedAboutRefsInRender = !0;
        }
      }
      var o = mi(e);
      return o ? Ll(o) === o : !1;
    }
    function fn(e) {
      if (Ll(e) !== e)
        throw new Error("Unable to find node on an unmounted component.");
    }
    function ja(e) {
      var t = e.alternate;
      if (!t) {
        var a = Ll(e);
        if (a === null)
          throw new Error("Unable to find node on an unmounted component.");
        return a !== e ? null : e;
      }
      for (var i = e, o = t; ; ) {
        var s = i.return;
        if (s === null)
          break;
        var f = s.alternate;
        if (f === null) {
          var p = s.return;
          if (p !== null) {
            i = o = p;
            continue;
          }
          break;
        }
        if (s.child === f.child) {
          for (var v = s.child; v; ) {
            if (v === i)
              return fn(s), e;
            if (v === o)
              return fn(s), t;
            v = v.sibling;
          }
          throw new Error("Unable to find node on an unmounted component.");
        }
        if (i.return !== o.return)
          i = s, o = f;
        else {
          for (var E = !1, C = s.child; C; ) {
            if (C === i) {
              E = !0, i = s, o = f;
              break;
            }
            if (C === o) {
              E = !0, o = s, i = f;
              break;
            }
            C = C.sibling;
          }
          if (!E) {
            for (C = f.child; C; ) {
              if (C === i) {
                E = !0, i = f, o = s;
                break;
              }
              if (C === o) {
                E = !0, o = f, i = s;
                break;
              }
              C = C.sibling;
            }
            if (!E)
              throw new Error("Child was not found in either parent set. This indicates a bug in React related to the return pointer. Please file an issue.");
          }
        }
        if (i.alternate !== o)
          throw new Error("Return fibers should always be each others' alternates. This error is likely caused by a bug in React. Please file an issue.");
      }
      if (i.tag !== A)
        throw new Error("Unable to find node on an unmounted component.");
      return i.stateNode.current === i ? e : t;
    }
    function hd(e) {
      var t = ja(e);
      return t !== null ? md(t) : null;
    }
    function md(e) {
      if (e.tag === q || e.tag === ve)
        return e;
      for (var t = e.child; t !== null; ) {
        var a = md(t);
        if (a !== null)
          return a;
        t = t.sibling;
      }
      return null;
    }
    function yd(e) {
      var t = ja(e);
      return t !== null ? Ac(t) : null;
    }
    function Ac(e) {
      if (e.tag === q || e.tag === ve)
        return e;
      for (var t = e.child; t !== null; ) {
        if (t.tag !== oe) {
          var a = Ac(t);
          if (a !== null)
            return a;
        }
        t = t.sibling;
      }
      return null;
    }
    var gd = g.unstable_scheduleCallback, Uc = g.unstable_cancelCallback, Vv = g.unstable_shouldYield, su = g.unstable_requestPaint, jn = g.unstable_now, Cy = g.unstable_getCurrentPriorityLevel, Al = g.unstable_ImmediatePriority, cu = g.unstable_UserBlockingPriority, Ul = g.unstable_NormalPriority, $v = g.unstable_LowPriority, zl = g.unstable_IdlePriority, Iv = g.unstable_yieldValue, zc = g.unstable_setDisableYieldValue, Ji = null, Mn = null, be = null, Pa = !1, ma = typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u";
    function Sd(e) {
      if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u")
        return !1;
      var t = __REACT_DEVTOOLS_GLOBAL_HOOK__;
      if (t.isDisabled)
        return !0;
      if (!t.supportsFiber)
        return S("The installed version of React DevTools is too old and will not work with the current version of React. Please update React DevTools. https://reactjs.org/link/react-devtools"), !0;
      try {
        ft && (e = yt({}, e, {
          getLaneLabelMap: Fl,
          injectProfilingHooks: Zi
        })), Ji = t.inject(e), Mn = t;
      } catch (a) {
        S("React instrumentation encountered an error: %s.", a);
      }
      return !!t.checkDCE;
    }
    function fu(e, t) {
      if (Mn && typeof Mn.onScheduleFiberRoot == "function")
        try {
          Mn.onScheduleFiberRoot(Ji, e, t);
        } catch (a) {
          Pa || (Pa = !0, S("React instrumentation encountered an error: %s", a));
        }
    }
    function Ha(e, t) {
      if (Mn && typeof Mn.onCommitFiberRoot == "function")
        try {
          var a = (e.current.flags & vt) === vt;
          if (St) {
            var i;
            switch (t) {
              case Ea:
                i = Al;
                break;
              case Ti:
                i = cu;
                break;
              case oi:
                i = Ul;
                break;
              case js:
                i = zl;
                break;
              default:
                i = Ul;
                break;
            }
            Mn.onCommitFiberRoot(Ji, e, i, a);
          }
        } catch (o) {
          Pa || (Pa = !0, S("React instrumentation encountered an error: %s", o));
        }
    }
    function bo(e) {
      if (Mn && typeof Mn.onPostCommitFiberRoot == "function")
        try {
          Mn.onPostCommitFiberRoot(Ji, e);
        } catch (t) {
          Pa || (Pa = !0, S("React instrumentation encountered an error: %s", t));
        }
    }
    function Ed(e) {
      if (Mn && typeof Mn.onCommitFiberUnmount == "function")
        try {
          Mn.onCommitFiberUnmount(Ji, e);
        } catch (t) {
          Pa || (Pa = !0, S("React instrumentation encountered an error: %s", t));
        }
    }
    function $n(e) {
      if (typeof Iv == "function" && (zc(e), U(e)), Mn && typeof Mn.setStrictMode == "function")
        try {
          Mn.setStrictMode(Ji, e);
        } catch (t) {
          Pa || (Pa = !0, S("React instrumentation encountered an error: %s", t));
        }
    }
    function Zi(e) {
      be = e;
    }
    function Fl() {
      {
        for (var e = /* @__PURE__ */ new Map(), t = 1, a = 0; a < ks; a++) {
          var i = Ty(t);
          e.set(t, i), t *= 2;
        }
        return e;
      }
    }
    function Cd(e) {
      be !== null && typeof be.markCommitStarted == "function" && be.markCommitStarted(e);
    }
    function bd() {
      be !== null && typeof be.markCommitStopped == "function" && be.markCommitStopped();
    }
    function ya(e) {
      be !== null && typeof be.markComponentRenderStarted == "function" && be.markComponentRenderStarted(e);
    }
    function ga() {
      be !== null && typeof be.markComponentRenderStopped == "function" && be.markComponentRenderStopped();
    }
    function Fc(e) {
      be !== null && typeof be.markComponentPassiveEffectMountStarted == "function" && be.markComponentPassiveEffectMountStarted(e);
    }
    function Yv() {
      be !== null && typeof be.markComponentPassiveEffectMountStopped == "function" && be.markComponentPassiveEffectMountStopped();
    }
    function jc(e) {
      be !== null && typeof be.markComponentPassiveEffectUnmountStarted == "function" && be.markComponentPassiveEffectUnmountStarted(e);
    }
    function Wv() {
      be !== null && typeof be.markComponentPassiveEffectUnmountStopped == "function" && be.markComponentPassiveEffectUnmountStopped();
    }
    function xs(e) {
      be !== null && typeof be.markComponentLayoutEffectMountStarted == "function" && be.markComponentLayoutEffectMountStarted(e);
    }
    function Si() {
      be !== null && typeof be.markComponentLayoutEffectMountStopped == "function" && be.markComponentLayoutEffectMountStopped();
    }
    function du(e) {
      be !== null && typeof be.markComponentLayoutEffectUnmountStarted == "function" && be.markComponentLayoutEffectUnmountStarted(e);
    }
    function pu() {
      be !== null && typeof be.markComponentLayoutEffectUnmountStopped == "function" && be.markComponentLayoutEffectUnmountStopped();
    }
    function To(e, t, a) {
      be !== null && typeof be.markComponentErrored == "function" && be.markComponentErrored(e, t, a);
    }
    function Td(e, t, a) {
      be !== null && typeof be.markComponentSuspended == "function" && be.markComponentSuspended(e, t, a);
    }
    function vu(e) {
      be !== null && typeof be.markLayoutEffectsStarted == "function" && be.markLayoutEffectsStarted(e);
    }
    function Qv() {
      be !== null && typeof be.markLayoutEffectsStopped == "function" && be.markLayoutEffectsStopped();
    }
    function Rd(e) {
      be !== null && typeof be.markPassiveEffectsStarted == "function" && be.markPassiveEffectsStarted(e);
    }
    function En() {
      be !== null && typeof be.markPassiveEffectsStopped == "function" && be.markPassiveEffectsStopped();
    }
    function _s(e) {
      be !== null && typeof be.markRenderStarted == "function" && be.markRenderStarted(e);
    }
    function wd() {
      be !== null && typeof be.markRenderYielded == "function" && be.markRenderYielded();
    }
    function Pc() {
      be !== null && typeof be.markRenderStopped == "function" && be.markRenderStopped();
    }
    function Hc(e) {
      be !== null && typeof be.markRenderScheduled == "function" && be.markRenderScheduled(e);
    }
    function xd(e, t) {
      be !== null && typeof be.markForceUpdateScheduled == "function" && be.markForceUpdateScheduled(e, t);
    }
    function el(e, t) {
      be !== null && typeof be.markStateUpdateScheduled == "function" && be.markStateUpdateScheduled(e, t);
    }
    var Ce = (
      /*                         */
      0
    ), qe = (
      /*                 */
      1
    ), pt = (
      /*                    */
      2
    ), dn = (
      /*               */
      8
    ), qr = (
      /*              */
      16
    ), hu = Math.clz32 ? Math.clz32 : _d, by = Math.log, gr = Math.LN2;
    function _d(e) {
      var t = e >>> 0;
      return t === 0 ? 32 : 31 - (by(t) / gr | 0) | 0;
    }
    var ks = 31, ie = (
      /*                        */
      0
    ), an = (
      /*                          */
      0
    ), Ve = (
      /*                        */
      1
    ), Ei = (
      /*    */
      2
    ), ii = (
      /*             */
      4
    ), tl = (
      /*            */
      8
    ), li = (
      /*                     */
      16
    ), mu = (
      /*                */
      32
    ), Ro = (
      /*                       */
      4194240
    ), yu = (
      /*                        */
      64
    ), Bc = (
      /*                        */
      128
    ), Vc = (
      /*                        */
      256
    ), $c = (
      /*                        */
      512
    ), Ic = (
      /*                        */
      1024
    ), wo = (
      /*                        */
      2048
    ), Yc = (
      /*                        */
      4096
    ), gu = (
      /*                        */
      8192
    ), Su = (
      /*                        */
      16384
    ), Wc = (
      /*                       */
      32768
    ), Ds = (
      /*                       */
      65536
    ), Qc = (
      /*                       */
      131072
    ), Gc = (
      /*                       */
      262144
    ), Kc = (
      /*                       */
      524288
    ), qc = (
      /*                       */
      1048576
    ), Os = (
      /*                       */
      2097152
    ), Ms = (
      /*                            */
      130023424
    ), xo = (
      /*                             */
      4194304
    ), Xc = (
      /*                             */
      8388608
    ), kd = (
      /*                             */
      16777216
    ), Jc = (
      /*                             */
      33554432
    ), Dd = (
      /*                             */
      67108864
    ), Gv = xo, Eu = (
      /*          */
      134217728
    ), Od = (
      /*                          */
      268435455
    ), Cu = (
      /*               */
      268435456
    ), Ci = (
      /*                        */
      536870912
    ), Sa = (
      /*                   */
      1073741824
    );
    function Ty(e) {
      {
        if (e & Ve)
          return "Sync";
        if (e & Ei)
          return "InputContinuousHydration";
        if (e & ii)
          return "InputContinuous";
        if (e & tl)
          return "DefaultHydration";
        if (e & li)
          return "Default";
        if (e & mu)
          return "TransitionHydration";
        if (e & Ro)
          return "Transition";
        if (e & Ms)
          return "Retry";
        if (e & Eu)
          return "SelectiveHydration";
        if (e & Cu)
          return "IdleHydration";
        if (e & Ci)
          return "Idle";
        if (e & Sa)
          return "Offscreen";
      }
    }
    var on = -1, Xr = yu, bu = xo;
    function jl(e) {
      switch (Pl(e)) {
        case Ve:
          return Ve;
        case Ei:
          return Ei;
        case ii:
          return ii;
        case tl:
          return tl;
        case li:
          return li;
        case mu:
          return mu;
        case yu:
        case Bc:
        case Vc:
        case $c:
        case Ic:
        case wo:
        case Yc:
        case gu:
        case Su:
        case Wc:
        case Ds:
        case Qc:
        case Gc:
        case Kc:
        case qc:
        case Os:
          return e & Ro;
        case xo:
        case Xc:
        case kd:
        case Jc:
        case Dd:
          return e & Ms;
        case Eu:
          return Eu;
        case Cu:
          return Cu;
        case Ci:
          return Ci;
        case Sa:
          return Sa;
        default:
          return S("Should have found matching lanes. This is a bug in React."), e;
      }
    }
    function Ns(e, t) {
      var a = e.pendingLanes;
      if (a === ie)
        return ie;
      var i = ie, o = e.suspendedLanes, s = e.pingedLanes, f = a & Od;
      if (f !== ie) {
        var p = f & ~o;
        if (p !== ie)
          i = jl(p);
        else {
          var v = f & s;
          v !== ie && (i = jl(v));
        }
      } else {
        var E = a & ~o;
        E !== ie ? i = jl(E) : s !== ie && (i = jl(s));
      }
      if (i === ie)
        return ie;
      if (t !== ie && t !== i && // If we already suspended with a delay, then interrupting is fine. Don't
      // bother waiting until the root is complete.
      (t & o) === ie) {
        var C = Pl(i), M = Pl(t);
        if (
          // Tests whether the next lane is equal or lower priority than the wip
          // one. This works because the bits decrease in priority as you go left.
          C >= M || // Default priority updates should not interrupt transition updates. The
          // only difference between default updates and transition updates is that
          // default updates do not support refresh transitions.
          C === li && (M & Ro) !== ie
        )
          return t;
      }
      (i & ii) !== ie && (i |= a & li);
      var D = e.entangledLanes;
      if (D !== ie)
        for (var B = e.entanglements, $ = i & D; $ > 0; ) {
          var G = Hl($), Re = 1 << G;
          i |= B[G], $ &= ~Re;
        }
      return i;
    }
    function Kv(e, t) {
      for (var a = e.eventTimes, i = on; t > 0; ) {
        var o = Hl(t), s = 1 << o, f = a[o];
        f > i && (i = f), t &= ~s;
      }
      return i;
    }
    function qv(e, t) {
      switch (e) {
        case Ve:
        case Ei:
        case ii:
          return t + 250;
        case tl:
        case li:
        case mu:
        case yu:
        case Bc:
        case Vc:
        case $c:
        case Ic:
        case wo:
        case Yc:
        case gu:
        case Su:
        case Wc:
        case Ds:
        case Qc:
        case Gc:
        case Kc:
        case qc:
        case Os:
          return t + 5e3;
        case xo:
        case Xc:
        case kd:
        case Jc:
        case Dd:
          return on;
        case Eu:
        case Cu:
        case Ci:
        case Sa:
          return on;
        default:
          return S("Should have found matching lanes. This is a bug in React."), on;
      }
    }
    function Md(e, t) {
      for (var a = e.pendingLanes, i = e.suspendedLanes, o = e.pingedLanes, s = e.expirationTimes, f = a; f > 0; ) {
        var p = Hl(f), v = 1 << p, E = s[p];
        E === on ? ((v & i) === ie || (v & o) !== ie) && (s[p] = qv(v, t)) : E <= t && (e.expiredLanes |= v), f &= ~v;
      }
    }
    function Tu(e) {
      return jl(e.pendingLanes);
    }
    function Ls(e) {
      var t = e.pendingLanes & ~Sa;
      return t !== ie ? t : t & Sa ? Sa : ie;
    }
    function Nd(e) {
      return (e & Ve) !== ie;
    }
    function Ld(e) {
      return (e & Od) !== ie;
    }
    function Ad(e) {
      return (e & Ms) === e;
    }
    function Xv(e) {
      var t = Ve | ii | li;
      return (e & t) === ie;
    }
    function Jv(e) {
      return (e & Ro) === e;
    }
    function As(e, t) {
      var a = Ei | ii | tl | li;
      return (t & a) !== ie;
    }
    function Zv(e, t) {
      return (t & e.expiredLanes) !== ie;
    }
    function eh(e) {
      return (e & Ro) !== ie;
    }
    function Rr() {
      var e = Xr;
      return Xr <<= 1, (Xr & Ro) === ie && (Xr = yu), e;
    }
    function wr() {
      var e = bu;
      return bu <<= 1, (bu & Ms) === ie && (bu = xo), e;
    }
    function Pl(e) {
      return e & -e;
    }
    function Ru(e) {
      return Pl(e);
    }
    function Hl(e) {
      return 31 - hu(e);
    }
    function Zc(e) {
      return Hl(e);
    }
    function Jr(e, t) {
      return (e & t) !== ie;
    }
    function Bl(e, t) {
      return (e & t) === t;
    }
    function gt(e, t) {
      return e | t;
    }
    function wu(e, t) {
      return e & ~t;
    }
    function Ud(e, t) {
      return e & t;
    }
    function Ry(e) {
      return e;
    }
    function zd(e, t) {
      return e !== an && e < t ? e : t;
    }
    function Us(e) {
      for (var t = [], a = 0; a < ks; a++)
        t.push(e);
      return t;
    }
    function xu(e, t, a) {
      e.pendingLanes |= t, t !== Ci && (e.suspendedLanes = ie, e.pingedLanes = ie);
      var i = e.eventTimes, o = Zc(t);
      i[o] = a;
    }
    function Fd(e, t) {
      e.suspendedLanes |= t, e.pingedLanes &= ~t;
      for (var a = e.expirationTimes, i = t; i > 0; ) {
        var o = Hl(i), s = 1 << o;
        a[o] = on, i &= ~s;
      }
    }
    function zs(e, t, a) {
      e.pingedLanes |= e.suspendedLanes & t;
    }
    function wy(e, t) {
      var a = e.pendingLanes & ~t;
      e.pendingLanes = t, e.suspendedLanes = ie, e.pingedLanes = ie, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t;
      for (var i = e.entanglements, o = e.eventTimes, s = e.expirationTimes, f = a; f > 0; ) {
        var p = Hl(f), v = 1 << p;
        i[p] = ie, o[p] = on, s[p] = on, f &= ~v;
      }
    }
    function ef(e, t) {
      for (var a = e.entangledLanes |= t, i = e.entanglements, o = a; o; ) {
        var s = Hl(o), f = 1 << s;
        // Is this one of the newly entangled lanes?
        f & t | // Is this lane transitively entangled with the newly entangled lanes?
        i[s] & t && (i[s] |= t), o &= ~f;
      }
    }
    function jd(e, t) {
      var a = Pl(t), i;
      switch (a) {
        case ii:
          i = Ei;
          break;
        case li:
          i = tl;
          break;
        case yu:
        case Bc:
        case Vc:
        case $c:
        case Ic:
        case wo:
        case Yc:
        case gu:
        case Su:
        case Wc:
        case Ds:
        case Qc:
        case Gc:
        case Kc:
        case qc:
        case Os:
        case xo:
        case Xc:
        case kd:
        case Jc:
        case Dd:
          i = mu;
          break;
        case Ci:
          i = Cu;
          break;
        default:
          i = an;
          break;
      }
      return (i & (e.suspendedLanes | t)) !== an ? an : i;
    }
    function Pd(e, t, a) {
      if (ma)
        for (var i = e.pendingUpdatersLaneMap; a > 0; ) {
          var o = Zc(a), s = 1 << o, f = i[o];
          f.add(t), a &= ~s;
        }
    }
    function Fs(e, t) {
      if (ma)
        for (var a = e.pendingUpdatersLaneMap, i = e.memoizedUpdaters; t > 0; ) {
          var o = Zc(t), s = 1 << o, f = a[o];
          f.size > 0 && (f.forEach(function(p) {
            var v = p.alternate;
            (v === null || !i.has(v)) && i.add(p);
          }), f.clear()), t &= ~s;
        }
    }
    function bi(e, t) {
      return null;
    }
    var Ea = Ve, Ti = ii, oi = li, js = Ci, _u = an;
    function xr() {
      return _u;
    }
    function Ut(e) {
      _u = e;
    }
    function xy(e, t) {
      var a = _u;
      try {
        return _u = e, t();
      } finally {
        _u = a;
      }
    }
    function _y(e, t) {
      return e !== 0 && e < t ? e : t;
    }
    function tf(e, t) {
      return e > t ? e : t;
    }
    function Gn(e, t) {
      return e !== 0 && e < t;
    }
    function th(e) {
      var t = Pl(e);
      return Gn(Ea, t) ? Gn(Ti, t) ? Ld(t) ? oi : js : Ti : Ea;
    }
    function Oe(e) {
      var t = e.current.memoizedState;
      return t.isDehydrated;
    }
    var _o;
    function Hd(e) {
      _o = e;
    }
    function nh(e) {
      _o(e);
    }
    var Bd;
    function Ps(e) {
      Bd = e;
    }
    var Hs;
    function Vd(e) {
      Hs = e;
    }
    var $d;
    function rh(e) {
      $d = e;
    }
    var Id;
    function Yd(e) {
      Id = e;
    }
    var Bs = !1, Pn = [], Kn = null, _r = null, nl = null, ku = /* @__PURE__ */ new Map(), kr = /* @__PURE__ */ new Map(), rl = [], Ri = [
      "mousedown",
      "mouseup",
      "touchcancel",
      "touchend",
      "touchstart",
      "auxclick",
      "dblclick",
      "pointercancel",
      "pointerdown",
      "pointerup",
      "dragend",
      "dragstart",
      "drop",
      "compositionend",
      "compositionstart",
      "keydown",
      "keypress",
      "keyup",
      "input",
      "textInput",
      // Intentionally camelCase
      "copy",
      "cut",
      "paste",
      "click",
      "change",
      "contextmenu",
      "reset",
      "submit"
    ];
    function ky(e) {
      return Ri.indexOf(e) > -1;
    }
    function ah(e, t, a, i, o) {
      return {
        blockedOn: e,
        domEventName: t,
        eventSystemFlags: a,
        nativeEvent: o,
        targetContainers: [i]
      };
    }
    function Wd(e, t) {
      switch (e) {
        case "focusin":
        case "focusout":
          Kn = null;
          break;
        case "dragenter":
        case "dragleave":
          _r = null;
          break;
        case "mouseover":
        case "mouseout":
          nl = null;
          break;
        case "pointerover":
        case "pointerout": {
          var a = t.pointerId;
          ku.delete(a);
          break;
        }
        case "gotpointercapture":
        case "lostpointercapture": {
          var i = t.pointerId;
          kr.delete(i);
          break;
        }
      }
    }
    function Du(e, t, a, i, o, s) {
      if (e === null || e.nativeEvent !== s) {
        var f = ah(t, a, i, o, s);
        if (t !== null) {
          var p = zu(t);
          p !== null && Bd(p);
        }
        return f;
      }
      e.eventSystemFlags |= i;
      var v = e.targetContainers;
      return o !== null && v.indexOf(o) === -1 && v.push(o), e;
    }
    function ih(e, t, a, i, o) {
      switch (t) {
        case "focusin": {
          var s = o;
          return Kn = Du(Kn, e, t, a, i, s), !0;
        }
        case "dragenter": {
          var f = o;
          return _r = Du(_r, e, t, a, i, f), !0;
        }
        case "mouseover": {
          var p = o;
          return nl = Du(nl, e, t, a, i, p), !0;
        }
        case "pointerover": {
          var v = o, E = v.pointerId;
          return ku.set(E, Du(ku.get(E) || null, e, t, a, i, v)), !0;
        }
        case "gotpointercapture": {
          var C = o, M = C.pointerId;
          return kr.set(M, Du(kr.get(M) || null, e, t, a, i, C)), !0;
        }
      }
      return !1;
    }
    function lh(e) {
      var t = nc(e.target);
      if (t !== null) {
        var a = Ll(t);
        if (a !== null) {
          var i = a.tag;
          if (i === Ne) {
            var o = Nc(a);
            if (o !== null) {
              e.blockedOn = o, Id(e.priority, function() {
                Hs(a);
              });
              return;
            }
          } else if (i === A) {
            var s = a.stateNode;
            if (Oe(s)) {
              e.blockedOn = Lc(a);
              return;
            }
          }
        }
      }
      e.blockedOn = null;
    }
    function nf(e) {
      for (var t = $d(), a = {
        blockedOn: null,
        target: e,
        priority: t
      }, i = 0; i < rl.length && Gn(t, rl[i].priority); i++)
        ;
      rl.splice(i, 0, a), i === 0 && lh(a);
    }
    function Ou(e) {
      if (e.blockedOn !== null)
        return !1;
      for (var t = e.targetContainers; t.length > 0; ) {
        var a = t[0], i = Ys(e.domEventName, e.eventSystemFlags, a, e.nativeEvent);
        if (i === null) {
          var o = e.nativeEvent, s = new o.constructor(o.type, o);
          gy(s), o.target.dispatchEvent(s), Uv();
        } else {
          var f = zu(i);
          return f !== null && Bd(f), e.blockedOn = i, !1;
        }
        t.shift();
      }
      return !0;
    }
    function Ca(e, t, a) {
      Ou(e) && a.delete(t);
    }
    function zt() {
      Bs = !1, Kn !== null && Ou(Kn) && (Kn = null), _r !== null && Ou(_r) && (_r = null), nl !== null && Ou(nl) && (nl = null), ku.forEach(Ca), kr.forEach(Ca);
    }
    function Rn(e, t) {
      e.blockedOn === t && (e.blockedOn = null, Bs || (Bs = !0, g.unstable_scheduleCallback(g.unstable_NormalPriority, zt)));
    }
    function mn(e) {
      if (Pn.length > 0) {
        Rn(Pn[0], e);
        for (var t = 1; t < Pn.length; t++) {
          var a = Pn[t];
          a.blockedOn === e && (a.blockedOn = null);
        }
      }
      Kn !== null && Rn(Kn, e), _r !== null && Rn(_r, e), nl !== null && Rn(nl, e);
      var i = function(p) {
        return Rn(p, e);
      };
      ku.forEach(i), kr.forEach(i);
      for (var o = 0; o < rl.length; o++) {
        var s = rl[o];
        s.blockedOn === e && (s.blockedOn = null);
      }
      for (; rl.length > 0; ) {
        var f = rl[0];
        if (f.blockedOn !== null)
          break;
        lh(f), f.blockedOn === null && rl.shift();
      }
    }
    var wn = T.ReactCurrentBatchConfig, Dr = !0;
    function ko(e) {
      Dr = !!e;
    }
    function In() {
      return Dr;
    }
    function Vs(e, t, a) {
      var i = Oo(t), o;
      switch (i) {
        case Ea:
          o = Do;
          break;
        case Ti:
          o = rf;
          break;
        case oi:
        default:
          o = $s;
          break;
      }
      return o.bind(null, t, a, e);
    }
    function Do(e, t, a, i) {
      var o = xr(), s = wn.transition;
      wn.transition = null;
      try {
        Ut(Ea), $s(e, t, a, i);
      } finally {
        Ut(o), wn.transition = s;
      }
    }
    function rf(e, t, a, i) {
      var o = xr(), s = wn.transition;
      wn.transition = null;
      try {
        Ut(Ti), $s(e, t, a, i);
      } finally {
        Ut(o), wn.transition = s;
      }
    }
    function $s(e, t, a, i) {
      Dr && Is(e, t, a, i);
    }
    function Is(e, t, a, i) {
      var o = Ys(e, t, a, i);
      if (o === null) {
        Qy(e, t, i, rr, a), Wd(e, i);
        return;
      }
      if (ih(o, e, t, a, i)) {
        i.stopPropagation();
        return;
      }
      if (Wd(e, i), t & Ss && ky(e)) {
        for (; o !== null; ) {
          var s = zu(o);
          s !== null && nh(s);
          var f = Ys(e, t, a, i);
          if (f === null && Qy(e, t, i, rr, a), f === o)
            break;
          o = f;
        }
        o !== null && i.stopPropagation();
        return;
      }
      Qy(e, t, i, null, a);
    }
    var rr = null;
    function Ys(e, t, a, i) {
      rr = null;
      var o = nn(i), s = nc(o);
      if (s !== null) {
        var f = Ll(s);
        if (f === null)
          s = null;
        else {
          var p = f.tag;
          if (p === Ne) {
            var v = Nc(f);
            if (v !== null)
              return v;
            s = null;
          } else if (p === A) {
            var E = f.stateNode;
            if (Oe(E))
              return Lc(f);
            s = null;
          } else f !== s && (s = null);
        }
      }
      return rr = s, null;
    }
    function Oo(e) {
      switch (e) {
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
          return Ea;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "toggle":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
          return Ti;
        case "message": {
          var t = Cy();
          switch (t) {
            case Al:
              return Ea;
            case cu:
              return Ti;
            case Ul:
            case $v:
              return oi;
            case zl:
              return js;
            default:
              return oi;
          }
        }
        default:
          return oi;
      }
    }
    function al(e, t, a) {
      return e.addEventListener(t, a, !1), a;
    }
    function af(e, t, a) {
      return e.addEventListener(t, a, !0), a;
    }
    function Qd(e, t, a, i) {
      return e.addEventListener(t, a, {
        capture: !0,
        passive: i
      }), a;
    }
    function Vl(e, t, a, i) {
      return e.addEventListener(t, a, {
        passive: i
      }), a;
    }
    var $l = null, wi = null, Il = null;
    function Ws(e) {
      return $l = e, wi = Gs(), !0;
    }
    function Gd() {
      $l = null, wi = null, Il = null;
    }
    function Qs() {
      if (Il)
        return Il;
      var e, t = wi, a = t.length, i, o = Gs(), s = o.length;
      for (e = 0; e < a && t[e] === o[e]; e++)
        ;
      var f = a - e;
      for (i = 1; i <= f && t[a - i] === o[s - i]; i++)
        ;
      var p = i > 1 ? 1 - i : void 0;
      return Il = o.slice(e, p), Il;
    }
    function Gs() {
      return "value" in $l ? $l.value : $l.textContent;
    }
    function qn(e) {
      var t, a = e.keyCode;
      return "charCode" in e ? (t = e.charCode, t === 0 && a === 13 && (t = 13)) : t = a, t === 10 && (t = 13), t >= 32 || t === 13 ? t : 0;
    }
    function ui() {
      return !0;
    }
    function Ba() {
      return !1;
    }
    function un(e) {
      function t(a, i, o, s, f) {
        this._reactName = a, this._targetInst = o, this.type = i, this.nativeEvent = s, this.target = f, this.currentTarget = null;
        for (var p in e)
          if (e.hasOwnProperty(p)) {
            var v = e[p];
            v ? this[p] = v(s) : this[p] = s[p];
          }
        var E = s.defaultPrevented != null ? s.defaultPrevented : s.returnValue === !1;
        return E ? this.isDefaultPrevented = ui : this.isDefaultPrevented = Ba, this.isPropagationStopped = Ba, this;
      }
      return yt(t.prototype, {
        preventDefault: function() {
          this.defaultPrevented = !0;
          var a = this.nativeEvent;
          a && (a.preventDefault ? a.preventDefault() : typeof a.returnValue != "unknown" && (a.returnValue = !1), this.isDefaultPrevented = ui);
        },
        stopPropagation: function() {
          var a = this.nativeEvent;
          a && (a.stopPropagation ? a.stopPropagation() : typeof a.cancelBubble != "unknown" && (a.cancelBubble = !0), this.isPropagationStopped = ui);
        },
        /**
         * We release all dispatched `SyntheticEvent`s after each event loop, adding
         * them back into the pool. This allows a way to hold onto a reference that
         * won't be added back into the pool.
         */
        persist: function() {
        },
        /**
         * Checks if this event should be released back into the pool.
         *
         * @return {boolean} True if this should not be released, false otherwise.
         */
        isPersistent: ui
      }), t;
    }
    var Mo = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function(e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0
    }, Ks = un(Mo), No = yt({}, Mo, {
      view: 0,
      detail: 0
    }), Dy = un(No), xi, lf, Lo;
    function Ao(e) {
      e !== Lo && (Lo && e.type === "mousemove" ? (xi = e.screenX - Lo.screenX, lf = e.screenY - Lo.screenY) : (xi = 0, lf = 0), Lo = e);
    }
    var Mu = yt({}, No, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: qd,
      button: 0,
      buttons: 0,
      relatedTarget: function(e) {
        return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
      },
      movementX: function(e) {
        return "movementX" in e ? e.movementX : (Ao(e), xi);
      },
      movementY: function(e) {
        return "movementY" in e ? e.movementY : lf;
      }
    }), Yl = un(Mu), oh = yt({}, Mu, {
      dataTransfer: 0
    }), uh = un(oh), Kd = yt({}, No, {
      relatedTarget: 0
    }), Nu = un(Kd), Oy = yt({}, Mo, {
      animationName: 0,
      elapsedTime: 0,
      pseudoElement: 0
    }), My = un(Oy), sh = yt({}, Mo, {
      clipboardData: function(e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      }
    }), ch = un(sh), Uo = yt({}, Mo, {
      data: 0
    }), fh = un(Uo), Lu = fh, dh = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified"
    }, xn = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta"
    };
    function Ny(e) {
      if (e.key) {
        var t = dh[e.key] || e.key;
        if (t !== "Unidentified")
          return t;
      }
      if (e.type === "keypress") {
        var a = qn(e);
        return a === 13 ? "Enter" : String.fromCharCode(a);
      }
      return e.type === "keydown" || e.type === "keyup" ? xn[e.keyCode] || "Unidentified" : "";
    }
    var ph = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey"
    };
    function Ly(e) {
      var t = this, a = t.nativeEvent;
      if (a.getModifierState)
        return a.getModifierState(e);
      var i = ph[e];
      return i ? !!a[i] : !1;
    }
    function qd(e) {
      return Ly;
    }
    var vh = yt({}, No, {
      key: Ny,
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: qd,
      // Legacy Interface
      charCode: function(e) {
        return e.type === "keypress" ? qn(e) : 0;
      },
      keyCode: function(e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function(e) {
        return e.type === "keypress" ? qn(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      }
    }), hh = un(vh), Ay = yt({}, Mu, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0
    }), ba = un(Ay), Xd = yt({}, No, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: qd
    }), Uy = un(Xd), Wl = yt({}, Mo, {
      propertyName: 0,
      elapsedTime: 0,
      pseudoElement: 0
    }), of = un(Wl), zo = yt({}, Mu, {
      deltaX: function(e) {
        return "deltaX" in e ? e.deltaX : (
          // Fallback to `wheelDeltaX` for Webkit and normalize (right is positive).
          "wheelDeltaX" in e ? -e.wheelDeltaX : 0
        );
      },
      deltaY: function(e) {
        return "deltaY" in e ? e.deltaY : (
          // Fallback to `wheelDeltaY` for Webkit and normalize (down is positive).
          "wheelDeltaY" in e ? -e.wheelDeltaY : (
            // Fallback to `wheelDelta` for IE<9 and normalize (down is positive).
            "wheelDelta" in e ? -e.wheelDelta : 0
          )
        );
      },
      deltaZ: 0,
      // Browsers without "deltaMode" is reporting in raw wheel delta where one
      // notch on the scroll is always +/- 120, roughly equivalent to pixels.
      // A good approximation of DOM_DELTA_LINE (1) is 5% of viewport size or
      // ~40 pixels, for DOM_DELTA_SCREEN (2) it is 87.5% of viewport size.
      deltaMode: 0
    }), uf = un(zo), Jd = [9, 13, 27, 32], sf = 229, Zd = bn && "CompositionEvent" in window, Fo = null;
    bn && "documentMode" in document && (Fo = document.documentMode);
    var zy = bn && "TextEvent" in window && !Fo, ep = bn && (!Zd || Fo && Fo > 8 && Fo <= 11), tp = 32, qs = String.fromCharCode(tp);
    function cf() {
      Pr("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), Pr("onCompositionEnd", ["compositionend", "focusout", "keydown", "keypress", "keyup", "mousedown"]), Pr("onCompositionStart", ["compositionstart", "focusout", "keydown", "keypress", "keyup", "mousedown"]), Pr("onCompositionUpdate", ["compositionupdate", "focusout", "keydown", "keypress", "keyup", "mousedown"]);
    }
    var np = !1;
    function rp(e) {
      return (e.ctrlKey || e.altKey || e.metaKey) && // ctrlKey && altKey is equivalent to AltGr, and is not a command.
      !(e.ctrlKey && e.altKey);
    }
    function Fy(e) {
      switch (e) {
        case "compositionstart":
          return "onCompositionStart";
        case "compositionend":
          return "onCompositionEnd";
        case "compositionupdate":
          return "onCompositionUpdate";
      }
    }
    function mh(e, t) {
      return e === "keydown" && t.keyCode === sf;
    }
    function ff(e, t) {
      switch (e) {
        case "keyup":
          return Jd.indexOf(t.keyCode) !== -1;
        case "keydown":
          return t.keyCode !== sf;
        case "keypress":
        case "mousedown":
        case "focusout":
          return !0;
        default:
          return !1;
      }
    }
    function Xs(e) {
      var t = e.detail;
      return typeof t == "object" && "data" in t ? t.data : null;
    }
    function df(e) {
      return e.locale === "ko";
    }
    var il = !1;
    function yh(e, t, a, i, o) {
      var s, f;
      if (Zd ? s = Fy(t) : il ? ff(t, i) && (s = "onCompositionEnd") : mh(t, i) && (s = "onCompositionStart"), !s)
        return null;
      ep && !df(i) && (!il && s === "onCompositionStart" ? il = Ws(o) : s === "onCompositionEnd" && il && (f = Qs()));
      var p = bh(a, s);
      if (p.length > 0) {
        var v = new fh(s, t, null, i, o);
        if (e.push({
          event: v,
          listeners: p
        }), f)
          v.data = f;
        else {
          var E = Xs(i);
          E !== null && (v.data = E);
        }
      }
    }
    function jy(e, t) {
      switch (e) {
        case "compositionend":
          return Xs(t);
        case "keypress":
          var a = t.which;
          return a !== tp ? null : (np = !0, qs);
        case "textInput":
          var i = t.data;
          return i === qs && np ? null : i;
        default:
          return null;
      }
    }
    function pf(e, t) {
      if (il) {
        if (e === "compositionend" || !Zd && ff(e, t)) {
          var a = Qs();
          return Gd(), il = !1, a;
        }
        return null;
      }
      switch (e) {
        case "paste":
          return null;
        case "keypress":
          if (!rp(t)) {
            if (t.char && t.char.length > 1)
              return t.char;
            if (t.which)
              return String.fromCharCode(t.which);
          }
          return null;
        case "compositionend":
          return ep && !df(t) ? null : t.data;
        default:
          return null;
      }
    }
    function Py(e, t, a, i, o) {
      var s;
      if (zy ? s = jy(t, i) : s = pf(t, i), !s)
        return null;
      var f = bh(a, "onBeforeInput");
      if (f.length > 0) {
        var p = new Lu("onBeforeInput", "beforeinput", null, i, o);
        e.push({
          event: p,
          listeners: f
        }), p.data = s;
      }
    }
    function Js(e, t, a, i, o, s, f) {
      yh(e, t, a, i, o), Py(e, t, a, i, o);
    }
    var Hy = {
      color: !0,
      date: !0,
      datetime: !0,
      "datetime-local": !0,
      email: !0,
      month: !0,
      number: !0,
      password: !0,
      range: !0,
      search: !0,
      tel: !0,
      text: !0,
      time: !0,
      url: !0,
      week: !0
    };
    function Zs(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return t === "input" ? !!Hy[e.type] : t === "textarea";
    }
    /**
     * Checks if an event is supported in the current execution environment.
     *
     * NOTE: This will not work correctly for non-generic events such as `change`,
     * `reset`, `load`, `error`, and `select`.
     *
     * Borrows from Modernizr.
     *
     * @param {string} eventNameSuffix Event name, e.g. "click".
     * @return {boolean} True if the event is supported.
     * @internal
     * @license Modernizr 3.0.0pre (Custom Build) | MIT
     */
    function n(e) {
      if (!bn)
        return !1;
      var t = "on" + e, a = t in document;
      if (!a) {
        var i = document.createElement("div");
        i.setAttribute(t, "return;"), a = typeof i[t] == "function";
      }
      return a;
    }
    function r() {
      Pr("onChange", ["change", "click", "focusin", "focusout", "input", "keydown", "keyup", "selectionchange"]);
    }
    function l(e, t, a, i) {
      ou(i);
      var o = bh(t, "onChange");
      if (o.length > 0) {
        var s = new Ks("onChange", "change", null, a, i);
        e.push({
          event: s,
          listeners: o
        });
      }
    }
    var u = null, c = null;
    function d(e) {
      var t = e.nodeName && e.nodeName.toLowerCase();
      return t === "select" || t === "input" && e.type === "file";
    }
    function y(e) {
      var t = [];
      l(t, c, e, nn(e)), Cs(R, t);
    }
    function R(e) {
      rE(e, 0);
    }
    function k(e) {
      var t = Sf(e);
      if (eu(t))
        return e;
    }
    function V(e, t) {
      if (e === "change")
        return t;
    }
    var se = !1;
    bn && (se = n("input") && (!document.documentMode || document.documentMode > 9));
    function fe(e, t) {
      u = e, c = t, u.attachEvent("onpropertychange", _e);
    }
    function le() {
      u && (u.detachEvent("onpropertychange", _e), u = null, c = null);
    }
    function _e(e) {
      e.propertyName === "value" && k(c) && y(e);
    }
    function ze(e, t, a) {
      e === "focusin" ? (le(), fe(t, a)) : e === "focusout" && le();
    }
    function Pe(e, t) {
      if (e === "selectionchange" || e === "keyup" || e === "keydown")
        return k(c);
    }
    function Nn(e) {
      var t = e.nodeName;
      return t && t.toLowerCase() === "input" && (e.type === "checkbox" || e.type === "radio");
    }
    function z(e, t) {
      if (e === "click")
        return k(t);
    }
    function O(e, t) {
      if (e === "input" || e === "change")
        return k(t);
    }
    function P(e) {
      var t = e._wrapperState;
      !t || !t.controlled || e.type !== "number" || ot(e, "number", e.value);
    }
    function me(e, t, a, i, o, s, f) {
      var p = a ? Sf(a) : window, v, E;
      if (d(p) ? v = V : Zs(p) ? se ? v = O : (v = Pe, E = ze) : Nn(p) && (v = z), v) {
        var C = v(t, a);
        if (C) {
          l(e, C, i, o);
          return;
        }
      }
      E && E(t, p, a), t === "focusout" && P(p);
    }
    function Be() {
      dr("onMouseEnter", ["mouseout", "mouseover"]), dr("onMouseLeave", ["mouseout", "mouseover"]), dr("onPointerEnter", ["pointerout", "pointerover"]), dr("onPointerLeave", ["pointerout", "pointerover"]);
    }
    function rt(e, t, a, i, o, s, f) {
      var p = t === "mouseover" || t === "pointerover", v = t === "mouseout" || t === "pointerout";
      if (p && !zv(i)) {
        var E = i.relatedTarget || i.fromElement;
        if (E && (nc(E) || yp(E)))
          return;
      }
      if (!(!v && !p)) {
        var C;
        if (o.window === o)
          C = o;
        else {
          var M = o.ownerDocument;
          M ? C = M.defaultView || M.parentWindow : C = window;
        }
        var D, B;
        if (v) {
          var $ = i.relatedTarget || i.toElement;
          if (D = a, B = $ ? nc($) : null, B !== null) {
            var G = Ll(B);
            (B !== G || B.tag !== q && B.tag !== ve) && (B = null);
          }
        } else
          D = null, B = a;
        if (D !== B) {
          var Re = Yl, et = "onMouseLeave", Ie = "onMouseEnter", Lt = "mouse";
          (t === "pointerout" || t === "pointerover") && (Re = ba, et = "onPointerLeave", Ie = "onPointerEnter", Lt = "pointer");
          var _t = D == null ? C : Sf(D), F = B == null ? C : Sf(B), K = new Re(et, Lt + "leave", D, i, o);
          K.target = _t, K.relatedTarget = F;
          var j = null, de = nc(o);
          if (de === a) {
            var Me = new Re(Ie, Lt + "enter", B, i, o);
            Me.target = F, Me.relatedTarget = _t, j = Me;
          }
          PR(e, K, j, D, B);
        }
      }
    }
    function at(e, t) {
      return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
    }
    var $e = typeof Object.is == "function" ? Object.is : at;
    function _n(e, t) {
      if ($e(e, t))
        return !0;
      if (typeof e != "object" || e === null || typeof t != "object" || t === null)
        return !1;
      var a = Object.keys(e), i = Object.keys(t);
      if (a.length !== i.length)
        return !1;
      for (var o = 0; o < a.length; o++) {
        var s = a[o];
        if (!Jn.call(t, s) || !$e(e[s], t[s]))
          return !1;
      }
      return !0;
    }
    function Ft(e) {
      for (; e && e.firstChild; )
        e = e.firstChild;
      return e;
    }
    function Ql(e) {
      for (; e; ) {
        if (e.nextSibling)
          return e.nextSibling;
        e = e.parentNode;
      }
    }
    function gh(e, t) {
      for (var a = Ft(e), i = 0, o = 0; a; ) {
        if (a.nodeType === Yi) {
          if (o = i + a.textContent.length, i <= t && o >= t)
            return {
              node: a,
              offset: t - i
            };
          i = o;
        }
        a = Ft(Ql(a));
      }
    }
    function gR(e) {
      var t = e.ownerDocument, a = t && t.defaultView || window, i = a.getSelection && a.getSelection();
      if (!i || i.rangeCount === 0)
        return null;
      var o = i.anchorNode, s = i.anchorOffset, f = i.focusNode, p = i.focusOffset;
      try {
        o.nodeType, f.nodeType;
      } catch {
        return null;
      }
      return SR(e, o, s, f, p);
    }
    function SR(e, t, a, i, o) {
      var s = 0, f = -1, p = -1, v = 0, E = 0, C = e, M = null;
      e: for (; ; ) {
        for (var D = null; C === t && (a === 0 || C.nodeType === Yi) && (f = s + a), C === i && (o === 0 || C.nodeType === Yi) && (p = s + o), C.nodeType === Yi && (s += C.nodeValue.length), (D = C.firstChild) !== null; )
          M = C, C = D;
        for (; ; ) {
          if (C === e)
            break e;
          if (M === t && ++v === a && (f = s), M === i && ++E === o && (p = s), (D = C.nextSibling) !== null)
            break;
          C = M, M = C.parentNode;
        }
        C = D;
      }
      return f === -1 || p === -1 ? null : {
        start: f,
        end: p
      };
    }
    function ER(e, t) {
      var a = e.ownerDocument || document, i = a && a.defaultView || window;
      if (i.getSelection) {
        var o = i.getSelection(), s = e.textContent.length, f = Math.min(t.start, s), p = t.end === void 0 ? f : Math.min(t.end, s);
        if (!o.extend && f > p) {
          var v = p;
          p = f, f = v;
        }
        var E = gh(e, f), C = gh(e, p);
        if (E && C) {
          if (o.rangeCount === 1 && o.anchorNode === E.node && o.anchorOffset === E.offset && o.focusNode === C.node && o.focusOffset === C.offset)
            return;
          var M = a.createRange();
          M.setStart(E.node, E.offset), o.removeAllRanges(), f > p ? (o.addRange(M), o.extend(C.node, C.offset)) : (M.setEnd(C.node, C.offset), o.addRange(M));
        }
      }
    }
    function Y0(e) {
      return e && e.nodeType === Yi;
    }
    function W0(e, t) {
      return !e || !t ? !1 : e === t ? !0 : Y0(e) ? !1 : Y0(t) ? W0(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1;
    }
    function CR(e) {
      return e && e.ownerDocument && W0(e.ownerDocument.documentElement, e);
    }
    function bR(e) {
      try {
        return typeof e.contentWindow.location.href == "string";
      } catch {
        return !1;
      }
    }
    function Q0() {
      for (var e = window, t = vi(); t instanceof e.HTMLIFrameElement; ) {
        if (bR(t))
          e = t.contentWindow;
        else
          return t;
        t = vi(e.document);
      }
      return t;
    }
    function By(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
    }
    function TR() {
      var e = Q0();
      return {
        focusedElem: e,
        selectionRange: By(e) ? wR(e) : null
      };
    }
    function RR(e) {
      var t = Q0(), a = e.focusedElem, i = e.selectionRange;
      if (t !== a && CR(a)) {
        i !== null && By(a) && xR(a, i);
        for (var o = [], s = a; s = s.parentNode; )
          s.nodeType === Yr && o.push({
            element: s,
            left: s.scrollLeft,
            top: s.scrollTop
          });
        typeof a.focus == "function" && a.focus();
        for (var f = 0; f < o.length; f++) {
          var p = o[f];
          p.element.scrollLeft = p.left, p.element.scrollTop = p.top;
        }
      }
    }
    function wR(e) {
      var t;
      return "selectionStart" in e ? t = {
        start: e.selectionStart,
        end: e.selectionEnd
      } : t = gR(e), t || {
        start: 0,
        end: 0
      };
    }
    function xR(e, t) {
      var a = t.start, i = t.end;
      i === void 0 && (i = a), "selectionStart" in e ? (e.selectionStart = a, e.selectionEnd = Math.min(i, e.value.length)) : ER(e, t);
    }
    var _R = bn && "documentMode" in document && document.documentMode <= 11;
    function kR() {
      Pr("onSelect", ["focusout", "contextmenu", "dragend", "focusin", "keydown", "keyup", "mousedown", "mouseup", "selectionchange"]);
    }
    var vf = null, Vy = null, ap = null, $y = !1;
    function DR(e) {
      if ("selectionStart" in e && By(e))
        return {
          start: e.selectionStart,
          end: e.selectionEnd
        };
      var t = e.ownerDocument && e.ownerDocument.defaultView || window, a = t.getSelection();
      return {
        anchorNode: a.anchorNode,
        anchorOffset: a.anchorOffset,
        focusNode: a.focusNode,
        focusOffset: a.focusOffset
      };
    }
    function OR(e) {
      return e.window === e ? e.document : e.nodeType === fa ? e : e.ownerDocument;
    }
    function G0(e, t, a) {
      var i = OR(a);
      if (!($y || vf == null || vf !== vi(i))) {
        var o = DR(vf);
        if (!ap || !_n(ap, o)) {
          ap = o;
          var s = bh(Vy, "onSelect");
          if (s.length > 0) {
            var f = new Ks("onSelect", "select", null, t, a);
            e.push({
              event: f,
              listeners: s
            }), f.target = vf;
          }
        }
      }
    }
    function MR(e, t, a, i, o, s, f) {
      var p = a ? Sf(a) : window;
      switch (t) {
        case "focusin":
          (Zs(p) || p.contentEditable === "true") && (vf = p, Vy = a, ap = null);
          break;
        case "focusout":
          vf = null, Vy = null, ap = null;
          break;
        case "mousedown":
          $y = !0;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          $y = !1, G0(e, i, o);
          break;
        case "selectionchange":
          if (_R)
            break;
        case "keydown":
        case "keyup":
          G0(e, i, o);
      }
    }
    function Sh(e, t) {
      var a = {};
      return a[e.toLowerCase()] = t.toLowerCase(), a["Webkit" + e] = "webkit" + t, a["Moz" + e] = "moz" + t, a;
    }
    var hf = {
      animationend: Sh("Animation", "AnimationEnd"),
      animationiteration: Sh("Animation", "AnimationIteration"),
      animationstart: Sh("Animation", "AnimationStart"),
      transitionend: Sh("Transition", "TransitionEnd")
    }, Iy = {}, K0 = {};
    bn && (K0 = document.createElement("div").style, "AnimationEvent" in window || (delete hf.animationend.animation, delete hf.animationiteration.animation, delete hf.animationstart.animation), "TransitionEvent" in window || delete hf.transitionend.transition);
    function Eh(e) {
      if (Iy[e])
        return Iy[e];
      if (!hf[e])
        return e;
      var t = hf[e];
      for (var a in t)
        if (t.hasOwnProperty(a) && a in K0)
          return Iy[e] = t[a];
      return e;
    }
    var q0 = Eh("animationend"), X0 = Eh("animationiteration"), J0 = Eh("animationstart"), Z0 = Eh("transitionend"), eE = /* @__PURE__ */ new Map(), tE = ["abort", "auxClick", "cancel", "canPlay", "canPlayThrough", "click", "close", "contextMenu", "copy", "cut", "drag", "dragEnd", "dragEnter", "dragExit", "dragLeave", "dragOver", "dragStart", "drop", "durationChange", "emptied", "encrypted", "ended", "error", "gotPointerCapture", "input", "invalid", "keyDown", "keyPress", "keyUp", "load", "loadedData", "loadedMetadata", "loadStart", "lostPointerCapture", "mouseDown", "mouseMove", "mouseOut", "mouseOver", "mouseUp", "paste", "pause", "play", "playing", "pointerCancel", "pointerDown", "pointerMove", "pointerOut", "pointerOver", "pointerUp", "progress", "rateChange", "reset", "resize", "seeked", "seeking", "stalled", "submit", "suspend", "timeUpdate", "touchCancel", "touchEnd", "touchStart", "volumeChange", "scroll", "toggle", "touchMove", "waiting", "wheel"];
    function Au(e, t) {
      eE.set(e, t), Pr(t, [e]);
    }
    function NR() {
      for (var e = 0; e < tE.length; e++) {
        var t = tE[e], a = t.toLowerCase(), i = t[0].toUpperCase() + t.slice(1);
        Au(a, "on" + i);
      }
      Au(q0, "onAnimationEnd"), Au(X0, "onAnimationIteration"), Au(J0, "onAnimationStart"), Au("dblclick", "onDoubleClick"), Au("focusin", "onFocus"), Au("focusout", "onBlur"), Au(Z0, "onTransitionEnd");
    }
    function LR(e, t, a, i, o, s, f) {
      var p = eE.get(t);
      if (p !== void 0) {
        var v = Ks, E = t;
        switch (t) {
          case "keypress":
            if (qn(i) === 0)
              return;
          case "keydown":
          case "keyup":
            v = hh;
            break;
          case "focusin":
            E = "focus", v = Nu;
            break;
          case "focusout":
            E = "blur", v = Nu;
            break;
          case "beforeblur":
          case "afterblur":
            v = Nu;
            break;
          case "click":
            if (i.button === 2)
              return;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            v = Yl;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            v = uh;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            v = Uy;
            break;
          case q0:
          case X0:
          case J0:
            v = My;
            break;
          case Z0:
            v = of;
            break;
          case "scroll":
            v = Dy;
            break;
          case "wheel":
            v = uf;
            break;
          case "copy":
          case "cut":
          case "paste":
            v = ch;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            v = ba;
            break;
        }
        var C = (s & Ss) !== 0;
        {
          var M = !C && // TODO: ideally, we'd eventually add all events from
          // nonDelegatedEvents list in DOMPluginEventSystem.
          // Then we can remove this special list.
          // This is a breaking change that can wait until React 18.
          t === "scroll", D = FR(a, p, i.type, C, M);
          if (D.length > 0) {
            var B = new v(p, E, null, i, o);
            e.push({
              event: B,
              listeners: D
            });
          }
        }
      }
    }
    NR(), Be(), r(), kR(), cf();
    function AR(e, t, a, i, o, s, f) {
      LR(e, t, a, i, o, s);
      var p = (s & yy) === 0;
      p && (rt(e, t, a, i, o), me(e, t, a, i, o), MR(e, t, a, i, o), Js(e, t, a, i, o));
    }
    var ip = ["abort", "canplay", "canplaythrough", "durationchange", "emptied", "encrypted", "ended", "error", "loadeddata", "loadedmetadata", "loadstart", "pause", "play", "playing", "progress", "ratechange", "resize", "seeked", "seeking", "stalled", "suspend", "timeupdate", "volumechange", "waiting"], Yy = new Set(["cancel", "close", "invalid", "load", "scroll", "toggle"].concat(ip));
    function nE(e, t, a) {
      var i = e.type || "unknown-event";
      e.currentTarget = a, vd(i, t, void 0, e), e.currentTarget = null;
    }
    function UR(e, t, a) {
      var i;
      if (a)
        for (var o = t.length - 1; o >= 0; o--) {
          var s = t[o], f = s.instance, p = s.currentTarget, v = s.listener;
          if (f !== i && e.isPropagationStopped())
            return;
          nE(e, v, p), i = f;
        }
      else
        for (var E = 0; E < t.length; E++) {
          var C = t[E], M = C.instance, D = C.currentTarget, B = C.listener;
          if (M !== i && e.isPropagationStopped())
            return;
          nE(e, B, D), i = M;
        }
    }
    function rE(e, t) {
      for (var a = (t & Ss) !== 0, i = 0; i < e.length; i++) {
        var o = e[i], s = o.event, f = o.listeners;
        UR(s, f, a);
      }
      Sy();
    }
    function zR(e, t, a, i, o) {
      var s = nn(a), f = [];
      AR(f, e, i, a, s, t), rE(f, t);
    }
    function Cn(e, t) {
      Yy.has(e) || S('Did not expect a listenToNonDelegatedEvent() call for "%s". This is a bug in React. Please file an issue.', e);
      var a = !1, i = dw(t), o = HR(e);
      i.has(o) || (aE(t, e, gs, a), i.add(o));
    }
    function Wy(e, t, a) {
      Yy.has(e) && !t && S('Did not expect a listenToNativeEvent() call for "%s" in the bubble phase. This is a bug in React. Please file an issue.', e);
      var i = 0;
      t && (i |= Ss), aE(a, e, i, t);
    }
    var Ch = "_reactListening" + Math.random().toString(36).slice(2);
    function lp(e) {
      if (!e[Ch]) {
        e[Ch] = !0, nt.forEach(function(a) {
          a !== "selectionchange" && (Yy.has(a) || Wy(a, !1, e), Wy(a, !0, e));
        });
        var t = e.nodeType === fa ? e : e.ownerDocument;
        t !== null && (t[Ch] || (t[Ch] = !0, Wy("selectionchange", !1, t)));
      }
    }
    function aE(e, t, a, i, o) {
      var s = Vs(e, t, a), f = void 0;
      bs && (t === "touchstart" || t === "touchmove" || t === "wheel") && (f = !0), e = e, i ? f !== void 0 ? Qd(e, t, s, f) : af(e, t, s) : f !== void 0 ? Vl(e, t, s, f) : al(e, t, s);
    }
    function iE(e, t) {
      return e === t || e.nodeType === Tn && e.parentNode === t;
    }
    function Qy(e, t, a, i, o) {
      var s = i;
      if (!(t & _c) && !(t & gs)) {
        var f = o;
        if (i !== null) {
          var p = i;
          e: for (; ; ) {
            if (p === null)
              return;
            var v = p.tag;
            if (v === A || v === oe) {
              var E = p.stateNode.containerInfo;
              if (iE(E, f))
                break;
              if (v === oe)
                for (var C = p.return; C !== null; ) {
                  var M = C.tag;
                  if (M === A || M === oe) {
                    var D = C.stateNode.containerInfo;
                    if (iE(D, f))
                      return;
                  }
                  C = C.return;
                }
              for (; E !== null; ) {
                var B = nc(E);
                if (B === null)
                  return;
                var $ = B.tag;
                if ($ === q || $ === ve) {
                  p = s = B;
                  continue e;
                }
                E = E.parentNode;
              }
            }
            p = p.return;
          }
        }
      }
      Cs(function() {
        return zR(e, t, a, s);
      });
    }
    function op(e, t, a) {
      return {
        instance: e,
        listener: t,
        currentTarget: a
      };
    }
    function FR(e, t, a, i, o, s) {
      for (var f = t !== null ? t + "Capture" : null, p = i ? f : t, v = [], E = e, C = null; E !== null; ) {
        var M = E, D = M.stateNode, B = M.tag;
        if (B === q && D !== null && (C = D, p !== null)) {
          var $ = go(E, p);
          $ != null && v.push(op(E, $, C));
        }
        if (o)
          break;
        E = E.return;
      }
      return v;
    }
    function bh(e, t) {
      for (var a = t + "Capture", i = [], o = e; o !== null; ) {
        var s = o, f = s.stateNode, p = s.tag;
        if (p === q && f !== null) {
          var v = f, E = go(o, a);
          E != null && i.unshift(op(o, E, v));
          var C = go(o, t);
          C != null && i.push(op(o, C, v));
        }
        o = o.return;
      }
      return i;
    }
    function mf(e) {
      if (e === null)
        return null;
      do
        e = e.return;
      while (e && e.tag !== q);
      return e || null;
    }
    function jR(e, t) {
      for (var a = e, i = t, o = 0, s = a; s; s = mf(s))
        o++;
      for (var f = 0, p = i; p; p = mf(p))
        f++;
      for (; o - f > 0; )
        a = mf(a), o--;
      for (; f - o > 0; )
        i = mf(i), f--;
      for (var v = o; v--; ) {
        if (a === i || i !== null && a === i.alternate)
          return a;
        a = mf(a), i = mf(i);
      }
      return null;
    }
    function lE(e, t, a, i, o) {
      for (var s = t._reactName, f = [], p = a; p !== null && p !== i; ) {
        var v = p, E = v.alternate, C = v.stateNode, M = v.tag;
        if (E !== null && E === i)
          break;
        if (M === q && C !== null) {
          var D = C;
          if (o) {
            var B = go(p, s);
            B != null && f.unshift(op(p, B, D));
          } else if (!o) {
            var $ = go(p, s);
            $ != null && f.push(op(p, $, D));
          }
        }
        p = p.return;
      }
      f.length !== 0 && e.push({
        event: t,
        listeners: f
      });
    }
    function PR(e, t, a, i, o) {
      var s = i && o ? jR(i, o) : null;
      i !== null && lE(e, t, i, s, !1), o !== null && a !== null && lE(e, a, o, s, !0);
    }
    function HR(e, t) {
      return e + "__bubble";
    }
    var Va = !1, up = "dangerouslySetInnerHTML", Th = "suppressContentEditableWarning", Uu = "suppressHydrationWarning", oE = "autoFocus", ec = "children", tc = "style", Rh = "__html", Gy, wh, sp, uE, xh, sE, cE;
    Gy = {
      // There are working polyfills for <dialog>. Let people use it.
      dialog: !0,
      // Electron ships a custom <webview> tag to display external web content in
      // an isolated frame and process.
      // This tag is not present in non Electron environments such as JSDom which
      // is often used for testing purposes.
      // @see https://electronjs.org/docs/api/webview-tag
      webview: !0
    }, wh = function(e, t) {
      lu(e, t), Ov(e, t), Dl(e, t, {
        registrationNameDependencies: wt,
        possibleRegistrationNames: kn
      });
    }, sE = bn && !document.documentMode, sp = function(e, t, a) {
      if (!Va) {
        var i = _h(a), o = _h(t);
        o !== i && (Va = !0, S("Prop `%s` did not match. Server: %s Client: %s", e, JSON.stringify(o), JSON.stringify(i)));
      }
    }, uE = function(e) {
      if (!Va) {
        Va = !0;
        var t = [];
        e.forEach(function(a) {
          t.push(a);
        }), S("Extra attributes from the server: %s", t);
      }
    }, xh = function(e, t) {
      t === !1 ? S("Expected `%s` listener to be a function, instead got `false`.\n\nIf you used to conditionally omit it with %s={condition && value}, pass %s={condition ? value : undefined} instead.", e, e, e) : S("Expected `%s` listener to be a function, instead got a value of `%s` type.", e, typeof t);
    }, cE = function(e, t) {
      var a = e.namespaceURI === Ii ? e.ownerDocument.createElement(e.tagName) : e.ownerDocument.createElementNS(e.namespaceURI, e.tagName);
      return a.innerHTML = t, a.innerHTML;
    };
    var BR = /\r\n?/g, VR = /\u0000|\uFFFD/g;
    function _h(e) {
      ia(e);
      var t = typeof e == "string" ? e : "" + e;
      return t.replace(BR, `
`).replace(VR, "");
    }
    function kh(e, t, a, i) {
      var o = _h(t), s = _h(e);
      if (s !== o && (i && (Va || (Va = !0, S('Text content did not match. Server: "%s" Client: "%s"', s, o))), a && I))
        throw new Error("Text content does not match server-rendered HTML.");
    }
    function fE(e) {
      return e.nodeType === fa ? e : e.ownerDocument;
    }
    function $R() {
    }
    function Dh(e) {
      e.onclick = $R;
    }
    function IR(e, t, a, i, o) {
      for (var s in i)
        if (i.hasOwnProperty(s)) {
          var f = i[s];
          if (s === tc)
            f && Object.freeze(f), Rv(t, f);
          else if (s === up) {
            var p = f ? f[Rh] : void 0;
            p != null && hv(t, p);
          } else if (s === ec)
            if (typeof f == "string") {
              var v = e !== "textarea" || f !== "";
              v && ds(t, f);
            } else typeof f == "number" && ds(t, "" + f);
          else s === Th || s === Uu || s === oE || (wt.hasOwnProperty(s) ? f != null && (typeof f != "function" && xh(s, f), s === "onScroll" && Cn("scroll", t)) : f != null && Ui(t, s, f, o));
        }
    }
    function YR(e, t, a, i) {
      for (var o = 0; o < t.length; o += 2) {
        var s = t[o], f = t[o + 1];
        s === tc ? Rv(e, f) : s === up ? hv(e, f) : s === ec ? ds(e, f) : Ui(e, s, f, i);
      }
    }
    function WR(e, t, a, i) {
      var o, s = fE(a), f, p = i;
      if (p === Ii && (p = qf(e)), p === Ii) {
        if (o = ho(e, t), !o && e !== e.toLowerCase() && S("<%s /> is using incorrect casing. Use PascalCase for React components, or lowercase for HTML elements.", e), e === "script") {
          var v = s.createElement("div");
          v.innerHTML = "<script><\/script>";
          var E = v.firstChild;
          f = v.removeChild(E);
        } else if (typeof t.is == "string")
          f = s.createElement(e, {
            is: t.is
          });
        else if (f = s.createElement(e), e === "select") {
          var C = f;
          t.multiple ? C.multiple = !0 : t.size && (C.size = t.size);
        }
      } else
        f = s.createElementNS(p, e);
      return p === Ii && !o && Object.prototype.toString.call(f) === "[object HTMLUnknownElement]" && !Jn.call(Gy, e) && (Gy[e] = !0, S("The tag <%s> is unrecognized in this browser. If you meant to render a React component, start its name with an uppercase letter.", e)), f;
    }
    function QR(e, t) {
      return fE(t).createTextNode(e);
    }
    function GR(e, t, a, i) {
      var o = ho(t, a);
      wh(t, a);
      var s;
      switch (t) {
        case "dialog":
          Cn("cancel", e), Cn("close", e), s = a;
          break;
        case "iframe":
        case "object":
        case "embed":
          Cn("load", e), s = a;
          break;
        case "video":
        case "audio":
          for (var f = 0; f < ip.length; f++)
            Cn(ip[f], e);
          s = a;
          break;
        case "source":
          Cn("error", e), s = a;
          break;
        case "img":
        case "image":
        case "link":
          Cn("error", e), Cn("load", e), s = a;
          break;
        case "details":
          Cn("toggle", e), s = a;
          break;
        case "input":
          w(e, a), s = h(e, a), Cn("invalid", e);
          break;
        case "option":
          qt(e, a), s = a;
          break;
        case "select":
          fs(e, a), s = cs(e, a), Cn("invalid", e);
          break;
        case "textarea":
          pv(e, a), s = Kf(e, a), Cn("invalid", e);
          break;
        default:
          s = a;
      }
      switch (hs(t, s), IR(t, e, i, s, o), t) {
        case "input":
          Bi(e), he(e, a, !1);
          break;
        case "textarea":
          Bi(e), Ec(e);
          break;
        case "option":
          Xt(e, a);
          break;
        case "select":
          Gf(e, a);
          break;
        default:
          typeof s.onClick == "function" && Dh(e);
          break;
      }
    }
    function KR(e, t, a, i, o) {
      wh(t, i);
      var s = null, f, p;
      switch (t) {
        case "input":
          f = h(e, a), p = h(e, i), s = [];
          break;
        case "select":
          f = cs(e, a), p = cs(e, i), s = [];
          break;
        case "textarea":
          f = Kf(e, a), p = Kf(e, i), s = [];
          break;
        default:
          f = a, p = i, typeof f.onClick != "function" && typeof p.onClick == "function" && Dh(e);
          break;
      }
      hs(t, p);
      var v, E, C = null;
      for (v in f)
        if (!(p.hasOwnProperty(v) || !f.hasOwnProperty(v) || f[v] == null))
          if (v === tc) {
            var M = f[v];
            for (E in M)
              M.hasOwnProperty(E) && (C || (C = {}), C[E] = "");
          } else v === up || v === ec || v === Th || v === Uu || v === oE || (wt.hasOwnProperty(v) ? s || (s = []) : (s = s || []).push(v, null));
      for (v in p) {
        var D = p[v], B = f != null ? f[v] : void 0;
        if (!(!p.hasOwnProperty(v) || D === B || D == null && B == null))
          if (v === tc)
            if (D && Object.freeze(D), B) {
              for (E in B)
                B.hasOwnProperty(E) && (!D || !D.hasOwnProperty(E)) && (C || (C = {}), C[E] = "");
              for (E in D)
                D.hasOwnProperty(E) && B[E] !== D[E] && (C || (C = {}), C[E] = D[E]);
            } else
              C || (s || (s = []), s.push(v, C)), C = D;
          else if (v === up) {
            var $ = D ? D[Rh] : void 0, G = B ? B[Rh] : void 0;
            $ != null && G !== $ && (s = s || []).push(v, $);
          } else v === ec ? (typeof D == "string" || typeof D == "number") && (s = s || []).push(v, "" + D) : v === Th || v === Uu || (wt.hasOwnProperty(v) ? (D != null && (typeof D != "function" && xh(v, D), v === "onScroll" && Cn("scroll", e)), !s && B !== D && (s = [])) : (s = s || []).push(v, D));
      }
      return C && (wv(C, p[tc]), (s = s || []).push(tc, C)), s;
    }
    function qR(e, t, a, i, o) {
      a === "input" && o.type === "radio" && o.name != null && H(e, o);
      var s = ho(a, i), f = ho(a, o);
      switch (YR(e, t, s, f), a) {
        case "input":
          Y(e, o);
          break;
        case "textarea":
          vv(e, o);
          break;
        case "select":
          ly(e, o);
          break;
      }
    }
    function XR(e) {
      {
        var t = e.toLowerCase();
        return Rc.hasOwnProperty(t) && Rc[t] || null;
      }
    }
    function JR(e, t, a, i, o, s, f) {
      var p, v;
      switch (p = ho(t, a), wh(t, a), t) {
        case "dialog":
          Cn("cancel", e), Cn("close", e);
          break;
        case "iframe":
        case "object":
        case "embed":
          Cn("load", e);
          break;
        case "video":
        case "audio":
          for (var E = 0; E < ip.length; E++)
            Cn(ip[E], e);
          break;
        case "source":
          Cn("error", e);
          break;
        case "img":
        case "image":
        case "link":
          Cn("error", e), Cn("load", e);
          break;
        case "details":
          Cn("toggle", e);
          break;
        case "input":
          w(e, a), Cn("invalid", e);
          break;
        case "option":
          qt(e, a);
          break;
        case "select":
          fs(e, a), Cn("invalid", e);
          break;
        case "textarea":
          pv(e, a), Cn("invalid", e);
          break;
      }
      hs(t, a);
      {
        v = /* @__PURE__ */ new Set();
        for (var C = e.attributes, M = 0; M < C.length; M++) {
          var D = C[M].name.toLowerCase();
          switch (D) {
            case "value":
              break;
            case "checked":
              break;
            case "selected":
              break;
            default:
              v.add(C[M].name);
          }
        }
      }
      var B = null;
      for (var $ in a)
        if (a.hasOwnProperty($)) {
          var G = a[$];
          if ($ === ec)
            typeof G == "string" ? e.textContent !== G && (a[Uu] !== !0 && kh(e.textContent, G, s, f), B = [ec, G]) : typeof G == "number" && e.textContent !== "" + G && (a[Uu] !== !0 && kh(e.textContent, G, s, f), B = [ec, "" + G]);
          else if (wt.hasOwnProperty($))
            G != null && (typeof G != "function" && xh($, G), $ === "onScroll" && Cn("scroll", e));
          else if (f && // Convince Flow we've calculated it (it's DEV-only in this method.)
          typeof p == "boolean") {
            var Re = void 0, et = p && We ? null : Wn($);
            if (a[Uu] !== !0) {
              if (!($ === Th || $ === Uu || // Controlled attributes are not validated
              // TODO: Only ignore them on controlled tags.
              $ === "value" || $ === "checked" || $ === "selected")) {
                if ($ === up) {
                  var Ie = e.innerHTML, Lt = G ? G[Rh] : void 0;
                  if (Lt != null) {
                    var _t = cE(e, Lt);
                    _t !== Ie && sp($, Ie, _t);
                  }
                } else if ($ === tc) {
                  if (v.delete($), sE) {
                    var F = my(G);
                    Re = e.getAttribute("style"), F !== Re && sp($, Re, F);
                  }
                } else if (p && !We)
                  v.delete($.toLowerCase()), Re = Da(e, $, G), G !== Re && sp($, Re, G);
                else if (!yn($, et, p) && !Gt($, G, et, p)) {
                  var K = !1;
                  if (et !== null)
                    v.delete(et.attributeName), Re = Xa(e, $, G, et);
                  else {
                    var j = i;
                    if (j === Ii && (j = qf(t)), j === Ii)
                      v.delete($.toLowerCase());
                    else {
                      var de = XR($);
                      de !== null && de !== $ && (K = !0, v.delete(de)), v.delete($);
                    }
                    Re = Da(e, $, G);
                  }
                  var Me = We;
                  !Me && G !== Re && !K && sp($, Re, G);
                }
              }
            }
          }
        }
      switch (f && // $FlowFixMe - Should be inferred as not undefined.
      v.size > 0 && a[Uu] !== !0 && uE(v), t) {
        case "input":
          Bi(e), he(e, a, !0);
          break;
        case "textarea":
          Bi(e), Ec(e);
          break;
        case "select":
        case "option":
          break;
        default:
          typeof a.onClick == "function" && Dh(e);
          break;
      }
      return B;
    }
    function ZR(e, t, a) {
      var i = e.nodeValue !== t;
      return i;
    }
    function Ky(e, t) {
      {
        if (Va)
          return;
        Va = !0, S("Did not expect server HTML to contain a <%s> in <%s>.", t.nodeName.toLowerCase(), e.nodeName.toLowerCase());
      }
    }
    function qy(e, t) {
      {
        if (Va)
          return;
        Va = !0, S('Did not expect server HTML to contain the text node "%s" in <%s>.', t.nodeValue, e.nodeName.toLowerCase());
      }
    }
    function Xy(e, t, a) {
      {
        if (Va)
          return;
        Va = !0, S("Expected server HTML to contain a matching <%s> in <%s>.", t, e.nodeName.toLowerCase());
      }
    }
    function Jy(e, t) {
      {
        if (t === "" || Va)
          return;
        Va = !0, S('Expected server HTML to contain a matching text node for "%s" in <%s>.', t, e.nodeName.toLowerCase());
      }
    }
    function e1(e, t, a) {
      switch (t) {
        case "input":
          je(e, a);
          return;
        case "textarea":
          oy(e, a);
          return;
        case "select":
          fv(e, a);
          return;
      }
    }
    var cp = function() {
    }, fp = function() {
    };
    {
      var t1 = ["address", "applet", "area", "article", "aside", "base", "basefont", "bgsound", "blockquote", "body", "br", "button", "caption", "center", "col", "colgroup", "dd", "details", "dir", "div", "dl", "dt", "embed", "fieldset", "figcaption", "figure", "footer", "form", "frame", "frameset", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "iframe", "img", "input", "isindex", "li", "link", "listing", "main", "marquee", "menu", "menuitem", "meta", "nav", "noembed", "noframes", "noscript", "object", "ol", "p", "param", "plaintext", "pre", "script", "section", "select", "source", "style", "summary", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "title", "tr", "track", "ul", "wbr", "xmp"], dE = [
        "applet",
        "caption",
        "html",
        "table",
        "td",
        "th",
        "marquee",
        "object",
        "template",
        // https://html.spec.whatwg.org/multipage/syntax.html#html-integration-point
        // TODO: Distinguish by namespace here -- for <title>, including it here
        // errs on the side of fewer warnings
        "foreignObject",
        "desc",
        "title"
      ], n1 = dE.concat(["button"]), r1 = ["dd", "dt", "li", "option", "optgroup", "p", "rp", "rt"], pE = {
        current: null,
        formTag: null,
        aTagInScope: null,
        buttonTagInScope: null,
        nobrTagInScope: null,
        pTagInButtonScope: null,
        listItemTagAutoclosing: null,
        dlItemTagAutoclosing: null
      };
      fp = function(e, t) {
        var a = yt({}, e || pE), i = {
          tag: t
        };
        return dE.indexOf(t) !== -1 && (a.aTagInScope = null, a.buttonTagInScope = null, a.nobrTagInScope = null), n1.indexOf(t) !== -1 && (a.pTagInButtonScope = null), t1.indexOf(t) !== -1 && t !== "address" && t !== "div" && t !== "p" && (a.listItemTagAutoclosing = null, a.dlItemTagAutoclosing = null), a.current = i, t === "form" && (a.formTag = i), t === "a" && (a.aTagInScope = i), t === "button" && (a.buttonTagInScope = i), t === "nobr" && (a.nobrTagInScope = i), t === "p" && (a.pTagInButtonScope = i), t === "li" && (a.listItemTagAutoclosing = i), (t === "dd" || t === "dt") && (a.dlItemTagAutoclosing = i), a;
      };
      var a1 = function(e, t) {
        switch (t) {
          case "select":
            return e === "option" || e === "optgroup" || e === "#text";
          case "optgroup":
            return e === "option" || e === "#text";
          case "option":
            return e === "#text";
          case "tr":
            return e === "th" || e === "td" || e === "style" || e === "script" || e === "template";
          case "tbody":
          case "thead":
          case "tfoot":
            return e === "tr" || e === "style" || e === "script" || e === "template";
          case "colgroup":
            return e === "col" || e === "template";
          case "table":
            return e === "caption" || e === "colgroup" || e === "tbody" || e === "tfoot" || e === "thead" || e === "style" || e === "script" || e === "template";
          case "head":
            return e === "base" || e === "basefont" || e === "bgsound" || e === "link" || e === "meta" || e === "title" || e === "noscript" || e === "noframes" || e === "style" || e === "script" || e === "template";
          case "html":
            return e === "head" || e === "body" || e === "frameset";
          case "frameset":
            return e === "frame";
          case "#document":
            return e === "html";
        }
        switch (e) {
          case "h1":
          case "h2":
          case "h3":
          case "h4":
          case "h5":
          case "h6":
            return t !== "h1" && t !== "h2" && t !== "h3" && t !== "h4" && t !== "h5" && t !== "h6";
          case "rp":
          case "rt":
            return r1.indexOf(t) === -1;
          case "body":
          case "caption":
          case "col":
          case "colgroup":
          case "frameset":
          case "frame":
          case "head":
          case "html":
          case "tbody":
          case "td":
          case "tfoot":
          case "th":
          case "thead":
          case "tr":
            return t == null;
        }
        return !0;
      }, i1 = function(e, t) {
        switch (e) {
          case "address":
          case "article":
          case "aside":
          case "blockquote":
          case "center":
          case "details":
          case "dialog":
          case "dir":
          case "div":
          case "dl":
          case "fieldset":
          case "figcaption":
          case "figure":
          case "footer":
          case "header":
          case "hgroup":
          case "main":
          case "menu":
          case "nav":
          case "ol":
          case "p":
          case "section":
          case "summary":
          case "ul":
          case "pre":
          case "listing":
          case "table":
          case "hr":
          case "xmp":
          case "h1":
          case "h2":
          case "h3":
          case "h4":
          case "h5":
          case "h6":
            return t.pTagInButtonScope;
          case "form":
            return t.formTag || t.pTagInButtonScope;
          case "li":
            return t.listItemTagAutoclosing;
          case "dd":
          case "dt":
            return t.dlItemTagAutoclosing;
          case "button":
            return t.buttonTagInScope;
          case "a":
            return t.aTagInScope;
          case "nobr":
            return t.nobrTagInScope;
        }
        return null;
      }, vE = {};
      cp = function(e, t, a) {
        a = a || pE;
        var i = a.current, o = i && i.tag;
        t != null && (e != null && S("validateDOMNesting: when childText is passed, childTag should be null"), e = "#text");
        var s = a1(e, o) ? null : i, f = s ? null : i1(e, a), p = s || f;
        if (p) {
          var v = p.tag, E = !!s + "|" + e + "|" + v;
          if (!vE[E]) {
            vE[E] = !0;
            var C = e, M = "";
            if (e === "#text" ? /\S/.test(t) ? C = "Text nodes" : (C = "Whitespace text nodes", M = " Make sure you don't have any extra whitespace between tags on each line of your source code.") : C = "<" + e + ">", s) {
              var D = "";
              v === "table" && e === "tr" && (D += " Add a <tbody>, <thead> or <tfoot> to your code to match the DOM tree generated by the browser."), S("validateDOMNesting(...): %s cannot appear as a child of <%s>.%s%s", C, v, M, D);
            } else
              S("validateDOMNesting(...): %s cannot appear as a descendant of <%s>.", C, v);
          }
        }
      };
    }
    var Oh = "suppressHydrationWarning", Mh = "$", Nh = "/$", dp = "$?", pp = "$!", l1 = "style", Zy = null, eg = null;
    function o1(e) {
      var t, a, i = e.nodeType;
      switch (i) {
        case fa:
        case Jf: {
          t = i === fa ? "#document" : "#fragment";
          var o = e.documentElement;
          a = o ? o.namespaceURI : Xf(null, "");
          break;
        }
        default: {
          var s = i === Tn ? e.parentNode : e, f = s.namespaceURI || null;
          t = s.tagName, a = Xf(f, t);
          break;
        }
      }
      {
        var p = t.toLowerCase(), v = fp(null, p);
        return {
          namespace: a,
          ancestorInfo: v
        };
      }
    }
    function u1(e, t, a) {
      {
        var i = e, o = Xf(i.namespace, t), s = fp(i.ancestorInfo, t);
        return {
          namespace: o,
          ancestorInfo: s
        };
      }
    }
    function HO(e) {
      return e;
    }
    function s1(e) {
      Zy = In(), eg = TR();
      var t = null;
      return ko(!1), t;
    }
    function c1(e) {
      RR(eg), ko(Zy), Zy = null, eg = null;
    }
    function f1(e, t, a, i, o) {
      var s;
      {
        var f = i;
        if (cp(e, null, f.ancestorInfo), typeof t.children == "string" || typeof t.children == "number") {
          var p = "" + t.children, v = fp(f.ancestorInfo, e);
          cp(null, p, v);
        }
        s = f.namespace;
      }
      var E = WR(e, t, a, s);
      return mp(o, E), ug(E, t), E;
    }
    function d1(e, t) {
      e.appendChild(t);
    }
    function p1(e, t, a, i, o) {
      switch (GR(e, t, a, i), t) {
        case "button":
        case "input":
        case "select":
        case "textarea":
          return !!a.autoFocus;
        case "img":
          return !0;
        default:
          return !1;
      }
    }
    function v1(e, t, a, i, o, s) {
      {
        var f = s;
        if (typeof i.children != typeof a.children && (typeof i.children == "string" || typeof i.children == "number")) {
          var p = "" + i.children, v = fp(f.ancestorInfo, t);
          cp(null, p, v);
        }
      }
      return KR(e, t, a, i);
    }
    function tg(e, t) {
      return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
    }
    function h1(e, t, a, i) {
      {
        var o = a;
        cp(null, e, o.ancestorInfo);
      }
      var s = QR(e, t);
      return mp(i, s), s;
    }
    function m1() {
      var e = window.event;
      return e === void 0 ? oi : Oo(e.type);
    }
    var ng = typeof setTimeout == "function" ? setTimeout : void 0, y1 = typeof clearTimeout == "function" ? clearTimeout : void 0, rg = -1, hE = typeof Promise == "function" ? Promise : void 0, g1 = typeof queueMicrotask == "function" ? queueMicrotask : typeof hE < "u" ? function(e) {
      return hE.resolve(null).then(e).catch(S1);
    } : ng;
    function S1(e) {
      setTimeout(function() {
        throw e;
      });
    }
    function E1(e, t, a, i) {
      switch (t) {
        case "button":
        case "input":
        case "select":
        case "textarea":
          a.autoFocus && e.focus();
          return;
        case "img": {
          a.src && (e.src = a.src);
          return;
        }
      }
    }
    function C1(e, t, a, i, o, s) {
      qR(e, t, a, i, o), ug(e, o);
    }
    function mE(e) {
      ds(e, "");
    }
    function b1(e, t, a) {
      e.nodeValue = a;
    }
    function T1(e, t) {
      e.appendChild(t);
    }
    function R1(e, t) {
      var a;
      e.nodeType === Tn ? (a = e.parentNode, a.insertBefore(t, e)) : (a = e, a.appendChild(t));
      var i = e._reactRootContainer;
      i == null && a.onclick === null && Dh(a);
    }
    function w1(e, t, a) {
      e.insertBefore(t, a);
    }
    function x1(e, t, a) {
      e.nodeType === Tn ? e.parentNode.insertBefore(t, a) : e.insertBefore(t, a);
    }
    function _1(e, t) {
      e.removeChild(t);
    }
    function k1(e, t) {
      e.nodeType === Tn ? e.parentNode.removeChild(t) : e.removeChild(t);
    }
    function ag(e, t) {
      var a = t, i = 0;
      do {
        var o = a.nextSibling;
        if (e.removeChild(a), o && o.nodeType === Tn) {
          var s = o.data;
          if (s === Nh)
            if (i === 0) {
              e.removeChild(o), mn(t);
              return;
            } else
              i--;
          else (s === Mh || s === dp || s === pp) && i++;
        }
        a = o;
      } while (a);
      mn(t);
    }
    function D1(e, t) {
      e.nodeType === Tn ? ag(e.parentNode, t) : e.nodeType === Yr && ag(e, t), mn(e);
    }
    function O1(e) {
      e = e;
      var t = e.style;
      typeof t.setProperty == "function" ? t.setProperty("display", "none", "important") : t.display = "none";
    }
    function M1(e) {
      e.nodeValue = "";
    }
    function N1(e, t) {
      e = e;
      var a = t[l1], i = a != null && a.hasOwnProperty("display") ? a.display : null;
      e.style.display = _l("display", i);
    }
    function L1(e, t) {
      e.nodeValue = t;
    }
    function A1(e) {
      e.nodeType === Yr ? e.textContent = "" : e.nodeType === fa && e.documentElement && e.removeChild(e.documentElement);
    }
    function U1(e, t, a) {
      return e.nodeType !== Yr || t.toLowerCase() !== e.nodeName.toLowerCase() ? null : e;
    }
    function z1(e, t) {
      return t === "" || e.nodeType !== Yi ? null : e;
    }
    function F1(e) {
      return e.nodeType !== Tn ? null : e;
    }
    function yE(e) {
      return e.data === dp;
    }
    function ig(e) {
      return e.data === pp;
    }
    function j1(e) {
      var t = e.nextSibling && e.nextSibling.dataset, a, i, o;
      return t && (a = t.dgst, i = t.msg, o = t.stck), {
        message: i,
        digest: a,
        stack: o
      };
    }
    function P1(e, t) {
      e._reactRetry = t;
    }
    function Lh(e) {
      for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === Yr || t === Yi)
          break;
        if (t === Tn) {
          var a = e.data;
          if (a === Mh || a === pp || a === dp)
            break;
          if (a === Nh)
            return null;
        }
      }
      return e;
    }
    function vp(e) {
      return Lh(e.nextSibling);
    }
    function H1(e) {
      return Lh(e.firstChild);
    }
    function B1(e) {
      return Lh(e.firstChild);
    }
    function V1(e) {
      return Lh(e.nextSibling);
    }
    function $1(e, t, a, i, o, s, f) {
      mp(s, e), ug(e, a);
      var p;
      {
        var v = o;
        p = v.namespace;
      }
      var E = (s.mode & qe) !== Ce;
      return JR(e, t, a, p, i, E, f);
    }
    function I1(e, t, a, i) {
      return mp(a, e), a.mode & qe, ZR(e, t);
    }
    function Y1(e, t) {
      mp(t, e);
    }
    function W1(e) {
      for (var t = e.nextSibling, a = 0; t; ) {
        if (t.nodeType === Tn) {
          var i = t.data;
          if (i === Nh) {
            if (a === 0)
              return vp(t);
            a--;
          } else (i === Mh || i === pp || i === dp) && a++;
        }
        t = t.nextSibling;
      }
      return null;
    }
    function gE(e) {
      for (var t = e.previousSibling, a = 0; t; ) {
        if (t.nodeType === Tn) {
          var i = t.data;
          if (i === Mh || i === pp || i === dp) {
            if (a === 0)
              return t;
            a--;
          } else i === Nh && a++;
        }
        t = t.previousSibling;
      }
      return null;
    }
    function Q1(e) {
      mn(e);
    }
    function G1(e) {
      mn(e);
    }
    function K1(e) {
      return e !== "head" && e !== "body";
    }
    function q1(e, t, a, i) {
      var o = !0;
      kh(t.nodeValue, a, i, o);
    }
    function X1(e, t, a, i, o, s) {
      if (t[Oh] !== !0) {
        var f = !0;
        kh(i.nodeValue, o, s, f);
      }
    }
    function J1(e, t) {
      t.nodeType === Yr ? Ky(e, t) : t.nodeType === Tn || qy(e, t);
    }
    function Z1(e, t) {
      {
        var a = e.parentNode;
        a !== null && (t.nodeType === Yr ? Ky(a, t) : t.nodeType === Tn || qy(a, t));
      }
    }
    function ew(e, t, a, i, o) {
      (o || t[Oh] !== !0) && (i.nodeType === Yr ? Ky(a, i) : i.nodeType === Tn || qy(a, i));
    }
    function tw(e, t, a) {
      Xy(e, t);
    }
    function nw(e, t) {
      Jy(e, t);
    }
    function rw(e, t, a) {
      {
        var i = e.parentNode;
        i !== null && Xy(i, t);
      }
    }
    function aw(e, t) {
      {
        var a = e.parentNode;
        a !== null && Jy(a, t);
      }
    }
    function iw(e, t, a, i, o, s) {
      (s || t[Oh] !== !0) && Xy(a, i);
    }
    function lw(e, t, a, i, o) {
      (o || t[Oh] !== !0) && Jy(a, i);
    }
    function ow(e) {
      S("An error occurred during hydration. The server HTML was replaced with client content in <%s>.", e.nodeName.toLowerCase());
    }
    function uw(e) {
      lp(e);
    }
    var yf = Math.random().toString(36).slice(2), gf = "__reactFiber$" + yf, lg = "__reactProps$" + yf, hp = "__reactContainer$" + yf, og = "__reactEvents$" + yf, sw = "__reactListeners$" + yf, cw = "__reactHandles$" + yf;
    function fw(e) {
      delete e[gf], delete e[lg], delete e[og], delete e[sw], delete e[cw];
    }
    function mp(e, t) {
      t[gf] = e;
    }
    function Ah(e, t) {
      t[hp] = e;
    }
    function SE(e) {
      e[hp] = null;
    }
    function yp(e) {
      return !!e[hp];
    }
    function nc(e) {
      var t = e[gf];
      if (t)
        return t;
      for (var a = e.parentNode; a; ) {
        if (t = a[hp] || a[gf], t) {
          var i = t.alternate;
          if (t.child !== null || i !== null && i.child !== null)
            for (var o = gE(e); o !== null; ) {
              var s = o[gf];
              if (s)
                return s;
              o = gE(o);
            }
          return t;
        }
        e = a, a = e.parentNode;
      }
      return null;
    }
    function zu(e) {
      var t = e[gf] || e[hp];
      return t && (t.tag === q || t.tag === ve || t.tag === Ne || t.tag === A) ? t : null;
    }
    function Sf(e) {
      if (e.tag === q || e.tag === ve)
        return e.stateNode;
      throw new Error("getNodeFromInstance: Invalid argument.");
    }
    function Uh(e) {
      return e[lg] || null;
    }
    function ug(e, t) {
      e[lg] = t;
    }
    function dw(e) {
      var t = e[og];
      return t === void 0 && (t = e[og] = /* @__PURE__ */ new Set()), t;
    }
    var EE = {}, CE = T.ReactDebugCurrentFrame;
    function zh(e) {
      if (e) {
        var t = e._owner, a = kt(e.type, e._source, t ? t.type : null);
        CE.setExtraStackFrame(a);
      } else
        CE.setExtraStackFrame(null);
    }
    function ll(e, t, a, i, o) {
      {
        var s = Function.call.bind(Jn);
        for (var f in e)
          if (s(e, f)) {
            var p = void 0;
            try {
              if (typeof e[f] != "function") {
                var v = Error((i || "React class") + ": " + a + " type `" + f + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof e[f] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw v.name = "Invariant Violation", v;
              }
              p = e[f](t, f, i, a, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (E) {
              p = E;
            }
            p && !(p instanceof Error) && (zh(o), S("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", i || "React class", a, f, typeof p), zh(null)), p instanceof Error && !(p.message in EE) && (EE[p.message] = !0, zh(o), S("Failed %s type: %s", a, p.message), zh(null));
          }
      }
    }
    var sg = [], Fh;
    Fh = [];
    var jo = -1;
    function Fu(e) {
      return {
        current: e
      };
    }
    function Zr(e, t) {
      if (jo < 0) {
        S("Unexpected pop.");
        return;
      }
      t !== Fh[jo] && S("Unexpected Fiber popped."), e.current = sg[jo], sg[jo] = null, Fh[jo] = null, jo--;
    }
    function ea(e, t, a) {
      jo++, sg[jo] = e.current, Fh[jo] = a, e.current = t;
    }
    var cg;
    cg = {};
    var si = {};
    Object.freeze(si);
    var Po = Fu(si), Gl = Fu(!1), fg = si;
    function Ef(e, t, a) {
      return a && Kl(t) ? fg : Po.current;
    }
    function bE(e, t, a) {
      {
        var i = e.stateNode;
        i.__reactInternalMemoizedUnmaskedChildContext = t, i.__reactInternalMemoizedMaskedChildContext = a;
      }
    }
    function Cf(e, t) {
      {
        var a = e.type, i = a.contextTypes;
        if (!i)
          return si;
        var o = e.stateNode;
        if (o && o.__reactInternalMemoizedUnmaskedChildContext === t)
          return o.__reactInternalMemoizedMaskedChildContext;
        var s = {};
        for (var f in i)
          s[f] = t[f];
        {
          var p = dt(e) || "Unknown";
          ll(i, s, "context", p);
        }
        return o && bE(e, t, s), s;
      }
    }
    function jh() {
      return Gl.current;
    }
    function Kl(e) {
      {
        var t = e.childContextTypes;
        return t != null;
      }
    }
    function Ph(e) {
      Zr(Gl, e), Zr(Po, e);
    }
    function dg(e) {
      Zr(Gl, e), Zr(Po, e);
    }
    function TE(e, t, a) {
      {
        if (Po.current !== si)
          throw new Error("Unexpected context found on stack. This error is likely caused by a bug in React. Please file an issue.");
        ea(Po, t, e), ea(Gl, a, e);
      }
    }
    function RE(e, t, a) {
      {
        var i = e.stateNode, o = t.childContextTypes;
        if (typeof i.getChildContext != "function") {
          {
            var s = dt(e) || "Unknown";
            cg[s] || (cg[s] = !0, S("%s.childContextTypes is specified but there is no getChildContext() method on the instance. You can either define getChildContext() on %s or remove childContextTypes from it.", s, s));
          }
          return a;
        }
        var f = i.getChildContext();
        for (var p in f)
          if (!(p in o))
            throw new Error((dt(e) || "Unknown") + '.getChildContext(): key "' + p + '" is not defined in childContextTypes.');
        {
          var v = dt(e) || "Unknown";
          ll(o, f, "child context", v);
        }
        return yt({}, a, f);
      }
    }
    function Hh(e) {
      {
        var t = e.stateNode, a = t && t.__reactInternalMemoizedMergedChildContext || si;
        return fg = Po.current, ea(Po, a, e), ea(Gl, Gl.current, e), !0;
      }
    }
    function wE(e, t, a) {
      {
        var i = e.stateNode;
        if (!i)
          throw new Error("Expected to have an instance by this point. This error is likely caused by a bug in React. Please file an issue.");
        if (a) {
          var o = RE(e, t, fg);
          i.__reactInternalMemoizedMergedChildContext = o, Zr(Gl, e), Zr(Po, e), ea(Po, o, e), ea(Gl, a, e);
        } else
          Zr(Gl, e), ea(Gl, a, e);
      }
    }
    function pw(e) {
      {
        if (!va(e) || e.tag !== Q)
          throw new Error("Expected subtree parent to be a mounted class component. This error is likely caused by a bug in React. Please file an issue.");
        var t = e;
        do {
          switch (t.tag) {
            case A:
              return t.stateNode.context;
            case Q: {
              var a = t.type;
              if (Kl(a))
                return t.stateNode.__reactInternalMemoizedMergedChildContext;
              break;
            }
          }
          t = t.return;
        } while (t !== null);
        throw new Error("Found unexpected detached subtree parent. This error is likely caused by a bug in React. Please file an issue.");
      }
    }
    var ju = 0, Bh = 1, Ho = null, pg = !1, vg = !1;
    function xE(e) {
      Ho === null ? Ho = [e] : Ho.push(e);
    }
    function vw(e) {
      pg = !0, xE(e);
    }
    function _E() {
      pg && Pu();
    }
    function Pu() {
      if (!vg && Ho !== null) {
        vg = !0;
        var e = 0, t = xr();
        try {
          var a = !0, i = Ho;
          for (Ut(Ea); e < i.length; e++) {
            var o = i[e];
            do
              o = o(a);
            while (o !== null);
          }
          Ho = null, pg = !1;
        } catch (s) {
          throw Ho !== null && (Ho = Ho.slice(e + 1)), gd(Al, Pu), s;
        } finally {
          Ut(t), vg = !1;
        }
      }
      return null;
    }
    var bf = [], Tf = 0, Vh = null, $h = 0, _i = [], ki = 0, rc = null, Bo = 1, Vo = "";
    function hw(e) {
      return ic(), (e.flags & Bv) !== Ze;
    }
    function mw(e) {
      return ic(), $h;
    }
    function yw() {
      var e = Vo, t = Bo, a = t & ~gw(t);
      return a.toString(32) + e;
    }
    function ac(e, t) {
      ic(), bf[Tf++] = $h, bf[Tf++] = Vh, Vh = e, $h = t;
    }
    function kE(e, t, a) {
      ic(), _i[ki++] = Bo, _i[ki++] = Vo, _i[ki++] = rc, rc = e;
      var i = Bo, o = Vo, s = Ih(i) - 1, f = i & ~(1 << s), p = a + 1, v = Ih(t) + s;
      if (v > 30) {
        var E = s - s % 5, C = (1 << E) - 1, M = (f & C).toString(32), D = f >> E, B = s - E, $ = Ih(t) + B, G = p << B, Re = G | D, et = M + o;
        Bo = 1 << $ | Re, Vo = et;
      } else {
        var Ie = p << s, Lt = Ie | f, _t = o;
        Bo = 1 << v | Lt, Vo = _t;
      }
    }
    function hg(e) {
      ic();
      var t = e.return;
      if (t !== null) {
        var a = 1, i = 0;
        ac(e, a), kE(e, a, i);
      }
    }
    function Ih(e) {
      return 32 - hu(e);
    }
    function gw(e) {
      return 1 << Ih(e) - 1;
    }
    function mg(e) {
      for (; e === Vh; )
        Vh = bf[--Tf], bf[Tf] = null, $h = bf[--Tf], bf[Tf] = null;
      for (; e === rc; )
        rc = _i[--ki], _i[ki] = null, Vo = _i[--ki], _i[ki] = null, Bo = _i[--ki], _i[ki] = null;
    }
    function Sw() {
      return ic(), rc !== null ? {
        id: Bo,
        overflow: Vo
      } : null;
    }
    function Ew(e, t) {
      ic(), _i[ki++] = Bo, _i[ki++] = Vo, _i[ki++] = rc, Bo = t.id, Vo = t.overflow, rc = e;
    }
    function ic() {
      Mr() || S("Expected to be hydrating. This is a bug in React. Please file an issue.");
    }
    var Or = null, Di = null, ol = !1, lc = !1, Hu = null;
    function Cw() {
      ol && S("We should not be hydrating here. This is a bug in React. Please file a bug.");
    }
    function DE() {
      lc = !0;
    }
    function bw() {
      return lc;
    }
    function Tw(e) {
      var t = e.stateNode.containerInfo;
      return Di = B1(t), Or = e, ol = !0, Hu = null, lc = !1, !0;
    }
    function Rw(e, t, a) {
      return Di = V1(t), Or = e, ol = !0, Hu = null, lc = !1, a !== null && Ew(e, a), !0;
    }
    function OE(e, t) {
      switch (e.tag) {
        case A: {
          J1(e.stateNode.containerInfo, t);
          break;
        }
        case q: {
          var a = (e.mode & qe) !== Ce;
          ew(
            e.type,
            e.memoizedProps,
            e.stateNode,
            t,
            // TODO: Delete this argument when we remove the legacy root API.
            a
          );
          break;
        }
        case Ne: {
          var i = e.memoizedState;
          i.dehydrated !== null && Z1(i.dehydrated, t);
          break;
        }
      }
    }
    function ME(e, t) {
      OE(e, t);
      var a = kk();
      a.stateNode = t, a.return = e;
      var i = e.deletions;
      i === null ? (e.deletions = [a], e.flags |= Ht) : i.push(a);
    }
    function yg(e, t) {
      {
        if (lc)
          return;
        switch (e.tag) {
          case A: {
            var a = e.stateNode.containerInfo;
            switch (t.tag) {
              case q:
                var i = t.type;
                t.pendingProps, tw(a, i);
                break;
              case ve:
                var o = t.pendingProps;
                nw(a, o);
                break;
            }
            break;
          }
          case q: {
            var s = e.type, f = e.memoizedProps, p = e.stateNode;
            switch (t.tag) {
              case q: {
                var v = t.type, E = t.pendingProps, C = (e.mode & qe) !== Ce;
                iw(
                  s,
                  f,
                  p,
                  v,
                  E,
                  // TODO: Delete this argument when we remove the legacy root API.
                  C
                );
                break;
              }
              case ve: {
                var M = t.pendingProps, D = (e.mode & qe) !== Ce;
                lw(
                  s,
                  f,
                  p,
                  M,
                  // TODO: Delete this argument when we remove the legacy root API.
                  D
                );
                break;
              }
            }
            break;
          }
          case Ne: {
            var B = e.memoizedState, $ = B.dehydrated;
            if ($ !== null) switch (t.tag) {
              case q:
                var G = t.type;
                t.pendingProps, rw($, G);
                break;
              case ve:
                var Re = t.pendingProps;
                aw($, Re);
                break;
            }
            break;
          }
          default:
            return;
        }
      }
    }
    function NE(e, t) {
      t.flags = t.flags & ~yi | rn, yg(e, t);
    }
    function LE(e, t) {
      switch (e.tag) {
        case q: {
          var a = e.type;
          e.pendingProps;
          var i = U1(t, a);
          return i !== null ? (e.stateNode = i, Or = e, Di = H1(i), !0) : !1;
        }
        case ve: {
          var o = e.pendingProps, s = z1(t, o);
          return s !== null ? (e.stateNode = s, Or = e, Di = null, !0) : !1;
        }
        case Ne: {
          var f = F1(t);
          if (f !== null) {
            var p = {
              dehydrated: f,
              treeContext: Sw(),
              retryLane: Sa
            };
            e.memoizedState = p;
            var v = Dk(f);
            return v.return = e, e.child = v, Or = e, Di = null, !0;
          }
          return !1;
        }
        default:
          return !1;
      }
    }
    function gg(e) {
      return (e.mode & qe) !== Ce && (e.flags & vt) === Ze;
    }
    function Sg(e) {
      throw new Error("Hydration failed because the initial UI does not match what was rendered on the server.");
    }
    function Eg(e) {
      if (ol) {
        var t = Di;
        if (!t) {
          gg(e) && (yg(Or, e), Sg()), NE(Or, e), ol = !1, Or = e;
          return;
        }
        var a = t;
        if (!LE(e, t)) {
          gg(e) && (yg(Or, e), Sg()), t = vp(a);
          var i = Or;
          if (!t || !LE(e, t)) {
            NE(Or, e), ol = !1, Or = e;
            return;
          }
          ME(i, a);
        }
      }
    }
    function ww(e, t, a) {
      var i = e.stateNode, o = !lc, s = $1(i, e.type, e.memoizedProps, t, a, e, o);
      return e.updateQueue = s, s !== null;
    }
    function xw(e) {
      var t = e.stateNode, a = e.memoizedProps, i = I1(t, a, e);
      if (i) {
        var o = Or;
        if (o !== null)
          switch (o.tag) {
            case A: {
              var s = o.stateNode.containerInfo, f = (o.mode & qe) !== Ce;
              q1(
                s,
                t,
                a,
                // TODO: Delete this argument when we remove the legacy root API.
                f
              );
              break;
            }
            case q: {
              var p = o.type, v = o.memoizedProps, E = o.stateNode, C = (o.mode & qe) !== Ce;
              X1(
                p,
                v,
                E,
                t,
                a,
                // TODO: Delete this argument when we remove the legacy root API.
                C
              );
              break;
            }
          }
      }
      return i;
    }
    function _w(e) {
      var t = e.memoizedState, a = t !== null ? t.dehydrated : null;
      if (!a)
        throw new Error("Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.");
      Y1(a, e);
    }
    function kw(e) {
      var t = e.memoizedState, a = t !== null ? t.dehydrated : null;
      if (!a)
        throw new Error("Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.");
      return W1(a);
    }
    function AE(e) {
      for (var t = e.return; t !== null && t.tag !== q && t.tag !== A && t.tag !== Ne; )
        t = t.return;
      Or = t;
    }
    function Yh(e) {
      if (e !== Or)
        return !1;
      if (!ol)
        return AE(e), ol = !0, !1;
      if (e.tag !== A && (e.tag !== q || K1(e.type) && !tg(e.type, e.memoizedProps))) {
        var t = Di;
        if (t)
          if (gg(e))
            UE(e), Sg();
          else
            for (; t; )
              ME(e, t), t = vp(t);
      }
      return AE(e), e.tag === Ne ? Di = kw(e) : Di = Or ? vp(e.stateNode) : null, !0;
    }
    function Dw() {
      return ol && Di !== null;
    }
    function UE(e) {
      for (var t = Di; t; )
        OE(e, t), t = vp(t);
    }
    function Rf() {
      Or = null, Di = null, ol = !1, lc = !1;
    }
    function zE() {
      Hu !== null && (Db(Hu), Hu = null);
    }
    function Mr() {
      return ol;
    }
    function Cg(e) {
      Hu === null ? Hu = [e] : Hu.push(e);
    }
    var Ow = T.ReactCurrentBatchConfig, Mw = null;
    function Nw() {
      return Ow.transition;
    }
    var ul = {
      recordUnsafeLifecycleWarnings: function(e, t) {
      },
      flushPendingUnsafeLifecycleWarnings: function() {
      },
      recordLegacyContextWarning: function(e, t) {
      },
      flushLegacyContextWarning: function() {
      },
      discardPendingWarnings: function() {
      }
    };
    {
      var Lw = function(e) {
        for (var t = null, a = e; a !== null; )
          a.mode & dn && (t = a), a = a.return;
        return t;
      }, oc = function(e) {
        var t = [];
        return e.forEach(function(a) {
          t.push(a);
        }), t.sort().join(", ");
      }, gp = [], Sp = [], Ep = [], Cp = [], bp = [], Tp = [], uc = /* @__PURE__ */ new Set();
      ul.recordUnsafeLifecycleWarnings = function(e, t) {
        uc.has(e.type) || (typeof t.componentWillMount == "function" && // Don't warn about react-lifecycles-compat polyfilled components.
        t.componentWillMount.__suppressDeprecationWarning !== !0 && gp.push(e), e.mode & dn && typeof t.UNSAFE_componentWillMount == "function" && Sp.push(e), typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps.__suppressDeprecationWarning !== !0 && Ep.push(e), e.mode & dn && typeof t.UNSAFE_componentWillReceiveProps == "function" && Cp.push(e), typeof t.componentWillUpdate == "function" && t.componentWillUpdate.__suppressDeprecationWarning !== !0 && bp.push(e), e.mode & dn && typeof t.UNSAFE_componentWillUpdate == "function" && Tp.push(e));
      }, ul.flushPendingUnsafeLifecycleWarnings = function() {
        var e = /* @__PURE__ */ new Set();
        gp.length > 0 && (gp.forEach(function(D) {
          e.add(dt(D) || "Component"), uc.add(D.type);
        }), gp = []);
        var t = /* @__PURE__ */ new Set();
        Sp.length > 0 && (Sp.forEach(function(D) {
          t.add(dt(D) || "Component"), uc.add(D.type);
        }), Sp = []);
        var a = /* @__PURE__ */ new Set();
        Ep.length > 0 && (Ep.forEach(function(D) {
          a.add(dt(D) || "Component"), uc.add(D.type);
        }), Ep = []);
        var i = /* @__PURE__ */ new Set();
        Cp.length > 0 && (Cp.forEach(function(D) {
          i.add(dt(D) || "Component"), uc.add(D.type);
        }), Cp = []);
        var o = /* @__PURE__ */ new Set();
        bp.length > 0 && (bp.forEach(function(D) {
          o.add(dt(D) || "Component"), uc.add(D.type);
        }), bp = []);
        var s = /* @__PURE__ */ new Set();
        if (Tp.length > 0 && (Tp.forEach(function(D) {
          s.add(dt(D) || "Component"), uc.add(D.type);
        }), Tp = []), t.size > 0) {
          var f = oc(t);
          S(`Using UNSAFE_componentWillMount in strict mode is not recommended and may indicate bugs in your code. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move code with side effects to componentDidMount, and set initial state in the constructor.

Please update the following components: %s`, f);
        }
        if (i.size > 0) {
          var p = oc(i);
          S(`Using UNSAFE_componentWillReceiveProps in strict mode is not recommended and may indicate bugs in your code. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* If you're updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://reactjs.org/link/derived-state

Please update the following components: %s`, p);
        }
        if (s.size > 0) {
          var v = oc(s);
          S(`Using UNSAFE_componentWillUpdate in strict mode is not recommended and may indicate bugs in your code. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.

Please update the following components: %s`, v);
        }
        if (e.size > 0) {
          var E = oc(e);
          x(`componentWillMount has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move code with side effects to componentDidMount, and set initial state in the constructor.
* Rename componentWillMount to UNSAFE_componentWillMount to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`, E);
        }
        if (a.size > 0) {
          var C = oc(a);
          x(`componentWillReceiveProps has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* If you're updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://reactjs.org/link/derived-state
* Rename componentWillReceiveProps to UNSAFE_componentWillReceiveProps to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`, C);
        }
        if (o.size > 0) {
          var M = oc(o);
          x(`componentWillUpdate has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* Rename componentWillUpdate to UNSAFE_componentWillUpdate to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`, M);
        }
      };
      var Wh = /* @__PURE__ */ new Map(), FE = /* @__PURE__ */ new Set();
      ul.recordLegacyContextWarning = function(e, t) {
        var a = Lw(e);
        if (a === null) {
          S("Expected to find a StrictMode component in a strict mode tree. This error is likely caused by a bug in React. Please file an issue.");
          return;
        }
        if (!FE.has(e.type)) {
          var i = Wh.get(a);
          (e.type.contextTypes != null || e.type.childContextTypes != null || t !== null && typeof t.getChildContext == "function") && (i === void 0 && (i = [], Wh.set(a, i)), i.push(e));
        }
      }, ul.flushLegacyContextWarning = function() {
        Wh.forEach(function(e, t) {
          if (e.length !== 0) {
            var a = e[0], i = /* @__PURE__ */ new Set();
            e.forEach(function(s) {
              i.add(dt(s) || "Component"), FE.add(s.type);
            });
            var o = oc(i);
            try {
              Sn(a), S(`Legacy context API has been detected within a strict-mode tree.

The old API will be supported in all 16.x releases, but applications using it should migrate to the new version.

Please update the following components: %s

Learn more about this warning here: https://reactjs.org/link/legacy-context`, o);
            } finally {
              sn();
            }
          }
        });
      }, ul.discardPendingWarnings = function() {
        gp = [], Sp = [], Ep = [], Cp = [], bp = [], Tp = [], Wh = /* @__PURE__ */ new Map();
      };
    }
    var bg, Tg, Rg, wg, xg, jE = function(e, t) {
    };
    bg = !1, Tg = !1, Rg = {}, wg = {}, xg = {}, jE = function(e, t) {
      if (!(e === null || typeof e != "object") && !(!e._store || e._store.validated || e.key != null)) {
        if (typeof e._store != "object")
          throw new Error("React Component in warnForMissingKey should have a _store. This error is likely caused by a bug in React. Please file an issue.");
        e._store.validated = !0;
        var a = dt(t) || "Component";
        wg[a] || (wg[a] = !0, S('Each child in a list should have a unique "key" prop. See https://reactjs.org/link/warning-keys for more information.'));
      }
    };
    function Aw(e) {
      return e.prototype && e.prototype.isReactComponent;
    }
    function Rp(e, t, a) {
      var i = a.ref;
      if (i !== null && typeof i != "function" && typeof i != "object") {
        if ((e.mode & dn || st) && // We warn in ReactElement.js if owner and self are equal for string refs
        // because these cannot be automatically converted to an arrow function
        // using a codemod. Therefore, we don't have to warn about string refs again.
        !(a._owner && a._self && a._owner.stateNode !== a._self) && // Will already throw with "Function components cannot have string refs"
        !(a._owner && a._owner.tag !== Q) && // Will already warn with "Function components cannot be given refs"
        !(typeof a.type == "function" && !Aw(a.type)) && // Will already throw with "Element ref was specified as a string (someStringRef) but no owner was set"
        a._owner) {
          var o = dt(e) || "Component";
          Rg[o] || (S('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. We recommend using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', o, i), Rg[o] = !0);
        }
        if (a._owner) {
          var s = a._owner, f;
          if (s) {
            var p = s;
            if (p.tag !== Q)
              throw new Error("Function components cannot have string refs. We recommend using useRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref");
            f = p.stateNode;
          }
          if (!f)
            throw new Error("Missing owner for string ref " + i + ". This error is likely caused by a bug in React. Please file an issue.");
          var v = f;
          Vn(i, "ref");
          var E = "" + i;
          if (t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === E)
            return t.ref;
          var C = function(M) {
            var D = v.refs;
            M === null ? delete D[E] : D[E] = M;
          };
          return C._stringRef = E, C;
        } else {
          if (typeof i != "string")
            throw new Error("Expected ref to be a function, a string, an object returned by React.createRef(), or null.");
          if (!a._owner)
            throw new Error("Element ref was specified as a string (" + i + `) but no owner was set. This could happen for one of the following reasons:
1. You may be adding a ref to a function component
2. You may be adding a ref to a component that was not created inside a component's render method
3. You have multiple copies of React loaded
See https://reactjs.org/link/refs-must-have-owner for more information.`);
        }
      }
      return i;
    }
    function Qh(e, t) {
      var a = Object.prototype.toString.call(t);
      throw new Error("Objects are not valid as a React child (found: " + (a === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : a) + "). If you meant to render a collection of children, use an array instead.");
    }
    function Gh(e) {
      {
        var t = dt(e) || "Component";
        if (xg[t])
          return;
        xg[t] = !0, S("Functions are not valid as a React child. This may happen if you return a Component instead of <Component /> from render. Or maybe you meant to call this function rather than return it.");
      }
    }
    function PE(e) {
      var t = e._payload, a = e._init;
      return a(t);
    }
    function HE(e) {
      function t(F, K) {
        if (e) {
          var j = F.deletions;
          j === null ? (F.deletions = [K], F.flags |= Ht) : j.push(K);
        }
      }
      function a(F, K) {
        if (!e)
          return null;
        for (var j = K; j !== null; )
          t(F, j), j = j.sibling;
        return null;
      }
      function i(F, K) {
        for (var j = /* @__PURE__ */ new Map(), de = K; de !== null; )
          de.key !== null ? j.set(de.key, de) : j.set(de.index, de), de = de.sibling;
        return j;
      }
      function o(F, K) {
        var j = yc(F, K);
        return j.index = 0, j.sibling = null, j;
      }
      function s(F, K, j) {
        if (F.index = j, !e)
          return F.flags |= Bv, K;
        var de = F.alternate;
        if (de !== null) {
          var Me = de.index;
          return Me < K ? (F.flags |= rn, K) : Me;
        } else
          return F.flags |= rn, K;
      }
      function f(F) {
        return e && F.alternate === null && (F.flags |= rn), F;
      }
      function p(F, K, j, de) {
        if (K === null || K.tag !== ve) {
          var Me = C0(j, F.mode, de);
          return Me.return = F, Me;
        } else {
          var xe = o(K, j);
          return xe.return = F, xe;
        }
      }
      function v(F, K, j, de) {
        var Me = j.type;
        if (Me === ca)
          return C(F, K, j.props.children, de, j.key);
        if (K !== null && (K.elementType === Me || // Keep this check inline so it only runs on the false path:
        Yb(K, j) || // Lazy types should reconcile their resolved type.
        // We need to do this after the Hot Reloading check above,
        // because hot reloading has different semantics than prod because
        // it doesn't resuspend. So we can't let the call below suspend.
        typeof Me == "object" && Me !== null && Me.$$typeof === tt && PE(Me) === K.type)) {
          var xe = o(K, j.props);
          return xe.ref = Rp(F, K, j), xe.return = F, xe._debugSource = j._source, xe._debugOwner = j._owner, xe;
        }
        var ct = E0(j, F.mode, de);
        return ct.ref = Rp(F, K, j), ct.return = F, ct;
      }
      function E(F, K, j, de) {
        if (K === null || K.tag !== oe || K.stateNode.containerInfo !== j.containerInfo || K.stateNode.implementation !== j.implementation) {
          var Me = b0(j, F.mode, de);
          return Me.return = F, Me;
        } else {
          var xe = o(K, j.children || []);
          return xe.return = F, xe;
        }
      }
      function C(F, K, j, de, Me) {
        if (K === null || K.tag !== Ae) {
          var xe = Xu(j, F.mode, de, Me);
          return xe.return = F, xe;
        } else {
          var ct = o(K, j);
          return ct.return = F, ct;
        }
      }
      function M(F, K, j) {
        if (typeof K == "string" && K !== "" || typeof K == "number") {
          var de = C0("" + K, F.mode, j);
          return de.return = F, de;
        }
        if (typeof K == "object" && K !== null) {
          switch (K.$$typeof) {
            case Cr: {
              var Me = E0(K, F.mode, j);
              return Me.ref = Rp(F, null, K), Me.return = F, Me;
            }
            case Hr: {
              var xe = b0(K, F.mode, j);
              return xe.return = F, xe;
            }
            case tt: {
              var ct = K._payload, mt = K._init;
              return M(F, mt(ct), j);
            }
          }
          if (At(K) || Br(K)) {
            var en = Xu(K, F.mode, j, null);
            return en.return = F, en;
          }
          Qh(F, K);
        }
        return typeof K == "function" && Gh(F), null;
      }
      function D(F, K, j, de) {
        var Me = K !== null ? K.key : null;
        if (typeof j == "string" && j !== "" || typeof j == "number")
          return Me !== null ? null : p(F, K, "" + j, de);
        if (typeof j == "object" && j !== null) {
          switch (j.$$typeof) {
            case Cr:
              return j.key === Me ? v(F, K, j, de) : null;
            case Hr:
              return j.key === Me ? E(F, K, j, de) : null;
            case tt: {
              var xe = j._payload, ct = j._init;
              return D(F, K, ct(xe), de);
            }
          }
          if (At(j) || Br(j))
            return Me !== null ? null : C(F, K, j, de, null);
          Qh(F, j);
        }
        return typeof j == "function" && Gh(F), null;
      }
      function B(F, K, j, de, Me) {
        if (typeof de == "string" && de !== "" || typeof de == "number") {
          var xe = F.get(j) || null;
          return p(K, xe, "" + de, Me);
        }
        if (typeof de == "object" && de !== null) {
          switch (de.$$typeof) {
            case Cr: {
              var ct = F.get(de.key === null ? j : de.key) || null;
              return v(K, ct, de, Me);
            }
            case Hr: {
              var mt = F.get(de.key === null ? j : de.key) || null;
              return E(K, mt, de, Me);
            }
            case tt:
              var en = de._payload, Bt = de._init;
              return B(F, K, j, Bt(en), Me);
          }
          if (At(de) || Br(de)) {
            var Yn = F.get(j) || null;
            return C(K, Yn, de, Me, null);
          }
          Qh(K, de);
        }
        return typeof de == "function" && Gh(K), null;
      }
      function $(F, K, j) {
        {
          if (typeof F != "object" || F === null)
            return K;
          switch (F.$$typeof) {
            case Cr:
            case Hr:
              jE(F, j);
              var de = F.key;
              if (typeof de != "string")
                break;
              if (K === null) {
                K = /* @__PURE__ */ new Set(), K.add(de);
                break;
              }
              if (!K.has(de)) {
                K.add(de);
                break;
              }
              S("Encountered two children with the same key, `%s`. Keys should be unique so that components maintain their identity across updates. Non-unique keys may cause children to be duplicated and/or omitted — the behavior is unsupported and could change in a future version.", de);
              break;
            case tt:
              var Me = F._payload, xe = F._init;
              $(xe(Me), K, j);
              break;
          }
        }
        return K;
      }
      function G(F, K, j, de) {
        for (var Me = null, xe = 0; xe < j.length; xe++) {
          var ct = j[xe];
          Me = $(ct, Me, F);
        }
        for (var mt = null, en = null, Bt = K, Yn = 0, Vt = 0, Hn = null; Bt !== null && Vt < j.length; Vt++) {
          Bt.index > Vt ? (Hn = Bt, Bt = null) : Hn = Bt.sibling;
          var na = D(F, Bt, j[Vt], de);
          if (na === null) {
            Bt === null && (Bt = Hn);
            break;
          }
          e && Bt && na.alternate === null && t(F, Bt), Yn = s(na, Yn, Vt), en === null ? mt = na : en.sibling = na, en = na, Bt = Hn;
        }
        if (Vt === j.length) {
          if (a(F, Bt), Mr()) {
            var jr = Vt;
            ac(F, jr);
          }
          return mt;
        }
        if (Bt === null) {
          for (; Vt < j.length; Vt++) {
            var fi = M(F, j[Vt], de);
            fi !== null && (Yn = s(fi, Yn, Vt), en === null ? mt = fi : en.sibling = fi, en = fi);
          }
          if (Mr()) {
            var xa = Vt;
            ac(F, xa);
          }
          return mt;
        }
        for (var _a = i(F, Bt); Vt < j.length; Vt++) {
          var ra = B(_a, F, Vt, j[Vt], de);
          ra !== null && (e && ra.alternate !== null && _a.delete(ra.key === null ? Vt : ra.key), Yn = s(ra, Yn, Vt), en === null ? mt = ra : en.sibling = ra, en = ra);
        }
        if (e && _a.forEach(function($f) {
          return t(F, $f);
        }), Mr()) {
          var Ko = Vt;
          ac(F, Ko);
        }
        return mt;
      }
      function Re(F, K, j, de) {
        var Me = Br(j);
        if (typeof Me != "function")
          throw new Error("An object is not an iterable. This error is likely caused by a bug in React. Please file an issue.");
        {
          typeof Symbol == "function" && // $FlowFixMe Flow doesn't know about toStringTag
          j[Symbol.toStringTag] === "Generator" && (Tg || S("Using Generators as children is unsupported and will likely yield unexpected results because enumerating a generator mutates it. You may convert it to an array with `Array.from()` or the `[...spread]` operator before rendering. Keep in mind you might need to polyfill these features for older browsers."), Tg = !0), j.entries === Me && (bg || S("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), bg = !0);
          var xe = Me.call(j);
          if (xe)
            for (var ct = null, mt = xe.next(); !mt.done; mt = xe.next()) {
              var en = mt.value;
              ct = $(en, ct, F);
            }
        }
        var Bt = Me.call(j);
        if (Bt == null)
          throw new Error("An iterable object provided no iterator.");
        for (var Yn = null, Vt = null, Hn = K, na = 0, jr = 0, fi = null, xa = Bt.next(); Hn !== null && !xa.done; jr++, xa = Bt.next()) {
          Hn.index > jr ? (fi = Hn, Hn = null) : fi = Hn.sibling;
          var _a = D(F, Hn, xa.value, de);
          if (_a === null) {
            Hn === null && (Hn = fi);
            break;
          }
          e && Hn && _a.alternate === null && t(F, Hn), na = s(_a, na, jr), Vt === null ? Yn = _a : Vt.sibling = _a, Vt = _a, Hn = fi;
        }
        if (xa.done) {
          if (a(F, Hn), Mr()) {
            var ra = jr;
            ac(F, ra);
          }
          return Yn;
        }
        if (Hn === null) {
          for (; !xa.done; jr++, xa = Bt.next()) {
            var Ko = M(F, xa.value, de);
            Ko !== null && (na = s(Ko, na, jr), Vt === null ? Yn = Ko : Vt.sibling = Ko, Vt = Ko);
          }
          if (Mr()) {
            var $f = jr;
            ac(F, $f);
          }
          return Yn;
        }
        for (var nv = i(F, Hn); !xa.done; jr++, xa = Bt.next()) {
          var ro = B(nv, F, jr, xa.value, de);
          ro !== null && (e && ro.alternate !== null && nv.delete(ro.key === null ? jr : ro.key), na = s(ro, na, jr), Vt === null ? Yn = ro : Vt.sibling = ro, Vt = ro);
        }
        if (e && nv.forEach(function(lD) {
          return t(F, lD);
        }), Mr()) {
          var iD = jr;
          ac(F, iD);
        }
        return Yn;
      }
      function et(F, K, j, de) {
        if (K !== null && K.tag === ve) {
          a(F, K.sibling);
          var Me = o(K, j);
          return Me.return = F, Me;
        }
        a(F, K);
        var xe = C0(j, F.mode, de);
        return xe.return = F, xe;
      }
      function Ie(F, K, j, de) {
        for (var Me = j.key, xe = K; xe !== null; ) {
          if (xe.key === Me) {
            var ct = j.type;
            if (ct === ca) {
              if (xe.tag === Ae) {
                a(F, xe.sibling);
                var mt = o(xe, j.props.children);
                return mt.return = F, mt._debugSource = j._source, mt._debugOwner = j._owner, mt;
              }
            } else if (xe.elementType === ct || // Keep this check inline so it only runs on the false path:
            Yb(xe, j) || // Lazy types should reconcile their resolved type.
            // We need to do this after the Hot Reloading check above,
            // because hot reloading has different semantics than prod because
            // it doesn't resuspend. So we can't let the call below suspend.
            typeof ct == "object" && ct !== null && ct.$$typeof === tt && PE(ct) === xe.type) {
              a(F, xe.sibling);
              var en = o(xe, j.props);
              return en.ref = Rp(F, xe, j), en.return = F, en._debugSource = j._source, en._debugOwner = j._owner, en;
            }
            a(F, xe);
            break;
          } else
            t(F, xe);
          xe = xe.sibling;
        }
        if (j.type === ca) {
          var Bt = Xu(j.props.children, F.mode, de, j.key);
          return Bt.return = F, Bt;
        } else {
          var Yn = E0(j, F.mode, de);
          return Yn.ref = Rp(F, K, j), Yn.return = F, Yn;
        }
      }
      function Lt(F, K, j, de) {
        for (var Me = j.key, xe = K; xe !== null; ) {
          if (xe.key === Me)
            if (xe.tag === oe && xe.stateNode.containerInfo === j.containerInfo && xe.stateNode.implementation === j.implementation) {
              a(F, xe.sibling);
              var ct = o(xe, j.children || []);
              return ct.return = F, ct;
            } else {
              a(F, xe);
              break;
            }
          else
            t(F, xe);
          xe = xe.sibling;
        }
        var mt = b0(j, F.mode, de);
        return mt.return = F, mt;
      }
      function _t(F, K, j, de) {
        var Me = typeof j == "object" && j !== null && j.type === ca && j.key === null;
        if (Me && (j = j.props.children), typeof j == "object" && j !== null) {
          switch (j.$$typeof) {
            case Cr:
              return f(Ie(F, K, j, de));
            case Hr:
              return f(Lt(F, K, j, de));
            case tt:
              var xe = j._payload, ct = j._init;
              return _t(F, K, ct(xe), de);
          }
          if (At(j))
            return G(F, K, j, de);
          if (Br(j))
            return Re(F, K, j, de);
          Qh(F, j);
        }
        return typeof j == "string" && j !== "" || typeof j == "number" ? f(et(F, K, "" + j, de)) : (typeof j == "function" && Gh(F), a(F, K));
      }
      return _t;
    }
    var wf = HE(!0), BE = HE(!1);
    function Uw(e, t) {
      if (e !== null && t.child !== e.child)
        throw new Error("Resuming work not yet implemented.");
      if (t.child !== null) {
        var a = t.child, i = yc(a, a.pendingProps);
        for (t.child = i, i.return = t; a.sibling !== null; )
          a = a.sibling, i = i.sibling = yc(a, a.pendingProps), i.return = t;
        i.sibling = null;
      }
    }
    function zw(e, t) {
      for (var a = e.child; a !== null; )
        Tk(a, t), a = a.sibling;
    }
    var _g = Fu(null), kg;
    kg = {};
    var Kh = null, xf = null, Dg = null, qh = !1;
    function Xh() {
      Kh = null, xf = null, Dg = null, qh = !1;
    }
    function VE() {
      qh = !0;
    }
    function $E() {
      qh = !1;
    }
    function IE(e, t, a) {
      ea(_g, t._currentValue, e), t._currentValue = a, t._currentRenderer !== void 0 && t._currentRenderer !== null && t._currentRenderer !== kg && S("Detected multiple renderers concurrently rendering the same context provider. This is currently unsupported."), t._currentRenderer = kg;
    }
    function Og(e, t) {
      var a = _g.current;
      Zr(_g, t), e._currentValue = a;
    }
    function Mg(e, t, a) {
      for (var i = e; i !== null; ) {
        var o = i.alternate;
        if (Bl(i.childLanes, t) ? o !== null && !Bl(o.childLanes, t) && (o.childLanes = gt(o.childLanes, t)) : (i.childLanes = gt(i.childLanes, t), o !== null && (o.childLanes = gt(o.childLanes, t))), i === a)
          break;
        i = i.return;
      }
      i !== a && S("Expected to find the propagation root when scheduling context work. This error is likely caused by a bug in React. Please file an issue.");
    }
    function Fw(e, t, a) {
      jw(e, t, a);
    }
    function jw(e, t, a) {
      var i = e.child;
      for (i !== null && (i.return = e); i !== null; ) {
        var o = void 0, s = i.dependencies;
        if (s !== null) {
          o = i.child;
          for (var f = s.firstContext; f !== null; ) {
            if (f.context === t) {
              if (i.tag === Q) {
                var p = Ru(a), v = $o(on, p);
                v.tag = Zh;
                var E = i.updateQueue;
                if (E !== null) {
                  var C = E.shared, M = C.pending;
                  M === null ? v.next = v : (v.next = M.next, M.next = v), C.pending = v;
                }
              }
              i.lanes = gt(i.lanes, a);
              var D = i.alternate;
              D !== null && (D.lanes = gt(D.lanes, a)), Mg(i.return, a, e), s.lanes = gt(s.lanes, a);
              break;
            }
            f = f.next;
          }
        } else if (i.tag === Ke)
          o = i.type === e.type ? null : i.child;
        else if (i.tag === Xe) {
          var B = i.return;
          if (B === null)
            throw new Error("We just came from a parent so we must have had a parent. This is a bug in React.");
          B.lanes = gt(B.lanes, a);
          var $ = B.alternate;
          $ !== null && ($.lanes = gt($.lanes, a)), Mg(B, a, e), o = i.sibling;
        } else
          o = i.child;
        if (o !== null)
          o.return = i;
        else
          for (o = i; o !== null; ) {
            if (o === e) {
              o = null;
              break;
            }
            var G = o.sibling;
            if (G !== null) {
              G.return = o.return, o = G;
              break;
            }
            o = o.return;
          }
        i = o;
      }
    }
    function _f(e, t) {
      Kh = e, xf = null, Dg = null;
      var a = e.dependencies;
      if (a !== null) {
        var i = a.firstContext;
        i !== null && (Jr(a.lanes, t) && Pp(), a.firstContext = null);
      }
    }
    function Xn(e) {
      qh && S("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
      var t = e._currentValue;
      if (Dg !== e) {
        var a = {
          context: e,
          memoizedValue: t,
          next: null
        };
        if (xf === null) {
          if (Kh === null)
            throw new Error("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
          xf = a, Kh.dependencies = {
            lanes: ie,
            firstContext: a
          };
        } else
          xf = xf.next = a;
      }
      return t;
    }
    var sc = null;
    function Ng(e) {
      sc === null ? sc = [e] : sc.push(e);
    }
    function Pw() {
      if (sc !== null) {
        for (var e = 0; e < sc.length; e++) {
          var t = sc[e], a = t.interleaved;
          if (a !== null) {
            t.interleaved = null;
            var i = a.next, o = t.pending;
            if (o !== null) {
              var s = o.next;
              o.next = i, a.next = s;
            }
            t.pending = a;
          }
        }
        sc = null;
      }
    }
    function YE(e, t, a, i) {
      var o = t.interleaved;
      return o === null ? (a.next = a, Ng(t)) : (a.next = o.next, o.next = a), t.interleaved = a, Jh(e, i);
    }
    function Hw(e, t, a, i) {
      var o = t.interleaved;
      o === null ? (a.next = a, Ng(t)) : (a.next = o.next, o.next = a), t.interleaved = a;
    }
    function Bw(e, t, a, i) {
      var o = t.interleaved;
      return o === null ? (a.next = a, Ng(t)) : (a.next = o.next, o.next = a), t.interleaved = a, Jh(e, i);
    }
    function $a(e, t) {
      return Jh(e, t);
    }
    var Vw = Jh;
    function Jh(e, t) {
      e.lanes = gt(e.lanes, t);
      var a = e.alternate;
      a !== null && (a.lanes = gt(a.lanes, t)), a === null && (e.flags & (rn | yi)) !== Ze && Bb(e);
      for (var i = e, o = e.return; o !== null; )
        o.childLanes = gt(o.childLanes, t), a = o.alternate, a !== null ? a.childLanes = gt(a.childLanes, t) : (o.flags & (rn | yi)) !== Ze && Bb(e), i = o, o = o.return;
      if (i.tag === A) {
        var s = i.stateNode;
        return s;
      } else
        return null;
    }
    var WE = 0, QE = 1, Zh = 2, Lg = 3, em = !1, Ag, tm;
    Ag = !1, tm = null;
    function Ug(e) {
      var t = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
          pending: null,
          interleaved: null,
          lanes: ie
        },
        effects: null
      };
      e.updateQueue = t;
    }
    function GE(e, t) {
      var a = t.updateQueue, i = e.updateQueue;
      if (a === i) {
        var o = {
          baseState: i.baseState,
          firstBaseUpdate: i.firstBaseUpdate,
          lastBaseUpdate: i.lastBaseUpdate,
          shared: i.shared,
          effects: i.effects
        };
        t.updateQueue = o;
      }
    }
    function $o(e, t) {
      var a = {
        eventTime: e,
        lane: t,
        tag: WE,
        payload: null,
        callback: null,
        next: null
      };
      return a;
    }
    function Bu(e, t, a) {
      var i = e.updateQueue;
      if (i === null)
        return null;
      var o = i.shared;
      if (tm === o && !Ag && (S("An update (setState, replaceState, or forceUpdate) was scheduled from inside an update function. Update functions should be pure, with zero side-effects. Consider using componentDidUpdate or a callback."), Ag = !0), H_()) {
        var s = o.pending;
        return s === null ? t.next = t : (t.next = s.next, s.next = t), o.pending = t, Vw(e, a);
      } else
        return Bw(e, o, t, a);
    }
    function nm(e, t, a) {
      var i = t.updateQueue;
      if (i !== null) {
        var o = i.shared;
        if (eh(a)) {
          var s = o.lanes;
          s = Ud(s, e.pendingLanes);
          var f = gt(s, a);
          o.lanes = f, ef(e, f);
        }
      }
    }
    function zg(e, t) {
      var a = e.updateQueue, i = e.alternate;
      if (i !== null) {
        var o = i.updateQueue;
        if (a === o) {
          var s = null, f = null, p = a.firstBaseUpdate;
          if (p !== null) {
            var v = p;
            do {
              var E = {
                eventTime: v.eventTime,
                lane: v.lane,
                tag: v.tag,
                payload: v.payload,
                callback: v.callback,
                next: null
              };
              f === null ? s = f = E : (f.next = E, f = E), v = v.next;
            } while (v !== null);
            f === null ? s = f = t : (f.next = t, f = t);
          } else
            s = f = t;
          a = {
            baseState: o.baseState,
            firstBaseUpdate: s,
            lastBaseUpdate: f,
            shared: o.shared,
            effects: o.effects
          }, e.updateQueue = a;
          return;
        }
      }
      var C = a.lastBaseUpdate;
      C === null ? a.firstBaseUpdate = t : C.next = t, a.lastBaseUpdate = t;
    }
    function $w(e, t, a, i, o, s) {
      switch (a.tag) {
        case QE: {
          var f = a.payload;
          if (typeof f == "function") {
            VE();
            var p = f.call(s, i, o);
            {
              if (e.mode & dn) {
                $n(!0);
                try {
                  f.call(s, i, o);
                } finally {
                  $n(!1);
                }
              }
              $E();
            }
            return p;
          }
          return f;
        }
        case Lg:
          e.flags = e.flags & ~tr | vt;
        case WE: {
          var v = a.payload, E;
          if (typeof v == "function") {
            VE(), E = v.call(s, i, o);
            {
              if (e.mode & dn) {
                $n(!0);
                try {
                  v.call(s, i, o);
                } finally {
                  $n(!1);
                }
              }
              $E();
            }
          } else
            E = v;
          return E == null ? i : yt({}, i, E);
        }
        case Zh:
          return em = !0, i;
      }
      return i;
    }
    function rm(e, t, a, i) {
      var o = e.updateQueue;
      em = !1, tm = o.shared;
      var s = o.firstBaseUpdate, f = o.lastBaseUpdate, p = o.shared.pending;
      if (p !== null) {
        o.shared.pending = null;
        var v = p, E = v.next;
        v.next = null, f === null ? s = E : f.next = E, f = v;
        var C = e.alternate;
        if (C !== null) {
          var M = C.updateQueue, D = M.lastBaseUpdate;
          D !== f && (D === null ? M.firstBaseUpdate = E : D.next = E, M.lastBaseUpdate = v);
        }
      }
      if (s !== null) {
        var B = o.baseState, $ = ie, G = null, Re = null, et = null, Ie = s;
        do {
          var Lt = Ie.lane, _t = Ie.eventTime;
          if (Bl(i, Lt)) {
            if (et !== null) {
              var K = {
                eventTime: _t,
                // This update is going to be committed so we never want uncommit
                // it. Using NoLane works because 0 is a subset of all bitmasks, so
                // this will never be skipped by the check above.
                lane: an,
                tag: Ie.tag,
                payload: Ie.payload,
                callback: Ie.callback,
                next: null
              };
              et = et.next = K;
            }
            B = $w(e, o, Ie, B, t, a);
            var j = Ie.callback;
            if (j !== null && // If the update was already committed, we should not queue its
            // callback again.
            Ie.lane !== an) {
              e.flags |= Qn;
              var de = o.effects;
              de === null ? o.effects = [Ie] : de.push(Ie);
            }
          } else {
            var F = {
              eventTime: _t,
              lane: Lt,
              tag: Ie.tag,
              payload: Ie.payload,
              callback: Ie.callback,
              next: null
            };
            et === null ? (Re = et = F, G = B) : et = et.next = F, $ = gt($, Lt);
          }
          if (Ie = Ie.next, Ie === null) {
            if (p = o.shared.pending, p === null)
              break;
            var Me = p, xe = Me.next;
            Me.next = null, Ie = xe, o.lastBaseUpdate = Me, o.shared.pending = null;
          }
        } while (!0);
        et === null && (G = B), o.baseState = G, o.firstBaseUpdate = Re, o.lastBaseUpdate = et;
        var ct = o.shared.interleaved;
        if (ct !== null) {
          var mt = ct;
          do
            $ = gt($, mt.lane), mt = mt.next;
          while (mt !== ct);
        } else s === null && (o.shared.lanes = ie);
        Xp($), e.lanes = $, e.memoizedState = B;
      }
      tm = null;
    }
    function Iw(e, t) {
      if (typeof e != "function")
        throw new Error("Invalid argument passed as callback. Expected a function. Instead " + ("received: " + e));
      e.call(t);
    }
    function KE() {
      em = !1;
    }
    function am() {
      return em;
    }
    function qE(e, t, a) {
      var i = t.effects;
      if (t.effects = null, i !== null)
        for (var o = 0; o < i.length; o++) {
          var s = i[o], f = s.callback;
          f !== null && (s.callback = null, Iw(f, a));
        }
    }
    var wp = {}, Vu = Fu(wp), xp = Fu(wp), im = Fu(wp);
    function lm(e) {
      if (e === wp)
        throw new Error("Expected host context to exist. This error is likely caused by a bug in React. Please file an issue.");
      return e;
    }
    function XE() {
      var e = lm(im.current);
      return e;
    }
    function Fg(e, t) {
      ea(im, t, e), ea(xp, e, e), ea(Vu, wp, e);
      var a = o1(t);
      Zr(Vu, e), ea(Vu, a, e);
    }
    function kf(e) {
      Zr(Vu, e), Zr(xp, e), Zr(im, e);
    }
    function jg() {
      var e = lm(Vu.current);
      return e;
    }
    function JE(e) {
      lm(im.current);
      var t = lm(Vu.current), a = u1(t, e.type);
      t !== a && (ea(xp, e, e), ea(Vu, a, e));
    }
    function Pg(e) {
      xp.current === e && (Zr(Vu, e), Zr(xp, e));
    }
    var Yw = 0, ZE = 1, eC = 1, _p = 2, sl = Fu(Yw);
    function Hg(e, t) {
      return (e & t) !== 0;
    }
    function Df(e) {
      return e & ZE;
    }
    function Bg(e, t) {
      return e & ZE | t;
    }
    function Ww(e, t) {
      return e | t;
    }
    function $u(e, t) {
      ea(sl, t, e);
    }
    function Of(e) {
      Zr(sl, e);
    }
    function Qw(e, t) {
      var a = e.memoizedState;
      return a !== null ? a.dehydrated !== null : (e.memoizedProps, !0);
    }
    function om(e) {
      for (var t = e; t !== null; ) {
        if (t.tag === Ne) {
          var a = t.memoizedState;
          if (a !== null) {
            var i = a.dehydrated;
            if (i === null || yE(i) || ig(i))
              return t;
          }
        } else if (t.tag === W && // revealOrder undefined can't be trusted because it don't
        // keep track of whether it suspended or not.
        t.memoizedProps.revealOrder !== void 0) {
          var o = (t.flags & vt) !== Ze;
          if (o)
            return t;
        } else if (t.child !== null) {
          t.child.return = t, t = t.child;
          continue;
        }
        if (t === e)
          return null;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === e)
            return null;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
      return null;
    }
    var Ia = (
      /*   */
      0
    ), ar = (
      /* */
      1
    ), ql = (
      /*  */
      2
    ), ir = (
      /*    */
      4
    ), Nr = (
      /*   */
      8
    ), Vg = [];
    function $g() {
      for (var e = 0; e < Vg.length; e++) {
        var t = Vg[e];
        t._workInProgressVersionPrimary = null;
      }
      Vg.length = 0;
    }
    function Gw(e, t) {
      var a = t._getVersion, i = a(t._source);
      e.mutableSourceEagerHydrationData == null ? e.mutableSourceEagerHydrationData = [t, i] : e.mutableSourceEagerHydrationData.push(t, i);
    }
    var ke = T.ReactCurrentDispatcher, kp = T.ReactCurrentBatchConfig, Ig, Mf;
    Ig = /* @__PURE__ */ new Set();
    var cc = ie, Zt = null, lr = null, or = null, um = !1, Dp = !1, Op = 0, Kw = 0, qw = 25, ee = null, Oi = null, Iu = -1, Yg = !1;
    function Qt() {
      {
        var e = ee;
        Oi === null ? Oi = [e] : Oi.push(e);
      }
    }
    function Se() {
      {
        var e = ee;
        Oi !== null && (Iu++, Oi[Iu] !== e && Xw(e));
      }
    }
    function Nf(e) {
      e != null && !At(e) && S("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", ee, typeof e);
    }
    function Xw(e) {
      {
        var t = dt(Zt);
        if (!Ig.has(t) && (Ig.add(t), Oi !== null)) {
          for (var a = "", i = 30, o = 0; o <= Iu; o++) {
            for (var s = Oi[o], f = o === Iu ? e : s, p = o + 1 + ". " + s; p.length < i; )
              p += " ";
            p += f + `
`, a += p;
          }
          S(`React has detected a change in the order of Hooks called by %s. This will lead to bugs and errors if not fixed. For more information, read the Rules of Hooks: https://reactjs.org/link/rules-of-hooks

   Previous render            Next render
   ------------------------------------------------------
%s   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
`, t, a);
        }
      }
    }
    function ta() {
      throw new Error(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.`);
    }
    function Wg(e, t) {
      if (Yg)
        return !1;
      if (t === null)
        return S("%s received a final argument during this render, but not during the previous render. Even though the final argument is optional, its type cannot change between renders.", ee), !1;
      e.length !== t.length && S(`The final argument passed to %s changed size between renders. The order and size of this array must remain constant.

Previous: %s
Incoming: %s`, ee, "[" + t.join(", ") + "]", "[" + e.join(", ") + "]");
      for (var a = 0; a < t.length && a < e.length; a++)
        if (!$e(e[a], t[a]))
          return !1;
      return !0;
    }
    function Lf(e, t, a, i, o, s) {
      cc = s, Zt = t, Oi = e !== null ? e._debugHookTypes : null, Iu = -1, Yg = e !== null && e.type !== t.type, t.memoizedState = null, t.updateQueue = null, t.lanes = ie, e !== null && e.memoizedState !== null ? ke.current = bC : Oi !== null ? ke.current = CC : ke.current = EC;
      var f = a(i, o);
      if (Dp) {
        var p = 0;
        do {
          if (Dp = !1, Op = 0, p >= qw)
            throw new Error("Too many re-renders. React limits the number of renders to prevent an infinite loop.");
          p += 1, Yg = !1, lr = null, or = null, t.updateQueue = null, Iu = -1, ke.current = TC, f = a(i, o);
        } while (Dp);
      }
      ke.current = Cm, t._debugHookTypes = Oi;
      var v = lr !== null && lr.next !== null;
      if (cc = ie, Zt = null, lr = null, or = null, ee = null, Oi = null, Iu = -1, e !== null && (e.flags & nr) !== (t.flags & nr) && // Disable this warning in legacy mode, because legacy Suspense is weird
      // and creates false positives. To make this work in legacy mode, we'd
      // need to mark fibers that commit in an incomplete state, somehow. For
      // now I'll disable the warning that most of the bugs that would trigger
      // it are either exclusive to concurrent mode or exist in both.
      (e.mode & qe) !== Ce && S("Internal React error: Expected static flag was missing. Please notify the React team."), um = !1, v)
        throw new Error("Rendered fewer hooks than expected. This may be caused by an accidental early return statement.");
      return f;
    }
    function Af() {
      var e = Op !== 0;
      return Op = 0, e;
    }
    function tC(e, t, a) {
      t.updateQueue = e.updateQueue, (t.mode & qr) !== Ce ? t.flags &= ~(Eo | Fa | Wr | He) : t.flags &= ~(Wr | He), e.lanes = wu(e.lanes, a);
    }
    function nC() {
      if (ke.current = Cm, um) {
        for (var e = Zt.memoizedState; e !== null; ) {
          var t = e.queue;
          t !== null && (t.pending = null), e = e.next;
        }
        um = !1;
      }
      cc = ie, Zt = null, lr = null, or = null, Oi = null, Iu = -1, ee = null, hC = !1, Dp = !1, Op = 0;
    }
    function Xl() {
      var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
      };
      return or === null ? Zt.memoizedState = or = e : or = or.next = e, or;
    }
    function Mi() {
      var e;
      if (lr === null) {
        var t = Zt.alternate;
        t !== null ? e = t.memoizedState : e = null;
      } else
        e = lr.next;
      var a;
      if (or === null ? a = Zt.memoizedState : a = or.next, a !== null)
        or = a, a = or.next, lr = e;
      else {
        if (e === null)
          throw new Error("Rendered more hooks than during the previous render.");
        lr = e;
        var i = {
          memoizedState: lr.memoizedState,
          baseState: lr.baseState,
          baseQueue: lr.baseQueue,
          queue: lr.queue,
          next: null
        };
        or === null ? Zt.memoizedState = or = i : or = or.next = i;
      }
      return or;
    }
    function rC() {
      return {
        lastEffect: null,
        stores: null
      };
    }
    function Qg(e, t) {
      return typeof t == "function" ? t(e) : t;
    }
    function Gg(e, t, a) {
      var i = Xl(), o;
      a !== void 0 ? o = a(t) : o = t, i.memoizedState = i.baseState = o;
      var s = {
        pending: null,
        interleaved: null,
        lanes: ie,
        dispatch: null,
        lastRenderedReducer: e,
        lastRenderedState: o
      };
      i.queue = s;
      var f = s.dispatch = tx.bind(null, Zt, s);
      return [i.memoizedState, f];
    }
    function Kg(e, t, a) {
      var i = Mi(), o = i.queue;
      if (o === null)
        throw new Error("Should have a queue. This is likely a bug in React. Please file an issue.");
      o.lastRenderedReducer = e;
      var s = lr, f = s.baseQueue, p = o.pending;
      if (p !== null) {
        if (f !== null) {
          var v = f.next, E = p.next;
          f.next = E, p.next = v;
        }
        s.baseQueue !== f && S("Internal error: Expected work-in-progress queue to be a clone. This is a bug in React."), s.baseQueue = f = p, o.pending = null;
      }
      if (f !== null) {
        var C = f.next, M = s.baseState, D = null, B = null, $ = null, G = C;
        do {
          var Re = G.lane;
          if (Bl(cc, Re)) {
            if ($ !== null) {
              var Ie = {
                // This update is going to be committed so we never want uncommit
                // it. Using NoLane works because 0 is a subset of all bitmasks, so
                // this will never be skipped by the check above.
                lane: an,
                action: G.action,
                hasEagerState: G.hasEagerState,
                eagerState: G.eagerState,
                next: null
              };
              $ = $.next = Ie;
            }
            if (G.hasEagerState)
              M = G.eagerState;
            else {
              var Lt = G.action;
              M = e(M, Lt);
            }
          } else {
            var et = {
              lane: Re,
              action: G.action,
              hasEagerState: G.hasEagerState,
              eagerState: G.eagerState,
              next: null
            };
            $ === null ? (B = $ = et, D = M) : $ = $.next = et, Zt.lanes = gt(Zt.lanes, Re), Xp(Re);
          }
          G = G.next;
        } while (G !== null && G !== C);
        $ === null ? D = M : $.next = B, $e(M, i.memoizedState) || Pp(), i.memoizedState = M, i.baseState = D, i.baseQueue = $, o.lastRenderedState = M;
      }
      var _t = o.interleaved;
      if (_t !== null) {
        var F = _t;
        do {
          var K = F.lane;
          Zt.lanes = gt(Zt.lanes, K), Xp(K), F = F.next;
        } while (F !== _t);
      } else f === null && (o.lanes = ie);
      var j = o.dispatch;
      return [i.memoizedState, j];
    }
    function qg(e, t, a) {
      var i = Mi(), o = i.queue;
      if (o === null)
        throw new Error("Should have a queue. This is likely a bug in React. Please file an issue.");
      o.lastRenderedReducer = e;
      var s = o.dispatch, f = o.pending, p = i.memoizedState;
      if (f !== null) {
        o.pending = null;
        var v = f.next, E = v;
        do {
          var C = E.action;
          p = e(p, C), E = E.next;
        } while (E !== v);
        $e(p, i.memoizedState) || Pp(), i.memoizedState = p, i.baseQueue === null && (i.baseState = p), o.lastRenderedState = p;
      }
      return [p, s];
    }
    function BO(e, t, a) {
    }
    function VO(e, t, a) {
    }
    function Xg(e, t, a) {
      var i = Zt, o = Xl(), s, f = Mr();
      if (f) {
        if (a === void 0)
          throw new Error("Missing getServerSnapshot, which is required for server-rendered content. Will revert to client rendering.");
        s = a(), Mf || s !== a() && (S("The result of getServerSnapshot should be cached to avoid an infinite loop"), Mf = !0);
      } else {
        if (s = t(), !Mf) {
          var p = t();
          $e(s, p) || (S("The result of getSnapshot should be cached to avoid an infinite loop"), Mf = !0);
        }
        var v = Hm();
        if (v === null)
          throw new Error("Expected a work-in-progress root. This is a bug in React. Please file an issue.");
        As(v, cc) || aC(i, t, s);
      }
      o.memoizedState = s;
      var E = {
        value: s,
        getSnapshot: t
      };
      return o.queue = E, pm(lC.bind(null, i, E, e), [e]), i.flags |= Wr, Mp(ar | Nr, iC.bind(null, i, E, s, t), void 0, null), s;
    }
    function sm(e, t, a) {
      var i = Zt, o = Mi(), s = t();
      if (!Mf) {
        var f = t();
        $e(s, f) || (S("The result of getSnapshot should be cached to avoid an infinite loop"), Mf = !0);
      }
      var p = o.memoizedState, v = !$e(p, s);
      v && (o.memoizedState = s, Pp());
      var E = o.queue;
      if (Lp(lC.bind(null, i, E, e), [e]), E.getSnapshot !== t || v || // Check if the susbcribe function changed. We can save some memory by
      // checking whether we scheduled a subscription effect above.
      or !== null && or.memoizedState.tag & ar) {
        i.flags |= Wr, Mp(ar | Nr, iC.bind(null, i, E, s, t), void 0, null);
        var C = Hm();
        if (C === null)
          throw new Error("Expected a work-in-progress root. This is a bug in React. Please file an issue.");
        As(C, cc) || aC(i, t, s);
      }
      return s;
    }
    function aC(e, t, a) {
      e.flags |= So;
      var i = {
        getSnapshot: t,
        value: a
      }, o = Zt.updateQueue;
      if (o === null)
        o = rC(), Zt.updateQueue = o, o.stores = [i];
      else {
        var s = o.stores;
        s === null ? o.stores = [i] : s.push(i);
      }
    }
    function iC(e, t, a, i) {
      t.value = a, t.getSnapshot = i, oC(t) && uC(e);
    }
    function lC(e, t, a) {
      var i = function() {
        oC(t) && uC(e);
      };
      return a(i);
    }
    function oC(e) {
      var t = e.getSnapshot, a = e.value;
      try {
        var i = t();
        return !$e(a, i);
      } catch {
        return !0;
      }
    }
    function uC(e) {
      var t = $a(e, Ve);
      t !== null && fr(t, e, Ve, on);
    }
    function cm(e) {
      var t = Xl();
      typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e;
      var a = {
        pending: null,
        interleaved: null,
        lanes: ie,
        dispatch: null,
        lastRenderedReducer: Qg,
        lastRenderedState: e
      };
      t.queue = a;
      var i = a.dispatch = nx.bind(null, Zt, a);
      return [t.memoizedState, i];
    }
    function Jg(e) {
      return Kg(Qg);
    }
    function Zg(e) {
      return qg(Qg);
    }
    function Mp(e, t, a, i) {
      var o = {
        tag: e,
        create: t,
        destroy: a,
        deps: i,
        // Circular
        next: null
      }, s = Zt.updateQueue;
      if (s === null)
        s = rC(), Zt.updateQueue = s, s.lastEffect = o.next = o;
      else {
        var f = s.lastEffect;
        if (f === null)
          s.lastEffect = o.next = o;
        else {
          var p = f.next;
          f.next = o, o.next = p, s.lastEffect = o;
        }
      }
      return o;
    }
    function eS(e) {
      var t = Xl();
      {
        var a = {
          current: e
        };
        return t.memoizedState = a, a;
      }
    }
    function fm(e) {
      var t = Mi();
      return t.memoizedState;
    }
    function Np(e, t, a, i) {
      var o = Xl(), s = i === void 0 ? null : i;
      Zt.flags |= e, o.memoizedState = Mp(ar | t, a, void 0, s);
    }
    function dm(e, t, a, i) {
      var o = Mi(), s = i === void 0 ? null : i, f = void 0;
      if (lr !== null) {
        var p = lr.memoizedState;
        if (f = p.destroy, s !== null) {
          var v = p.deps;
          if (Wg(s, v)) {
            o.memoizedState = Mp(t, a, f, s);
            return;
          }
        }
      }
      Zt.flags |= e, o.memoizedState = Mp(ar | t, a, f, s);
    }
    function pm(e, t) {
      return (Zt.mode & qr) !== Ce ? Np(Eo | Wr | Nl, Nr, e, t) : Np(Wr | Nl, Nr, e, t);
    }
    function Lp(e, t) {
      return dm(Wr, Nr, e, t);
    }
    function tS(e, t) {
      return Np(He, ql, e, t);
    }
    function vm(e, t) {
      return dm(He, ql, e, t);
    }
    function nS(e, t) {
      var a = He;
      return a |= za, (Zt.mode & qr) !== Ce && (a |= Fa), Np(a, ir, e, t);
    }
    function hm(e, t) {
      return dm(He, ir, e, t);
    }
    function sC(e, t) {
      if (typeof t == "function") {
        var a = t, i = e();
        return a(i), function() {
          a(null);
        };
      } else if (t != null) {
        var o = t;
        o.hasOwnProperty("current") || S("Expected useImperativeHandle() first argument to either be a ref callback or React.createRef() object. Instead received: %s.", "an object with keys {" + Object.keys(o).join(", ") + "}");
        var s = e();
        return o.current = s, function() {
          o.current = null;
        };
      }
    }
    function rS(e, t, a) {
      typeof t != "function" && S("Expected useImperativeHandle() second argument to be a function that creates a handle. Instead received: %s.", t !== null ? typeof t : "null");
      var i = a != null ? a.concat([e]) : null, o = He;
      return o |= za, (Zt.mode & qr) !== Ce && (o |= Fa), Np(o, ir, sC.bind(null, t, e), i);
    }
    function mm(e, t, a) {
      typeof t != "function" && S("Expected useImperativeHandle() second argument to be a function that creates a handle. Instead received: %s.", t !== null ? typeof t : "null");
      var i = a != null ? a.concat([e]) : null;
      return dm(He, ir, sC.bind(null, t, e), i);
    }
    function Jw(e, t) {
    }
    var ym = Jw;
    function aS(e, t) {
      var a = Xl(), i = t === void 0 ? null : t;
      return a.memoizedState = [e, i], e;
    }
    function gm(e, t) {
      var a = Mi(), i = t === void 0 ? null : t, o = a.memoizedState;
      if (o !== null && i !== null) {
        var s = o[1];
        if (Wg(i, s))
          return o[0];
      }
      return a.memoizedState = [e, i], e;
    }
    function iS(e, t) {
      var a = Xl(), i = t === void 0 ? null : t, o = e();
      return a.memoizedState = [o, i], o;
    }
    function Sm(e, t) {
      var a = Mi(), i = t === void 0 ? null : t, o = a.memoizedState;
      if (o !== null && i !== null) {
        var s = o[1];
        if (Wg(i, s))
          return o[0];
      }
      var f = e();
      return a.memoizedState = [f, i], f;
    }
    function lS(e) {
      var t = Xl();
      return t.memoizedState = e, e;
    }
    function cC(e) {
      var t = Mi(), a = lr, i = a.memoizedState;
      return dC(t, i, e);
    }
    function fC(e) {
      var t = Mi();
      if (lr === null)
        return t.memoizedState = e, e;
      var a = lr.memoizedState;
      return dC(t, a, e);
    }
    function dC(e, t, a) {
      var i = !Xv(cc);
      if (i) {
        if (!$e(a, t)) {
          var o = Rr();
          Zt.lanes = gt(Zt.lanes, o), Xp(o), e.baseState = !0;
        }
        return t;
      } else
        return e.baseState && (e.baseState = !1, Pp()), e.memoizedState = a, a;
    }
    function Zw(e, t, a) {
      var i = xr();
      Ut(_y(i, Ti)), e(!0);
      var o = kp.transition;
      kp.transition = {};
      var s = kp.transition;
      kp.transition._updatedFibers = /* @__PURE__ */ new Set();
      try {
        e(!1), t();
      } finally {
        if (Ut(i), kp.transition = o, o === null && s._updatedFibers) {
          var f = s._updatedFibers.size;
          f > 10 && x("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."), s._updatedFibers.clear();
        }
      }
    }
    function oS() {
      var e = cm(!1), t = e[0], a = e[1], i = Zw.bind(null, a), o = Xl();
      return o.memoizedState = i, [t, i];
    }
    function pC() {
      var e = Jg(), t = e[0], a = Mi(), i = a.memoizedState;
      return [t, i];
    }
    function vC() {
      var e = Zg(), t = e[0], a = Mi(), i = a.memoizedState;
      return [t, i];
    }
    var hC = !1;
    function ex() {
      return hC;
    }
    function uS() {
      var e = Xl(), t = Hm(), a = t.identifierPrefix, i;
      if (Mr()) {
        var o = yw();
        i = ":" + a + "R" + o;
        var s = Op++;
        s > 0 && (i += "H" + s.toString(32)), i += ":";
      } else {
        var f = Kw++;
        i = ":" + a + "r" + f.toString(32) + ":";
      }
      return e.memoizedState = i, i;
    }
    function Em() {
      var e = Mi(), t = e.memoizedState;
      return t;
    }
    function tx(e, t, a) {
      typeof arguments[3] == "function" && S("State updates from the useState() and useReducer() Hooks don't support the second callback argument. To execute a side effect after rendering, declare it in the component body with useEffect().");
      var i = Ku(e), o = {
        lane: i,
        action: a,
        hasEagerState: !1,
        eagerState: null,
        next: null
      };
      if (mC(e))
        yC(t, o);
      else {
        var s = YE(e, t, o, i);
        if (s !== null) {
          var f = wa();
          fr(s, e, i, f), gC(s, t, i);
        }
      }
      SC(e, i);
    }
    function nx(e, t, a) {
      typeof arguments[3] == "function" && S("State updates from the useState() and useReducer() Hooks don't support the second callback argument. To execute a side effect after rendering, declare it in the component body with useEffect().");
      var i = Ku(e), o = {
        lane: i,
        action: a,
        hasEagerState: !1,
        eagerState: null,
        next: null
      };
      if (mC(e))
        yC(t, o);
      else {
        var s = e.alternate;
        if (e.lanes === ie && (s === null || s.lanes === ie)) {
          var f = t.lastRenderedReducer;
          if (f !== null) {
            var p;
            p = ke.current, ke.current = cl;
            try {
              var v = t.lastRenderedState, E = f(v, a);
              if (o.hasEagerState = !0, o.eagerState = E, $e(E, v)) {
                Hw(e, t, o, i);
                return;
              }
            } catch {
            } finally {
              ke.current = p;
            }
          }
        }
        var C = YE(e, t, o, i);
        if (C !== null) {
          var M = wa();
          fr(C, e, i, M), gC(C, t, i);
        }
      }
      SC(e, i);
    }
    function mC(e) {
      var t = e.alternate;
      return e === Zt || t !== null && t === Zt;
    }
    function yC(e, t) {
      Dp = um = !0;
      var a = e.pending;
      a === null ? t.next = t : (t.next = a.next, a.next = t), e.pending = t;
    }
    function gC(e, t, a) {
      if (eh(a)) {
        var i = t.lanes;
        i = Ud(i, e.pendingLanes);
        var o = gt(i, a);
        t.lanes = o, ef(e, o);
      }
    }
    function SC(e, t, a) {
      el(e, t);
    }
    var Cm = {
      readContext: Xn,
      useCallback: ta,
      useContext: ta,
      useEffect: ta,
      useImperativeHandle: ta,
      useInsertionEffect: ta,
      useLayoutEffect: ta,
      useMemo: ta,
      useReducer: ta,
      useRef: ta,
      useState: ta,
      useDebugValue: ta,
      useDeferredValue: ta,
      useTransition: ta,
      useMutableSource: ta,
      useSyncExternalStore: ta,
      useId: ta,
      unstable_isNewReconciler: ge
    }, EC = null, CC = null, bC = null, TC = null, Jl = null, cl = null, bm = null;
    {
      var sS = function() {
        S("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
      }, ht = function() {
        S("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
      };
      EC = {
        readContext: function(e) {
          return Xn(e);
        },
        useCallback: function(e, t) {
          return ee = "useCallback", Qt(), Nf(t), aS(e, t);
        },
        useContext: function(e) {
          return ee = "useContext", Qt(), Xn(e);
        },
        useEffect: function(e, t) {
          return ee = "useEffect", Qt(), Nf(t), pm(e, t);
        },
        useImperativeHandle: function(e, t, a) {
          return ee = "useImperativeHandle", Qt(), Nf(a), rS(e, t, a);
        },
        useInsertionEffect: function(e, t) {
          return ee = "useInsertionEffect", Qt(), Nf(t), tS(e, t);
        },
        useLayoutEffect: function(e, t) {
          return ee = "useLayoutEffect", Qt(), Nf(t), nS(e, t);
        },
        useMemo: function(e, t) {
          ee = "useMemo", Qt(), Nf(t);
          var a = ke.current;
          ke.current = Jl;
          try {
            return iS(e, t);
          } finally {
            ke.current = a;
          }
        },
        useReducer: function(e, t, a) {
          ee = "useReducer", Qt();
          var i = ke.current;
          ke.current = Jl;
          try {
            return Gg(e, t, a);
          } finally {
            ke.current = i;
          }
        },
        useRef: function(e) {
          return ee = "useRef", Qt(), eS(e);
        },
        useState: function(e) {
          ee = "useState", Qt();
          var t = ke.current;
          ke.current = Jl;
          try {
            return cm(e);
          } finally {
            ke.current = t;
          }
        },
        useDebugValue: function(e, t) {
          return ee = "useDebugValue", Qt(), void 0;
        },
        useDeferredValue: function(e) {
          return ee = "useDeferredValue", Qt(), lS(e);
        },
        useTransition: function() {
          return ee = "useTransition", Qt(), oS();
        },
        useMutableSource: function(e, t, a) {
          return ee = "useMutableSource", Qt(), void 0;
        },
        useSyncExternalStore: function(e, t, a) {
          return ee = "useSyncExternalStore", Qt(), Xg(e, t, a);
        },
        useId: function() {
          return ee = "useId", Qt(), uS();
        },
        unstable_isNewReconciler: ge
      }, CC = {
        readContext: function(e) {
          return Xn(e);
        },
        useCallback: function(e, t) {
          return ee = "useCallback", Se(), aS(e, t);
        },
        useContext: function(e) {
          return ee = "useContext", Se(), Xn(e);
        },
        useEffect: function(e, t) {
          return ee = "useEffect", Se(), pm(e, t);
        },
        useImperativeHandle: function(e, t, a) {
          return ee = "useImperativeHandle", Se(), rS(e, t, a);
        },
        useInsertionEffect: function(e, t) {
          return ee = "useInsertionEffect", Se(), tS(e, t);
        },
        useLayoutEffect: function(e, t) {
          return ee = "useLayoutEffect", Se(), nS(e, t);
        },
        useMemo: function(e, t) {
          ee = "useMemo", Se();
          var a = ke.current;
          ke.current = Jl;
          try {
            return iS(e, t);
          } finally {
            ke.current = a;
          }
        },
        useReducer: function(e, t, a) {
          ee = "useReducer", Se();
          var i = ke.current;
          ke.current = Jl;
          try {
            return Gg(e, t, a);
          } finally {
            ke.current = i;
          }
        },
        useRef: function(e) {
          return ee = "useRef", Se(), eS(e);
        },
        useState: function(e) {
          ee = "useState", Se();
          var t = ke.current;
          ke.current = Jl;
          try {
            return cm(e);
          } finally {
            ke.current = t;
          }
        },
        useDebugValue: function(e, t) {
          return ee = "useDebugValue", Se(), void 0;
        },
        useDeferredValue: function(e) {
          return ee = "useDeferredValue", Se(), lS(e);
        },
        useTransition: function() {
          return ee = "useTransition", Se(), oS();
        },
        useMutableSource: function(e, t, a) {
          return ee = "useMutableSource", Se(), void 0;
        },
        useSyncExternalStore: function(e, t, a) {
          return ee = "useSyncExternalStore", Se(), Xg(e, t, a);
        },
        useId: function() {
          return ee = "useId", Se(), uS();
        },
        unstable_isNewReconciler: ge
      }, bC = {
        readContext: function(e) {
          return Xn(e);
        },
        useCallback: function(e, t) {
          return ee = "useCallback", Se(), gm(e, t);
        },
        useContext: function(e) {
          return ee = "useContext", Se(), Xn(e);
        },
        useEffect: function(e, t) {
          return ee = "useEffect", Se(), Lp(e, t);
        },
        useImperativeHandle: function(e, t, a) {
          return ee = "useImperativeHandle", Se(), mm(e, t, a);
        },
        useInsertionEffect: function(e, t) {
          return ee = "useInsertionEffect", Se(), vm(e, t);
        },
        useLayoutEffect: function(e, t) {
          return ee = "useLayoutEffect", Se(), hm(e, t);
        },
        useMemo: function(e, t) {
          ee = "useMemo", Se();
          var a = ke.current;
          ke.current = cl;
          try {
            return Sm(e, t);
          } finally {
            ke.current = a;
          }
        },
        useReducer: function(e, t, a) {
          ee = "useReducer", Se();
          var i = ke.current;
          ke.current = cl;
          try {
            return Kg(e, t, a);
          } finally {
            ke.current = i;
          }
        },
        useRef: function(e) {
          return ee = "useRef", Se(), fm();
        },
        useState: function(e) {
          ee = "useState", Se();
          var t = ke.current;
          ke.current = cl;
          try {
            return Jg(e);
          } finally {
            ke.current = t;
          }
        },
        useDebugValue: function(e, t) {
          return ee = "useDebugValue", Se(), ym();
        },
        useDeferredValue: function(e) {
          return ee = "useDeferredValue", Se(), cC(e);
        },
        useTransition: function() {
          return ee = "useTransition", Se(), pC();
        },
        useMutableSource: function(e, t, a) {
          return ee = "useMutableSource", Se(), void 0;
        },
        useSyncExternalStore: function(e, t, a) {
          return ee = "useSyncExternalStore", Se(), sm(e, t);
        },
        useId: function() {
          return ee = "useId", Se(), Em();
        },
        unstable_isNewReconciler: ge
      }, TC = {
        readContext: function(e) {
          return Xn(e);
        },
        useCallback: function(e, t) {
          return ee = "useCallback", Se(), gm(e, t);
        },
        useContext: function(e) {
          return ee = "useContext", Se(), Xn(e);
        },
        useEffect: function(e, t) {
          return ee = "useEffect", Se(), Lp(e, t);
        },
        useImperativeHandle: function(e, t, a) {
          return ee = "useImperativeHandle", Se(), mm(e, t, a);
        },
        useInsertionEffect: function(e, t) {
          return ee = "useInsertionEffect", Se(), vm(e, t);
        },
        useLayoutEffect: function(e, t) {
          return ee = "useLayoutEffect", Se(), hm(e, t);
        },
        useMemo: function(e, t) {
          ee = "useMemo", Se();
          var a = ke.current;
          ke.current = bm;
          try {
            return Sm(e, t);
          } finally {
            ke.current = a;
          }
        },
        useReducer: function(e, t, a) {
          ee = "useReducer", Se();
          var i = ke.current;
          ke.current = bm;
          try {
            return qg(e, t, a);
          } finally {
            ke.current = i;
          }
        },
        useRef: function(e) {
          return ee = "useRef", Se(), fm();
        },
        useState: function(e) {
          ee = "useState", Se();
          var t = ke.current;
          ke.current = bm;
          try {
            return Zg(e);
          } finally {
            ke.current = t;
          }
        },
        useDebugValue: function(e, t) {
          return ee = "useDebugValue", Se(), ym();
        },
        useDeferredValue: function(e) {
          return ee = "useDeferredValue", Se(), fC(e);
        },
        useTransition: function() {
          return ee = "useTransition", Se(), vC();
        },
        useMutableSource: function(e, t, a) {
          return ee = "useMutableSource", Se(), void 0;
        },
        useSyncExternalStore: function(e, t, a) {
          return ee = "useSyncExternalStore", Se(), sm(e, t);
        },
        useId: function() {
          return ee = "useId", Se(), Em();
        },
        unstable_isNewReconciler: ge
      }, Jl = {
        readContext: function(e) {
          return sS(), Xn(e);
        },
        useCallback: function(e, t) {
          return ee = "useCallback", ht(), Qt(), aS(e, t);
        },
        useContext: function(e) {
          return ee = "useContext", ht(), Qt(), Xn(e);
        },
        useEffect: function(e, t) {
          return ee = "useEffect", ht(), Qt(), pm(e, t);
        },
        useImperativeHandle: function(e, t, a) {
          return ee = "useImperativeHandle", ht(), Qt(), rS(e, t, a);
        },
        useInsertionEffect: function(e, t) {
          return ee = "useInsertionEffect", ht(), Qt(), tS(e, t);
        },
        useLayoutEffect: function(e, t) {
          return ee = "useLayoutEffect", ht(), Qt(), nS(e, t);
        },
        useMemo: function(e, t) {
          ee = "useMemo", ht(), Qt();
          var a = ke.current;
          ke.current = Jl;
          try {
            return iS(e, t);
          } finally {
            ke.current = a;
          }
        },
        useReducer: function(e, t, a) {
          ee = "useReducer", ht(), Qt();
          var i = ke.current;
          ke.current = Jl;
          try {
            return Gg(e, t, a);
          } finally {
            ke.current = i;
          }
        },
        useRef: function(e) {
          return ee = "useRef", ht(), Qt(), eS(e);
        },
        useState: function(e) {
          ee = "useState", ht(), Qt();
          var t = ke.current;
          ke.current = Jl;
          try {
            return cm(e);
          } finally {
            ke.current = t;
          }
        },
        useDebugValue: function(e, t) {
          return ee = "useDebugValue", ht(), Qt(), void 0;
        },
        useDeferredValue: function(e) {
          return ee = "useDeferredValue", ht(), Qt(), lS(e);
        },
        useTransition: function() {
          return ee = "useTransition", ht(), Qt(), oS();
        },
        useMutableSource: function(e, t, a) {
          return ee = "useMutableSource", ht(), Qt(), void 0;
        },
        useSyncExternalStore: function(e, t, a) {
          return ee = "useSyncExternalStore", ht(), Qt(), Xg(e, t, a);
        },
        useId: function() {
          return ee = "useId", ht(), Qt(), uS();
        },
        unstable_isNewReconciler: ge
      }, cl = {
        readContext: function(e) {
          return sS(), Xn(e);
        },
        useCallback: function(e, t) {
          return ee = "useCallback", ht(), Se(), gm(e, t);
        },
        useContext: function(e) {
          return ee = "useContext", ht(), Se(), Xn(e);
        },
        useEffect: function(e, t) {
          return ee = "useEffect", ht(), Se(), Lp(e, t);
        },
        useImperativeHandle: function(e, t, a) {
          return ee = "useImperativeHandle", ht(), Se(), mm(e, t, a);
        },
        useInsertionEffect: function(e, t) {
          return ee = "useInsertionEffect", ht(), Se(), vm(e, t);
        },
        useLayoutEffect: function(e, t) {
          return ee = "useLayoutEffect", ht(), Se(), hm(e, t);
        },
        useMemo: function(e, t) {
          ee = "useMemo", ht(), Se();
          var a = ke.current;
          ke.current = cl;
          try {
            return Sm(e, t);
          } finally {
            ke.current = a;
          }
        },
        useReducer: function(e, t, a) {
          ee = "useReducer", ht(), Se();
          var i = ke.current;
          ke.current = cl;
          try {
            return Kg(e, t, a);
          } finally {
            ke.current = i;
          }
        },
        useRef: function(e) {
          return ee = "useRef", ht(), Se(), fm();
        },
        useState: function(e) {
          ee = "useState", ht(), Se();
          var t = ke.current;
          ke.current = cl;
          try {
            return Jg(e);
          } finally {
            ke.current = t;
          }
        },
        useDebugValue: function(e, t) {
          return ee = "useDebugValue", ht(), Se(), ym();
        },
        useDeferredValue: function(e) {
          return ee = "useDeferredValue", ht(), Se(), cC(e);
        },
        useTransition: function() {
          return ee = "useTransition", ht(), Se(), pC();
        },
        useMutableSource: function(e, t, a) {
          return ee = "useMutableSource", ht(), Se(), void 0;
        },
        useSyncExternalStore: function(e, t, a) {
          return ee = "useSyncExternalStore", ht(), Se(), sm(e, t);
        },
        useId: function() {
          return ee = "useId", ht(), Se(), Em();
        },
        unstable_isNewReconciler: ge
      }, bm = {
        readContext: function(e) {
          return sS(), Xn(e);
        },
        useCallback: function(e, t) {
          return ee = "useCallback", ht(), Se(), gm(e, t);
        },
        useContext: function(e) {
          return ee = "useContext", ht(), Se(), Xn(e);
        },
        useEffect: function(e, t) {
          return ee = "useEffect", ht(), Se(), Lp(e, t);
        },
        useImperativeHandle: function(e, t, a) {
          return ee = "useImperativeHandle", ht(), Se(), mm(e, t, a);
        },
        useInsertionEffect: function(e, t) {
          return ee = "useInsertionEffect", ht(), Se(), vm(e, t);
        },
        useLayoutEffect: function(e, t) {
          return ee = "useLayoutEffect", ht(), Se(), hm(e, t);
        },
        useMemo: function(e, t) {
          ee = "useMemo", ht(), Se();
          var a = ke.current;
          ke.current = cl;
          try {
            return Sm(e, t);
          } finally {
            ke.current = a;
          }
        },
        useReducer: function(e, t, a) {
          ee = "useReducer", ht(), Se();
          var i = ke.current;
          ke.current = cl;
          try {
            return qg(e, t, a);
          } finally {
            ke.current = i;
          }
        },
        useRef: function(e) {
          return ee = "useRef", ht(), Se(), fm();
        },
        useState: function(e) {
          ee = "useState", ht(), Se();
          var t = ke.current;
          ke.current = cl;
          try {
            return Zg(e);
          } finally {
            ke.current = t;
          }
        },
        useDebugValue: function(e, t) {
          return ee = "useDebugValue", ht(), Se(), ym();
        },
        useDeferredValue: function(e) {
          return ee = "useDeferredValue", ht(), Se(), fC(e);
        },
        useTransition: function() {
          return ee = "useTransition", ht(), Se(), vC();
        },
        useMutableSource: function(e, t, a) {
          return ee = "useMutableSource", ht(), Se(), void 0;
        },
        useSyncExternalStore: function(e, t, a) {
          return ee = "useSyncExternalStore", ht(), Se(), sm(e, t);
        },
        useId: function() {
          return ee = "useId", ht(), Se(), Em();
        },
        unstable_isNewReconciler: ge
      };
    }
    var Yu = g.unstable_now, RC = 0, Tm = -1, Ap = -1, Rm = -1, cS = !1, wm = !1;
    function wC() {
      return cS;
    }
    function rx() {
      wm = !0;
    }
    function ax() {
      cS = !1, wm = !1;
    }
    function ix() {
      cS = wm, wm = !1;
    }
    function xC() {
      return RC;
    }
    function _C() {
      RC = Yu();
    }
    function fS(e) {
      Ap = Yu(), e.actualStartTime < 0 && (e.actualStartTime = Yu());
    }
    function kC(e) {
      Ap = -1;
    }
    function xm(e, t) {
      if (Ap >= 0) {
        var a = Yu() - Ap;
        e.actualDuration += a, t && (e.selfBaseDuration = a), Ap = -1;
      }
    }
    function Zl(e) {
      if (Tm >= 0) {
        var t = Yu() - Tm;
        Tm = -1;
        for (var a = e.return; a !== null; ) {
          switch (a.tag) {
            case A:
              var i = a.stateNode;
              i.effectDuration += t;
              return;
            case Rt:
              var o = a.stateNode;
              o.effectDuration += t;
              return;
          }
          a = a.return;
        }
      }
    }
    function dS(e) {
      if (Rm >= 0) {
        var t = Yu() - Rm;
        Rm = -1;
        for (var a = e.return; a !== null; ) {
          switch (a.tag) {
            case A:
              var i = a.stateNode;
              i !== null && (i.passiveEffectDuration += t);
              return;
            case Rt:
              var o = a.stateNode;
              o !== null && (o.passiveEffectDuration += t);
              return;
          }
          a = a.return;
        }
      }
    }
    function eo() {
      Tm = Yu();
    }
    function pS() {
      Rm = Yu();
    }
    function vS(e) {
      for (var t = e.child; t; )
        e.actualDuration += t.actualDuration, t = t.sibling;
    }
    function fl(e, t) {
      if (e && e.defaultProps) {
        var a = yt({}, t), i = e.defaultProps;
        for (var o in i)
          a[o] === void 0 && (a[o] = i[o]);
        return a;
      }
      return t;
    }
    var hS = {}, mS, yS, gS, SS, ES, DC, _m, CS, bS, TS, Up;
    {
      mS = /* @__PURE__ */ new Set(), yS = /* @__PURE__ */ new Set(), gS = /* @__PURE__ */ new Set(), SS = /* @__PURE__ */ new Set(), CS = /* @__PURE__ */ new Set(), ES = /* @__PURE__ */ new Set(), bS = /* @__PURE__ */ new Set(), TS = /* @__PURE__ */ new Set(), Up = /* @__PURE__ */ new Set();
      var OC = /* @__PURE__ */ new Set();
      _m = function(e, t) {
        if (!(e === null || typeof e == "function")) {
          var a = t + "_" + e;
          OC.has(a) || (OC.add(a), S("%s(...): Expected the last optional `callback` argument to be a function. Instead received: %s.", t, e));
        }
      }, DC = function(e, t) {
        if (t === void 0) {
          var a = Dt(e) || "Component";
          ES.has(a) || (ES.add(a), S("%s.getDerivedStateFromProps(): A valid state object (or null) must be returned. You have returned undefined.", a));
        }
      }, Object.defineProperty(hS, "_processChildContext", {
        enumerable: !1,
        value: function() {
          throw new Error("_processChildContext is not available in React 16+. This likely means you have multiple copies of React and are attempting to nest a React 15 tree inside a React 16 tree using unstable_renderSubtreeIntoContainer, which isn't supported. Try to make sure you have only one copy of React (and ideally, switch to ReactDOM.createPortal).");
        }
      }), Object.freeze(hS);
    }
    function RS(e, t, a, i) {
      var o = e.memoizedState, s = a(i, o);
      {
        if (e.mode & dn) {
          $n(!0);
          try {
            s = a(i, o);
          } finally {
            $n(!1);
          }
        }
        DC(t, s);
      }
      var f = s == null ? o : yt({}, o, s);
      if (e.memoizedState = f, e.lanes === ie) {
        var p = e.updateQueue;
        p.baseState = f;
      }
    }
    var wS = {
      isMounted: ha,
      enqueueSetState: function(e, t, a) {
        var i = mi(e), o = wa(), s = Ku(i), f = $o(o, s);
        f.payload = t, a != null && (_m(a, "setState"), f.callback = a);
        var p = Bu(i, f, s);
        p !== null && (fr(p, i, s, o), nm(p, i, s)), el(i, s);
      },
      enqueueReplaceState: function(e, t, a) {
        var i = mi(e), o = wa(), s = Ku(i), f = $o(o, s);
        f.tag = QE, f.payload = t, a != null && (_m(a, "replaceState"), f.callback = a);
        var p = Bu(i, f, s);
        p !== null && (fr(p, i, s, o), nm(p, i, s)), el(i, s);
      },
      enqueueForceUpdate: function(e, t) {
        var a = mi(e), i = wa(), o = Ku(a), s = $o(i, o);
        s.tag = Zh, t != null && (_m(t, "forceUpdate"), s.callback = t);
        var f = Bu(a, s, o);
        f !== null && (fr(f, a, o, i), nm(f, a, o)), xd(a, o);
      }
    };
    function MC(e, t, a, i, o, s, f) {
      var p = e.stateNode;
      if (typeof p.shouldComponentUpdate == "function") {
        var v = p.shouldComponentUpdate(i, s, f);
        {
          if (e.mode & dn) {
            $n(!0);
            try {
              v = p.shouldComponentUpdate(i, s, f);
            } finally {
              $n(!1);
            }
          }
          v === void 0 && S("%s.shouldComponentUpdate(): Returned undefined instead of a boolean value. Make sure to return true or false.", Dt(t) || "Component");
        }
        return v;
      }
      return t.prototype && t.prototype.isPureReactComponent ? !_n(a, i) || !_n(o, s) : !0;
    }
    function lx(e, t, a) {
      var i = e.stateNode;
      {
        var o = Dt(t) || "Component", s = i.render;
        s || (t.prototype && typeof t.prototype.render == "function" ? S("%s(...): No `render` method found on the returned component instance: did you accidentally return an object from the constructor?", o) : S("%s(...): No `render` method found on the returned component instance: you may have forgotten to define `render`.", o)), i.getInitialState && !i.getInitialState.isReactClassApproved && !i.state && S("getInitialState was defined on %s, a plain JavaScript class. This is only supported for classes created using React.createClass. Did you mean to define a state property instead?", o), i.getDefaultProps && !i.getDefaultProps.isReactClassApproved && S("getDefaultProps was defined on %s, a plain JavaScript class. This is only supported for classes created using React.createClass. Use a static property to define defaultProps instead.", o), i.propTypes && S("propTypes was defined as an instance property on %s. Use a static property to define propTypes instead.", o), i.contextType && S("contextType was defined as an instance property on %s. Use a static property to define contextType instead.", o), t.childContextTypes && !Up.has(t) && // Strict Mode has its own warning for legacy context, so we can skip
        // this one.
        (e.mode & dn) === Ce && (Up.add(t), S(`%s uses the legacy childContextTypes API which is no longer supported and will be removed in the next major release. Use React.createContext() instead

.Learn more about this warning here: https://reactjs.org/link/legacy-context`, o)), t.contextTypes && !Up.has(t) && // Strict Mode has its own warning for legacy context, so we can skip
        // this one.
        (e.mode & dn) === Ce && (Up.add(t), S(`%s uses the legacy contextTypes API which is no longer supported and will be removed in the next major release. Use React.createContext() with static contextType instead.

Learn more about this warning here: https://reactjs.org/link/legacy-context`, o)), i.contextTypes && S("contextTypes was defined as an instance property on %s. Use a static property to define contextTypes instead.", o), t.contextType && t.contextTypes && !bS.has(t) && (bS.add(t), S("%s declares both contextTypes and contextType static properties. The legacy contextTypes property will be ignored.", o)), typeof i.componentShouldUpdate == "function" && S("%s has a method called componentShouldUpdate(). Did you mean shouldComponentUpdate()? The name is phrased as a question because the function is expected to return a value.", o), t.prototype && t.prototype.isPureReactComponent && typeof i.shouldComponentUpdate < "u" && S("%s has a method called shouldComponentUpdate(). shouldComponentUpdate should not be used when extending React.PureComponent. Please extend React.Component if shouldComponentUpdate is used.", Dt(t) || "A pure component"), typeof i.componentDidUnmount == "function" && S("%s has a method called componentDidUnmount(). But there is no such lifecycle method. Did you mean componentWillUnmount()?", o), typeof i.componentDidReceiveProps == "function" && S("%s has a method called componentDidReceiveProps(). But there is no such lifecycle method. If you meant to update the state in response to changing props, use componentWillReceiveProps(). If you meant to fetch data or run side-effects or mutations after React has updated the UI, use componentDidUpdate().", o), typeof i.componentWillRecieveProps == "function" && S("%s has a method called componentWillRecieveProps(). Did you mean componentWillReceiveProps()?", o), typeof i.UNSAFE_componentWillRecieveProps == "function" && S("%s has a method called UNSAFE_componentWillRecieveProps(). Did you mean UNSAFE_componentWillReceiveProps()?", o);
        var f = i.props !== a;
        i.props !== void 0 && f && S("%s(...): When calling super() in `%s`, make sure to pass up the same props that your component's constructor was passed.", o, o), i.defaultProps && S("Setting defaultProps as an instance property on %s is not supported and will be ignored. Instead, define defaultProps as a static property on %s.", o, o), typeof i.getSnapshotBeforeUpdate == "function" && typeof i.componentDidUpdate != "function" && !gS.has(t) && (gS.add(t), S("%s: getSnapshotBeforeUpdate() should be used with componentDidUpdate(). This component defines getSnapshotBeforeUpdate() only.", Dt(t))), typeof i.getDerivedStateFromProps == "function" && S("%s: getDerivedStateFromProps() is defined as an instance method and will be ignored. Instead, declare it as a static method.", o), typeof i.getDerivedStateFromError == "function" && S("%s: getDerivedStateFromError() is defined as an instance method and will be ignored. Instead, declare it as a static method.", o), typeof t.getSnapshotBeforeUpdate == "function" && S("%s: getSnapshotBeforeUpdate() is defined as a static method and will be ignored. Instead, declare it as an instance method.", o);
        var p = i.state;
        p && (typeof p != "object" || At(p)) && S("%s.state: must be set to an object or null", o), typeof i.getChildContext == "function" && typeof t.childContextTypes != "object" && S("%s.getChildContext(): childContextTypes must be defined in order to use getChildContext().", o);
      }
    }
    function NC(e, t) {
      t.updater = wS, e.stateNode = t, Oc(t, e), t._reactInternalInstance = hS;
    }
    function LC(e, t, a) {
      var i = !1, o = si, s = si, f = t.contextType;
      if ("contextType" in t) {
        var p = (
          // Allow null for conditional declaration
          f === null || f !== void 0 && f.$$typeof === ue && f._context === void 0
        );
        if (!p && !TS.has(t)) {
          TS.add(t);
          var v = "";
          f === void 0 ? v = " However, it is set to undefined. This can be caused by a typo or by mixing up named and default imports. This can also happen due to a circular dependency, so try moving the createContext() call to a separate file." : typeof f != "object" ? v = " However, it is set to a " + typeof f + "." : f.$$typeof === _ ? v = " Did you accidentally pass the Context.Provider instead?" : f._context !== void 0 ? v = " Did you accidentally pass the Context.Consumer instead?" : v = " However, it is set to an object with keys {" + Object.keys(f).join(", ") + "}.", S("%s defines an invalid contextType. contextType should point to the Context object returned by React.createContext().%s", Dt(t) || "Component", v);
        }
      }
      if (typeof f == "object" && f !== null)
        s = Xn(f);
      else {
        o = Ef(e, t, !0);
        var E = t.contextTypes;
        i = E != null, s = i ? Cf(e, o) : si;
      }
      var C = new t(a, s);
      if (e.mode & dn) {
        $n(!0);
        try {
          C = new t(a, s);
        } finally {
          $n(!1);
        }
      }
      var M = e.memoizedState = C.state !== null && C.state !== void 0 ? C.state : null;
      NC(e, C);
      {
        if (typeof t.getDerivedStateFromProps == "function" && M === null) {
          var D = Dt(t) || "Component";
          yS.has(D) || (yS.add(D), S("`%s` uses `getDerivedStateFromProps` but its initial state is %s. This is not recommended. Instead, define the initial state by assigning an object to `this.state` in the constructor of `%s`. This ensures that `getDerivedStateFromProps` arguments have a consistent shape.", D, C.state === null ? "null" : "undefined", D));
        }
        if (typeof t.getDerivedStateFromProps == "function" || typeof C.getSnapshotBeforeUpdate == "function") {
          var B = null, $ = null, G = null;
          if (typeof C.componentWillMount == "function" && C.componentWillMount.__suppressDeprecationWarning !== !0 ? B = "componentWillMount" : typeof C.UNSAFE_componentWillMount == "function" && (B = "UNSAFE_componentWillMount"), typeof C.componentWillReceiveProps == "function" && C.componentWillReceiveProps.__suppressDeprecationWarning !== !0 ? $ = "componentWillReceiveProps" : typeof C.UNSAFE_componentWillReceiveProps == "function" && ($ = "UNSAFE_componentWillReceiveProps"), typeof C.componentWillUpdate == "function" && C.componentWillUpdate.__suppressDeprecationWarning !== !0 ? G = "componentWillUpdate" : typeof C.UNSAFE_componentWillUpdate == "function" && (G = "UNSAFE_componentWillUpdate"), B !== null || $ !== null || G !== null) {
            var Re = Dt(t) || "Component", et = typeof t.getDerivedStateFromProps == "function" ? "getDerivedStateFromProps()" : "getSnapshotBeforeUpdate()";
            SS.has(Re) || (SS.add(Re), S(`Unsafe legacy lifecycles will not be called for components using new component APIs.

%s uses %s but also contains the following legacy lifecycles:%s%s%s

The above lifecycles should be removed. Learn more about this warning here:
https://reactjs.org/link/unsafe-component-lifecycles`, Re, et, B !== null ? `
  ` + B : "", $ !== null ? `
  ` + $ : "", G !== null ? `
  ` + G : ""));
          }
        }
      }
      return i && bE(e, o, s), C;
    }
    function ox(e, t) {
      var a = t.state;
      typeof t.componentWillMount == "function" && t.componentWillMount(), typeof t.UNSAFE_componentWillMount == "function" && t.UNSAFE_componentWillMount(), a !== t.state && (S("%s.componentWillMount(): Assigning directly to this.state is deprecated (except inside a component's constructor). Use setState instead.", dt(e) || "Component"), wS.enqueueReplaceState(t, t.state, null));
    }
    function AC(e, t, a, i) {
      var o = t.state;
      if (typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(a, i), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(a, i), t.state !== o) {
        {
          var s = dt(e) || "Component";
          mS.has(s) || (mS.add(s), S("%s.componentWillReceiveProps(): Assigning directly to this.state is deprecated (except inside a component's constructor). Use setState instead.", s));
        }
        wS.enqueueReplaceState(t, t.state, null);
      }
    }
    function xS(e, t, a, i) {
      lx(e, t, a);
      var o = e.stateNode;
      o.props = a, o.state = e.memoizedState, o.refs = {}, Ug(e);
      var s = t.contextType;
      if (typeof s == "object" && s !== null)
        o.context = Xn(s);
      else {
        var f = Ef(e, t, !0);
        o.context = Cf(e, f);
      }
      {
        if (o.state === a) {
          var p = Dt(t) || "Component";
          CS.has(p) || (CS.add(p), S("%s: It is not recommended to assign props directly to state because updates to props won't be reflected in state. In most cases, it is better to use props directly.", p));
        }
        e.mode & dn && ul.recordLegacyContextWarning(e, o), ul.recordUnsafeLifecycleWarnings(e, o);
      }
      o.state = e.memoizedState;
      var v = t.getDerivedStateFromProps;
      if (typeof v == "function" && (RS(e, t, v, a), o.state = e.memoizedState), typeof t.getDerivedStateFromProps != "function" && typeof o.getSnapshotBeforeUpdate != "function" && (typeof o.UNSAFE_componentWillMount == "function" || typeof o.componentWillMount == "function") && (ox(e, o), rm(e, a, o, i), o.state = e.memoizedState), typeof o.componentDidMount == "function") {
        var E = He;
        E |= za, (e.mode & qr) !== Ce && (E |= Fa), e.flags |= E;
      }
    }
    function ux(e, t, a, i) {
      var o = e.stateNode, s = e.memoizedProps;
      o.props = s;
      var f = o.context, p = t.contextType, v = si;
      if (typeof p == "object" && p !== null)
        v = Xn(p);
      else {
        var E = Ef(e, t, !0);
        v = Cf(e, E);
      }
      var C = t.getDerivedStateFromProps, M = typeof C == "function" || typeof o.getSnapshotBeforeUpdate == "function";
      !M && (typeof o.UNSAFE_componentWillReceiveProps == "function" || typeof o.componentWillReceiveProps == "function") && (s !== a || f !== v) && AC(e, o, a, v), KE();
      var D = e.memoizedState, B = o.state = D;
      if (rm(e, a, o, i), B = e.memoizedState, s === a && D === B && !jh() && !am()) {
        if (typeof o.componentDidMount == "function") {
          var $ = He;
          $ |= za, (e.mode & qr) !== Ce && ($ |= Fa), e.flags |= $;
        }
        return !1;
      }
      typeof C == "function" && (RS(e, t, C, a), B = e.memoizedState);
      var G = am() || MC(e, t, s, a, D, B, v);
      if (G) {
        if (!M && (typeof o.UNSAFE_componentWillMount == "function" || typeof o.componentWillMount == "function") && (typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount()), typeof o.componentDidMount == "function") {
          var Re = He;
          Re |= za, (e.mode & qr) !== Ce && (Re |= Fa), e.flags |= Re;
        }
      } else {
        if (typeof o.componentDidMount == "function") {
          var et = He;
          et |= za, (e.mode & qr) !== Ce && (et |= Fa), e.flags |= et;
        }
        e.memoizedProps = a, e.memoizedState = B;
      }
      return o.props = a, o.state = B, o.context = v, G;
    }
    function sx(e, t, a, i, o) {
      var s = t.stateNode;
      GE(e, t);
      var f = t.memoizedProps, p = t.type === t.elementType ? f : fl(t.type, f);
      s.props = p;
      var v = t.pendingProps, E = s.context, C = a.contextType, M = si;
      if (typeof C == "object" && C !== null)
        M = Xn(C);
      else {
        var D = Ef(t, a, !0);
        M = Cf(t, D);
      }
      var B = a.getDerivedStateFromProps, $ = typeof B == "function" || typeof s.getSnapshotBeforeUpdate == "function";
      !$ && (typeof s.UNSAFE_componentWillReceiveProps == "function" || typeof s.componentWillReceiveProps == "function") && (f !== v || E !== M) && AC(t, s, i, M), KE();
      var G = t.memoizedState, Re = s.state = G;
      if (rm(t, i, s, o), Re = t.memoizedState, f === v && G === Re && !jh() && !am() && !pe)
        return typeof s.componentDidUpdate == "function" && (f !== e.memoizedProps || G !== e.memoizedState) && (t.flags |= He), typeof s.getSnapshotBeforeUpdate == "function" && (f !== e.memoizedProps || G !== e.memoizedState) && (t.flags |= Fn), !1;
      typeof B == "function" && (RS(t, a, B, i), Re = t.memoizedState);
      var et = am() || MC(t, a, p, i, G, Re, M) || // TODO: In some cases, we'll end up checking if context has changed twice,
      // both before and after `shouldComponentUpdate` has been called. Not ideal,
      // but I'm loath to refactor this function. This only happens for memoized
      // components so it's not that common.
      pe;
      return et ? (!$ && (typeof s.UNSAFE_componentWillUpdate == "function" || typeof s.componentWillUpdate == "function") && (typeof s.componentWillUpdate == "function" && s.componentWillUpdate(i, Re, M), typeof s.UNSAFE_componentWillUpdate == "function" && s.UNSAFE_componentWillUpdate(i, Re, M)), typeof s.componentDidUpdate == "function" && (t.flags |= He), typeof s.getSnapshotBeforeUpdate == "function" && (t.flags |= Fn)) : (typeof s.componentDidUpdate == "function" && (f !== e.memoizedProps || G !== e.memoizedState) && (t.flags |= He), typeof s.getSnapshotBeforeUpdate == "function" && (f !== e.memoizedProps || G !== e.memoizedState) && (t.flags |= Fn), t.memoizedProps = i, t.memoizedState = Re), s.props = i, s.state = Re, s.context = M, et;
    }
    function fc(e, t) {
      return {
        value: e,
        source: t,
        stack: Xo(t),
        digest: null
      };
    }
    function _S(e, t, a) {
      return {
        value: e,
        source: null,
        stack: a ?? null,
        digest: t ?? null
      };
    }
    function cx(e, t) {
      return !0;
    }
    function kS(e, t) {
      try {
        var a = cx(e, t);
        if (a === !1)
          return;
        var i = t.value, o = t.source, s = t.stack, f = s !== null ? s : "";
        if (i != null && i._suppressLogging) {
          if (e.tag === Q)
            return;
          console.error(i);
        }
        var p = o ? dt(o) : null, v = p ? "The above error occurred in the <" + p + "> component:" : "The above error occurred in one of your React components:", E;
        if (e.tag === A)
          E = `Consider adding an error boundary to your tree to customize error handling behavior.
Visit https://reactjs.org/link/error-boundaries to learn more about error boundaries.`;
        else {
          var C = dt(e) || "Anonymous";
          E = "React will try to recreate this component tree from scratch " + ("using the error boundary you provided, " + C + ".");
        }
        var M = v + `
` + f + `

` + ("" + E);
        console.error(M);
      } catch (D) {
        setTimeout(function() {
          throw D;
        });
      }
    }
    var fx = typeof WeakMap == "function" ? WeakMap : Map;
    function UC(e, t, a) {
      var i = $o(on, a);
      i.tag = Lg, i.payload = {
        element: null
      };
      var o = t.value;
      return i.callback = function() {
        rk(o), kS(e, t);
      }, i;
    }
    function DS(e, t, a) {
      var i = $o(on, a);
      i.tag = Lg;
      var o = e.type.getDerivedStateFromError;
      if (typeof o == "function") {
        var s = t.value;
        i.payload = function() {
          return o(s);
        }, i.callback = function() {
          Wb(e), kS(e, t);
        };
      }
      var f = e.stateNode;
      return f !== null && typeof f.componentDidCatch == "function" && (i.callback = function() {
        Wb(e), kS(e, t), typeof o != "function" && tk(this);
        var v = t.value, E = t.stack;
        this.componentDidCatch(v, {
          componentStack: E !== null ? E : ""
        }), typeof o != "function" && (Jr(e.lanes, Ve) || S("%s: Error boundaries should implement getDerivedStateFromError(). In that method, return a state update to display an error message or fallback UI.", dt(e) || "Unknown"));
      }), i;
    }
    function zC(e, t, a) {
      var i = e.pingCache, o;
      if (i === null ? (i = e.pingCache = new fx(), o = /* @__PURE__ */ new Set(), i.set(t, o)) : (o = i.get(t), o === void 0 && (o = /* @__PURE__ */ new Set(), i.set(t, o))), !o.has(a)) {
        o.add(a);
        var s = ak.bind(null, e, t, a);
        ma && Jp(e, a), t.then(s, s);
      }
    }
    function dx(e, t, a, i) {
      var o = e.updateQueue;
      if (o === null) {
        var s = /* @__PURE__ */ new Set();
        s.add(a), e.updateQueue = s;
      } else
        o.add(a);
    }
    function px(e, t) {
      var a = e.tag;
      if ((e.mode & qe) === Ce && (a === te || a === Ge || a === it)) {
        var i = e.alternate;
        i ? (e.updateQueue = i.updateQueue, e.memoizedState = i.memoizedState, e.lanes = i.lanes) : (e.updateQueue = null, e.memoizedState = null);
      }
    }
    function FC(e) {
      var t = e;
      do {
        if (t.tag === Ne && Qw(t))
          return t;
        t = t.return;
      } while (t !== null);
      return null;
    }
    function jC(e, t, a, i, o) {
      if ((e.mode & qe) === Ce) {
        if (e === t)
          e.flags |= tr;
        else {
          if (e.flags |= vt, a.flags |= Mc, a.flags &= ~(Hv | Ml), a.tag === Q) {
            var s = a.alternate;
            if (s === null)
              a.tag = jt;
            else {
              var f = $o(on, Ve);
              f.tag = Zh, Bu(a, f, Ve);
            }
          }
          a.lanes = gt(a.lanes, Ve);
        }
        return e;
      }
      return e.flags |= tr, e.lanes = o, e;
    }
    function vx(e, t, a, i, o) {
      if (a.flags |= Ml, ma && Jp(e, o), i !== null && typeof i == "object" && typeof i.then == "function") {
        var s = i;
        px(a), Mr() && a.mode & qe && DE();
        var f = FC(t);
        if (f !== null) {
          f.flags &= ~Tr, jC(f, t, a, e, o), f.mode & qe && zC(e, s, o), dx(f, e, s);
          return;
        } else {
          if (!Nd(o)) {
            zC(e, s, o), u0();
            return;
          }
          var p = new Error("A component suspended while responding to synchronous input. This will cause the UI to be replaced with a loading indicator. To fix, updates that suspend should be wrapped with startTransition.");
          i = p;
        }
      } else if (Mr() && a.mode & qe) {
        DE();
        var v = FC(t);
        if (v !== null) {
          (v.flags & tr) === Ze && (v.flags |= Tr), jC(v, t, a, e, o), Cg(fc(i, a));
          return;
        }
      }
      i = fc(i, a), Q_(i);
      var E = t;
      do {
        switch (E.tag) {
          case A: {
            var C = i;
            E.flags |= tr;
            var M = Ru(o);
            E.lanes = gt(E.lanes, M);
            var D = UC(E, C, M);
            zg(E, D);
            return;
          }
          case Q:
            var B = i, $ = E.type, G = E.stateNode;
            if ((E.flags & vt) === Ze && (typeof $.getDerivedStateFromError == "function" || G !== null && typeof G.componentDidCatch == "function" && !Fb(G))) {
              E.flags |= tr;
              var Re = Ru(o);
              E.lanes = gt(E.lanes, Re);
              var et = DS(E, B, Re);
              zg(E, et);
              return;
            }
            break;
        }
        E = E.return;
      } while (E !== null);
    }
    function hx() {
      return null;
    }
    var zp = T.ReactCurrentOwner, dl = !1, OS, Fp, MS, NS, LS, dc, AS, km, jp;
    OS = {}, Fp = {}, MS = {}, NS = {}, LS = {}, dc = !1, AS = {}, km = {}, jp = {};
    function Ta(e, t, a, i) {
      e === null ? t.child = BE(t, null, a, i) : t.child = wf(t, e.child, a, i);
    }
    function mx(e, t, a, i) {
      t.child = wf(t, e.child, null, i), t.child = wf(t, null, a, i);
    }
    function PC(e, t, a, i, o) {
      if (t.type !== t.elementType) {
        var s = a.propTypes;
        s && ll(
          s,
          i,
          // Resolved props
          "prop",
          Dt(a)
        );
      }
      var f = a.render, p = t.ref, v, E;
      _f(t, o), ya(t);
      {
        if (zp.current = t, er(!0), v = Lf(e, t, f, i, p, o), E = Af(), t.mode & dn) {
          $n(!0);
          try {
            v = Lf(e, t, f, i, p, o), E = Af();
          } finally {
            $n(!1);
          }
        }
        er(!1);
      }
      return ga(), e !== null && !dl ? (tC(e, t, o), Io(e, t, o)) : (Mr() && E && hg(t), t.flags |= ri, Ta(e, t, v, o), t.child);
    }
    function HC(e, t, a, i, o) {
      if (e === null) {
        var s = a.type;
        if (Ck(s) && a.compare === null && // SimpleMemoComponent codepath doesn't resolve outer props either.
        a.defaultProps === void 0) {
          var f = s;
          return f = Vf(s), t.tag = it, t.type = f, FS(t, s), BC(e, t, f, i, o);
        }
        {
          var p = s.propTypes;
          if (p && ll(
            p,
            i,
            // Resolved props
            "prop",
            Dt(s)
          ), a.defaultProps !== void 0) {
            var v = Dt(s) || "Unknown";
            jp[v] || (S("%s: Support for defaultProps will be removed from memo components in a future major release. Use JavaScript default parameters instead.", v), jp[v] = !0);
          }
        }
        var E = S0(a.type, null, i, t, t.mode, o);
        return E.ref = t.ref, E.return = t, t.child = E, E;
      }
      {
        var C = a.type, M = C.propTypes;
        M && ll(
          M,
          i,
          // Resolved props
          "prop",
          Dt(C)
        );
      }
      var D = e.child, B = $S(e, o);
      if (!B) {
        var $ = D.memoizedProps, G = a.compare;
        if (G = G !== null ? G : _n, G($, i) && e.ref === t.ref)
          return Io(e, t, o);
      }
      t.flags |= ri;
      var Re = yc(D, i);
      return Re.ref = t.ref, Re.return = t, t.child = Re, Re;
    }
    function BC(e, t, a, i, o) {
      if (t.type !== t.elementType) {
        var s = t.elementType;
        if (s.$$typeof === tt) {
          var f = s, p = f._payload, v = f._init;
          try {
            s = v(p);
          } catch {
            s = null;
          }
          var E = s && s.propTypes;
          E && ll(
            E,
            i,
            // Resolved (SimpleMemoComponent has no defaultProps)
            "prop",
            Dt(s)
          );
        }
      }
      if (e !== null) {
        var C = e.memoizedProps;
        if (_n(C, i) && e.ref === t.ref && // Prevent bailout if the implementation changed due to hot reload.
        t.type === e.type)
          if (dl = !1, t.pendingProps = i = C, $S(e, o))
            (e.flags & Mc) !== Ze && (dl = !0);
          else return t.lanes = e.lanes, Io(e, t, o);
      }
      return US(e, t, a, i, o);
    }
    function VC(e, t, a) {
      var i = t.pendingProps, o = i.children, s = e !== null ? e.memoizedState : null;
      if (i.mode === "hidden" || N)
        if ((t.mode & qe) === Ce) {
          var f = {
            baseLanes: ie,
            cachePool: null,
            transitions: null
          };
          t.memoizedState = f, Bm(t, a);
        } else if (Jr(a, Sa)) {
          var M = {
            baseLanes: ie,
            cachePool: null,
            transitions: null
          };
          t.memoizedState = M;
          var D = s !== null ? s.baseLanes : a;
          Bm(t, D);
        } else {
          var p = null, v;
          if (s !== null) {
            var E = s.baseLanes;
            v = gt(E, a);
          } else
            v = a;
          t.lanes = t.childLanes = Sa;
          var C = {
            baseLanes: v,
            cachePool: p,
            transitions: null
          };
          return t.memoizedState = C, t.updateQueue = null, Bm(t, v), null;
        }
      else {
        var B;
        s !== null ? (B = gt(s.baseLanes, a), t.memoizedState = null) : B = a, Bm(t, B);
      }
      return Ta(e, t, o, a), t.child;
    }
    function yx(e, t, a) {
      var i = t.pendingProps;
      return Ta(e, t, i, a), t.child;
    }
    function gx(e, t, a) {
      var i = t.pendingProps.children;
      return Ta(e, t, i, a), t.child;
    }
    function Sx(e, t, a) {
      {
        t.flags |= He;
        {
          var i = t.stateNode;
          i.effectDuration = 0, i.passiveEffectDuration = 0;
        }
      }
      var o = t.pendingProps, s = o.children;
      return Ta(e, t, s, a), t.child;
    }
    function $C(e, t) {
      var a = t.ref;
      (e === null && a !== null || e !== null && e.ref !== a) && (t.flags |= pa, t.flags |= gi);
    }
    function US(e, t, a, i, o) {
      if (t.type !== t.elementType) {
        var s = a.propTypes;
        s && ll(
          s,
          i,
          // Resolved props
          "prop",
          Dt(a)
        );
      }
      var f;
      {
        var p = Ef(t, a, !0);
        f = Cf(t, p);
      }
      var v, E;
      _f(t, o), ya(t);
      {
        if (zp.current = t, er(!0), v = Lf(e, t, a, i, f, o), E = Af(), t.mode & dn) {
          $n(!0);
          try {
            v = Lf(e, t, a, i, f, o), E = Af();
          } finally {
            $n(!1);
          }
        }
        er(!1);
      }
      return ga(), e !== null && !dl ? (tC(e, t, o), Io(e, t, o)) : (Mr() && E && hg(t), t.flags |= ri, Ta(e, t, v, o), t.child);
    }
    function IC(e, t, a, i, o) {
      {
        switch (zk(t)) {
          case !1: {
            var s = t.stateNode, f = t.type, p = new f(t.memoizedProps, s.context), v = p.state;
            s.updater.enqueueSetState(s, v, null);
            break;
          }
          case !0: {
            t.flags |= vt, t.flags |= tr;
            var E = new Error("Simulated error coming from DevTools"), C = Ru(o);
            t.lanes = gt(t.lanes, C);
            var M = DS(t, fc(E, t), C);
            zg(t, M);
            break;
          }
        }
        if (t.type !== t.elementType) {
          var D = a.propTypes;
          D && ll(
            D,
            i,
            // Resolved props
            "prop",
            Dt(a)
          );
        }
      }
      var B;
      Kl(a) ? (B = !0, Hh(t)) : B = !1, _f(t, o);
      var $ = t.stateNode, G;
      $ === null ? (Om(e, t), LC(t, a, i), xS(t, a, i, o), G = !0) : e === null ? G = ux(t, a, i, o) : G = sx(e, t, a, i, o);
      var Re = zS(e, t, a, G, B, o);
      {
        var et = t.stateNode;
        G && et.props !== i && (dc || S("It looks like %s is reassigning its own `this.props` while rendering. This is not supported and can lead to confusing bugs.", dt(t) || "a component"), dc = !0);
      }
      return Re;
    }
    function zS(e, t, a, i, o, s) {
      $C(e, t);
      var f = (t.flags & vt) !== Ze;
      if (!i && !f)
        return o && wE(t, a, !1), Io(e, t, s);
      var p = t.stateNode;
      zp.current = t;
      var v;
      if (f && typeof a.getDerivedStateFromError != "function")
        v = null, kC();
      else {
        ya(t);
        {
          if (er(!0), v = p.render(), t.mode & dn) {
            $n(!0);
            try {
              p.render();
            } finally {
              $n(!1);
            }
          }
          er(!1);
        }
        ga();
      }
      return t.flags |= ri, e !== null && f ? mx(e, t, v, s) : Ta(e, t, v, s), t.memoizedState = p.state, o && wE(t, a, !0), t.child;
    }
    function YC(e) {
      var t = e.stateNode;
      t.pendingContext ? TE(e, t.pendingContext, t.pendingContext !== t.context) : t.context && TE(e, t.context, !1), Fg(e, t.containerInfo);
    }
    function Ex(e, t, a) {
      if (YC(t), e === null)
        throw new Error("Should have a current fiber. This is a bug in React.");
      var i = t.pendingProps, o = t.memoizedState, s = o.element;
      GE(e, t), rm(t, i, null, a);
      var f = t.memoizedState;
      t.stateNode;
      var p = f.element;
      if (o.isDehydrated) {
        var v = {
          element: p,
          isDehydrated: !1,
          cache: f.cache,
          pendingSuspenseBoundaries: f.pendingSuspenseBoundaries,
          transitions: f.transitions
        }, E = t.updateQueue;
        if (E.baseState = v, t.memoizedState = v, t.flags & Tr) {
          var C = fc(new Error("There was an error while hydrating. Because the error happened outside of a Suspense boundary, the entire root will switch to client rendering."), t);
          return WC(e, t, p, a, C);
        } else if (p !== s) {
          var M = fc(new Error("This root received an early update, before anything was able hydrate. Switched the entire root to client rendering."), t);
          return WC(e, t, p, a, M);
        } else {
          Tw(t);
          var D = BE(t, null, p, a);
          t.child = D;
          for (var B = D; B; )
            B.flags = B.flags & ~rn | yi, B = B.sibling;
        }
      } else {
        if (Rf(), p === s)
          return Io(e, t, a);
        Ta(e, t, p, a);
      }
      return t.child;
    }
    function WC(e, t, a, i, o) {
      return Rf(), Cg(o), t.flags |= Tr, Ta(e, t, a, i), t.child;
    }
    function Cx(e, t, a) {
      JE(t), e === null && Eg(t);
      var i = t.type, o = t.pendingProps, s = e !== null ? e.memoizedProps : null, f = o.children, p = tg(i, o);
      return p ? f = null : s !== null && tg(i, s) && (t.flags |= Ua), $C(e, t), Ta(e, t, f, a), t.child;
    }
    function bx(e, t) {
      return e === null && Eg(t), null;
    }
    function Tx(e, t, a, i) {
      Om(e, t);
      var o = t.pendingProps, s = a, f = s._payload, p = s._init, v = p(f);
      t.type = v;
      var E = t.tag = bk(v), C = fl(v, o), M;
      switch (E) {
        case te:
          return FS(t, v), t.type = v = Vf(v), M = US(null, t, v, C, i), M;
        case Q:
          return t.type = v = p0(v), M = IC(null, t, v, C, i), M;
        case Ge:
          return t.type = v = v0(v), M = PC(null, t, v, C, i), M;
        case lt: {
          if (t.type !== t.elementType) {
            var D = v.propTypes;
            D && ll(
              D,
              C,
              // Resolved for outer only
              "prop",
              Dt(v)
            );
          }
          return M = HC(
            null,
            t,
            v,
            fl(v.type, C),
            // The inner type can have defaults too
            i
          ), M;
        }
      }
      var B = "";
      throw v !== null && typeof v == "object" && v.$$typeof === tt && (B = " Did you wrap a component in React.lazy() more than once?"), new Error("Element type is invalid. Received a promise that resolves to: " + v + ". " + ("Lazy element type must resolve to a class or function." + B));
    }
    function Rx(e, t, a, i, o) {
      Om(e, t), t.tag = Q;
      var s;
      return Kl(a) ? (s = !0, Hh(t)) : s = !1, _f(t, o), LC(t, a, i), xS(t, a, i, o), zS(null, t, a, !0, s, o);
    }
    function wx(e, t, a, i) {
      Om(e, t);
      var o = t.pendingProps, s;
      {
        var f = Ef(t, a, !1);
        s = Cf(t, f);
      }
      _f(t, i);
      var p, v;
      ya(t);
      {
        if (a.prototype && typeof a.prototype.render == "function") {
          var E = Dt(a) || "Unknown";
          OS[E] || (S("The <%s /> component appears to have a render method, but doesn't extend React.Component. This is likely to cause errors. Change %s to extend React.Component instead.", E, E), OS[E] = !0);
        }
        t.mode & dn && ul.recordLegacyContextWarning(t, null), er(!0), zp.current = t, p = Lf(null, t, a, o, s, i), v = Af(), er(!1);
      }
      if (ga(), t.flags |= ri, typeof p == "object" && p !== null && typeof p.render == "function" && p.$$typeof === void 0) {
        var C = Dt(a) || "Unknown";
        Fp[C] || (S("The <%s /> component appears to be a function component that returns a class instance. Change %s to a class that extends React.Component instead. If you can't use a class try assigning the prototype on the function as a workaround. `%s.prototype = React.Component.prototype`. Don't use an arrow function since it cannot be called with `new` by React.", C, C, C), Fp[C] = !0);
      }
      if (
        // Run these checks in production only if the flag is off.
        // Eventually we'll delete this branch altogether.
        typeof p == "object" && p !== null && typeof p.render == "function" && p.$$typeof === void 0
      ) {
        {
          var M = Dt(a) || "Unknown";
          Fp[M] || (S("The <%s /> component appears to be a function component that returns a class instance. Change %s to a class that extends React.Component instead. If you can't use a class try assigning the prototype on the function as a workaround. `%s.prototype = React.Component.prototype`. Don't use an arrow function since it cannot be called with `new` by React.", M, M, M), Fp[M] = !0);
        }
        t.tag = Q, t.memoizedState = null, t.updateQueue = null;
        var D = !1;
        return Kl(a) ? (D = !0, Hh(t)) : D = !1, t.memoizedState = p.state !== null && p.state !== void 0 ? p.state : null, Ug(t), NC(t, p), xS(t, a, o, i), zS(null, t, a, !0, D, i);
      } else {
        if (t.tag = te, t.mode & dn) {
          $n(!0);
          try {
            p = Lf(null, t, a, o, s, i), v = Af();
          } finally {
            $n(!1);
          }
        }
        return Mr() && v && hg(t), Ta(null, t, p, i), FS(t, a), t.child;
      }
    }
    function FS(e, t) {
      {
        if (t && t.childContextTypes && S("%s(...): childContextTypes cannot be defined on a function component.", t.displayName || t.name || "Component"), e.ref !== null) {
          var a = "", i = Na();
          i && (a += `

Check the render method of \`` + i + "`.");
          var o = i || "", s = e._debugSource;
          s && (o = s.fileName + ":" + s.lineNumber), LS[o] || (LS[o] = !0, S("Function components cannot be given refs. Attempts to access this ref will fail. Did you mean to use React.forwardRef()?%s", a));
        }
        if (t.defaultProps !== void 0) {
          var f = Dt(t) || "Unknown";
          jp[f] || (S("%s: Support for defaultProps will be removed from function components in a future major release. Use JavaScript default parameters instead.", f), jp[f] = !0);
        }
        if (typeof t.getDerivedStateFromProps == "function") {
          var p = Dt(t) || "Unknown";
          NS[p] || (S("%s: Function components do not support getDerivedStateFromProps.", p), NS[p] = !0);
        }
        if (typeof t.contextType == "object" && t.contextType !== null) {
          var v = Dt(t) || "Unknown";
          MS[v] || (S("%s: Function components do not support contextType.", v), MS[v] = !0);
        }
      }
    }
    var jS = {
      dehydrated: null,
      treeContext: null,
      retryLane: an
    };
    function PS(e) {
      return {
        baseLanes: e,
        cachePool: hx(),
        transitions: null
      };
    }
    function xx(e, t) {
      var a = null;
      return {
        baseLanes: gt(e.baseLanes, t),
        cachePool: a,
        transitions: e.transitions
      };
    }
    function _x(e, t, a, i) {
      if (t !== null) {
        var o = t.memoizedState;
        if (o === null)
          return !1;
      }
      return Hg(e, _p);
    }
    function kx(e, t) {
      return wu(e.childLanes, t);
    }
    function QC(e, t, a) {
      var i = t.pendingProps;
      Fk(t) && (t.flags |= vt);
      var o = sl.current, s = !1, f = (t.flags & vt) !== Ze;
      if (f || _x(o, e) ? (s = !0, t.flags &= ~vt) : (e === null || e.memoizedState !== null) && (o = Ww(o, eC)), o = Df(o), $u(t, o), e === null) {
        Eg(t);
        var p = t.memoizedState;
        if (p !== null) {
          var v = p.dehydrated;
          if (v !== null)
            return Lx(t, v);
        }
        var E = i.children, C = i.fallback;
        if (s) {
          var M = Dx(t, E, C, a), D = t.child;
          return D.memoizedState = PS(a), t.memoizedState = jS, M;
        } else
          return HS(t, E);
      } else {
        var B = e.memoizedState;
        if (B !== null) {
          var $ = B.dehydrated;
          if ($ !== null)
            return Ax(e, t, f, i, $, B, a);
        }
        if (s) {
          var G = i.fallback, Re = i.children, et = Mx(e, t, Re, G, a), Ie = t.child, Lt = e.child.memoizedState;
          return Ie.memoizedState = Lt === null ? PS(a) : xx(Lt, a), Ie.childLanes = kx(e, a), t.memoizedState = jS, et;
        } else {
          var _t = i.children, F = Ox(e, t, _t, a);
          return t.memoizedState = null, F;
        }
      }
    }
    function HS(e, t, a) {
      var i = e.mode, o = {
        mode: "visible",
        children: t
      }, s = BS(o, i);
      return s.return = e, e.child = s, s;
    }
    function Dx(e, t, a, i) {
      var o = e.mode, s = e.child, f = {
        mode: "hidden",
        children: t
      }, p, v;
      return (o & qe) === Ce && s !== null ? (p = s, p.childLanes = ie, p.pendingProps = f, e.mode & pt && (p.actualDuration = 0, p.actualStartTime = -1, p.selfBaseDuration = 0, p.treeBaseDuration = 0), v = Xu(a, o, i, null)) : (p = BS(f, o), v = Xu(a, o, i, null)), p.return = e, v.return = e, p.sibling = v, e.child = p, v;
    }
    function BS(e, t, a) {
      return Gb(e, t, ie, null);
    }
    function GC(e, t) {
      return yc(e, t);
    }
    function Ox(e, t, a, i) {
      var o = e.child, s = o.sibling, f = GC(o, {
        mode: "visible",
        children: a
      });
      if ((t.mode & qe) === Ce && (f.lanes = i), f.return = t, f.sibling = null, s !== null) {
        var p = t.deletions;
        p === null ? (t.deletions = [s], t.flags |= Ht) : p.push(s);
      }
      return t.child = f, f;
    }
    function Mx(e, t, a, i, o) {
      var s = t.mode, f = e.child, p = f.sibling, v = {
        mode: "hidden",
        children: a
      }, E;
      if (
        // In legacy mode, we commit the primary tree as if it successfully
        // completed, even though it's in an inconsistent state.
        (s & qe) === Ce && // Make sure we're on the second pass, i.e. the primary child fragment was
        // already cloned. In legacy mode, the only case where this isn't true is
        // when DevTools forces us to display a fallback; we skip the first render
        // pass entirely and go straight to rendering the fallback. (In Concurrent
        // Mode, SuspenseList can also trigger this scenario, but this is a legacy-
        // only codepath.)
        t.child !== f
      ) {
        var C = t.child;
        E = C, E.childLanes = ie, E.pendingProps = v, t.mode & pt && (E.actualDuration = 0, E.actualStartTime = -1, E.selfBaseDuration = f.selfBaseDuration, E.treeBaseDuration = f.treeBaseDuration), t.deletions = null;
      } else
        E = GC(f, v), E.subtreeFlags = f.subtreeFlags & nr;
      var M;
      return p !== null ? M = yc(p, i) : (M = Xu(i, s, o, null), M.flags |= rn), M.return = t, E.return = t, E.sibling = M, t.child = E, M;
    }
    function Dm(e, t, a, i) {
      i !== null && Cg(i), wf(t, e.child, null, a);
      var o = t.pendingProps, s = o.children, f = HS(t, s);
      return f.flags |= rn, t.memoizedState = null, f;
    }
    function Nx(e, t, a, i, o) {
      var s = t.mode, f = {
        mode: "visible",
        children: a
      }, p = BS(f, s), v = Xu(i, s, o, null);
      return v.flags |= rn, p.return = t, v.return = t, p.sibling = v, t.child = p, (t.mode & qe) !== Ce && wf(t, e.child, null, o), v;
    }
    function Lx(e, t, a) {
      return (e.mode & qe) === Ce ? (S("Cannot hydrate Suspense in legacy mode. Switch from ReactDOM.hydrate(element, container) to ReactDOMClient.hydrateRoot(container, <App />).render(element) or remove the Suspense components from the server rendered components."), e.lanes = Ve) : ig(t) ? e.lanes = tl : e.lanes = Sa, null;
    }
    function Ax(e, t, a, i, o, s, f) {
      if (a)
        if (t.flags & Tr) {
          t.flags &= ~Tr;
          var F = _S(new Error("There was an error while hydrating this Suspense boundary. Switched to client rendering."));
          return Dm(e, t, f, F);
        } else {
          if (t.memoizedState !== null)
            return t.child = e.child, t.flags |= vt, null;
          var K = i.children, j = i.fallback, de = Nx(e, t, K, j, f), Me = t.child;
          return Me.memoizedState = PS(f), t.memoizedState = jS, de;
        }
      else {
        if (Cw(), (t.mode & qe) === Ce)
          return Dm(
            e,
            t,
            f,
            // TODO: When we delete legacy mode, we should make this error argument
            // required — every concurrent mode path that causes hydration to
            // de-opt to client rendering should have an error message.
            null
          );
        if (ig(o)) {
          var p, v, E;
          {
            var C = j1(o);
            p = C.digest, v = C.message, E = C.stack;
          }
          var M;
          v ? M = new Error(v) : M = new Error("The server could not finish this Suspense boundary, likely due to an error during server rendering. Switched to client rendering.");
          var D = _S(M, p, E);
          return Dm(e, t, f, D);
        }
        var B = Jr(f, e.childLanes);
        if (dl || B) {
          var $ = Hm();
          if ($ !== null) {
            var G = jd($, f);
            if (G !== an && G !== s.retryLane) {
              s.retryLane = G;
              var Re = on;
              $a(e, G), fr($, e, G, Re);
            }
          }
          u0();
          var et = _S(new Error("This Suspense boundary received an update before it finished hydrating. This caused the boundary to switch to client rendering. The usual way to fix this is to wrap the original update in startTransition."));
          return Dm(e, t, f, et);
        } else if (yE(o)) {
          t.flags |= vt, t.child = e.child;
          var Ie = ik.bind(null, e);
          return P1(o, Ie), null;
        } else {
          Rw(t, o, s.treeContext);
          var Lt = i.children, _t = HS(t, Lt);
          return _t.flags |= yi, _t;
        }
      }
    }
    function KC(e, t, a) {
      e.lanes = gt(e.lanes, t);
      var i = e.alternate;
      i !== null && (i.lanes = gt(i.lanes, t)), Mg(e.return, t, a);
    }
    function Ux(e, t, a) {
      for (var i = t; i !== null; ) {
        if (i.tag === Ne) {
          var o = i.memoizedState;
          o !== null && KC(i, a, e);
        } else if (i.tag === W)
          KC(i, a, e);
        else if (i.child !== null) {
          i.child.return = i, i = i.child;
          continue;
        }
        if (i === e)
          return;
        for (; i.sibling === null; ) {
          if (i.return === null || i.return === e)
            return;
          i = i.return;
        }
        i.sibling.return = i.return, i = i.sibling;
      }
    }
    function zx(e) {
      for (var t = e, a = null; t !== null; ) {
        var i = t.alternate;
        i !== null && om(i) === null && (a = t), t = t.sibling;
      }
      return a;
    }
    function Fx(e) {
      if (e !== void 0 && e !== "forwards" && e !== "backwards" && e !== "together" && !AS[e])
        if (AS[e] = !0, typeof e == "string")
          switch (e.toLowerCase()) {
            case "together":
            case "forwards":
            case "backwards": {
              S('"%s" is not a valid value for revealOrder on <SuspenseList />. Use lowercase "%s" instead.', e, e.toLowerCase());
              break;
            }
            case "forward":
            case "backward": {
              S('"%s" is not a valid value for revealOrder on <SuspenseList />. React uses the -s suffix in the spelling. Use "%ss" instead.', e, e.toLowerCase());
              break;
            }
            default:
              S('"%s" is not a supported revealOrder on <SuspenseList />. Did you mean "together", "forwards" or "backwards"?', e);
              break;
          }
        else
          S('%s is not a supported value for revealOrder on <SuspenseList />. Did you mean "together", "forwards" or "backwards"?', e);
    }
    function jx(e, t) {
      e !== void 0 && !km[e] && (e !== "collapsed" && e !== "hidden" ? (km[e] = !0, S('"%s" is not a supported value for tail on <SuspenseList />. Did you mean "collapsed" or "hidden"?', e)) : t !== "forwards" && t !== "backwards" && (km[e] = !0, S('<SuspenseList tail="%s" /> is only valid if revealOrder is "forwards" or "backwards". Did you mean to specify revealOrder="forwards"?', e)));
    }
    function qC(e, t) {
      {
        var a = At(e), i = !a && typeof Br(e) == "function";
        if (a || i) {
          var o = a ? "array" : "iterable";
          return S("A nested %s was passed to row #%s in <SuspenseList />. Wrap it in an additional SuspenseList to configure its revealOrder: <SuspenseList revealOrder=...> ... <SuspenseList revealOrder=...>{%s}</SuspenseList> ... </SuspenseList>", o, t, o), !1;
        }
      }
      return !0;
    }
    function Px(e, t) {
      if ((t === "forwards" || t === "backwards") && e !== void 0 && e !== null && e !== !1)
        if (At(e)) {
          for (var a = 0; a < e.length; a++)
            if (!qC(e[a], a))
              return;
        } else {
          var i = Br(e);
          if (typeof i == "function") {
            var o = i.call(e);
            if (o)
              for (var s = o.next(), f = 0; !s.done; s = o.next()) {
                if (!qC(s.value, f))
                  return;
                f++;
              }
          } else
            S('A single row was passed to a <SuspenseList revealOrder="%s" />. This is not useful since it needs multiple rows. Did you mean to pass multiple children or an array?', t);
        }
    }
    function VS(e, t, a, i, o) {
      var s = e.memoizedState;
      s === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: i,
        tail: a,
        tailMode: o
      } : (s.isBackwards = t, s.rendering = null, s.renderingStartTime = 0, s.last = i, s.tail = a, s.tailMode = o);
    }
    function XC(e, t, a) {
      var i = t.pendingProps, o = i.revealOrder, s = i.tail, f = i.children;
      Fx(o), jx(s, o), Px(f, o), Ta(e, t, f, a);
      var p = sl.current, v = Hg(p, _p);
      if (v)
        p = Bg(p, _p), t.flags |= vt;
      else {
        var E = e !== null && (e.flags & vt) !== Ze;
        E && Ux(t, t.child, a), p = Df(p);
      }
      if ($u(t, p), (t.mode & qe) === Ce)
        t.memoizedState = null;
      else
        switch (o) {
          case "forwards": {
            var C = zx(t.child), M;
            C === null ? (M = t.child, t.child = null) : (M = C.sibling, C.sibling = null), VS(
              t,
              !1,
              // isBackwards
              M,
              C,
              s
            );
            break;
          }
          case "backwards": {
            var D = null, B = t.child;
            for (t.child = null; B !== null; ) {
              var $ = B.alternate;
              if ($ !== null && om($) === null) {
                t.child = B;
                break;
              }
              var G = B.sibling;
              B.sibling = D, D = B, B = G;
            }
            VS(
              t,
              !0,
              // isBackwards
              D,
              null,
              // last
              s
            );
            break;
          }
          case "together": {
            VS(
              t,
              !1,
              // isBackwards
              null,
              // tail
              null,
              // last
              void 0
            );
            break;
          }
          default:
            t.memoizedState = null;
        }
      return t.child;
    }
    function Hx(e, t, a) {
      Fg(t, t.stateNode.containerInfo);
      var i = t.pendingProps;
      return e === null ? t.child = wf(t, null, i, a) : Ta(e, t, i, a), t.child;
    }
    var JC = !1;
    function Bx(e, t, a) {
      var i = t.type, o = i._context, s = t.pendingProps, f = t.memoizedProps, p = s.value;
      {
        "value" in s || JC || (JC = !0, S("The `value` prop is required for the `<Context.Provider>`. Did you misspell it or forget to pass it?"));
        var v = t.type.propTypes;
        v && ll(v, s, "prop", "Context.Provider");
      }
      if (IE(t, o, p), f !== null) {
        var E = f.value;
        if ($e(E, p)) {
          if (f.children === s.children && !jh())
            return Io(e, t, a);
        } else
          Fw(t, o, a);
      }
      var C = s.children;
      return Ta(e, t, C, a), t.child;
    }
    var ZC = !1;
    function Vx(e, t, a) {
      var i = t.type;
      i._context === void 0 ? i !== i.Consumer && (ZC || (ZC = !0, S("Rendering <Context> directly is not supported and will be removed in a future major release. Did you mean to render <Context.Consumer> instead?"))) : i = i._context;
      var o = t.pendingProps, s = o.children;
      typeof s != "function" && S("A context consumer was rendered with multiple children, or a child that isn't a function. A context consumer expects a single child that is a function. If you did pass a function, make sure there is no trailing or leading whitespace around it."), _f(t, a);
      var f = Xn(i);
      ya(t);
      var p;
      return zp.current = t, er(!0), p = s(f), er(!1), ga(), t.flags |= ri, Ta(e, t, p, a), t.child;
    }
    function Pp() {
      dl = !0;
    }
    function Om(e, t) {
      (t.mode & qe) === Ce && e !== null && (e.alternate = null, t.alternate = null, t.flags |= rn);
    }
    function Io(e, t, a) {
      return e !== null && (t.dependencies = e.dependencies), kC(), Xp(t.lanes), Jr(a, t.childLanes) ? (Uw(e, t), t.child) : null;
    }
    function $x(e, t, a) {
      {
        var i = t.return;
        if (i === null)
          throw new Error("Cannot swap the root fiber.");
        if (e.alternate = null, t.alternate = null, a.index = t.index, a.sibling = t.sibling, a.return = t.return, a.ref = t.ref, t === i.child)
          i.child = a;
        else {
          var o = i.child;
          if (o === null)
            throw new Error("Expected parent to have a child.");
          for (; o.sibling !== t; )
            if (o = o.sibling, o === null)
              throw new Error("Expected to find the previous sibling.");
          o.sibling = a;
        }
        var s = i.deletions;
        return s === null ? (i.deletions = [e], i.flags |= Ht) : s.push(e), a.flags |= rn, a;
      }
    }
    function $S(e, t) {
      var a = e.lanes;
      return !!Jr(a, t);
    }
    function Ix(e, t, a) {
      switch (t.tag) {
        case A:
          YC(t), t.stateNode, Rf();
          break;
        case q:
          JE(t);
          break;
        case Q: {
          var i = t.type;
          Kl(i) && Hh(t);
          break;
        }
        case oe:
          Fg(t, t.stateNode.containerInfo);
          break;
        case Ke: {
          var o = t.memoizedProps.value, s = t.type._context;
          IE(t, s, o);
          break;
        }
        case Rt:
          {
            var f = Jr(a, t.childLanes);
            f && (t.flags |= He);
            {
              var p = t.stateNode;
              p.effectDuration = 0, p.passiveEffectDuration = 0;
            }
          }
          break;
        case Ne: {
          var v = t.memoizedState;
          if (v !== null) {
            if (v.dehydrated !== null)
              return $u(t, Df(sl.current)), t.flags |= vt, null;
            var E = t.child, C = E.childLanes;
            if (Jr(a, C))
              return QC(e, t, a);
            $u(t, Df(sl.current));
            var M = Io(e, t, a);
            return M !== null ? M.sibling : null;
          } else
            $u(t, Df(sl.current));
          break;
        }
        case W: {
          var D = (e.flags & vt) !== Ze, B = Jr(a, t.childLanes);
          if (D) {
            if (B)
              return XC(e, t, a);
            t.flags |= vt;
          }
          var $ = t.memoizedState;
          if ($ !== null && ($.rendering = null, $.tail = null, $.lastEffect = null), $u(t, sl.current), B)
            break;
          return null;
        }
        case ae:
        case we:
          return t.lanes = ie, VC(e, t, a);
      }
      return Io(e, t, a);
    }
    function eb(e, t, a) {
      if (t._debugNeedsRemount && e !== null)
        return $x(e, t, S0(t.type, t.key, t.pendingProps, t._debugOwner || null, t.mode, t.lanes));
      if (e !== null) {
        var i = e.memoizedProps, o = t.pendingProps;
        if (i !== o || jh() || // Force a re-render if the implementation changed due to hot reload:
        t.type !== e.type)
          dl = !0;
        else {
          var s = $S(e, a);
          if (!s && // If this is the second pass of an error or suspense boundary, there
          // may not be work scheduled on `current`, so we check for this flag.
          (t.flags & vt) === Ze)
            return dl = !1, Ix(e, t, a);
          (e.flags & Mc) !== Ze ? dl = !0 : dl = !1;
        }
      } else if (dl = !1, Mr() && hw(t)) {
        var f = t.index, p = mw();
        kE(t, p, f);
      }
      switch (t.lanes = ie, t.tag) {
        case Z:
          return wx(e, t, t.type, a);
        case Jt: {
          var v = t.elementType;
          return Tx(e, t, v, a);
        }
        case te: {
          var E = t.type, C = t.pendingProps, M = t.elementType === E ? C : fl(E, C);
          return US(e, t, E, M, a);
        }
        case Q: {
          var D = t.type, B = t.pendingProps, $ = t.elementType === D ? B : fl(D, B);
          return IC(e, t, D, $, a);
        }
        case A:
          return Ex(e, t, a);
        case q:
          return Cx(e, t, a);
        case ve:
          return bx(e, t);
        case Ne:
          return QC(e, t, a);
        case oe:
          return Hx(e, t, a);
        case Ge: {
          var G = t.type, Re = t.pendingProps, et = t.elementType === G ? Re : fl(G, Re);
          return PC(e, t, G, et, a);
        }
        case Ae:
          return yx(e, t, a);
        case Ye:
          return gx(e, t, a);
        case Rt:
          return Sx(e, t, a);
        case Ke:
          return Bx(e, t, a);
        case ut:
          return Vx(e, t, a);
        case lt: {
          var Ie = t.type, Lt = t.pendingProps, _t = fl(Ie, Lt);
          if (t.type !== t.elementType) {
            var F = Ie.propTypes;
            F && ll(
              F,
              _t,
              // Resolved for outer only
              "prop",
              Dt(Ie)
            );
          }
          return _t = fl(Ie.type, _t), HC(e, t, Ie, _t, a);
        }
        case it:
          return BC(e, t, t.type, t.pendingProps, a);
        case jt: {
          var K = t.type, j = t.pendingProps, de = t.elementType === K ? j : fl(K, j);
          return Rx(e, t, K, de, a);
        }
        case W:
          return XC(e, t, a);
        case X:
          break;
        case ae:
          return VC(e, t, a);
      }
      throw new Error("Unknown unit of work tag (" + t.tag + "). This error is likely caused by a bug in React. Please file an issue.");
    }
    function Uf(e) {
      e.flags |= He;
    }
    function tb(e) {
      e.flags |= pa, e.flags |= gi;
    }
    var nb, IS, rb, ab;
    nb = function(e, t, a, i) {
      for (var o = t.child; o !== null; ) {
        if (o.tag === q || o.tag === ve)
          d1(e, o.stateNode);
        else if (o.tag !== oe) {
          if (o.child !== null) {
            o.child.return = o, o = o.child;
            continue;
          }
        }
        if (o === t)
          return;
        for (; o.sibling === null; ) {
          if (o.return === null || o.return === t)
            return;
          o = o.return;
        }
        o.sibling.return = o.return, o = o.sibling;
      }
    }, IS = function(e, t) {
    }, rb = function(e, t, a, i, o) {
      var s = e.memoizedProps;
      if (s !== i) {
        var f = t.stateNode, p = jg(), v = v1(f, a, s, i, o, p);
        t.updateQueue = v, v && Uf(t);
      }
    }, ab = function(e, t, a, i) {
      a !== i && Uf(t);
    };
    function Hp(e, t) {
      if (!Mr())
        switch (e.tailMode) {
          case "hidden": {
            for (var a = e.tail, i = null; a !== null; )
              a.alternate !== null && (i = a), a = a.sibling;
            i === null ? e.tail = null : i.sibling = null;
            break;
          }
          case "collapsed": {
            for (var o = e.tail, s = null; o !== null; )
              o.alternate !== null && (s = o), o = o.sibling;
            s === null ? !t && e.tail !== null ? e.tail.sibling = null : e.tail = null : s.sibling = null;
            break;
          }
        }
    }
    function Lr(e) {
      var t = e.alternate !== null && e.alternate.child === e.child, a = ie, i = Ze;
      if (t) {
        if ((e.mode & pt) !== Ce) {
          for (var v = e.selfBaseDuration, E = e.child; E !== null; )
            a = gt(a, gt(E.lanes, E.childLanes)), i |= E.subtreeFlags & nr, i |= E.flags & nr, v += E.treeBaseDuration, E = E.sibling;
          e.treeBaseDuration = v;
        } else
          for (var C = e.child; C !== null; )
            a = gt(a, gt(C.lanes, C.childLanes)), i |= C.subtreeFlags & nr, i |= C.flags & nr, C.return = e, C = C.sibling;
        e.subtreeFlags |= i;
      } else {
        if ((e.mode & pt) !== Ce) {
          for (var o = e.actualDuration, s = e.selfBaseDuration, f = e.child; f !== null; )
            a = gt(a, gt(f.lanes, f.childLanes)), i |= f.subtreeFlags, i |= f.flags, o += f.actualDuration, s += f.treeBaseDuration, f = f.sibling;
          e.actualDuration = o, e.treeBaseDuration = s;
        } else
          for (var p = e.child; p !== null; )
            a = gt(a, gt(p.lanes, p.childLanes)), i |= p.subtreeFlags, i |= p.flags, p.return = e, p = p.sibling;
        e.subtreeFlags |= i;
      }
      return e.childLanes = a, t;
    }
    function Yx(e, t, a) {
      if (Dw() && (t.mode & qe) !== Ce && (t.flags & vt) === Ze)
        return UE(t), Rf(), t.flags |= Tr | Ml | tr, !1;
      var i = Yh(t);
      if (a !== null && a.dehydrated !== null)
        if (e === null) {
          if (!i)
            throw new Error("A dehydrated suspense component was completed without a hydrated node. This is probably a bug in React.");
          if (_w(t), Lr(t), (t.mode & pt) !== Ce) {
            var o = a !== null;
            if (o) {
              var s = t.child;
              s !== null && (t.treeBaseDuration -= s.treeBaseDuration);
            }
          }
          return !1;
        } else {
          if (Rf(), (t.flags & vt) === Ze && (t.memoizedState = null), t.flags |= He, Lr(t), (t.mode & pt) !== Ce) {
            var f = a !== null;
            if (f) {
              var p = t.child;
              p !== null && (t.treeBaseDuration -= p.treeBaseDuration);
            }
          }
          return !1;
        }
      else
        return zE(), !0;
    }
    function ib(e, t, a) {
      var i = t.pendingProps;
      switch (mg(t), t.tag) {
        case Z:
        case Jt:
        case it:
        case te:
        case Ge:
        case Ae:
        case Ye:
        case Rt:
        case ut:
        case lt:
          return Lr(t), null;
        case Q: {
          var o = t.type;
          return Kl(o) && Ph(t), Lr(t), null;
        }
        case A: {
          var s = t.stateNode;
          if (kf(t), dg(t), $g(), s.pendingContext && (s.context = s.pendingContext, s.pendingContext = null), e === null || e.child === null) {
            var f = Yh(t);
            if (f)
              Uf(t);
            else if (e !== null) {
              var p = e.memoizedState;
              // Check if this is a client root
              (!p.isDehydrated || // Check if we reverted to client rendering (e.g. due to an error)
              (t.flags & Tr) !== Ze) && (t.flags |= Fn, zE());
            }
          }
          return IS(e, t), Lr(t), null;
        }
        case q: {
          Pg(t);
          var v = XE(), E = t.type;
          if (e !== null && t.stateNode != null)
            rb(e, t, E, i, v), e.ref !== t.ref && tb(t);
          else {
            if (!i) {
              if (t.stateNode === null)
                throw new Error("We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.");
              return Lr(t), null;
            }
            var C = jg(), M = Yh(t);
            if (M)
              ww(t, v, C) && Uf(t);
            else {
              var D = f1(E, i, v, C, t);
              nb(D, t, !1, !1), t.stateNode = D, p1(D, E, i, v) && Uf(t);
            }
            t.ref !== null && tb(t);
          }
          return Lr(t), null;
        }
        case ve: {
          var B = i;
          if (e && t.stateNode != null) {
            var $ = e.memoizedProps;
            ab(e, t, $, B);
          } else {
            if (typeof B != "string" && t.stateNode === null)
              throw new Error("We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.");
            var G = XE(), Re = jg(), et = Yh(t);
            et ? xw(t) && Uf(t) : t.stateNode = h1(B, G, Re, t);
          }
          return Lr(t), null;
        }
        case Ne: {
          Of(t);
          var Ie = t.memoizedState;
          if (e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
            var Lt = Yx(e, t, Ie);
            if (!Lt)
              return t.flags & tr ? t : null;
          }
          if ((t.flags & vt) !== Ze)
            return t.lanes = a, (t.mode & pt) !== Ce && vS(t), t;
          var _t = Ie !== null, F = e !== null && e.memoizedState !== null;
          if (_t !== F && _t) {
            var K = t.child;
            if (K.flags |= Ol, (t.mode & qe) !== Ce) {
              var j = e === null && (t.memoizedProps.unstable_avoidThisFallback !== !0 || !J);
              j || Hg(sl.current, eC) ? W_() : u0();
            }
          }
          var de = t.updateQueue;
          if (de !== null && (t.flags |= He), Lr(t), (t.mode & pt) !== Ce && _t) {
            var Me = t.child;
            Me !== null && (t.treeBaseDuration -= Me.treeBaseDuration);
          }
          return null;
        }
        case oe:
          return kf(t), IS(e, t), e === null && uw(t.stateNode.containerInfo), Lr(t), null;
        case Ke:
          var xe = t.type._context;
          return Og(xe, t), Lr(t), null;
        case jt: {
          var ct = t.type;
          return Kl(ct) && Ph(t), Lr(t), null;
        }
        case W: {
          Of(t);
          var mt = t.memoizedState;
          if (mt === null)
            return Lr(t), null;
          var en = (t.flags & vt) !== Ze, Bt = mt.rendering;
          if (Bt === null)
            if (en)
              Hp(mt, !1);
            else {
              var Yn = G_() && (e === null || (e.flags & vt) === Ze);
              if (!Yn)
                for (var Vt = t.child; Vt !== null; ) {
                  var Hn = om(Vt);
                  if (Hn !== null) {
                    en = !0, t.flags |= vt, Hp(mt, !1);
                    var na = Hn.updateQueue;
                    return na !== null && (t.updateQueue = na, t.flags |= He), t.subtreeFlags = Ze, zw(t, a), $u(t, Bg(sl.current, _p)), t.child;
                  }
                  Vt = Vt.sibling;
                }
              mt.tail !== null && jn() > xb() && (t.flags |= vt, en = !0, Hp(mt, !1), t.lanes = Gv);
            }
          else {
            if (!en) {
              var jr = om(Bt);
              if (jr !== null) {
                t.flags |= vt, en = !0;
                var fi = jr.updateQueue;
                if (fi !== null && (t.updateQueue = fi, t.flags |= He), Hp(mt, !0), mt.tail === null && mt.tailMode === "hidden" && !Bt.alternate && !Mr())
                  return Lr(t), null;
              } else // The time it took to render last row is greater than the remaining
              // time we have to render. So rendering one more row would likely
              // exceed it.
              jn() * 2 - mt.renderingStartTime > xb() && a !== Sa && (t.flags |= vt, en = !0, Hp(mt, !1), t.lanes = Gv);
            }
            if (mt.isBackwards)
              Bt.sibling = t.child, t.child = Bt;
            else {
              var xa = mt.last;
              xa !== null ? xa.sibling = Bt : t.child = Bt, mt.last = Bt;
            }
          }
          if (mt.tail !== null) {
            var _a = mt.tail;
            mt.rendering = _a, mt.tail = _a.sibling, mt.renderingStartTime = jn(), _a.sibling = null;
            var ra = sl.current;
            return en ? ra = Bg(ra, _p) : ra = Df(ra), $u(t, ra), _a;
          }
          return Lr(t), null;
        }
        case X:
          break;
        case ae:
        case we: {
          o0(t);
          var Ko = t.memoizedState, $f = Ko !== null;
          if (e !== null) {
            var nv = e.memoizedState, ro = nv !== null;
            ro !== $f && // LegacyHidden doesn't do any hiding — it only pre-renders.
            !N && (t.flags |= Ol);
          }
          return !$f || (t.mode & qe) === Ce ? Lr(t) : Jr(no, Sa) && (Lr(t), t.subtreeFlags & (rn | He) && (t.flags |= Ol)), null;
        }
        case Ue:
          return null;
        case Le:
          return null;
      }
      throw new Error("Unknown unit of work tag (" + t.tag + "). This error is likely caused by a bug in React. Please file an issue.");
    }
    function Wx(e, t, a) {
      switch (mg(t), t.tag) {
        case Q: {
          var i = t.type;
          Kl(i) && Ph(t);
          var o = t.flags;
          return o & tr ? (t.flags = o & ~tr | vt, (t.mode & pt) !== Ce && vS(t), t) : null;
        }
        case A: {
          t.stateNode, kf(t), dg(t), $g();
          var s = t.flags;
          return (s & tr) !== Ze && (s & vt) === Ze ? (t.flags = s & ~tr | vt, t) : null;
        }
        case q:
          return Pg(t), null;
        case Ne: {
          Of(t);
          var f = t.memoizedState;
          if (f !== null && f.dehydrated !== null) {
            if (t.alternate === null)
              throw new Error("Threw in newly mounted dehydrated component. This is likely a bug in React. Please file an issue.");
            Rf();
          }
          var p = t.flags;
          return p & tr ? (t.flags = p & ~tr | vt, (t.mode & pt) !== Ce && vS(t), t) : null;
        }
        case W:
          return Of(t), null;
        case oe:
          return kf(t), null;
        case Ke:
          var v = t.type._context;
          return Og(v, t), null;
        case ae:
        case we:
          return o0(t), null;
        case Ue:
          return null;
        default:
          return null;
      }
    }
    function lb(e, t, a) {
      switch (mg(t), t.tag) {
        case Q: {
          var i = t.type.childContextTypes;
          i != null && Ph(t);
          break;
        }
        case A: {
          t.stateNode, kf(t), dg(t), $g();
          break;
        }
        case q: {
          Pg(t);
          break;
        }
        case oe:
          kf(t);
          break;
        case Ne:
          Of(t);
          break;
        case W:
          Of(t);
          break;
        case Ke:
          var o = t.type._context;
          Og(o, t);
          break;
        case ae:
        case we:
          o0(t);
          break;
      }
    }
    var ob = null;
    ob = /* @__PURE__ */ new Set();
    var Mm = !1, Ar = !1, Qx = typeof WeakSet == "function" ? WeakSet : Set, Fe = null, zf = null, Ff = null;
    function Gx(e) {
      ni(null, function() {
        throw e;
      }), qi();
    }
    var Kx = function(e, t) {
      if (t.props = e.memoizedProps, t.state = e.memoizedState, e.mode & pt)
        try {
          eo(), t.componentWillUnmount();
        } finally {
          Zl(e);
        }
      else
        t.componentWillUnmount();
    };
    function ub(e, t) {
      try {
        Wu(ir, e);
      } catch (a) {
        pn(e, t, a);
      }
    }
    function YS(e, t, a) {
      try {
        Kx(e, a);
      } catch (i) {
        pn(e, t, i);
      }
    }
    function qx(e, t, a) {
      try {
        a.componentDidMount();
      } catch (i) {
        pn(e, t, i);
      }
    }
    function sb(e, t) {
      try {
        fb(e);
      } catch (a) {
        pn(e, t, a);
      }
    }
    function jf(e, t) {
      var a = e.ref;
      if (a !== null)
        if (typeof a == "function") {
          var i;
          try {
            if (St && Et && e.mode & pt)
              try {
                eo(), i = a(null);
              } finally {
                Zl(e);
              }
            else
              i = a(null);
          } catch (o) {
            pn(e, t, o);
          }
          typeof i == "function" && S("Unexpected return value from a callback ref in %s. A callback ref should not return a function.", dt(e));
        } else
          a.current = null;
    }
    function Nm(e, t, a) {
      try {
        a();
      } catch (i) {
        pn(e, t, i);
      }
    }
    var cb = !1;
    function Xx(e, t) {
      s1(e.containerInfo), Fe = t, Jx();
      var a = cb;
      return cb = !1, a;
    }
    function Jx() {
      for (; Fe !== null; ) {
        var e = Fe, t = e.child;
        (e.subtreeFlags & Qr) !== Ze && t !== null ? (t.return = e, Fe = t) : Zx();
      }
    }
    function Zx() {
      for (; Fe !== null; ) {
        var e = Fe;
        Sn(e);
        try {
          e_(e);
        } catch (a) {
          pn(e, e.return, a);
        }
        sn();
        var t = e.sibling;
        if (t !== null) {
          t.return = e.return, Fe = t;
          return;
        }
        Fe = e.return;
      }
    }
    function e_(e) {
      var t = e.alternate, a = e.flags;
      if ((a & Fn) !== Ze) {
        switch (Sn(e), e.tag) {
          case te:
          case Ge:
          case it:
            break;
          case Q: {
            if (t !== null) {
              var i = t.memoizedProps, o = t.memoizedState, s = e.stateNode;
              e.type === e.elementType && !dc && (s.props !== e.memoizedProps && S("Expected %s props to match memoized props before getSnapshotBeforeUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", dt(e) || "instance"), s.state !== e.memoizedState && S("Expected %s state to match memoized state before getSnapshotBeforeUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", dt(e) || "instance"));
              var f = s.getSnapshotBeforeUpdate(e.elementType === e.type ? i : fl(e.type, i), o);
              {
                var p = ob;
                f === void 0 && !p.has(e.type) && (p.add(e.type), S("%s.getSnapshotBeforeUpdate(): A snapshot value (or null) must be returned. You have returned undefined.", dt(e)));
              }
              s.__reactInternalSnapshotBeforeUpdate = f;
            }
            break;
          }
          case A: {
            {
              var v = e.stateNode;
              A1(v.containerInfo);
            }
            break;
          }
          case q:
          case ve:
          case oe:
          case jt:
            break;
          default:
            throw new Error("This unit of work tag should not have side-effects. This error is likely caused by a bug in React. Please file an issue.");
        }
        sn();
      }
    }
    function pl(e, t, a) {
      var i = t.updateQueue, o = i !== null ? i.lastEffect : null;
      if (o !== null) {
        var s = o.next, f = s;
        do {
          if ((f.tag & e) === e) {
            var p = f.destroy;
            f.destroy = void 0, p !== void 0 && ((e & Nr) !== Ia ? jc(t) : (e & ir) !== Ia && du(t), (e & ql) !== Ia && Zp(!0), Nm(t, a, p), (e & ql) !== Ia && Zp(!1), (e & Nr) !== Ia ? Wv() : (e & ir) !== Ia && pu());
          }
          f = f.next;
        } while (f !== s);
      }
    }
    function Wu(e, t) {
      var a = t.updateQueue, i = a !== null ? a.lastEffect : null;
      if (i !== null) {
        var o = i.next, s = o;
        do {
          if ((s.tag & e) === e) {
            (e & Nr) !== Ia ? Fc(t) : (e & ir) !== Ia && xs(t);
            var f = s.create;
            (e & ql) !== Ia && Zp(!0), s.destroy = f(), (e & ql) !== Ia && Zp(!1), (e & Nr) !== Ia ? Yv() : (e & ir) !== Ia && Si();
            {
              var p = s.destroy;
              if (p !== void 0 && typeof p != "function") {
                var v = void 0;
                (s.tag & ir) !== Ze ? v = "useLayoutEffect" : (s.tag & ql) !== Ze ? v = "useInsertionEffect" : v = "useEffect";
                var E = void 0;
                p === null ? E = " You returned null. If your effect does not require clean up, return undefined (or nothing)." : typeof p.then == "function" ? E = `

It looks like you wrote ` + v + `(async () => ...) or returned a Promise. Instead, write the async function inside your effect and call it immediately:

` + v + `(() => {
  async function fetchData() {
    // You can await here
    const response = await MyAPI.getData(someId);
    // ...
  }
  fetchData();
}, [someId]); // Or [] if effect doesn't need props or state

Learn more about data fetching with Hooks: https://reactjs.org/link/hooks-data-fetching` : E = " You returned: " + p, S("%s must not return anything besides a function, which is used for clean-up.%s", v, E);
              }
            }
          }
          s = s.next;
        } while (s !== o);
      }
    }
    function t_(e, t) {
      if ((t.flags & He) !== Ze)
        switch (t.tag) {
          case Rt: {
            var a = t.stateNode.passiveEffectDuration, i = t.memoizedProps, o = i.id, s = i.onPostCommit, f = xC(), p = t.alternate === null ? "mount" : "update";
            wC() && (p = "nested-update"), typeof s == "function" && s(o, p, a, f);
            var v = t.return;
            e: for (; v !== null; ) {
              switch (v.tag) {
                case A:
                  var E = v.stateNode;
                  E.passiveEffectDuration += a;
                  break e;
                case Rt:
                  var C = v.stateNode;
                  C.passiveEffectDuration += a;
                  break e;
              }
              v = v.return;
            }
            break;
          }
        }
    }
    function n_(e, t, a, i) {
      if ((a.flags & ai) !== Ze)
        switch (a.tag) {
          case te:
          case Ge:
          case it: {
            if (!Ar)
              if (a.mode & pt)
                try {
                  eo(), Wu(ir | ar, a);
                } finally {
                  Zl(a);
                }
              else
                Wu(ir | ar, a);
            break;
          }
          case Q: {
            var o = a.stateNode;
            if (a.flags & He && !Ar)
              if (t === null)
                if (a.type === a.elementType && !dc && (o.props !== a.memoizedProps && S("Expected %s props to match memoized props before componentDidMount. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", dt(a) || "instance"), o.state !== a.memoizedState && S("Expected %s state to match memoized state before componentDidMount. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", dt(a) || "instance")), a.mode & pt)
                  try {
                    eo(), o.componentDidMount();
                  } finally {
                    Zl(a);
                  }
                else
                  o.componentDidMount();
              else {
                var s = a.elementType === a.type ? t.memoizedProps : fl(a.type, t.memoizedProps), f = t.memoizedState;
                if (a.type === a.elementType && !dc && (o.props !== a.memoizedProps && S("Expected %s props to match memoized props before componentDidUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", dt(a) || "instance"), o.state !== a.memoizedState && S("Expected %s state to match memoized state before componentDidUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", dt(a) || "instance")), a.mode & pt)
                  try {
                    eo(), o.componentDidUpdate(s, f, o.__reactInternalSnapshotBeforeUpdate);
                  } finally {
                    Zl(a);
                  }
                else
                  o.componentDidUpdate(s, f, o.__reactInternalSnapshotBeforeUpdate);
              }
            var p = a.updateQueue;
            p !== null && (a.type === a.elementType && !dc && (o.props !== a.memoizedProps && S("Expected %s props to match memoized props before processing the update queue. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", dt(a) || "instance"), o.state !== a.memoizedState && S("Expected %s state to match memoized state before processing the update queue. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", dt(a) || "instance")), qE(a, p, o));
            break;
          }
          case A: {
            var v = a.updateQueue;
            if (v !== null) {
              var E = null;
              if (a.child !== null)
                switch (a.child.tag) {
                  case q:
                    E = a.child.stateNode;
                    break;
                  case Q:
                    E = a.child.stateNode;
                    break;
                }
              qE(a, v, E);
            }
            break;
          }
          case q: {
            var C = a.stateNode;
            if (t === null && a.flags & He) {
              var M = a.type, D = a.memoizedProps;
              E1(C, M, D);
            }
            break;
          }
          case ve:
            break;
          case oe:
            break;
          case Rt: {
            {
              var B = a.memoizedProps, $ = B.onCommit, G = B.onRender, Re = a.stateNode.effectDuration, et = xC(), Ie = t === null ? "mount" : "update";
              wC() && (Ie = "nested-update"), typeof G == "function" && G(a.memoizedProps.id, Ie, a.actualDuration, a.treeBaseDuration, a.actualStartTime, et);
              {
                typeof $ == "function" && $(a.memoizedProps.id, Ie, Re, et), Z_(a);
                var Lt = a.return;
                e: for (; Lt !== null; ) {
                  switch (Lt.tag) {
                    case A:
                      var _t = Lt.stateNode;
                      _t.effectDuration += Re;
                      break e;
                    case Rt:
                      var F = Lt.stateNode;
                      F.effectDuration += Re;
                      break e;
                  }
                  Lt = Lt.return;
                }
              }
            }
            break;
          }
          case Ne: {
            c_(e, a);
            break;
          }
          case W:
          case jt:
          case X:
          case ae:
          case we:
          case Le:
            break;
          default:
            throw new Error("This unit of work tag should not have side-effects. This error is likely caused by a bug in React. Please file an issue.");
        }
      Ar || a.flags & pa && fb(a);
    }
    function r_(e) {
      switch (e.tag) {
        case te:
        case Ge:
        case it: {
          if (e.mode & pt)
            try {
              eo(), ub(e, e.return);
            } finally {
              Zl(e);
            }
          else
            ub(e, e.return);
          break;
        }
        case Q: {
          var t = e.stateNode;
          typeof t.componentDidMount == "function" && qx(e, e.return, t), sb(e, e.return);
          break;
        }
        case q: {
          sb(e, e.return);
          break;
        }
      }
    }
    function a_(e, t) {
      for (var a = null, i = e; ; ) {
        if (i.tag === q) {
          if (a === null) {
            a = i;
            try {
              var o = i.stateNode;
              t ? O1(o) : N1(i.stateNode, i.memoizedProps);
            } catch (f) {
              pn(e, e.return, f);
            }
          }
        } else if (i.tag === ve) {
          if (a === null)
            try {
              var s = i.stateNode;
              t ? M1(s) : L1(s, i.memoizedProps);
            } catch (f) {
              pn(e, e.return, f);
            }
        } else if (!((i.tag === ae || i.tag === we) && i.memoizedState !== null && i !== e)) {
          if (i.child !== null) {
            i.child.return = i, i = i.child;
            continue;
          }
        }
        if (i === e)
          return;
        for (; i.sibling === null; ) {
          if (i.return === null || i.return === e)
            return;
          a === i && (a = null), i = i.return;
        }
        a === i && (a = null), i.sibling.return = i.return, i = i.sibling;
      }
    }
    function fb(e) {
      var t = e.ref;
      if (t !== null) {
        var a = e.stateNode, i;
        switch (e.tag) {
          case q:
            i = a;
            break;
          default:
            i = a;
        }
        if (typeof t == "function") {
          var o;
          if (e.mode & pt)
            try {
              eo(), o = t(i);
            } finally {
              Zl(e);
            }
          else
            o = t(i);
          typeof o == "function" && S("Unexpected return value from a callback ref in %s. A callback ref should not return a function.", dt(e));
        } else
          t.hasOwnProperty("current") || S("Unexpected ref object provided for %s. Use either a ref-setter function or React.createRef().", dt(e)), t.current = i;
      }
    }
    function i_(e) {
      var t = e.alternate;
      t !== null && (t.return = null), e.return = null;
    }
    function db(e) {
      var t = e.alternate;
      t !== null && (e.alternate = null, db(t));
      {
        if (e.child = null, e.deletions = null, e.sibling = null, e.tag === q) {
          var a = e.stateNode;
          a !== null && fw(a);
        }
        e.stateNode = null, e._debugOwner = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
      }
    }
    function l_(e) {
      for (var t = e.return; t !== null; ) {
        if (pb(t))
          return t;
        t = t.return;
      }
      throw new Error("Expected to find a host parent. This error is likely caused by a bug in React. Please file an issue.");
    }
    function pb(e) {
      return e.tag === q || e.tag === A || e.tag === oe;
    }
    function vb(e) {
      var t = e;
      e: for (; ; ) {
        for (; t.sibling === null; ) {
          if (t.return === null || pb(t.return))
            return null;
          t = t.return;
        }
        for (t.sibling.return = t.return, t = t.sibling; t.tag !== q && t.tag !== ve && t.tag !== Xe; ) {
          if (t.flags & rn || t.child === null || t.tag === oe)
            continue e;
          t.child.return = t, t = t.child;
        }
        if (!(t.flags & rn))
          return t.stateNode;
      }
    }
    function o_(e) {
      var t = l_(e);
      switch (t.tag) {
        case q: {
          var a = t.stateNode;
          t.flags & Ua && (mE(a), t.flags &= ~Ua);
          var i = vb(e);
          QS(e, i, a);
          break;
        }
        case A:
        case oe: {
          var o = t.stateNode.containerInfo, s = vb(e);
          WS(e, s, o);
          break;
        }
        default:
          throw new Error("Invalid host parent fiber. This error is likely caused by a bug in React. Please file an issue.");
      }
    }
    function WS(e, t, a) {
      var i = e.tag, o = i === q || i === ve;
      if (o) {
        var s = e.stateNode;
        t ? x1(a, s, t) : R1(a, s);
      } else if (i !== oe) {
        var f = e.child;
        if (f !== null) {
          WS(f, t, a);
          for (var p = f.sibling; p !== null; )
            WS(p, t, a), p = p.sibling;
        }
      }
    }
    function QS(e, t, a) {
      var i = e.tag, o = i === q || i === ve;
      if (o) {
        var s = e.stateNode;
        t ? w1(a, s, t) : T1(a, s);
      } else if (i !== oe) {
        var f = e.child;
        if (f !== null) {
          QS(f, t, a);
          for (var p = f.sibling; p !== null; )
            QS(p, t, a), p = p.sibling;
        }
      }
    }
    var Ur = null, vl = !1;
    function u_(e, t, a) {
      {
        var i = t;
        e: for (; i !== null; ) {
          switch (i.tag) {
            case q: {
              Ur = i.stateNode, vl = !1;
              break e;
            }
            case A: {
              Ur = i.stateNode.containerInfo, vl = !0;
              break e;
            }
            case oe: {
              Ur = i.stateNode.containerInfo, vl = !0;
              break e;
            }
          }
          i = i.return;
        }
        if (Ur === null)
          throw new Error("Expected to find a host parent. This error is likely caused by a bug in React. Please file an issue.");
        hb(e, t, a), Ur = null, vl = !1;
      }
      i_(a);
    }
    function Qu(e, t, a) {
      for (var i = a.child; i !== null; )
        hb(e, t, i), i = i.sibling;
    }
    function hb(e, t, a) {
      switch (Ed(a), a.tag) {
        case q:
          Ar || jf(a, t);
        case ve: {
          {
            var i = Ur, o = vl;
            Ur = null, Qu(e, t, a), Ur = i, vl = o, Ur !== null && (vl ? k1(Ur, a.stateNode) : _1(Ur, a.stateNode));
          }
          return;
        }
        case Xe: {
          Ur !== null && (vl ? D1(Ur, a.stateNode) : ag(Ur, a.stateNode));
          return;
        }
        case oe: {
          {
            var s = Ur, f = vl;
            Ur = a.stateNode.containerInfo, vl = !0, Qu(e, t, a), Ur = s, vl = f;
          }
          return;
        }
        case te:
        case Ge:
        case lt:
        case it: {
          if (!Ar) {
            var p = a.updateQueue;
            if (p !== null) {
              var v = p.lastEffect;
              if (v !== null) {
                var E = v.next, C = E;
                do {
                  var M = C, D = M.destroy, B = M.tag;
                  D !== void 0 && ((B & ql) !== Ia ? Nm(a, t, D) : (B & ir) !== Ia && (du(a), a.mode & pt ? (eo(), Nm(a, t, D), Zl(a)) : Nm(a, t, D), pu())), C = C.next;
                } while (C !== E);
              }
            }
          }
          Qu(e, t, a);
          return;
        }
        case Q: {
          if (!Ar) {
            jf(a, t);
            var $ = a.stateNode;
            typeof $.componentWillUnmount == "function" && YS(a, t, $);
          }
          Qu(e, t, a);
          return;
        }
        case X: {
          Qu(e, t, a);
          return;
        }
        case ae: {
          if (
            // TODO: Remove this dead flag
            a.mode & qe
          ) {
            var G = Ar;
            Ar = G || a.memoizedState !== null, Qu(e, t, a), Ar = G;
          } else
            Qu(e, t, a);
          break;
        }
        default: {
          Qu(e, t, a);
          return;
        }
      }
    }
    function s_(e) {
      e.memoizedState;
    }
    function c_(e, t) {
      var a = t.memoizedState;
      if (a === null) {
        var i = t.alternate;
        if (i !== null) {
          var o = i.memoizedState;
          if (o !== null) {
            var s = o.dehydrated;
            s !== null && G1(s);
          }
        }
      }
    }
    function mb(e) {
      var t = e.updateQueue;
      if (t !== null) {
        e.updateQueue = null;
        var a = e.stateNode;
        a === null && (a = e.stateNode = new Qx()), t.forEach(function(i) {
          var o = lk.bind(null, e, i);
          if (!a.has(i)) {
            if (a.add(i), ma)
              if (zf !== null && Ff !== null)
                Jp(Ff, zf);
              else
                throw Error("Expected finished root and lanes to be set. This is a bug in React.");
            i.then(o, o);
          }
        });
      }
    }
    function f_(e, t, a) {
      zf = a, Ff = e, Sn(t), yb(t, e), Sn(t), zf = null, Ff = null;
    }
    function hl(e, t, a) {
      var i = t.deletions;
      if (i !== null)
        for (var o = 0; o < i.length; o++) {
          var s = i[o];
          try {
            u_(e, t, s);
          } catch (v) {
            pn(s, t, v);
          }
        }
      var f = ls();
      if (t.subtreeFlags & Gr)
        for (var p = t.child; p !== null; )
          Sn(p), yb(p, e), p = p.sibling;
      Sn(f);
    }
    function yb(e, t, a) {
      var i = e.alternate, o = e.flags;
      switch (e.tag) {
        case te:
        case Ge:
        case lt:
        case it: {
          if (hl(t, e), to(e), o & He) {
            try {
              pl(ql | ar, e, e.return), Wu(ql | ar, e);
            } catch (ct) {
              pn(e, e.return, ct);
            }
            if (e.mode & pt) {
              try {
                eo(), pl(ir | ar, e, e.return);
              } catch (ct) {
                pn(e, e.return, ct);
              }
              Zl(e);
            } else
              try {
                pl(ir | ar, e, e.return);
              } catch (ct) {
                pn(e, e.return, ct);
              }
          }
          return;
        }
        case Q: {
          hl(t, e), to(e), o & pa && i !== null && jf(i, i.return);
          return;
        }
        case q: {
          hl(t, e), to(e), o & pa && i !== null && jf(i, i.return);
          {
            if (e.flags & Ua) {
              var s = e.stateNode;
              try {
                mE(s);
              } catch (ct) {
                pn(e, e.return, ct);
              }
            }
            if (o & He) {
              var f = e.stateNode;
              if (f != null) {
                var p = e.memoizedProps, v = i !== null ? i.memoizedProps : p, E = e.type, C = e.updateQueue;
                if (e.updateQueue = null, C !== null)
                  try {
                    C1(f, C, E, v, p, e);
                  } catch (ct) {
                    pn(e, e.return, ct);
                  }
              }
            }
          }
          return;
        }
        case ve: {
          if (hl(t, e), to(e), o & He) {
            if (e.stateNode === null)
              throw new Error("This should have a text node initialized. This error is likely caused by a bug in React. Please file an issue.");
            var M = e.stateNode, D = e.memoizedProps, B = i !== null ? i.memoizedProps : D;
            try {
              b1(M, B, D);
            } catch (ct) {
              pn(e, e.return, ct);
            }
          }
          return;
        }
        case A: {
          if (hl(t, e), to(e), o & He && i !== null) {
            var $ = i.memoizedState;
            if ($.isDehydrated)
              try {
                Q1(t.containerInfo);
              } catch (ct) {
                pn(e, e.return, ct);
              }
          }
          return;
        }
        case oe: {
          hl(t, e), to(e);
          return;
        }
        case Ne: {
          hl(t, e), to(e);
          var G = e.child;
          if (G.flags & Ol) {
            var Re = G.stateNode, et = G.memoizedState, Ie = et !== null;
            if (Re.isHidden = Ie, Ie) {
              var Lt = G.alternate !== null && G.alternate.memoizedState !== null;
              Lt || Y_();
            }
          }
          if (o & He) {
            try {
              s_(e);
            } catch (ct) {
              pn(e, e.return, ct);
            }
            mb(e);
          }
          return;
        }
        case ae: {
          var _t = i !== null && i.memoizedState !== null;
          if (
            // TODO: Remove this dead flag
            e.mode & qe
          ) {
            var F = Ar;
            Ar = F || _t, hl(t, e), Ar = F;
          } else
            hl(t, e);
          if (to(e), o & Ol) {
            var K = e.stateNode, j = e.memoizedState, de = j !== null, Me = e;
            if (K.isHidden = de, de && !_t && (Me.mode & qe) !== Ce) {
              Fe = Me;
              for (var xe = Me.child; xe !== null; )
                Fe = xe, p_(xe), xe = xe.sibling;
            }
            a_(Me, de);
          }
          return;
        }
        case W: {
          hl(t, e), to(e), o & He && mb(e);
          return;
        }
        case X:
          return;
        default: {
          hl(t, e), to(e);
          return;
        }
      }
    }
    function to(e) {
      var t = e.flags;
      if (t & rn) {
        try {
          o_(e);
        } catch (a) {
          pn(e, e.return, a);
        }
        e.flags &= ~rn;
      }
      t & yi && (e.flags &= ~yi);
    }
    function d_(e, t, a) {
      zf = a, Ff = t, Fe = e, gb(e, t, a), zf = null, Ff = null;
    }
    function gb(e, t, a) {
      for (var i = (e.mode & qe) !== Ce; Fe !== null; ) {
        var o = Fe, s = o.child;
        if (o.tag === ae && i) {
          var f = o.memoizedState !== null, p = f || Mm;
          if (p) {
            GS(e, t, a);
            continue;
          } else {
            var v = o.alternate, E = v !== null && v.memoizedState !== null, C = E || Ar, M = Mm, D = Ar;
            Mm = p, Ar = C, Ar && !D && (Fe = o, v_(o));
            for (var B = s; B !== null; )
              Fe = B, gb(
                B,
                // New root; bubble back up to here and stop.
                t,
                a
              ), B = B.sibling;
            Fe = o, Mm = M, Ar = D, GS(e, t, a);
            continue;
          }
        }
        (o.subtreeFlags & ai) !== Ze && s !== null ? (s.return = o, Fe = s) : GS(e, t, a);
      }
    }
    function GS(e, t, a) {
      for (; Fe !== null; ) {
        var i = Fe;
        if ((i.flags & ai) !== Ze) {
          var o = i.alternate;
          Sn(i);
          try {
            n_(t, o, i, a);
          } catch (f) {
            pn(i, i.return, f);
          }
          sn();
        }
        if (i === e) {
          Fe = null;
          return;
        }
        var s = i.sibling;
        if (s !== null) {
          s.return = i.return, Fe = s;
          return;
        }
        Fe = i.return;
      }
    }
    function p_(e) {
      for (; Fe !== null; ) {
        var t = Fe, a = t.child;
        switch (t.tag) {
          case te:
          case Ge:
          case lt:
          case it: {
            if (t.mode & pt)
              try {
                eo(), pl(ir, t, t.return);
              } finally {
                Zl(t);
              }
            else
              pl(ir, t, t.return);
            break;
          }
          case Q: {
            jf(t, t.return);
            var i = t.stateNode;
            typeof i.componentWillUnmount == "function" && YS(t, t.return, i);
            break;
          }
          case q: {
            jf(t, t.return);
            break;
          }
          case ae: {
            var o = t.memoizedState !== null;
            if (o) {
              Sb(e);
              continue;
            }
            break;
          }
        }
        a !== null ? (a.return = t, Fe = a) : Sb(e);
      }
    }
    function Sb(e) {
      for (; Fe !== null; ) {
        var t = Fe;
        if (t === e) {
          Fe = null;
          return;
        }
        var a = t.sibling;
        if (a !== null) {
          a.return = t.return, Fe = a;
          return;
        }
        Fe = t.return;
      }
    }
    function v_(e) {
      for (; Fe !== null; ) {
        var t = Fe, a = t.child;
        if (t.tag === ae) {
          var i = t.memoizedState !== null;
          if (i) {
            Eb(e);
            continue;
          }
        }
        a !== null ? (a.return = t, Fe = a) : Eb(e);
      }
    }
    function Eb(e) {
      for (; Fe !== null; ) {
        var t = Fe;
        Sn(t);
        try {
          r_(t);
        } catch (i) {
          pn(t, t.return, i);
        }
        if (sn(), t === e) {
          Fe = null;
          return;
        }
        var a = t.sibling;
        if (a !== null) {
          a.return = t.return, Fe = a;
          return;
        }
        Fe = t.return;
      }
    }
    function h_(e, t, a, i) {
      Fe = t, m_(t, e, a, i);
    }
    function m_(e, t, a, i) {
      for (; Fe !== null; ) {
        var o = Fe, s = o.child;
        (o.subtreeFlags & Kr) !== Ze && s !== null ? (s.return = o, Fe = s) : y_(e, t, a, i);
      }
    }
    function y_(e, t, a, i) {
      for (; Fe !== null; ) {
        var o = Fe;
        if ((o.flags & Wr) !== Ze) {
          Sn(o);
          try {
            g_(t, o, a, i);
          } catch (f) {
            pn(o, o.return, f);
          }
          sn();
        }
        if (o === e) {
          Fe = null;
          return;
        }
        var s = o.sibling;
        if (s !== null) {
          s.return = o.return, Fe = s;
          return;
        }
        Fe = o.return;
      }
    }
    function g_(e, t, a, i) {
      switch (t.tag) {
        case te:
        case Ge:
        case it: {
          if (t.mode & pt) {
            pS();
            try {
              Wu(Nr | ar, t);
            } finally {
              dS(t);
            }
          } else
            Wu(Nr | ar, t);
          break;
        }
      }
    }
    function S_(e) {
      Fe = e, E_();
    }
    function E_() {
      for (; Fe !== null; ) {
        var e = Fe, t = e.child;
        if ((Fe.flags & Ht) !== Ze) {
          var a = e.deletions;
          if (a !== null) {
            for (var i = 0; i < a.length; i++) {
              var o = a[i];
              Fe = o, T_(o, e);
            }
            {
              var s = e.alternate;
              if (s !== null) {
                var f = s.child;
                if (f !== null) {
                  s.child = null;
                  do {
                    var p = f.sibling;
                    f.sibling = null, f = p;
                  } while (f !== null);
                }
              }
            }
            Fe = e;
          }
        }
        (e.subtreeFlags & Kr) !== Ze && t !== null ? (t.return = e, Fe = t) : C_();
      }
    }
    function C_() {
      for (; Fe !== null; ) {
        var e = Fe;
        (e.flags & Wr) !== Ze && (Sn(e), b_(e), sn());
        var t = e.sibling;
        if (t !== null) {
          t.return = e.return, Fe = t;
          return;
        }
        Fe = e.return;
      }
    }
    function b_(e) {
      switch (e.tag) {
        case te:
        case Ge:
        case it: {
          e.mode & pt ? (pS(), pl(Nr | ar, e, e.return), dS(e)) : pl(Nr | ar, e, e.return);
          break;
        }
      }
    }
    function T_(e, t) {
      for (; Fe !== null; ) {
        var a = Fe;
        Sn(a), w_(a, t), sn();
        var i = a.child;
        i !== null ? (i.return = a, Fe = i) : R_(e);
      }
    }
    function R_(e) {
      for (; Fe !== null; ) {
        var t = Fe, a = t.sibling, i = t.return;
        if (db(t), t === e) {
          Fe = null;
          return;
        }
        if (a !== null) {
          a.return = i, Fe = a;
          return;
        }
        Fe = i;
      }
    }
    function w_(e, t) {
      switch (e.tag) {
        case te:
        case Ge:
        case it: {
          e.mode & pt ? (pS(), pl(Nr, e, t), dS(e)) : pl(Nr, e, t);
          break;
        }
      }
    }
    function x_(e) {
      switch (e.tag) {
        case te:
        case Ge:
        case it: {
          try {
            Wu(ir | ar, e);
          } catch (a) {
            pn(e, e.return, a);
          }
          break;
        }
        case Q: {
          var t = e.stateNode;
          try {
            t.componentDidMount();
          } catch (a) {
            pn(e, e.return, a);
          }
          break;
        }
      }
    }
    function __(e) {
      switch (e.tag) {
        case te:
        case Ge:
        case it: {
          try {
            Wu(Nr | ar, e);
          } catch (t) {
            pn(e, e.return, t);
          }
          break;
        }
      }
    }
    function k_(e) {
      switch (e.tag) {
        case te:
        case Ge:
        case it: {
          try {
            pl(ir | ar, e, e.return);
          } catch (a) {
            pn(e, e.return, a);
          }
          break;
        }
        case Q: {
          var t = e.stateNode;
          typeof t.componentWillUnmount == "function" && YS(e, e.return, t);
          break;
        }
      }
    }
    function D_(e) {
      switch (e.tag) {
        case te:
        case Ge:
        case it:
          try {
            pl(Nr | ar, e, e.return);
          } catch (t) {
            pn(e, e.return, t);
          }
      }
    }
    if (typeof Symbol == "function" && Symbol.for) {
      var Bp = Symbol.for;
      Bp("selector.component"), Bp("selector.has_pseudo_class"), Bp("selector.role"), Bp("selector.test_id"), Bp("selector.text");
    }
    var O_ = [];
    function M_() {
      O_.forEach(function(e) {
        return e();
      });
    }
    var N_ = T.ReactCurrentActQueue;
    function L_(e) {
      {
        var t = (
          // $FlowExpectedError – Flow doesn't know about IS_REACT_ACT_ENVIRONMENT global
          typeof IS_REACT_ACT_ENVIRONMENT < "u" ? IS_REACT_ACT_ENVIRONMENT : void 0
        ), a = typeof jest < "u";
        return a && t !== !1;
      }
    }
    function Cb() {
      {
        var e = (
          // $FlowExpectedError – Flow doesn't know about IS_REACT_ACT_ENVIRONMENT global
          typeof IS_REACT_ACT_ENVIRONMENT < "u" ? IS_REACT_ACT_ENVIRONMENT : void 0
        );
        return !e && N_.current !== null && S("The current testing environment is not configured to support act(...)"), e;
      }
    }
    var A_ = Math.ceil, KS = T.ReactCurrentDispatcher, qS = T.ReactCurrentOwner, zr = T.ReactCurrentBatchConfig, ml = T.ReactCurrentActQueue, ur = (
      /*             */
      0
    ), bb = (
      /*               */
      1
    ), Fr = (
      /*                */
      2
    ), Ni = (
      /*                */
      4
    ), Yo = 0, Vp = 1, pc = 2, Lm = 3, $p = 4, Tb = 5, XS = 6, Nt = ur, Ra = null, Ln = null, sr = ie, no = ie, JS = Fu(ie), cr = Yo, Ip = null, Am = ie, Yp = ie, Um = ie, Wp = null, Ya = null, ZS = 0, Rb = 500, wb = 1 / 0, U_ = 500, Wo = null;
    function Qp() {
      wb = jn() + U_;
    }
    function xb() {
      return wb;
    }
    var zm = !1, e0 = null, Pf = null, vc = !1, Gu = null, Gp = ie, t0 = [], n0 = null, z_ = 50, Kp = 0, r0 = null, a0 = !1, Fm = !1, F_ = 50, Hf = 0, jm = null, qp = on, Pm = ie, _b = !1;
    function Hm() {
      return Ra;
    }
    function wa() {
      return (Nt & (Fr | Ni)) !== ur ? jn() : (qp !== on || (qp = jn()), qp);
    }
    function Ku(e) {
      var t = e.mode;
      if ((t & qe) === Ce)
        return Ve;
      if ((Nt & Fr) !== ur && sr !== ie)
        return Ru(sr);
      var a = Nw() !== Mw;
      if (a) {
        if (zr.transition !== null) {
          var i = zr.transition;
          i._updatedFibers || (i._updatedFibers = /* @__PURE__ */ new Set()), i._updatedFibers.add(e);
        }
        return Pm === an && (Pm = Rr()), Pm;
      }
      var o = xr();
      if (o !== an)
        return o;
      var s = m1();
      return s;
    }
    function j_(e) {
      var t = e.mode;
      return (t & qe) === Ce ? Ve : wr();
    }
    function fr(e, t, a, i) {
      uk(), _b && S("useInsertionEffect must not schedule updates."), a0 && (Fm = !0), xu(e, a, i), (Nt & Fr) !== ie && e === Ra ? fk(t) : (ma && Pd(e, t, a), dk(t), e === Ra && ((Nt & Fr) === ur && (Yp = gt(Yp, a)), cr === $p && qu(e, sr)), Wa(e, i), a === Ve && Nt === ur && (t.mode & qe) === Ce && // Treat `act` as if it's inside `batchedUpdates`, even in legacy mode.
      !ml.isBatchingLegacy && (Qp(), _E()));
    }
    function P_(e, t, a) {
      var i = e.current;
      i.lanes = t, xu(e, t, a), Wa(e, a);
    }
    function H_(e) {
      return (
        // TODO: Remove outdated deferRenderPhaseUpdateToNextBatch experiment. We
        // decided not to enable it.
        (Nt & Fr) !== ur
      );
    }
    function Wa(e, t) {
      var a = e.callbackNode;
      Md(e, t);
      var i = Ns(e, e === Ra ? sr : ie);
      if (i === ie) {
        a !== null && $b(a), e.callbackNode = null, e.callbackPriority = an;
        return;
      }
      var o = Pl(i), s = e.callbackPriority;
      if (s === o && // Special case related to `act`. If the currently scheduled task is a
      // Scheduler task, rather than an `act` task, cancel it and re-scheduled
      // on the `act` queue.
      !(ml.current !== null && a !== f0)) {
        a == null && s !== Ve && S("Expected scheduled callback to exist. This error is likely caused by a bug in React. Please file an issue.");
        return;
      }
      a != null && $b(a);
      var f;
      if (o === Ve)
        e.tag === ju ? (ml.isBatchingLegacy !== null && (ml.didScheduleLegacyUpdate = !0), vw(Ob.bind(null, e))) : xE(Ob.bind(null, e)), ml.current !== null ? ml.current.push(Pu) : g1(function() {
          (Nt & (Fr | Ni)) === ur && Pu();
        }), f = null;
      else {
        var p;
        switch (th(i)) {
          case Ea:
            p = Al;
            break;
          case Ti:
            p = cu;
            break;
          case oi:
            p = Ul;
            break;
          case js:
            p = zl;
            break;
          default:
            p = Ul;
            break;
        }
        f = d0(p, kb.bind(null, e));
      }
      e.callbackPriority = o, e.callbackNode = f;
    }
    function kb(e, t) {
      if (ax(), qp = on, Pm = ie, (Nt & (Fr | Ni)) !== ur)
        throw new Error("Should not already be working.");
      var a = e.callbackNode, i = Go();
      if (i && e.callbackNode !== a)
        return null;
      var o = Ns(e, e === Ra ? sr : ie);
      if (o === ie)
        return null;
      var s = !As(e, o) && !Zv(e, o) && !t, f = s ? q_(e, o) : Vm(e, o);
      if (f !== Yo) {
        if (f === pc) {
          var p = Ls(e);
          p !== ie && (o = p, f = i0(e, p));
        }
        if (f === Vp) {
          var v = Ip;
          throw hc(e, ie), qu(e, o), Wa(e, jn()), v;
        }
        if (f === XS)
          qu(e, o);
        else {
          var E = !As(e, o), C = e.current.alternate;
          if (E && !V_(C)) {
            if (f = Vm(e, o), f === pc) {
              var M = Ls(e);
              M !== ie && (o = M, f = i0(e, M));
            }
            if (f === Vp) {
              var D = Ip;
              throw hc(e, ie), qu(e, o), Wa(e, jn()), D;
            }
          }
          e.finishedWork = C, e.finishedLanes = o, B_(e, f, o);
        }
      }
      return Wa(e, jn()), e.callbackNode === a ? kb.bind(null, e) : null;
    }
    function i0(e, t) {
      var a = Wp;
      if (Oe(e)) {
        var i = hc(e, t);
        i.flags |= Tr, ow(e.containerInfo);
      }
      var o = Vm(e, t);
      if (o !== pc) {
        var s = Ya;
        Ya = a, s !== null && Db(s);
      }
      return o;
    }
    function Db(e) {
      Ya === null ? Ya = e : Ya.push.apply(Ya, e);
    }
    function B_(e, t, a) {
      switch (t) {
        case Yo:
        case Vp:
          throw new Error("Root did not complete. This is a bug in React.");
        case pc: {
          mc(e, Ya, Wo);
          break;
        }
        case Lm: {
          if (qu(e, a), Ad(a) && // do not delay if we're inside an act() scope
          !Ib()) {
            var i = ZS + Rb - jn();
            if (i > 10) {
              var o = Ns(e, ie);
              if (o !== ie)
                break;
              var s = e.suspendedLanes;
              if (!Bl(s, a)) {
                wa(), zs(e, s);
                break;
              }
              e.timeoutHandle = ng(mc.bind(null, e, Ya, Wo), i);
              break;
            }
          }
          mc(e, Ya, Wo);
          break;
        }
        case $p: {
          if (qu(e, a), Jv(a))
            break;
          if (!Ib()) {
            var f = Kv(e, a), p = f, v = jn() - p, E = ok(v) - v;
            if (E > 10) {
              e.timeoutHandle = ng(mc.bind(null, e, Ya, Wo), E);
              break;
            }
          }
          mc(e, Ya, Wo);
          break;
        }
        case Tb: {
          mc(e, Ya, Wo);
          break;
        }
        default:
          throw new Error("Unknown root exit status.");
      }
    }
    function V_(e) {
      for (var t = e; ; ) {
        if (t.flags & So) {
          var a = t.updateQueue;
          if (a !== null) {
            var i = a.stores;
            if (i !== null)
              for (var o = 0; o < i.length; o++) {
                var s = i[o], f = s.getSnapshot, p = s.value;
                try {
                  if (!$e(f(), p))
                    return !1;
                } catch {
                  return !1;
                }
              }
          }
        }
        var v = t.child;
        if (t.subtreeFlags & So && v !== null) {
          v.return = t, t = v;
          continue;
        }
        if (t === e)
          return !0;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === e)
            return !0;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
      return !0;
    }
    function qu(e, t) {
      t = wu(t, Um), t = wu(t, Yp), Fd(e, t);
    }
    function Ob(e) {
      if (ix(), (Nt & (Fr | Ni)) !== ur)
        throw new Error("Should not already be working.");
      Go();
      var t = Ns(e, ie);
      if (!Jr(t, Ve))
        return Wa(e, jn()), null;
      var a = Vm(e, t);
      if (e.tag !== ju && a === pc) {
        var i = Ls(e);
        i !== ie && (t = i, a = i0(e, i));
      }
      if (a === Vp) {
        var o = Ip;
        throw hc(e, ie), qu(e, t), Wa(e, jn()), o;
      }
      if (a === XS)
        throw new Error("Root did not complete. This is a bug in React.");
      var s = e.current.alternate;
      return e.finishedWork = s, e.finishedLanes = t, mc(e, Ya, Wo), Wa(e, jn()), null;
    }
    function $_(e, t) {
      t !== ie && (ef(e, gt(t, Ve)), Wa(e, jn()), (Nt & (Fr | Ni)) === ur && (Qp(), Pu()));
    }
    function l0(e, t) {
      var a = Nt;
      Nt |= bb;
      try {
        return e(t);
      } finally {
        Nt = a, Nt === ur && // Treat `act` as if it's inside `batchedUpdates`, even in legacy mode.
        !ml.isBatchingLegacy && (Qp(), _E());
      }
    }
    function I_(e, t, a, i, o) {
      var s = xr(), f = zr.transition;
      try {
        return zr.transition = null, Ut(Ea), e(t, a, i, o);
      } finally {
        Ut(s), zr.transition = f, Nt === ur && Qp();
      }
    }
    function Qo(e) {
      Gu !== null && Gu.tag === ju && (Nt & (Fr | Ni)) === ur && Go();
      var t = Nt;
      Nt |= bb;
      var a = zr.transition, i = xr();
      try {
        return zr.transition = null, Ut(Ea), e ? e() : void 0;
      } finally {
        Ut(i), zr.transition = a, Nt = t, (Nt & (Fr | Ni)) === ur && Pu();
      }
    }
    function Mb() {
      return (Nt & (Fr | Ni)) !== ur;
    }
    function Bm(e, t) {
      ea(JS, no, e), no = gt(no, t);
    }
    function o0(e) {
      no = JS.current, Zr(JS, e);
    }
    function hc(e, t) {
      e.finishedWork = null, e.finishedLanes = ie;
      var a = e.timeoutHandle;
      if (a !== rg && (e.timeoutHandle = rg, y1(a)), Ln !== null)
        for (var i = Ln.return; i !== null; ) {
          var o = i.alternate;
          lb(o, i), i = i.return;
        }
      Ra = e;
      var s = yc(e.current, null);
      return Ln = s, sr = no = t, cr = Yo, Ip = null, Am = ie, Yp = ie, Um = ie, Wp = null, Ya = null, Pw(), ul.discardPendingWarnings(), s;
    }
    function Nb(e, t) {
      do {
        var a = Ln;
        try {
          if (Xh(), nC(), sn(), qS.current = null, a === null || a.return === null) {
            cr = Vp, Ip = t, Ln = null;
            return;
          }
          if (St && a.mode & pt && xm(a, !0), ft)
            if (ga(), t !== null && typeof t == "object" && typeof t.then == "function") {
              var i = t;
              Td(a, i, sr);
            } else
              To(a, t, sr);
          vx(e, a.return, a, t, sr), zb(a);
        } catch (o) {
          t = o, Ln === a && a !== null ? (a = a.return, Ln = a) : a = Ln;
          continue;
        }
        return;
      } while (!0);
    }
    function Lb() {
      var e = KS.current;
      return KS.current = Cm, e === null ? Cm : e;
    }
    function Ab(e) {
      KS.current = e;
    }
    function Y_() {
      ZS = jn();
    }
    function Xp(e) {
      Am = gt(e, Am);
    }
    function W_() {
      cr === Yo && (cr = Lm);
    }
    function u0() {
      (cr === Yo || cr === Lm || cr === pc) && (cr = $p), Ra !== null && (Ld(Am) || Ld(Yp)) && qu(Ra, sr);
    }
    function Q_(e) {
      cr !== $p && (cr = pc), Wp === null ? Wp = [e] : Wp.push(e);
    }
    function G_() {
      return cr === Yo;
    }
    function Vm(e, t) {
      var a = Nt;
      Nt |= Fr;
      var i = Lb();
      if (Ra !== e || sr !== t) {
        if (ma) {
          var o = e.memoizedUpdaters;
          o.size > 0 && (Jp(e, sr), o.clear()), Fs(e, t);
        }
        Wo = bi(), hc(e, t);
      }
      _s(t);
      do
        try {
          K_();
          break;
        } catch (s) {
          Nb(e, s);
        }
      while (!0);
      if (Xh(), Nt = a, Ab(i), Ln !== null)
        throw new Error("Cannot commit an incomplete root. This error is likely caused by a bug in React. Please file an issue.");
      return Pc(), Ra = null, sr = ie, cr;
    }
    function K_() {
      for (; Ln !== null; )
        Ub(Ln);
    }
    function q_(e, t) {
      var a = Nt;
      Nt |= Fr;
      var i = Lb();
      if (Ra !== e || sr !== t) {
        if (ma) {
          var o = e.memoizedUpdaters;
          o.size > 0 && (Jp(e, sr), o.clear()), Fs(e, t);
        }
        Wo = bi(), Qp(), hc(e, t);
      }
      _s(t);
      do
        try {
          X_();
          break;
        } catch (s) {
          Nb(e, s);
        }
      while (!0);
      return Xh(), Ab(i), Nt = a, Ln !== null ? (wd(), Yo) : (Pc(), Ra = null, sr = ie, cr);
    }
    function X_() {
      for (; Ln !== null && !Vv(); )
        Ub(Ln);
    }
    function Ub(e) {
      var t = e.alternate;
      Sn(e);
      var a;
      (e.mode & pt) !== Ce ? (fS(e), a = s0(t, e, no), xm(e, !0)) : a = s0(t, e, no), sn(), e.memoizedProps = e.pendingProps, a === null ? zb(e) : Ln = a, qS.current = null;
    }
    function zb(e) {
      var t = e;
      do {
        var a = t.alternate, i = t.return;
        if ((t.flags & Ml) === Ze) {
          Sn(t);
          var o = void 0;
          if ((t.mode & pt) === Ce ? o = ib(a, t, no) : (fS(t), o = ib(a, t, no), xm(t, !1)), sn(), o !== null) {
            Ln = o;
            return;
          }
        } else {
          var s = Wx(a, t);
          if (s !== null) {
            s.flags &= Xi, Ln = s;
            return;
          }
          if ((t.mode & pt) !== Ce) {
            xm(t, !1);
            for (var f = t.actualDuration, p = t.child; p !== null; )
              f += p.actualDuration, p = p.sibling;
            t.actualDuration = f;
          }
          if (i !== null)
            i.flags |= Ml, i.subtreeFlags = Ze, i.deletions = null;
          else {
            cr = XS, Ln = null;
            return;
          }
        }
        var v = t.sibling;
        if (v !== null) {
          Ln = v;
          return;
        }
        t = i, Ln = t;
      } while (t !== null);
      cr === Yo && (cr = Tb);
    }
    function mc(e, t, a) {
      var i = xr(), o = zr.transition;
      try {
        zr.transition = null, Ut(Ea), J_(e, t, a, i);
      } finally {
        zr.transition = o, Ut(i);
      }
      return null;
    }
    function J_(e, t, a, i) {
      do
        Go();
      while (Gu !== null);
      if (sk(), (Nt & (Fr | Ni)) !== ur)
        throw new Error("Should not already be working.");
      var o = e.finishedWork, s = e.finishedLanes;
      if (Cd(s), o === null)
        return bd(), null;
      if (s === ie && S("root.finishedLanes should not be empty during a commit. This is a bug in React."), e.finishedWork = null, e.finishedLanes = ie, o === e.current)
        throw new Error("Cannot commit the same tree as before. This error is likely caused by a bug in React. Please file an issue.");
      e.callbackNode = null, e.callbackPriority = an;
      var f = gt(o.lanes, o.childLanes);
      wy(e, f), e === Ra && (Ra = null, Ln = null, sr = ie), ((o.subtreeFlags & Kr) !== Ze || (o.flags & Kr) !== Ze) && (vc || (vc = !0, n0 = a, d0(Ul, function() {
        return Go(), null;
      })));
      var p = (o.subtreeFlags & (Qr | Gr | ai | Kr)) !== Ze, v = (o.flags & (Qr | Gr | ai | Kr)) !== Ze;
      if (p || v) {
        var E = zr.transition;
        zr.transition = null;
        var C = xr();
        Ut(Ea);
        var M = Nt;
        Nt |= Ni, qS.current = null, Xx(e, o), _C(), f_(e, o, s), c1(e.containerInfo), e.current = o, vu(s), d_(o, e, s), Qv(), su(), Nt = M, Ut(C), zr.transition = E;
      } else
        e.current = o, _C();
      var D = vc;
      if (vc ? (vc = !1, Gu = e, Gp = s) : (Hf = 0, jm = null), f = e.pendingLanes, f === ie && (Pf = null), D || Hb(e.current, !1), Ha(o.stateNode, i), ma && e.memoizedUpdaters.clear(), M_(), Wa(e, jn()), t !== null)
        for (var B = e.onRecoverableError, $ = 0; $ < t.length; $++) {
          var G = t[$], Re = G.stack, et = G.digest;
          B(G.value, {
            componentStack: Re,
            digest: et
          });
        }
      if (zm) {
        zm = !1;
        var Ie = e0;
        throw e0 = null, Ie;
      }
      return Jr(Gp, Ve) && e.tag !== ju && Go(), f = e.pendingLanes, Jr(f, Ve) ? (rx(), e === r0 ? Kp++ : (Kp = 0, r0 = e)) : Kp = 0, Pu(), bd(), null;
    }
    function Go() {
      if (Gu !== null) {
        var e = th(Gp), t = tf(oi, e), a = zr.transition, i = xr();
        try {
          return zr.transition = null, Ut(t), ek();
        } finally {
          Ut(i), zr.transition = a;
        }
      }
      return !1;
    }
    function Z_(e) {
      t0.push(e), vc || (vc = !0, d0(Ul, function() {
        return Go(), null;
      }));
    }
    function ek() {
      if (Gu === null)
        return !1;
      var e = n0;
      n0 = null;
      var t = Gu, a = Gp;
      if (Gu = null, Gp = ie, (Nt & (Fr | Ni)) !== ur)
        throw new Error("Cannot flush passive effects while already rendering.");
      a0 = !0, Fm = !1, Rd(a);
      var i = Nt;
      Nt |= Ni, S_(t.current), h_(t, t.current, a, e);
      {
        var o = t0;
        t0 = [];
        for (var s = 0; s < o.length; s++) {
          var f = o[s];
          t_(t, f);
        }
      }
      En(), Hb(t.current, !0), Nt = i, Pu(), Fm ? t === jm ? Hf++ : (Hf = 0, jm = t) : Hf = 0, a0 = !1, Fm = !1, bo(t);
      {
        var p = t.current.stateNode;
        p.effectDuration = 0, p.passiveEffectDuration = 0;
      }
      return !0;
    }
    function Fb(e) {
      return Pf !== null && Pf.has(e);
    }
    function tk(e) {
      Pf === null ? Pf = /* @__PURE__ */ new Set([e]) : Pf.add(e);
    }
    function nk(e) {
      zm || (zm = !0, e0 = e);
    }
    var rk = nk;
    function jb(e, t, a) {
      var i = fc(a, t), o = UC(e, i, Ve), s = Bu(e, o, Ve), f = wa();
      s !== null && (xu(s, Ve, f), Wa(s, f));
    }
    function pn(e, t, a) {
      if (Gx(a), Zp(!1), e.tag === A) {
        jb(e, e, a);
        return;
      }
      var i = null;
      for (i = t; i !== null; ) {
        if (i.tag === A) {
          jb(i, e, a);
          return;
        } else if (i.tag === Q) {
          var o = i.type, s = i.stateNode;
          if (typeof o.getDerivedStateFromError == "function" || typeof s.componentDidCatch == "function" && !Fb(s)) {
            var f = fc(a, e), p = DS(i, f, Ve), v = Bu(i, p, Ve), E = wa();
            v !== null && (xu(v, Ve, E), Wa(v, E));
            return;
          }
        }
        i = i.return;
      }
      S(`Internal React error: Attempted to capture a commit phase error inside a detached tree. This indicates a bug in React. Likely causes include deleting the same fiber more than once, committing an already-finished tree, or an inconsistent return pointer.

Error message:

%s`, a);
    }
    function ak(e, t, a) {
      var i = e.pingCache;
      i !== null && i.delete(t);
      var o = wa();
      zs(e, a), pk(e), Ra === e && Bl(sr, a) && (cr === $p || cr === Lm && Ad(sr) && jn() - ZS < Rb ? hc(e, ie) : Um = gt(Um, a)), Wa(e, o);
    }
    function Pb(e, t) {
      t === an && (t = j_(e));
      var a = wa(), i = $a(e, t);
      i !== null && (xu(i, t, a), Wa(i, a));
    }
    function ik(e) {
      var t = e.memoizedState, a = an;
      t !== null && (a = t.retryLane), Pb(e, a);
    }
    function lk(e, t) {
      var a = an, i;
      switch (e.tag) {
        case Ne:
          i = e.stateNode;
          var o = e.memoizedState;
          o !== null && (a = o.retryLane);
          break;
        case W:
          i = e.stateNode;
          break;
        default:
          throw new Error("Pinged unknown suspense boundary type. This is probably a bug in React.");
      }
      i !== null && i.delete(t), Pb(e, a);
    }
    function ok(e) {
      return e < 120 ? 120 : e < 480 ? 480 : e < 1080 ? 1080 : e < 1920 ? 1920 : e < 3e3 ? 3e3 : e < 4320 ? 4320 : A_(e / 1960) * 1960;
    }
    function uk() {
      if (Kp > z_)
        throw Kp = 0, r0 = null, new Error("Maximum update depth exceeded. This can happen when a component repeatedly calls setState inside componentWillUpdate or componentDidUpdate. React limits the number of nested updates to prevent infinite loops.");
      Hf > F_ && (Hf = 0, jm = null, S("Maximum update depth exceeded. This can happen when a component calls setState inside useEffect, but useEffect either doesn't have a dependency array, or one of the dependencies changes on every render."));
    }
    function sk() {
      ul.flushLegacyContextWarning(), ul.flushPendingUnsafeLifecycleWarnings();
    }
    function Hb(e, t) {
      Sn(e), $m(e, Fa, k_), t && $m(e, Eo, D_), $m(e, Fa, x_), t && $m(e, Eo, __), sn();
    }
    function $m(e, t, a) {
      for (var i = e, o = null; i !== null; ) {
        var s = i.subtreeFlags & t;
        i !== o && i.child !== null && s !== Ze ? i = i.child : ((i.flags & t) !== Ze && a(i), i.sibling !== null ? i = i.sibling : i = o = i.return);
      }
    }
    var Im = null;
    function Bb(e) {
      {
        if ((Nt & Fr) !== ur || !(e.mode & qe))
          return;
        var t = e.tag;
        if (t !== Z && t !== A && t !== Q && t !== te && t !== Ge && t !== lt && t !== it)
          return;
        var a = dt(e) || "ReactComponent";
        if (Im !== null) {
          if (Im.has(a))
            return;
          Im.add(a);
        } else
          Im = /* @__PURE__ */ new Set([a]);
        var i = gn;
        try {
          Sn(e), S("Can't perform a React state update on a component that hasn't mounted yet. This indicates that you have a side-effect in your render function that asynchronously later calls tries to update the component. Move this work to useEffect instead.");
        } finally {
          i ? Sn(e) : sn();
        }
      }
    }
    var s0;
    {
      var ck = null;
      s0 = function(e, t, a) {
        var i = Kb(ck, t);
        try {
          return eb(e, t, a);
        } catch (s) {
          if (bw() || s !== null && typeof s == "object" && typeof s.then == "function")
            throw s;
          if (Xh(), nC(), lb(e, t), Kb(t, i), t.mode & pt && fS(t), ni(null, eb, null, e, t, a), Ey()) {
            var o = qi();
            typeof o == "object" && o !== null && o._suppressLogging && typeof s == "object" && s !== null && !s._suppressLogging && (s._suppressLogging = !0);
          }
          throw s;
        }
      };
    }
    var Vb = !1, c0;
    c0 = /* @__PURE__ */ new Set();
    function fk(e) {
      if ($r && !ex())
        switch (e.tag) {
          case te:
          case Ge:
          case it: {
            var t = Ln && dt(Ln) || "Unknown", a = t;
            if (!c0.has(a)) {
              c0.add(a);
              var i = dt(e) || "Unknown";
              S("Cannot update a component (`%s`) while rendering a different component (`%s`). To locate the bad setState() call inside `%s`, follow the stack trace as described in https://reactjs.org/link/setstate-in-render", i, t, t);
            }
            break;
          }
          case Q: {
            Vb || (S("Cannot update during an existing state transition (such as within `render`). Render methods should be a pure function of props and state."), Vb = !0);
            break;
          }
        }
    }
    function Jp(e, t) {
      if (ma) {
        var a = e.memoizedUpdaters;
        a.forEach(function(i) {
          Pd(e, i, t);
        });
      }
    }
    var f0 = {};
    function d0(e, t) {
      {
        var a = ml.current;
        return a !== null ? (a.push(t), f0) : gd(e, t);
      }
    }
    function $b(e) {
      if (e !== f0)
        return Uc(e);
    }
    function Ib() {
      return ml.current !== null;
    }
    function dk(e) {
      {
        if (e.mode & qe) {
          if (!Cb())
            return;
        } else if (!L_() || Nt !== ur || e.tag !== te && e.tag !== Ge && e.tag !== it)
          return;
        if (ml.current === null) {
          var t = gn;
          try {
            Sn(e), S(`An update to %s inside a test was not wrapped in act(...).

When testing, code that causes React state updates should be wrapped into act(...):

act(() => {
  /* fire events that update state */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://reactjs.org/link/wrap-tests-with-act`, dt(e));
          } finally {
            t ? Sn(e) : sn();
          }
        }
      }
    }
    function pk(e) {
      e.tag !== ju && Cb() && ml.current === null && S(`A suspended resource finished loading inside a test, but the event was not wrapped in act(...).

When testing, code that resolves suspended data should be wrapped into act(...):

act(() => {
  /* finish loading suspended data */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://reactjs.org/link/wrap-tests-with-act`);
    }
    function Zp(e) {
      _b = e;
    }
    var Li = null, Bf = null, vk = function(e) {
      Li = e;
    };
    function Vf(e) {
      {
        if (Li === null)
          return e;
        var t = Li(e);
        return t === void 0 ? e : t.current;
      }
    }
    function p0(e) {
      return Vf(e);
    }
    function v0(e) {
      {
        if (Li === null)
          return e;
        var t = Li(e);
        if (t === void 0) {
          if (e != null && typeof e.render == "function") {
            var a = Vf(e.render);
            if (e.render !== a) {
              var i = {
                $$typeof: ce,
                render: a
              };
              return e.displayName !== void 0 && (i.displayName = e.displayName), i;
            }
          }
          return e;
        }
        return t.current;
      }
    }
    function Yb(e, t) {
      {
        if (Li === null)
          return !1;
        var a = e.elementType, i = t.type, o = !1, s = typeof i == "object" && i !== null ? i.$$typeof : null;
        switch (e.tag) {
          case Q: {
            typeof i == "function" && (o = !0);
            break;
          }
          case te: {
            (typeof i == "function" || s === tt) && (o = !0);
            break;
          }
          case Ge: {
            (s === ce || s === tt) && (o = !0);
            break;
          }
          case lt:
          case it: {
            (s === Mt || s === tt) && (o = !0);
            break;
          }
          default:
            return !1;
        }
        if (o) {
          var f = Li(a);
          if (f !== void 0 && f === Li(i))
            return !0;
        }
        return !1;
      }
    }
    function Wb(e) {
      {
        if (Li === null || typeof WeakSet != "function")
          return;
        Bf === null && (Bf = /* @__PURE__ */ new WeakSet()), Bf.add(e);
      }
    }
    var hk = function(e, t) {
      {
        if (Li === null)
          return;
        var a = t.staleFamilies, i = t.updatedFamilies;
        Go(), Qo(function() {
          h0(e.current, i, a);
        });
      }
    }, mk = function(e, t) {
      {
        if (e.context !== si)
          return;
        Go(), Qo(function() {
          ev(t, e, null, null);
        });
      }
    };
    function h0(e, t, a) {
      {
        var i = e.alternate, o = e.child, s = e.sibling, f = e.tag, p = e.type, v = null;
        switch (f) {
          case te:
          case it:
          case Q:
            v = p;
            break;
          case Ge:
            v = p.render;
            break;
        }
        if (Li === null)
          throw new Error("Expected resolveFamily to be set during hot reload.");
        var E = !1, C = !1;
        if (v !== null) {
          var M = Li(v);
          M !== void 0 && (a.has(M) ? C = !0 : t.has(M) && (f === Q ? C = !0 : E = !0));
        }
        if (Bf !== null && (Bf.has(e) || i !== null && Bf.has(i)) && (C = !0), C && (e._debugNeedsRemount = !0), C || E) {
          var D = $a(e, Ve);
          D !== null && fr(D, e, Ve, on);
        }
        o !== null && !C && h0(o, t, a), s !== null && h0(s, t, a);
      }
    }
    var yk = function(e, t) {
      {
        var a = /* @__PURE__ */ new Set(), i = new Set(t.map(function(o) {
          return o.current;
        }));
        return m0(e.current, i, a), a;
      }
    };
    function m0(e, t, a) {
      {
        var i = e.child, o = e.sibling, s = e.tag, f = e.type, p = null;
        switch (s) {
          case te:
          case it:
          case Q:
            p = f;
            break;
          case Ge:
            p = f.render;
            break;
        }
        var v = !1;
        p !== null && t.has(p) && (v = !0), v ? gk(e, a) : i !== null && m0(i, t, a), o !== null && m0(o, t, a);
      }
    }
    function gk(e, t) {
      {
        var a = Sk(e, t);
        if (a)
          return;
        for (var i = e; ; ) {
          switch (i.tag) {
            case q:
              t.add(i.stateNode);
              return;
            case oe:
              t.add(i.stateNode.containerInfo);
              return;
            case A:
              t.add(i.stateNode.containerInfo);
              return;
          }
          if (i.return === null)
            throw new Error("Expected to reach root first.");
          i = i.return;
        }
      }
    }
    function Sk(e, t) {
      for (var a = e, i = !1; ; ) {
        if (a.tag === q)
          i = !0, t.add(a.stateNode);
        else if (a.child !== null) {
          a.child.return = a, a = a.child;
          continue;
        }
        if (a === e)
          return i;
        for (; a.sibling === null; ) {
          if (a.return === null || a.return === e)
            return i;
          a = a.return;
        }
        a.sibling.return = a.return, a = a.sibling;
      }
      return !1;
    }
    var y0;
    {
      y0 = !1;
      try {
        var Qb = Object.preventExtensions({});
      } catch {
        y0 = !0;
      }
    }
    function Ek(e, t, a, i) {
      this.tag = e, this.key = a, this.elementType = null, this.type = null, this.stateNode = null, this.return = null, this.child = null, this.sibling = null, this.index = 0, this.ref = null, this.pendingProps = t, this.memoizedProps = null, this.updateQueue = null, this.memoizedState = null, this.dependencies = null, this.mode = i, this.flags = Ze, this.subtreeFlags = Ze, this.deletions = null, this.lanes = ie, this.childLanes = ie, this.alternate = null, this.actualDuration = Number.NaN, this.actualStartTime = Number.NaN, this.selfBaseDuration = Number.NaN, this.treeBaseDuration = Number.NaN, this.actualDuration = 0, this.actualStartTime = -1, this.selfBaseDuration = 0, this.treeBaseDuration = 0, this._debugSource = null, this._debugOwner = null, this._debugNeedsRemount = !1, this._debugHookTypes = null, !y0 && typeof Object.preventExtensions == "function" && Object.preventExtensions(this);
    }
    var ci = function(e, t, a, i) {
      return new Ek(e, t, a, i);
    };
    function g0(e) {
      var t = e.prototype;
      return !!(t && t.isReactComponent);
    }
    function Ck(e) {
      return typeof e == "function" && !g0(e) && e.defaultProps === void 0;
    }
    function bk(e) {
      if (typeof e == "function")
        return g0(e) ? Q : te;
      if (e != null) {
        var t = e.$$typeof;
        if (t === ce)
          return Ge;
        if (t === Mt)
          return lt;
      }
      return Z;
    }
    function yc(e, t) {
      var a = e.alternate;
      a === null ? (a = ci(e.tag, t, e.key, e.mode), a.elementType = e.elementType, a.type = e.type, a.stateNode = e.stateNode, a._debugSource = e._debugSource, a._debugOwner = e._debugOwner, a._debugHookTypes = e._debugHookTypes, a.alternate = e, e.alternate = a) : (a.pendingProps = t, a.type = e.type, a.flags = Ze, a.subtreeFlags = Ze, a.deletions = null, a.actualDuration = 0, a.actualStartTime = -1), a.flags = e.flags & nr, a.childLanes = e.childLanes, a.lanes = e.lanes, a.child = e.child, a.memoizedProps = e.memoizedProps, a.memoizedState = e.memoizedState, a.updateQueue = e.updateQueue;
      var i = e.dependencies;
      switch (a.dependencies = i === null ? null : {
        lanes: i.lanes,
        firstContext: i.firstContext
      }, a.sibling = e.sibling, a.index = e.index, a.ref = e.ref, a.selfBaseDuration = e.selfBaseDuration, a.treeBaseDuration = e.treeBaseDuration, a._debugNeedsRemount = e._debugNeedsRemount, a.tag) {
        case Z:
        case te:
        case it:
          a.type = Vf(e.type);
          break;
        case Q:
          a.type = p0(e.type);
          break;
        case Ge:
          a.type = v0(e.type);
          break;
      }
      return a;
    }
    function Tk(e, t) {
      e.flags &= nr | rn;
      var a = e.alternate;
      if (a === null)
        e.childLanes = ie, e.lanes = t, e.child = null, e.subtreeFlags = Ze, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null, e.selfBaseDuration = 0, e.treeBaseDuration = 0;
      else {
        e.childLanes = a.childLanes, e.lanes = a.lanes, e.child = a.child, e.subtreeFlags = Ze, e.deletions = null, e.memoizedProps = a.memoizedProps, e.memoizedState = a.memoizedState, e.updateQueue = a.updateQueue, e.type = a.type;
        var i = a.dependencies;
        e.dependencies = i === null ? null : {
          lanes: i.lanes,
          firstContext: i.firstContext
        }, e.selfBaseDuration = a.selfBaseDuration, e.treeBaseDuration = a.treeBaseDuration;
      }
      return e;
    }
    function Rk(e, t, a) {
      var i;
      return e === Bh ? (i = qe, t === !0 && (i |= dn, i |= qr)) : i = Ce, ma && (i |= pt), ci(A, null, null, i);
    }
    function S0(e, t, a, i, o, s) {
      var f = Z, p = e;
      if (typeof e == "function")
        g0(e) ? (f = Q, p = p0(p)) : p = Vf(p);
      else if (typeof e == "string")
        f = q;
      else
        e: switch (e) {
          case ca:
            return Xu(a.children, o, s, t);
          case zi:
            f = Ye, o |= dn, (o & qe) !== Ce && (o |= qr);
            break;
          case Sl:
            return wk(a, o, s, t);
          case Je:
            return xk(a, o, s, t);
          case xt:
            return _k(a, o, s, t);
          case tn:
            return Gb(a, o, s, t);
          case hn:
          case bt:
          case mr:
          case Yt:
          case Un:
          default: {
            if (typeof e == "object" && e !== null)
              switch (e.$$typeof) {
                case _:
                  f = Ke;
                  break e;
                case ue:
                  f = ut;
                  break e;
                case ce:
                  f = Ge, p = v0(p);
                  break e;
                case Mt:
                  f = lt;
                  break e;
                case tt:
                  f = Jt, p = null;
                  break e;
              }
            var v = "";
            {
              (e === void 0 || typeof e == "object" && e !== null && Object.keys(e).length === 0) && (v += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
              var E = i ? dt(i) : null;
              E && (v += `

Check the render method of \`` + E + "`.");
            }
            throw new Error("Element type is invalid: expected a string (for built-in components) or a class/function (for composite components) " + ("but got: " + (e == null ? e : typeof e) + "." + v));
          }
        }
      var C = ci(f, a, t, o);
      return C.elementType = e, C.type = p, C.lanes = s, C._debugOwner = i, C;
    }
    function E0(e, t, a) {
      var i = null;
      i = e._owner;
      var o = e.type, s = e.key, f = e.props, p = S0(o, s, f, i, t, a);
      return p._debugSource = e._source, p._debugOwner = e._owner, p;
    }
    function Xu(e, t, a, i) {
      var o = ci(Ae, e, i, t);
      return o.lanes = a, o;
    }
    function wk(e, t, a, i) {
      typeof e.id != "string" && S('Profiler must specify an "id" of type `string` as a prop. Received the type `%s` instead.', typeof e.id);
      var o = ci(Rt, e, i, t | pt);
      return o.elementType = Sl, o.lanes = a, o.stateNode = {
        effectDuration: 0,
        passiveEffectDuration: 0
      }, o;
    }
    function xk(e, t, a, i) {
      var o = ci(Ne, e, i, t);
      return o.elementType = Je, o.lanes = a, o;
    }
    function _k(e, t, a, i) {
      var o = ci(W, e, i, t);
      return o.elementType = xt, o.lanes = a, o;
    }
    function Gb(e, t, a, i) {
      var o = ci(ae, e, i, t);
      o.elementType = tn, o.lanes = a;
      var s = {
        isHidden: !1
      };
      return o.stateNode = s, o;
    }
    function C0(e, t, a) {
      var i = ci(ve, e, null, t);
      return i.lanes = a, i;
    }
    function kk() {
      var e = ci(q, null, null, Ce);
      return e.elementType = "DELETED", e;
    }
    function Dk(e) {
      var t = ci(Xe, null, null, Ce);
      return t.stateNode = e, t;
    }
    function b0(e, t, a) {
      var i = e.children !== null ? e.children : [], o = ci(oe, i, e.key, t);
      return o.lanes = a, o.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        // Used by persistent updates
        implementation: e.implementation
      }, o;
    }
    function Kb(e, t) {
      return e === null && (e = ci(Z, null, null, Ce)), e.tag = t.tag, e.key = t.key, e.elementType = t.elementType, e.type = t.type, e.stateNode = t.stateNode, e.return = t.return, e.child = t.child, e.sibling = t.sibling, e.index = t.index, e.ref = t.ref, e.pendingProps = t.pendingProps, e.memoizedProps = t.memoizedProps, e.updateQueue = t.updateQueue, e.memoizedState = t.memoizedState, e.dependencies = t.dependencies, e.mode = t.mode, e.flags = t.flags, e.subtreeFlags = t.subtreeFlags, e.deletions = t.deletions, e.lanes = t.lanes, e.childLanes = t.childLanes, e.alternate = t.alternate, e.actualDuration = t.actualDuration, e.actualStartTime = t.actualStartTime, e.selfBaseDuration = t.selfBaseDuration, e.treeBaseDuration = t.treeBaseDuration, e._debugSource = t._debugSource, e._debugOwner = t._debugOwner, e._debugNeedsRemount = t._debugNeedsRemount, e._debugHookTypes = t._debugHookTypes, e;
    }
    function Ok(e, t, a, i, o) {
      this.tag = t, this.containerInfo = e, this.pendingChildren = null, this.current = null, this.pingCache = null, this.finishedWork = null, this.timeoutHandle = rg, this.context = null, this.pendingContext = null, this.callbackNode = null, this.callbackPriority = an, this.eventTimes = Us(ie), this.expirationTimes = Us(on), this.pendingLanes = ie, this.suspendedLanes = ie, this.pingedLanes = ie, this.expiredLanes = ie, this.mutableReadLanes = ie, this.finishedLanes = ie, this.entangledLanes = ie, this.entanglements = Us(ie), this.identifierPrefix = i, this.onRecoverableError = o, this.mutableSourceEagerHydrationData = null, this.effectDuration = 0, this.passiveEffectDuration = 0;
      {
        this.memoizedUpdaters = /* @__PURE__ */ new Set();
        for (var s = this.pendingUpdatersLaneMap = [], f = 0; f < ks; f++)
          s.push(/* @__PURE__ */ new Set());
      }
      switch (t) {
        case Bh:
          this._debugRootType = a ? "hydrateRoot()" : "createRoot()";
          break;
        case ju:
          this._debugRootType = a ? "hydrate()" : "render()";
          break;
      }
    }
    function qb(e, t, a, i, o, s, f, p, v, E) {
      var C = new Ok(e, t, a, p, v), M = Rk(t, s);
      C.current = M, M.stateNode = C;
      {
        var D = {
          element: i,
          isDehydrated: a,
          cache: null,
          // not enabled yet
          transitions: null,
          pendingSuspenseBoundaries: null
        };
        M.memoizedState = D;
      }
      return Ug(M), C;
    }
    var T0 = "18.3.1";
    function Mk(e, t, a) {
      var i = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null;
      return pr(i), {
        // This tag allow us to uniquely identify this as a React Portal
        $$typeof: Hr,
        key: i == null ? null : "" + i,
        children: e,
        containerInfo: t,
        implementation: a
      };
    }
    var R0, w0;
    R0 = !1, w0 = {};
    function Xb(e) {
      if (!e)
        return si;
      var t = mi(e), a = pw(t);
      if (t.tag === Q) {
        var i = t.type;
        if (Kl(i))
          return RE(t, i, a);
      }
      return a;
    }
    function Nk(e, t) {
      {
        var a = mi(e);
        if (a === void 0) {
          if (typeof e.render == "function")
            throw new Error("Unable to find node on an unmounted component.");
          var i = Object.keys(e).join(",");
          throw new Error("Argument appears to not be a ReactComponent. Keys: " + i);
        }
        var o = hd(a);
        if (o === null)
          return null;
        if (o.mode & dn) {
          var s = dt(a) || "Component";
          if (!w0[s]) {
            w0[s] = !0;
            var f = gn;
            try {
              Sn(o), a.mode & dn ? S("%s is deprecated in StrictMode. %s was passed an instance of %s which is inside StrictMode. Instead, add a ref directly to the element you want to reference. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-find-node", t, t, s) : S("%s is deprecated in StrictMode. %s was passed an instance of %s which renders StrictMode children. Instead, add a ref directly to the element you want to reference. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-find-node", t, t, s);
            } finally {
              f ? Sn(f) : sn();
            }
          }
        }
        return o.stateNode;
      }
    }
    function Jb(e, t, a, i, o, s, f, p) {
      var v = !1, E = null;
      return qb(e, t, v, E, a, i, o, s, f);
    }
    function Zb(e, t, a, i, o, s, f, p, v, E) {
      var C = !0, M = qb(a, i, C, e, o, s, f, p, v);
      M.context = Xb(null);
      var D = M.current, B = wa(), $ = Ku(D), G = $o(B, $);
      return G.callback = t ?? null, Bu(D, G, $), P_(M, $, B), M;
    }
    function ev(e, t, a, i) {
      fu(t, e);
      var o = t.current, s = wa(), f = Ku(o);
      Hc(f);
      var p = Xb(a);
      t.context === null ? t.context = p : t.pendingContext = p, $r && gn !== null && !R0 && (R0 = !0, S(`Render methods should be a pure function of props and state; triggering nested component updates from render is not allowed. If necessary, trigger nested updates in componentDidUpdate.

Check the render method of %s.`, dt(gn) || "Unknown"));
      var v = $o(s, f);
      v.payload = {
        element: e
      }, i = i === void 0 ? null : i, i !== null && (typeof i != "function" && S("render(...): Expected the last optional `callback` argument to be a function. Instead received: %s.", i), v.callback = i);
      var E = Bu(o, v, f);
      return E !== null && (fr(E, o, f, s), nm(E, o, f)), f;
    }
    function Ym(e) {
      var t = e.current;
      if (!t.child)
        return null;
      switch (t.child.tag) {
        case q:
          return t.child.stateNode;
        default:
          return t.child.stateNode;
      }
    }
    function Lk(e) {
      switch (e.tag) {
        case A: {
          var t = e.stateNode;
          if (Oe(t)) {
            var a = Tu(t);
            $_(t, a);
          }
          break;
        }
        case Ne: {
          Qo(function() {
            var o = $a(e, Ve);
            if (o !== null) {
              var s = wa();
              fr(o, e, Ve, s);
            }
          });
          var i = Ve;
          x0(e, i);
          break;
        }
      }
    }
    function eT(e, t) {
      var a = e.memoizedState;
      a !== null && a.dehydrated !== null && (a.retryLane = zd(a.retryLane, t));
    }
    function x0(e, t) {
      eT(e, t);
      var a = e.alternate;
      a && eT(a, t);
    }
    function Ak(e) {
      if (e.tag === Ne) {
        var t = Eu, a = $a(e, t);
        if (a !== null) {
          var i = wa();
          fr(a, e, t, i);
        }
        x0(e, t);
      }
    }
    function Uk(e) {
      if (e.tag === Ne) {
        var t = Ku(e), a = $a(e, t);
        if (a !== null) {
          var i = wa();
          fr(a, e, t, i);
        }
        x0(e, t);
      }
    }
    function tT(e) {
      var t = yd(e);
      return t === null ? null : t.stateNode;
    }
    var nT = function(e) {
      return null;
    };
    function zk(e) {
      return nT(e);
    }
    var rT = function(e) {
      return !1;
    };
    function Fk(e) {
      return rT(e);
    }
    var aT = null, iT = null, lT = null, oT = null, uT = null, sT = null, cT = null, fT = null, dT = null;
    {
      var pT = function(e, t, a) {
        var i = t[a], o = At(e) ? e.slice() : yt({}, e);
        return a + 1 === t.length ? (At(o) ? o.splice(i, 1) : delete o[i], o) : (o[i] = pT(e[i], t, a + 1), o);
      }, vT = function(e, t) {
        return pT(e, t, 0);
      }, hT = function(e, t, a, i) {
        var o = t[i], s = At(e) ? e.slice() : yt({}, e);
        if (i + 1 === t.length) {
          var f = a[i];
          s[f] = s[o], At(s) ? s.splice(o, 1) : delete s[o];
        } else
          s[o] = hT(
            // $FlowFixMe number or string is fine here
            e[o],
            t,
            a,
            i + 1
          );
        return s;
      }, mT = function(e, t, a) {
        if (t.length !== a.length) {
          x("copyWithRename() expects paths of the same length");
          return;
        } else
          for (var i = 0; i < a.length - 1; i++)
            if (t[i] !== a[i]) {
              x("copyWithRename() expects paths to be the same except for the deepest key");
              return;
            }
        return hT(e, t, a, 0);
      }, yT = function(e, t, a, i) {
        if (a >= t.length)
          return i;
        var o = t[a], s = At(e) ? e.slice() : yt({}, e);
        return s[o] = yT(e[o], t, a + 1, i), s;
      }, gT = function(e, t, a) {
        return yT(e, t, 0, a);
      }, _0 = function(e, t) {
        for (var a = e.memoizedState; a !== null && t > 0; )
          a = a.next, t--;
        return a;
      };
      aT = function(e, t, a, i) {
        var o = _0(e, t);
        if (o !== null) {
          var s = gT(o.memoizedState, a, i);
          o.memoizedState = s, o.baseState = s, e.memoizedProps = yt({}, e.memoizedProps);
          var f = $a(e, Ve);
          f !== null && fr(f, e, Ve, on);
        }
      }, iT = function(e, t, a) {
        var i = _0(e, t);
        if (i !== null) {
          var o = vT(i.memoizedState, a);
          i.memoizedState = o, i.baseState = o, e.memoizedProps = yt({}, e.memoizedProps);
          var s = $a(e, Ve);
          s !== null && fr(s, e, Ve, on);
        }
      }, lT = function(e, t, a, i) {
        var o = _0(e, t);
        if (o !== null) {
          var s = mT(o.memoizedState, a, i);
          o.memoizedState = s, o.baseState = s, e.memoizedProps = yt({}, e.memoizedProps);
          var f = $a(e, Ve);
          f !== null && fr(f, e, Ve, on);
        }
      }, oT = function(e, t, a) {
        e.pendingProps = gT(e.memoizedProps, t, a), e.alternate && (e.alternate.pendingProps = e.pendingProps);
        var i = $a(e, Ve);
        i !== null && fr(i, e, Ve, on);
      }, uT = function(e, t) {
        e.pendingProps = vT(e.memoizedProps, t), e.alternate && (e.alternate.pendingProps = e.pendingProps);
        var a = $a(e, Ve);
        a !== null && fr(a, e, Ve, on);
      }, sT = function(e, t, a) {
        e.pendingProps = mT(e.memoizedProps, t, a), e.alternate && (e.alternate.pendingProps = e.pendingProps);
        var i = $a(e, Ve);
        i !== null && fr(i, e, Ve, on);
      }, cT = function(e) {
        var t = $a(e, Ve);
        t !== null && fr(t, e, Ve, on);
      }, fT = function(e) {
        nT = e;
      }, dT = function(e) {
        rT = e;
      };
    }
    function jk(e) {
      var t = hd(e);
      return t === null ? null : t.stateNode;
    }
    function Pk(e) {
      return null;
    }
    function Hk() {
      return gn;
    }
    function Bk(e) {
      var t = e.findFiberByHostInstance, a = T.ReactCurrentDispatcher;
      return Sd({
        bundleType: e.bundleType,
        version: e.version,
        rendererPackageName: e.rendererPackageName,
        rendererConfig: e.rendererConfig,
        overrideHookState: aT,
        overrideHookStateDeletePath: iT,
        overrideHookStateRenamePath: lT,
        overrideProps: oT,
        overridePropsDeletePath: uT,
        overridePropsRenamePath: sT,
        setErrorHandler: fT,
        setSuspenseHandler: dT,
        scheduleUpdate: cT,
        currentDispatcherRef: a,
        findHostInstanceByFiber: jk,
        findFiberByHostInstance: t || Pk,
        // React Refresh
        findHostInstancesForRefresh: yk,
        scheduleRefresh: hk,
        scheduleRoot: mk,
        setRefreshHandler: vk,
        // Enables DevTools to append owner stacks to error messages in DEV mode.
        getCurrentFiber: Hk,
        // Enables DevTools to detect reconciler version rather than renderer version
        // which may not match for third party renderers.
        reconcilerVersion: T0
      });
    }
    var ST = typeof reportError == "function" ? (
      // In modern browsers, reportError will dispatch an error event,
      // emulating an uncaught JavaScript error.
      reportError
    ) : function(e) {
      console.error(e);
    };
    function k0(e) {
      this._internalRoot = e;
    }
    Wm.prototype.render = k0.prototype.render = function(e) {
      var t = this._internalRoot;
      if (t === null)
        throw new Error("Cannot update an unmounted root.");
      {
        typeof arguments[1] == "function" ? S("render(...): does not support the second callback argument. To execute a side effect after rendering, declare it in a component body with useEffect().") : Qm(arguments[1]) ? S("You passed a container to the second argument of root.render(...). You don't need to pass it again since you already passed it to create the root.") : typeof arguments[1] < "u" && S("You passed a second argument to root.render(...) but it only accepts one argument.");
        var a = t.containerInfo;
        if (a.nodeType !== Tn) {
          var i = tT(t.current);
          i && i.parentNode !== a && S("render(...): It looks like the React-rendered content of the root container was removed without using React. This is not supported and will cause errors. Instead, call root.unmount() to empty a root's container.");
        }
      }
      ev(e, t, null, null);
    }, Wm.prototype.unmount = k0.prototype.unmount = function() {
      typeof arguments[0] == "function" && S("unmount(...): does not support a callback argument. To execute a side effect after rendering, declare it in a component body with useEffect().");
      var e = this._internalRoot;
      if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        Mb() && S("Attempted to synchronously unmount a root while React was already rendering. React cannot finish unmounting the root until the current render has completed, which may lead to a race condition."), Qo(function() {
          ev(null, e, null, null);
        }), SE(t);
      }
    };
    function Vk(e, t) {
      if (!Qm(e))
        throw new Error("createRoot(...): Target container is not a DOM element.");
      ET(e);
      var a = !1, i = !1, o = "", s = ST;
      t != null && (t.hydrate ? x("hydrate through createRoot is deprecated. Use ReactDOMClient.hydrateRoot(container, <App />) instead.") : typeof t == "object" && t !== null && t.$$typeof === Cr && S(`You passed a JSX element to createRoot. You probably meant to call root.render instead. Example usage:

  let root = createRoot(domContainer);
  root.render(<App />);`), t.unstable_strictMode === !0 && (a = !0), t.identifierPrefix !== void 0 && (o = t.identifierPrefix), t.onRecoverableError !== void 0 && (s = t.onRecoverableError), t.transitionCallbacks !== void 0 && t.transitionCallbacks);
      var f = Jb(e, Bh, null, a, i, o, s);
      Ah(f.current, e);
      var p = e.nodeType === Tn ? e.parentNode : e;
      return lp(p), new k0(f);
    }
    function Wm(e) {
      this._internalRoot = e;
    }
    function $k(e) {
      e && nf(e);
    }
    Wm.prototype.unstable_scheduleHydration = $k;
    function Ik(e, t, a) {
      if (!Qm(e))
        throw new Error("hydrateRoot(...): Target container is not a DOM element.");
      ET(e), t === void 0 && S("Must provide initial children as second argument to hydrateRoot. Example usage: hydrateRoot(domContainer, <App />)");
      var i = a ?? null, o = a != null && a.hydratedSources || null, s = !1, f = !1, p = "", v = ST;
      a != null && (a.unstable_strictMode === !0 && (s = !0), a.identifierPrefix !== void 0 && (p = a.identifierPrefix), a.onRecoverableError !== void 0 && (v = a.onRecoverableError));
      var E = Zb(t, null, e, Bh, i, s, f, p, v);
      if (Ah(E.current, e), lp(e), o)
        for (var C = 0; C < o.length; C++) {
          var M = o[C];
          Gw(E, M);
        }
      return new Wm(E);
    }
    function Qm(e) {
      return !!(e && (e.nodeType === Yr || e.nodeType === fa || e.nodeType === Jf || !Te));
    }
    function tv(e) {
      return !!(e && (e.nodeType === Yr || e.nodeType === fa || e.nodeType === Jf || e.nodeType === Tn && e.nodeValue === " react-mount-point-unstable "));
    }
    function ET(e) {
      e.nodeType === Yr && e.tagName && e.tagName.toUpperCase() === "BODY" && S("createRoot(): Creating roots directly with document.body is discouraged, since its children are often manipulated by third-party scripts and browser extensions. This may lead to subtle reconciliation issues. Try using a container element created for your app."), yp(e) && (e._reactRootContainer ? S("You are calling ReactDOMClient.createRoot() on a container that was previously passed to ReactDOM.render(). This is not supported.") : S("You are calling ReactDOMClient.createRoot() on a container that has already been passed to createRoot() before. Instead, call root.render() on the existing root instead if you want to update it."));
    }
    var Yk = T.ReactCurrentOwner, CT;
    CT = function(e) {
      if (e._reactRootContainer && e.nodeType !== Tn) {
        var t = tT(e._reactRootContainer.current);
        t && t.parentNode !== e && S("render(...): It looks like the React-rendered content of this container was removed without using React. This is not supported and will cause errors. Instead, call ReactDOM.unmountComponentAtNode to empty a container.");
      }
      var a = !!e._reactRootContainer, i = D0(e), o = !!(i && zu(i));
      o && !a && S("render(...): Replacing React-rendered children with a new root component. If you intended to update the children of this node, you should instead have the existing children update their state and render the new components instead of calling ReactDOM.render."), e.nodeType === Yr && e.tagName && e.tagName.toUpperCase() === "BODY" && S("render(): Rendering components directly into document.body is discouraged, since its children are often manipulated by third-party scripts and browser extensions. This may lead to subtle reconciliation issues. Try rendering into a container element created for your app.");
    };
    function D0(e) {
      return e ? e.nodeType === fa ? e.documentElement : e.firstChild : null;
    }
    function bT() {
    }
    function Wk(e, t, a, i, o) {
      if (o) {
        if (typeof i == "function") {
          var s = i;
          i = function() {
            var D = Ym(f);
            s.call(D);
          };
        }
        var f = Zb(
          t,
          i,
          e,
          ju,
          null,
          // hydrationCallbacks
          !1,
          // isStrictMode
          !1,
          // concurrentUpdatesByDefaultOverride,
          "",
          // identifierPrefix
          bT
        );
        e._reactRootContainer = f, Ah(f.current, e);
        var p = e.nodeType === Tn ? e.parentNode : e;
        return lp(p), Qo(), f;
      } else {
        for (var v; v = e.lastChild; )
          e.removeChild(v);
        if (typeof i == "function") {
          var E = i;
          i = function() {
            var D = Ym(C);
            E.call(D);
          };
        }
        var C = Jb(
          e,
          ju,
          null,
          // hydrationCallbacks
          !1,
          // isStrictMode
          !1,
          // concurrentUpdatesByDefaultOverride,
          "",
          // identifierPrefix
          bT
        );
        e._reactRootContainer = C, Ah(C.current, e);
        var M = e.nodeType === Tn ? e.parentNode : e;
        return lp(M), Qo(function() {
          ev(t, C, a, i);
        }), C;
      }
    }
    function Qk(e, t) {
      e !== null && typeof e != "function" && S("%s(...): Expected the last optional `callback` argument to be a function. Instead received: %s.", t, e);
    }
    function Gm(e, t, a, i, o) {
      CT(a), Qk(o === void 0 ? null : o, "render");
      var s = a._reactRootContainer, f;
      if (!s)
        f = Wk(a, t, e, o, i);
      else {
        if (f = s, typeof o == "function") {
          var p = o;
          o = function() {
            var v = Ym(f);
            p.call(v);
          };
        }
        ev(t, f, e, o);
      }
      return Ym(f);
    }
    var TT = !1;
    function Gk(e) {
      {
        TT || (TT = !0, S("findDOMNode is deprecated and will be removed in the next major release. Instead, add a ref directly to the element you want to reference. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-find-node"));
        var t = Yk.current;
        if (t !== null && t.stateNode !== null) {
          var a = t.stateNode._warnedAboutRefsInRender;
          a || S("%s is accessing findDOMNode inside its render(). render() should be a pure function of props and state. It should never access something that requires stale data from the previous render, such as refs. Move this logic to componentDidMount and componentDidUpdate instead.", Dt(t.type) || "A component"), t.stateNode._warnedAboutRefsInRender = !0;
        }
      }
      return e == null ? null : e.nodeType === Yr ? e : Nk(e, "findDOMNode");
    }
    function Kk(e, t, a) {
      if (S("ReactDOM.hydrate is no longer supported in React 18. Use hydrateRoot instead. Until you switch to the new API, your app will behave as if it's running React 17. Learn more: https://reactjs.org/link/switch-to-createroot"), !tv(t))
        throw new Error("Target container is not a DOM element.");
      {
        var i = yp(t) && t._reactRootContainer === void 0;
        i && S("You are calling ReactDOM.hydrate() on a container that was previously passed to ReactDOMClient.createRoot(). This is not supported. Did you mean to call hydrateRoot(container, element)?");
      }
      return Gm(null, e, t, !0, a);
    }
    function qk(e, t, a) {
      if (S("ReactDOM.render is no longer supported in React 18. Use createRoot instead. Until you switch to the new API, your app will behave as if it's running React 17. Learn more: https://reactjs.org/link/switch-to-createroot"), !tv(t))
        throw new Error("Target container is not a DOM element.");
      {
        var i = yp(t) && t._reactRootContainer === void 0;
        i && S("You are calling ReactDOM.render() on a container that was previously passed to ReactDOMClient.createRoot(). This is not supported. Did you mean to call root.render(element)?");
      }
      return Gm(null, e, t, !1, a);
    }
    function Xk(e, t, a, i) {
      if (S("ReactDOM.unstable_renderSubtreeIntoContainer() is no longer supported in React 18. Consider using a portal instead. Until you switch to the createRoot API, your app will behave as if it's running React 17. Learn more: https://reactjs.org/link/switch-to-createroot"), !tv(a))
        throw new Error("Target container is not a DOM element.");
      if (e == null || !uu(e))
        throw new Error("parentComponent must be a valid React Component");
      return Gm(e, t, a, !1, i);
    }
    var RT = !1;
    function Jk(e) {
      if (RT || (RT = !0, S("unmountComponentAtNode is deprecated and will be removed in the next major release. Switch to the createRoot API. Learn more: https://reactjs.org/link/switch-to-createroot")), !tv(e))
        throw new Error("unmountComponentAtNode(...): Target container is not a DOM element.");
      {
        var t = yp(e) && e._reactRootContainer === void 0;
        t && S("You are calling ReactDOM.unmountComponentAtNode() on a container that was previously passed to ReactDOMClient.createRoot(). This is not supported. Did you mean to call root.unmount()?");
      }
      if (e._reactRootContainer) {
        {
          var a = D0(e), i = a && !zu(a);
          i && S("unmountComponentAtNode(): The node you're attempting to unmount was rendered by another copy of React.");
        }
        return Qo(function() {
          Gm(null, null, e, !1, function() {
            e._reactRootContainer = null, SE(e);
          });
        }), !0;
      } else {
        {
          var o = D0(e), s = !!(o && zu(o)), f = e.nodeType === Yr && tv(e.parentNode) && !!e.parentNode._reactRootContainer;
          s && S("unmountComponentAtNode(): The node you're attempting to unmount was rendered by React and is not a top-level container. %s", f ? "You may have accidentally passed in a React root node instead of its container." : "Instead, have the parent component update its state and rerender in order to remove this component.");
        }
        return !1;
      }
    }
    Hd(Lk), Ps(Ak), Vd(Uk), rh(xr), Yd(xy), (typeof Map != "function" || // $FlowIssue Flow incorrectly thinks Map has no prototype
    Map.prototype == null || typeof Map.prototype.forEach != "function" || typeof Set != "function" || // $FlowIssue Flow incorrectly thinks Set has no prototype
    Set.prototype == null || typeof Set.prototype.clear != "function" || typeof Set.prototype.forEach != "function") && S("React depends on Map and Set built-in types. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills"), ld(e1), Dc(l0, I_, Qo);
    function Zk(e, t) {
      var a = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
      if (!Qm(t))
        throw new Error("Target container is not a DOM element.");
      return Mk(e, t, null, a);
    }
    function eD(e, t, a, i) {
      return Xk(e, t, a, i);
    }
    var O0 = {
      usingClientEntryPoint: !1,
      // Keep in sync with ReactTestUtils.js.
      // This is an array for better minification.
      Events: [zu, Sf, Uh, ou, yo, l0]
    };
    function tD(e, t) {
      return O0.usingClientEntryPoint || S('You are importing createRoot from "react-dom" which is not supported. You should instead import it from "react-dom/client".'), Vk(e, t);
    }
    function nD(e, t, a) {
      return O0.usingClientEntryPoint || S('You are importing hydrateRoot from "react-dom" which is not supported. You should instead import it from "react-dom/client".'), Ik(e, t, a);
    }
    function rD(e) {
      return Mb() && S("flushSync was called from inside a lifecycle method. React cannot flush when React is already rendering. Consider moving this call to a scheduler task or micro task."), Qo(e);
    }
    var aD = Bk({
      findFiberByHostInstance: nc,
      bundleType: 1,
      version: T0,
      rendererPackageName: "react-dom"
    });
    if (!aD && bn && window.top === window.self && (navigator.userAgent.indexOf("Chrome") > -1 && navigator.userAgent.indexOf("Edge") === -1 || navigator.userAgent.indexOf("Firefox") > -1)) {
      var wT = window.location.protocol;
      /^(https?|file):$/.test(wT) && console.info("%cDownload the React DevTools for a better development experience: https://reactjs.org/link/react-devtools" + (wT === "file:" ? `
You might need to use a local HTTP server (instead of file://): https://reactjs.org/link/react-devtools-faq` : ""), "font-weight:bold");
    }
    Ga.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = O0, Ga.createPortal = Zk, Ga.createRoot = tD, Ga.findDOMNode = Gk, Ga.flushSync = rD, Ga.hydrate = Kk, Ga.hydrateRoot = nD, Ga.render = qk, Ga.unmountComponentAtNode = Jk, Ga.unstable_batchedUpdates = l0, Ga.unstable_renderSubtreeIntoContainer = eD, Ga.version = T0, typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
  }(), Ga;
}
var JT = {};
function ZT() {
  if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) {
    if (JT.NODE_ENV !== "production")
      throw new Error("^_^");
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(ZT);
    } catch (b) {
      console.error(b);
    }
  }
}
JT.NODE_ENV === "production" ? (ZT(), F0.exports = _D()) : F0.exports = kD();
var V0 = F0.exports;
const DD = /* @__PURE__ */ $T(V0), OD = "_AutoResizeTextarea_1s70s_2", MD = "_proofreadingResultModalLoading_1s70s_8", ND = "_spScaleAlpha_1s70s_1", LD = "_spScaleAlphaBefore_1s70s_1", AD = "_spScaleAlphaAfter_1s70s_1", UD = "_proofreadingModalBody_1s70s_62", zD = "_proofreadingModalBodyPrompt_1s70s_69", FD = "_proofreadingModalBodyPromptSelect_1s70s_74", jD = "_proofreadingModalBodyPromptTextarea_1s70s_83", PD = "_proofreadingModalBodyPrompButton_1s70s_96", HD = "_proofreadingModalBodyTextareas_1s70s_100", BD = "_proofreadingModalBodyTextareasUnitLabel_1s70s_105", VD = "_proofreadingModalBodyTextareasUnitFocus_1s70s_111", $D = "_proofreadingModalBodyTextareasUnit_1s70s_105", Ai = {
  AutoResizeTextarea: OD,
  proofreadingResultModalLoading: MD,
  spScaleAlpha: ND,
  spScaleAlphaBefore: LD,
  spScaleAlphaAfter: AD,
  proofreadingModalBody: UD,
  proofreadingModalBodyPrompt: zD,
  proofreadingModalBodyPromptSelect: FD,
  proofreadingModalBodyPromptTextarea: jD,
  proofreadingModalBodyPrompButton: PD,
  proofreadingModalBodyTextareas: HD,
  proofreadingModalBodyTextareasUnitLabel: BD,
  proofreadingModalBodyTextareasUnitFocus: VD,
  proofreadingModalBodyTextareasUnit: $D
};
var eR = { exports: {} };
/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/
(function(b) {
  (function() {
    var m = {}.hasOwnProperty;
    function g() {
      for (var U = "", x = 0; x < arguments.length; x++) {
        var S = arguments[x];
        S && (U = L(U, T(S)));
      }
      return U;
    }
    function T(U) {
      if (typeof U == "string" || typeof U == "number")
        return U;
      if (typeof U != "object")
        return "";
      if (Array.isArray(U))
        return g.apply(null, U);
      if (U.toString !== Object.prototype.toString && !U.toString.toString().includes("[native code]"))
        return U.toString();
      var x = "";
      for (var S in U)
        m.call(U, S) && U[S] && (x = L(x, S));
      return x;
    }
    function L(U, x) {
      return x ? U ? U + " " + x : U + x : U;
    }
    b.exports ? (g.default = g, b.exports = g) : window.classNames = g;
  })();
})(eR);
var ID = eR.exports;
const Wf = /* @__PURE__ */ $T(ID);
function YD(b) {
  if (Array.isArray(b)) {
    for (var m = 0, g = Array(b.length); m < b.length; m++)
      g[m] = b[m];
    return g;
  } else
    return Array.from(b);
}
var iy = !1;
if (typeof window < "u") {
  var UT = {
    get passive() {
      iy = !0;
    }
  };
  window.addEventListener("testPassive", null, UT), window.removeEventListener("testPassive", null, UT);
}
var $0 = typeof window < "u" && window.navigator && window.navigator.platform && (/iP(ad|hone|od)/.test(window.navigator.platform) || window.navigator.platform === "MacIntel" && window.navigator.maxTouchPoints > 1), ao = [], Qf = !1, I0 = -1, ov = void 0, uv = void 0, tR = function(m) {
  return ao.some(function(g) {
    return !!(g.options.allowTouchMove && g.options.allowTouchMove(m));
  });
}, cv = function(m) {
  var g = m || window.event;
  return tR(g.target) || g.touches.length > 1 ? !0 : (g.preventDefault && g.preventDefault(), !1);
}, WD = function(m) {
  if (uv === void 0) {
    var g = !!m && m.reserveScrollBarGap === !0, T = window.innerWidth - document.documentElement.clientWidth;
    g && T > 0 && (uv = document.body.style.paddingRight, document.body.style.paddingRight = T + "px");
  }
  ov === void 0 && (ov = document.body.style.overflow, document.body.style.overflow = "hidden");
}, nR = function() {
  uv !== void 0 && (document.body.style.paddingRight = uv, uv = void 0), ov !== void 0 && (document.body.style.overflow = ov, ov = void 0);
}, QD = function(m) {
  return m ? m.scrollHeight - m.scrollTop <= m.clientHeight : !1;
}, GD = function(m, g) {
  var T = m.targetTouches[0].clientY - I0;
  return tR(m.target) ? !1 : g && g.scrollTop === 0 && T > 0 || QD(g) && T < 0 ? cv(m) : (m.stopPropagation(), !0);
}, KD = function(m, g) {
  if (!m) {
    console.error("disableBodyScroll unsuccessful - targetElement must be provided when calling disableBodyScroll on IOS devices.");
    return;
  }
  if (!ao.some(function(L) {
    return L.targetElement === m;
  })) {
    var T = {
      targetElement: m,
      options: g || {}
    };
    ao = [].concat(YD(ao), [T]), $0 ? (m.ontouchstart = function(L) {
      L.targetTouches.length === 1 && (I0 = L.targetTouches[0].clientY);
    }, m.ontouchmove = function(L) {
      L.targetTouches.length === 1 && GD(L, m);
    }, Qf || (document.addEventListener("touchmove", cv, iy ? { passive: !1 } : void 0), Qf = !0)) : WD(g);
  }
}, qD = function() {
  $0 ? (ao.forEach(function(m) {
    m.targetElement.ontouchstart = null, m.targetElement.ontouchmove = null;
  }), Qf && (document.removeEventListener("touchmove", cv, iy ? { passive: !1 } : void 0), Qf = !1), I0 = -1) : nR(), ao = [];
}, XD = function(m) {
  if (!m) {
    console.error("enableBodyScroll unsuccessful - targetElement must be provided when calling enableBodyScroll on IOS devices.");
    return;
  }
  ao = ao.filter(function(g) {
    return g.targetElement !== m;
  }), $0 ? (m.ontouchstart = null, m.ontouchmove = null, Qf && ao.length === 0 && (document.removeEventListener("touchmove", cv, iy ? { passive: !1 } : void 0), Qf = !1)) : ao.length || nR();
};
const JD = () => {
  const b = re.useRef(null), m = re.useCallback((L) => {
    b.current && KD(b.current, L);
  }, []), g = re.useCallback(() => {
    b.current && XD(b.current);
  }, []);
  return re.useEffect(
    () => () => {
      qD();
    },
    []
  ), {
    setRef: re.useCallback((L) => {
      L !== null && (b.current = L);
    }, []),
    disableScroll: m,
    enableScroll: g
  };
};
/*!
* tabbable 6.2.0
* @license MIT, https://github.com/focus-trap/tabbable/blob/master/LICENSE
*/
var rR = ["input:not([inert])", "select:not([inert])", "textarea:not([inert])", "a[href]:not([inert])", "button:not([inert])", "[tabindex]:not(slot):not([inert])", "audio[controls]:not([inert])", "video[controls]:not([inert])", '[contenteditable]:not([contenteditable="false"]):not([inert])', "details>summary:first-of-type:not([inert])", "details:not([inert])"], ty = /* @__PURE__ */ rR.join(","), aR = typeof Element > "u", Sc = aR ? function() {
} : Element.prototype.matches || Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector, ny = !aR && Element.prototype.getRootNode ? function(b) {
  var m;
  return b == null || (m = b.getRootNode) === null || m === void 0 ? void 0 : m.call(b);
} : function(b) {
  return b == null ? void 0 : b.ownerDocument;
}, ry = function b(m, g) {
  var T;
  g === void 0 && (g = !0);
  var L = m == null || (T = m.getAttribute) === null || T === void 0 ? void 0 : T.call(m, "inert"), U = L === "" || L === "true", x = U || g && m && b(m.parentNode);
  return x;
}, ZD = function(m) {
  var g, T = m == null || (g = m.getAttribute) === null || g === void 0 ? void 0 : g.call(m, "contenteditable");
  return T === "" || T === "true";
}, iR = function(m, g, T) {
  if (ry(m))
    return [];
  var L = Array.prototype.slice.apply(m.querySelectorAll(ty));
  return g && Sc.call(m, ty) && L.unshift(m), L = L.filter(T), L;
}, lR = function b(m, g, T) {
  for (var L = [], U = Array.from(m); U.length; ) {
    var x = U.shift();
    if (!ry(x, !1))
      if (x.tagName === "SLOT") {
        var S = x.assignedElements(), ne = S.length ? S : x.children, te = b(ne, !0, T);
        T.flatten ? L.push.apply(L, te) : L.push({
          scopeParent: x,
          candidates: te
        });
      } else {
        var Q = Sc.call(x, ty);
        Q && T.filter(x) && (g || !m.includes(x)) && L.push(x);
        var Z = x.shadowRoot || // check for an undisclosed shadow
        typeof T.getShadowRoot == "function" && T.getShadowRoot(x), A = !ry(Z, !1) && (!T.shadowRootFilter || T.shadowRootFilter(x));
        if (Z && A) {
          var oe = b(Z === !0 ? x.children : Z.children, !0, T);
          T.flatten ? L.push.apply(L, oe) : L.push({
            scopeParent: x,
            candidates: oe
          });
        } else
          U.unshift.apply(U, x.children);
      }
  }
  return L;
}, oR = function(m) {
  return !isNaN(parseInt(m.getAttribute("tabindex"), 10));
}, gc = function(m) {
  if (!m)
    throw new Error("No node provided");
  return m.tabIndex < 0 && (/^(AUDIO|VIDEO|DETAILS)$/.test(m.tagName) || ZD(m)) && !oR(m) ? 0 : m.tabIndex;
}, eO = function(m, g) {
  var T = gc(m);
  return T < 0 && g && !oR(m) ? 0 : T;
}, tO = function(m, g) {
  return m.tabIndex === g.tabIndex ? m.documentOrder - g.documentOrder : m.tabIndex - g.tabIndex;
}, uR = function(m) {
  return m.tagName === "INPUT";
}, nO = function(m) {
  return uR(m) && m.type === "hidden";
}, rO = function(m) {
  var g = m.tagName === "DETAILS" && Array.prototype.slice.apply(m.children).some(function(T) {
    return T.tagName === "SUMMARY";
  });
  return g;
}, aO = function(m, g) {
  for (var T = 0; T < m.length; T++)
    if (m[T].checked && m[T].form === g)
      return m[T];
}, iO = function(m) {
  if (!m.name)
    return !0;
  var g = m.form || ny(m), T = function(S) {
    return g.querySelectorAll('input[type="radio"][name="' + S + '"]');
  }, L;
  if (typeof window < "u" && typeof window.CSS < "u" && typeof window.CSS.escape == "function")
    L = T(window.CSS.escape(m.name));
  else
    try {
      L = T(m.name);
    } catch (x) {
      return console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s", x.message), !1;
    }
  var U = aO(L, m.form);
  return !U || U === m;
}, lO = function(m) {
  return uR(m) && m.type === "radio";
}, oO = function(m) {
  return lO(m) && !iO(m);
}, uO = function(m) {
  var g, T = m && ny(m), L = (g = T) === null || g === void 0 ? void 0 : g.host, U = !1;
  if (T && T !== m) {
    var x, S, ne;
    for (U = !!((x = L) !== null && x !== void 0 && (S = x.ownerDocument) !== null && S !== void 0 && S.contains(L) || m != null && (ne = m.ownerDocument) !== null && ne !== void 0 && ne.contains(m)); !U && L; ) {
      var te, Q, Z;
      T = ny(L), L = (te = T) === null || te === void 0 ? void 0 : te.host, U = !!((Q = L) !== null && Q !== void 0 && (Z = Q.ownerDocument) !== null && Z !== void 0 && Z.contains(L));
    }
  }
  return U;
}, zT = function(m) {
  var g = m.getBoundingClientRect(), T = g.width, L = g.height;
  return T === 0 && L === 0;
}, sO = function(m, g) {
  var T = g.displayCheck, L = g.getShadowRoot;
  if (getComputedStyle(m).visibility === "hidden")
    return !0;
  var U = Sc.call(m, "details>summary:first-of-type"), x = U ? m.parentElement : m;
  if (Sc.call(x, "details:not([open]) *"))
    return !0;
  if (!T || T === "full" || T === "legacy-full") {
    if (typeof L == "function") {
      for (var S = m; m; ) {
        var ne = m.parentElement, te = ny(m);
        if (ne && !ne.shadowRoot && L(ne) === !0)
          return zT(m);
        m.assignedSlot ? m = m.assignedSlot : !ne && te !== m.ownerDocument ? m = te.host : m = ne;
      }
      m = S;
    }
    if (uO(m))
      return !m.getClientRects().length;
    if (T !== "legacy-full")
      return !0;
  } else if (T === "non-zero-area")
    return zT(m);
  return !1;
}, cO = function(m) {
  if (/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(m.tagName))
    for (var g = m.parentElement; g; ) {
      if (g.tagName === "FIELDSET" && g.disabled) {
        for (var T = 0; T < g.children.length; T++) {
          var L = g.children.item(T);
          if (L.tagName === "LEGEND")
            return Sc.call(g, "fieldset[disabled] *") ? !0 : !L.contains(m);
        }
        return !0;
      }
      g = g.parentElement;
    }
  return !1;
}, ay = function(m, g) {
  return !(g.disabled || // we must do an inert look up to filter out any elements inside an inert ancestor
  //  because we're limited in the type of selectors we can use in JSDom (see related
  //  note related to `candidateSelectors`)
  ry(g) || nO(g) || sO(g, m) || // For a details element with a summary, the summary element gets the focus
  rO(g) || cO(g));
}, j0 = function(m, g) {
  return !(oO(g) || gc(g) < 0 || !ay(m, g));
}, fO = function(m) {
  var g = parseInt(m.getAttribute("tabindex"), 10);
  return !!(isNaN(g) || g >= 0);
}, dO = function b(m) {
  var g = [], T = [];
  return m.forEach(function(L, U) {
    var x = !!L.scopeParent, S = x ? L.scopeParent : L, ne = eO(S, x), te = x ? b(L.candidates) : S;
    ne === 0 ? x ? g.push.apply(g, te) : g.push(S) : T.push({
      documentOrder: U,
      tabIndex: ne,
      item: L,
      isScope: x,
      content: te
    });
  }), T.sort(tO).reduce(function(L, U) {
    return U.isScope ? L.push.apply(L, U.content) : L.push(U.content), L;
  }, []).concat(g);
}, pO = function(m, g) {
  g = g || {};
  var T;
  return g.getShadowRoot ? T = lR([m], g.includeContainer, {
    filter: j0.bind(null, g),
    flatten: !1,
    getShadowRoot: g.getShadowRoot,
    shadowRootFilter: fO
  }) : T = iR(m, g.includeContainer, j0.bind(null, g)), dO(T);
}, vO = function(m, g) {
  g = g || {};
  var T;
  return g.getShadowRoot ? T = lR([m], g.includeContainer, {
    filter: ay.bind(null, g),
    flatten: !0,
    getShadowRoot: g.getShadowRoot
  }) : T = iR(m, g.includeContainer, ay.bind(null, g)), T;
}, If = function(m, g) {
  if (g = g || {}, !m)
    throw new Error("No node provided");
  return Sc.call(m, ty) === !1 ? !1 : j0(g, m);
}, hO = /* @__PURE__ */ rR.concat("iframe").join(","), L0 = function(m, g) {
  if (g = g || {}, !m)
    throw new Error("No node provided");
  return Sc.call(m, hO) === !1 ? !1 : ay(g, m);
};
/*!
* focus-trap 7.5.4
* @license MIT, https://github.com/focus-trap/focus-trap/blob/master/LICENSE
*/
function FT(b, m) {
  var g = Object.keys(b);
  if (Object.getOwnPropertySymbols) {
    var T = Object.getOwnPropertySymbols(b);
    m && (T = T.filter(function(L) {
      return Object.getOwnPropertyDescriptor(b, L).enumerable;
    })), g.push.apply(g, T);
  }
  return g;
}
function jT(b) {
  for (var m = 1; m < arguments.length; m++) {
    var g = arguments[m] != null ? arguments[m] : {};
    m % 2 ? FT(Object(g), !0).forEach(function(T) {
      mO(b, T, g[T]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(b, Object.getOwnPropertyDescriptors(g)) : FT(Object(g)).forEach(function(T) {
      Object.defineProperty(b, T, Object.getOwnPropertyDescriptor(g, T));
    });
  }
  return b;
}
function mO(b, m, g) {
  return m = gO(m), m in b ? Object.defineProperty(b, m, {
    value: g,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : b[m] = g, b;
}
function yO(b, m) {
  if (typeof b != "object" || b === null) return b;
  var g = b[Symbol.toPrimitive];
  if (g !== void 0) {
    var T = g.call(b, m || "default");
    if (typeof T != "object") return T;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (m === "string" ? String : Number)(b);
}
function gO(b) {
  var m = yO(b, "string");
  return typeof m == "symbol" ? m : String(m);
}
var PT = {
  activateTrap: function(m, g) {
    if (m.length > 0) {
      var T = m[m.length - 1];
      T !== g && T.pause();
    }
    var L = m.indexOf(g);
    L === -1 || m.splice(L, 1), m.push(g);
  },
  deactivateTrap: function(m, g) {
    var T = m.indexOf(g);
    T !== -1 && m.splice(T, 1), m.length > 0 && m[m.length - 1].unpause();
  }
}, SO = function(m) {
  return m.tagName && m.tagName.toLowerCase() === "input" && typeof m.select == "function";
}, EO = function(m) {
  return (m == null ? void 0 : m.key) === "Escape" || (m == null ? void 0 : m.key) === "Esc" || (m == null ? void 0 : m.keyCode) === 27;
}, sv = function(m) {
  return (m == null ? void 0 : m.key) === "Tab" || (m == null ? void 0 : m.keyCode) === 9;
}, CO = function(m) {
  return sv(m) && !m.shiftKey;
}, bO = function(m) {
  return sv(m) && m.shiftKey;
}, HT = function(m) {
  return setTimeout(m, 0);
}, BT = function(m, g) {
  var T = -1;
  return m.every(function(L, U) {
    return g(L) ? (T = U, !1) : !0;
  }), T;
}, iv = function(m) {
  for (var g = arguments.length, T = new Array(g > 1 ? g - 1 : 0), L = 1; L < g; L++)
    T[L - 1] = arguments[L];
  return typeof m == "function" ? m.apply(void 0, T) : m;
}, qm = function(m) {
  return m.target.shadowRoot && typeof m.composedPath == "function" ? m.composedPath()[0] : m.target;
}, TO = [], RO = function(m, g) {
  var T = (g == null ? void 0 : g.document) || document, L = (g == null ? void 0 : g.trapStack) || TO, U = jT({
    returnFocusOnDeactivate: !0,
    escapeDeactivates: !0,
    delayInitialFocus: !0,
    isKeyForward: CO,
    isKeyBackward: bO
  }, g), x = {
    // containers given to createFocusTrap()
    // @type {Array<HTMLElement>}
    containers: [],
    // list of objects identifying tabbable nodes in `containers` in the trap
    // NOTE: it's possible that a group has no tabbable nodes if nodes get removed while the trap
    //  is active, but the trap should never get to a state where there isn't at least one group
    //  with at least one tabbable node in it (that would lead to an error condition that would
    //  result in an error being thrown)
    // @type {Array<{
    //   container: HTMLElement,
    //   tabbableNodes: Array<HTMLElement>, // empty if none
    //   focusableNodes: Array<HTMLElement>, // empty if none
    //   posTabIndexesFound: boolean,
    //   firstTabbableNode: HTMLElement|undefined,
    //   lastTabbableNode: HTMLElement|undefined,
    //   firstDomTabbableNode: HTMLElement|undefined,
    //   lastDomTabbableNode: HTMLElement|undefined,
    //   nextTabbableNode: (node: HTMLElement, forward: boolean) => HTMLElement|undefined
    // }>}
    containerGroups: [],
    // same order/length as `containers` list
    // references to objects in `containerGroups`, but only those that actually have
    //  tabbable nodes in them
    // NOTE: same order as `containers` and `containerGroups`, but __not necessarily__
    //  the same length
    tabbableGroups: [],
    nodeFocusedBeforeActivation: null,
    mostRecentlyFocusedNode: null,
    active: !1,
    paused: !1,
    // timer ID for when delayInitialFocus is true and initial focus in this trap
    //  has been delayed during activation
    delayInitialFocusTimer: void 0,
    // the most recent KeyboardEvent for the configured nav key (typically [SHIFT+]TAB), if any
    recentNavEvent: void 0
  }, S, ne = function(W, X, ae) {
    return W && W[X] !== void 0 ? W[X] : U[ae || X];
  }, te = function(W, X) {
    var ae = typeof (X == null ? void 0 : X.composedPath) == "function" ? X.composedPath() : void 0;
    return x.containerGroups.findIndex(function(we) {
      var Ue = we.container, Le = we.tabbableNodes;
      return Ue.contains(W) || // fall back to explicit tabbable search which will take into consideration any
      //  web components if the `tabbableOptions.getShadowRoot` option was used for
      //  the trap, enabling shadow DOM support in tabbable (`Node.contains()` doesn't
      //  look inside web components even if open)
      (ae == null ? void 0 : ae.includes(Ue)) || Le.find(function(I) {
        return I === W;
      });
    });
  }, Q = function(W) {
    var X = U[W];
    if (typeof X == "function") {
      for (var ae = arguments.length, we = new Array(ae > 1 ? ae - 1 : 0), Ue = 1; Ue < ae; Ue++)
        we[Ue - 1] = arguments[Ue];
      X = X.apply(void 0, we);
    }
    if (X === !0 && (X = void 0), !X) {
      if (X === void 0 || X === !1)
        return X;
      throw new Error("`".concat(W, "` was specified but was not a node, or did not return a node"));
    }
    var Le = X;
    if (typeof X == "string" && (Le = T.querySelector(X), !Le))
      throw new Error("`".concat(W, "` as selector refers to no known node"));
    return Le;
  }, Z = function() {
    var W = Q("initialFocus");
    if (W === !1)
      return !1;
    if (W === void 0 || !L0(W, U.tabbableOptions))
      if (te(T.activeElement) >= 0)
        W = T.activeElement;
      else {
        var X = x.tabbableGroups[0], ae = X && X.firstTabbableNode;
        W = ae || Q("fallbackFocus");
      }
    if (!W)
      throw new Error("Your focus-trap needs to have at least one focusable element");
    return W;
  }, A = function() {
    if (x.containerGroups = x.containers.map(function(W) {
      var X = pO(W, U.tabbableOptions), ae = vO(W, U.tabbableOptions), we = X.length > 0 ? X[0] : void 0, Ue = X.length > 0 ? X[X.length - 1] : void 0, Le = ae.find(function(pe) {
        return If(pe);
      }), I = ae.slice().reverse().find(function(pe) {
        return If(pe);
      }), ge = !!X.find(function(pe) {
        return gc(pe) > 0;
      });
      return {
        container: W,
        tabbableNodes: X,
        focusableNodes: ae,
        /** True if at least one node with positive `tabindex` was found in this container. */
        posTabIndexesFound: ge,
        /** First tabbable node in container, __tabindex__ order; `undefined` if none. */
        firstTabbableNode: we,
        /** Last tabbable node in container, __tabindex__ order; `undefined` if none. */
        lastTabbableNode: Ue,
        // NOTE: DOM order is NOT NECESSARILY "document position" order, but figuring that out
        //  would require more than just https://developer.mozilla.org/en-US/docs/Web/API/Node/compareDocumentPosition
        //  because that API doesn't work with Shadow DOM as well as it should (@see
        //  https://github.com/whatwg/dom/issues/320) and since this first/last is only needed, so far,
        //  to address an edge case related to positive tabindex support, this seems like a much easier,
        //  "close enough most of the time" alternative for positive tabindexes which should generally
        //  be avoided anyway...
        /** First tabbable node in container, __DOM__ order; `undefined` if none. */
        firstDomTabbableNode: Le,
        /** Last tabbable node in container, __DOM__ order; `undefined` if none. */
        lastDomTabbableNode: I,
        /**
         * Finds the __tabbable__ node that follows the given node in the specified direction,
         *  in this container, if any.
         * @param {HTMLElement} node
         * @param {boolean} [forward] True if going in forward tab order; false if going
         *  in reverse.
         * @returns {HTMLElement|undefined} The next tabbable node, if any.
         */
        nextTabbableNode: function(N) {
          var J = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0, Te = X.indexOf(N);
          return Te < 0 ? J ? ae.slice(ae.indexOf(N) + 1).find(function(We) {
            return If(We);
          }) : ae.slice(0, ae.indexOf(N)).reverse().find(function(We) {
            return If(We);
          }) : X[Te + (J ? 1 : -1)];
        }
      };
    }), x.tabbableGroups = x.containerGroups.filter(function(W) {
      return W.tabbableNodes.length > 0;
    }), x.tabbableGroups.length <= 0 && !Q("fallbackFocus"))
      throw new Error("Your focus-trap must have at least one container with at least one tabbable node in it at all times");
    if (x.containerGroups.find(function(W) {
      return W.posTabIndexesFound;
    }) && x.containerGroups.length > 1)
      throw new Error("At least one node with a positive tabindex was found in one of your focus-trap's multiple containers. Positive tabindexes are only supported in single-container focus-traps.");
  }, oe = function Xe(W) {
    var X = W.activeElement;
    if (X)
      return X.shadowRoot && X.shadowRoot.activeElement !== null ? Xe(X.shadowRoot) : X;
  }, q = function Xe(W) {
    if (W !== !1 && W !== oe(document)) {
      if (!W || !W.focus) {
        Xe(Z());
        return;
      }
      W.focus({
        preventScroll: !!U.preventScroll
      }), x.mostRecentlyFocusedNode = W, SO(W) && W.select();
    }
  }, ve = function(W) {
    var X = Q("setReturnFocus", W);
    return X || (X === !1 ? !1 : W);
  }, Ae = function(W) {
    var X = W.target, ae = W.event, we = W.isBackward, Ue = we === void 0 ? !1 : we;
    X = X || qm(ae), A();
    var Le = null;
    if (x.tabbableGroups.length > 0) {
      var I = te(X, ae), ge = I >= 0 ? x.containerGroups[I] : void 0;
      if (I < 0)
        Ue ? Le = x.tabbableGroups[x.tabbableGroups.length - 1].lastTabbableNode : Le = x.tabbableGroups[0].firstTabbableNode;
      else if (Ue) {
        var pe = BT(x.tabbableGroups, function(ft) {
          var St = ft.firstTabbableNode;
          return X === St;
        });
        if (pe < 0 && (ge.container === X || L0(X, U.tabbableOptions) && !If(X, U.tabbableOptions) && !ge.nextTabbableNode(X, !1)) && (pe = I), pe >= 0) {
          var N = pe === 0 ? x.tabbableGroups.length - 1 : pe - 1, J = x.tabbableGroups[N];
          Le = gc(X) >= 0 ? J.lastTabbableNode : J.lastDomTabbableNode;
        } else sv(ae) || (Le = ge.nextTabbableNode(X, !1));
      } else {
        var Te = BT(x.tabbableGroups, function(ft) {
          var St = ft.lastTabbableNode;
          return X === St;
        });
        if (Te < 0 && (ge.container === X || L0(X, U.tabbableOptions) && !If(X, U.tabbableOptions) && !ge.nextTabbableNode(X)) && (Te = I), Te >= 0) {
          var We = Te === x.tabbableGroups.length - 1 ? 0 : Te + 1, st = x.tabbableGroups[We];
          Le = gc(X) >= 0 ? st.firstTabbableNode : st.firstDomTabbableNode;
        } else sv(ae) || (Le = ge.nextTabbableNode(X));
      }
    } else
      Le = Q("fallbackFocus");
    return Le;
  }, Ye = function(W) {
    var X = qm(W);
    if (!(te(X, W) >= 0)) {
      if (iv(U.clickOutsideDeactivates, W)) {
        S.deactivate({
          // NOTE: by setting `returnFocus: false`, deactivate() will do nothing,
          //  which will result in the outside click setting focus to the node
          //  that was clicked (and if not focusable, to "nothing"); by setting
          //  `returnFocus: true`, we'll attempt to re-focus the node originally-focused
          //  on activation (or the configured `setReturnFocus` node), whether the
          //  outside click was on a focusable node or not
          returnFocus: U.returnFocusOnDeactivate
        });
        return;
      }
      iv(U.allowOutsideClick, W) || W.preventDefault();
    }
  }, ut = function(W) {
    var X = qm(W), ae = te(X, W) >= 0;
    if (ae || X instanceof Document)
      ae && (x.mostRecentlyFocusedNode = X);
    else {
      W.stopImmediatePropagation();
      var we, Ue = !0;
      if (x.mostRecentlyFocusedNode)
        if (gc(x.mostRecentlyFocusedNode) > 0) {
          var Le = te(x.mostRecentlyFocusedNode), I = x.containerGroups[Le].tabbableNodes;
          if (I.length > 0) {
            var ge = I.findIndex(function(pe) {
              return pe === x.mostRecentlyFocusedNode;
            });
            ge >= 0 && (U.isKeyForward(x.recentNavEvent) ? ge + 1 < I.length && (we = I[ge + 1], Ue = !1) : ge - 1 >= 0 && (we = I[ge - 1], Ue = !1));
          }
        } else
          x.containerGroups.some(function(pe) {
            return pe.tabbableNodes.some(function(N) {
              return gc(N) > 0;
            });
          }) || (Ue = !1);
      else
        Ue = !1;
      Ue && (we = Ae({
        // move FROM the MRU node, not event-related node (which will be the node that is
        //  outside the trap causing the focus escape we're trying to fix)
        target: x.mostRecentlyFocusedNode,
        isBackward: U.isKeyBackward(x.recentNavEvent)
      })), q(we || x.mostRecentlyFocusedNode || Z());
    }
    x.recentNavEvent = void 0;
  }, Ke = function(W) {
    var X = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    x.recentNavEvent = W;
    var ae = Ae({
      event: W,
      isBackward: X
    });
    ae && (sv(W) && W.preventDefault(), q(ae));
  }, Ge = function(W) {
    if (EO(W) && iv(U.escapeDeactivates, W) !== !1) {
      W.preventDefault(), S.deactivate();
      return;
    }
    (U.isKeyForward(W) || U.isKeyBackward(W)) && Ke(W, U.isKeyBackward(W));
  }, Rt = function(W) {
    var X = qm(W);
    te(X, W) >= 0 || iv(U.clickOutsideDeactivates, W) || iv(U.allowOutsideClick, W) || (W.preventDefault(), W.stopImmediatePropagation());
  }, Ne = function() {
    if (x.active)
      return PT.activateTrap(L, S), x.delayInitialFocusTimer = U.delayInitialFocus ? HT(function() {
        q(Z());
      }) : q(Z()), T.addEventListener("focusin", ut, !0), T.addEventListener("mousedown", Ye, {
        capture: !0,
        passive: !1
      }), T.addEventListener("touchstart", Ye, {
        capture: !0,
        passive: !1
      }), T.addEventListener("click", Rt, {
        capture: !0,
        passive: !1
      }), T.addEventListener("keydown", Ge, {
        capture: !0,
        passive: !1
      }), S;
  }, lt = function() {
    if (x.active)
      return T.removeEventListener("focusin", ut, !0), T.removeEventListener("mousedown", Ye, !0), T.removeEventListener("touchstart", Ye, !0), T.removeEventListener("click", Rt, !0), T.removeEventListener("keydown", Ge, !0), S;
  }, it = function(W) {
    var X = W.some(function(ae) {
      var we = Array.from(ae.removedNodes);
      return we.some(function(Ue) {
        return Ue === x.mostRecentlyFocusedNode;
      });
    });
    X && q(Z());
  }, Jt = typeof window < "u" && "MutationObserver" in window ? new MutationObserver(it) : void 0, jt = function() {
    Jt && (Jt.disconnect(), x.active && !x.paused && x.containers.map(function(W) {
      Jt.observe(W, {
        subtree: !0,
        childList: !0
      });
    }));
  };
  return S = {
    get active() {
      return x.active;
    },
    get paused() {
      return x.paused;
    },
    activate: function(W) {
      if (x.active)
        return this;
      var X = ne(W, "onActivate"), ae = ne(W, "onPostActivate"), we = ne(W, "checkCanFocusTrap");
      we || A(), x.active = !0, x.paused = !1, x.nodeFocusedBeforeActivation = T.activeElement, X == null || X();
      var Ue = function() {
        we && A(), Ne(), jt(), ae == null || ae();
      };
      return we ? (we(x.containers.concat()).then(Ue, Ue), this) : (Ue(), this);
    },
    deactivate: function(W) {
      if (!x.active)
        return this;
      var X = jT({
        onDeactivate: U.onDeactivate,
        onPostDeactivate: U.onPostDeactivate,
        checkCanReturnFocus: U.checkCanReturnFocus
      }, W);
      clearTimeout(x.delayInitialFocusTimer), x.delayInitialFocusTimer = void 0, lt(), x.active = !1, x.paused = !1, jt(), PT.deactivateTrap(L, S);
      var ae = ne(X, "onDeactivate"), we = ne(X, "onPostDeactivate"), Ue = ne(X, "checkCanReturnFocus"), Le = ne(X, "returnFocus", "returnFocusOnDeactivate");
      ae == null || ae();
      var I = function() {
        HT(function() {
          Le && q(ve(x.nodeFocusedBeforeActivation)), we == null || we();
        });
      };
      return Le && Ue ? (Ue(ve(x.nodeFocusedBeforeActivation)).then(I, I), this) : (I(), this);
    },
    pause: function(W) {
      if (x.paused || !x.active)
        return this;
      var X = ne(W, "onPause"), ae = ne(W, "onPostPause");
      return x.paused = !0, X == null || X(), lt(), jt(), ae == null || ae(), this;
    },
    unpause: function(W) {
      if (!x.paused || !x.active)
        return this;
      var X = ne(W, "onUnpause"), ae = ne(W, "onPostUnpause");
      return x.paused = !1, X == null || X(), A(), Ne(), jt(), ae == null || ae(), this;
    },
    updateContainerElements: function(W) {
      var X = [].concat(W).filter(Boolean);
      return x.containers = X.map(function(ae) {
        return typeof ae == "string" ? T.querySelector(ae) : ae;
      }), x.active && A(), jt(), this;
    }
  }, S.updateContainerElements(m), S;
};
const wO = (b = {}) => {
  const m = re.useRef(null), [g, T] = re.useState(!1), [L, U] = re.useState(!1), x = re.useCallback((Z) => {
    var A;
    (A = m.current) == null || A.activate(Z);
  }, []), S = re.useCallback((Z) => {
    var A;
    (A = m.current) == null || A.deactivate(Z);
  }, []), ne = re.useCallback(() => {
    m.current && (m.current.pause(), U(!0));
  }, []), te = re.useCallback(() => {
    m.current && (m.current.unpause(), U(!1));
  }, []), Q = re.useCallback(
    (Z) => {
      if (Z !== null) {
        if (m.current)
          return m.current.updateContainerElements(Z);
        m.current = RO(Z, {
          ...b,
          onActivate() {
            T(!0), b.onActivate && b.onActivate();
          },
          onDeactivate() {
            T(!1), b.onDeactivate && b.onDeactivate();
          }
        });
      }
    },
    [b]
  );
  return re.useEffect(
    () => () => {
      S();
    },
    [S]
  ), {
    isActive: g,
    isPaused: L,
    setRef: Q,
    activate: x,
    deactivate: S,
    pause: ne,
    unpause: te
  };
};
var xO = function(b) {
  if (typeof document > "u")
    return null;
  var m = Array.isArray(b) ? b[0] : b;
  return m.ownerDocument.body;
}, Yf = /* @__PURE__ */ new WeakMap(), Xm = /* @__PURE__ */ new WeakMap(), Jm = {}, A0 = 0, sR = function(b) {
  return b && (b.host || sR(b.parentNode));
}, _O = function(b, m) {
  return m.map(function(g) {
    if (b.contains(g))
      return g;
    var T = sR(g);
    return T && b.contains(T) ? T : (console.error("aria-hidden", g, "in not contained inside", b, ". Doing nothing"), null);
  }).filter(function(g) {
    return !!g;
  });
}, kO = function(b, m, g, T) {
  var L = _O(m, Array.isArray(b) ? b : [b]);
  Jm[g] || (Jm[g] = /* @__PURE__ */ new WeakMap());
  var U = Jm[g], x = [], S = /* @__PURE__ */ new Set(), ne = new Set(L), te = function(Z) {
    !Z || S.has(Z) || (S.add(Z), te(Z.parentNode));
  };
  L.forEach(te);
  var Q = function(Z) {
    !Z || ne.has(Z) || Array.prototype.forEach.call(Z.children, function(A) {
      if (S.has(A))
        Q(A);
      else
        try {
          var oe = A.getAttribute(T), q = oe !== null && oe !== "false", ve = (Yf.get(A) || 0) + 1, Ae = (U.get(A) || 0) + 1;
          Yf.set(A, ve), U.set(A, Ae), x.push(A), ve === 1 && q && Xm.set(A, !0), Ae === 1 && A.setAttribute(g, "true"), q || A.setAttribute(T, "true");
        } catch (Ye) {
          console.error("aria-hidden: cannot operate on ", A, Ye);
        }
    });
  };
  return Q(m), S.clear(), A0++, function() {
    x.forEach(function(Z) {
      var A = Yf.get(Z) - 1, oe = U.get(Z) - 1;
      Yf.set(Z, A), U.set(Z, oe), A || (Xm.has(Z) || Z.removeAttribute(T), Xm.delete(Z)), oe || Z.removeAttribute(g);
    }), A0--, A0 || (Yf = /* @__PURE__ */ new WeakMap(), Yf = /* @__PURE__ */ new WeakMap(), Xm = /* @__PURE__ */ new WeakMap(), Jm = {});
  };
}, DO = function(b, m, g) {
  g === void 0 && (g = "data-aria-hidden");
  var T = Array.from(Array.isArray(b) ? b : [b]), L = m || xO(b);
  return L ? (T.push.apply(T, Array.from(L.querySelectorAll("[aria-live]"))), kO(T, L, g, "aria-hidden")) : function() {
    return null;
  };
};
const OO = (b) => {
  const m = re.useRef(null), g = re.useRef(void 0), T = re.useRef(null), L = re.useCallback(() => {
    m.current && (T.current = DO(m.current, g.current, b));
  }, [b]), U = re.useCallback(() => {
    T.current && T.current();
  }, []);
  re.useEffect(
    () => () => {
      U();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );
  const x = re.useCallback((ne) => {
    ne !== null && (m.current = ne);
  }, []), S = re.useCallback((ne) => {
    ne !== null && (g.current = ne);
  }, []);
  return {
    setRef: x,
    setParentRef: S,
    hide: L,
    unhide: U
  };
}, MO = () => {
  const b = re.useRef(!0);
  return b.current ? (b.current = !1, !0) : b.current;
}, NO = ({
  isOpen: b,
  defaultIsOpen: m = !1,
  closeTimeout: g = 0,
  onAfterOpen: T,
  onAfterClose: L
} = {}) => {
  const U = MO(), [x, S] = re.useState({
    isOpen: b ?? m,
    beforeClose: !1,
    afterOpen: !1
  });
  re.useEffect(() => {
    b !== void 0 && (b ? S((Q) => ({
      ...Q,
      isOpen: !0,
      beforeClose: !1
    })) : !U && x.isOpen && S((Q) => ({
      ...Q,
      beforeClose: !0
    })));
  }, [b, U, x.isOpen]), re.useEffect(() => {
    let Q;
    return x.isOpen && !x.afterOpen && (Q = requestAnimationFrame(() => {
      S((Z) => ({
        ...Z,
        afterOpen: !0
      })), T && T();
    })), () => {
      Q && cancelAnimationFrame(Q);
    };
  }, [x.isOpen, x.afterOpen]), re.useEffect(() => {
    let Q;
    return x.beforeClose && (Q = window.setTimeout(() => {
      S({
        isOpen: !1,
        beforeClose: !1,
        afterOpen: !1
      }), L && L();
    }, g)), () => {
      Q && clearTimeout(Q);
    };
  }, [x.beforeClose, g]);
  const ne = re.useCallback(() => {
    S({
      isOpen: !0,
      beforeClose: !1,
      afterOpen: !1
    });
  }, []), te = re.useCallback(() => {
    S((Q) => ({
      ...Q,
      beforeClose: !0
    }));
  }, []);
  return {
    // beforeCloseがtrueの間はisOpenをtrueとすることで、閉じるアニメーションを実行する
    isOpen: x.isOpen || x.beforeClose,
    beforeClose: x.beforeClose,
    afterOpen: x.afterOpen,
    open: ne,
    close: te
  };
}, cR = ({
  isOpen: b,
  onClose: m = () => {
  },
  container: g = document.body,
  onAfterOpen: T,
  onAfterClose: L,
  shouldCloseOnBackdropClick: U = !0,
  shouldCloseOnEsc: x = !0,
  id: S,
  className: ne = "",
  backdropClassName: te = "",
  dialogClassName: Q = "",
  style: Z = {},
  backdropStyle: A = {},
  dialogStyle: oe = {},
  afterOpenClassName: q = "is-after-open",
  beforeCloseClassName: ve = "is-before-close",
  preventScroll: Ae = !0,
  closeTimeout: Ye = 0,
  role: ut = "dialog",
  "aria-modal": Ke = !0,
  "aria-describedby": Ge,
  "aria-labelledby": Rt,
  children: Ne,
  focusTrapOptions: lt = {}
}, it) => {
  const Jt = re.useRef(null), jt = re.useRef(null), { setRef: Xe, disableScroll: W, enableScroll: X } = JD(), { setRef: ae, hide: we, unhide: Ue } = OO(), {
    setRef: Le,
    activate: I,
    deactivate: ge
  } = wO({
    fallbackFocus() {
      return jt.current;
    },
    ...lt,
    allowOutsideClick: !0,
    // falseの場合、モーダルを閉じてもFocusTrapが解除されないので注意
    escapeDeactivates: !1,
    // ESCキーを押したときの動作は自前でカスタマイズしたいのでfalse
    returnFocusOnDeactivate: !0
  }), pe = re.useCallback(
    (nt) => {
      Jt.current = nt, Le(nt), ae(nt);
    },
    [Le, ae]
  ), N = re.useCallback(
    (nt) => {
      jt.current = nt, Xe(nt);
    },
    [Xe]
  );
  re.useImperativeHandle(it, () => Jt.current);
  const J = re.useCallback(() => {
    m();
  }, [m]), Te = NO({
    isOpen: b,
    closeTimeout: Ye,
    onAfterOpen: T,
    onAfterClose: L
  });
  re.useEffect(() => {
    Te.isOpen || (Ae && X(), ge(), Ue());
  }, [Te.isOpen, Ae, X, ge, Ue]), re.useEffect(() => {
    Te.afterOpen && Te.isOpen && (Ae && W({
      allowTouchMove(nt) {
        let wt = nt;
        for (; wt && wt !== document.body; ) {
          if (wt !== null && mD(wt))
            return !0;
          wt = wt.parentElement;
        }
        return !1;
      }
    }), I(), we());
  }, [Te.afterOpen, Te.isOpen, Ae, W, I, we]);
  const We = re.useRef(null), st = re.useCallback(() => {
    U && J();
  }, [U, J]), ft = (nt) => {
    nt.target !== jt.current && nt.stopPropagation();
  }, St = re.useCallback(
    (nt) => {
      x && nt.code === "Escape" && (nt.stopPropagation(), J());
    },
    [x, J]
  ), Et = () => {
    const { afterOpen: nt, beforeClose: wt } = Te;
    let kn = ne;
    return nt && (kn = `${ne} ${q}`), wt && (kn = `${ne} ${ve}`), kn;
  };
  return Te.isOpen ? V0.createPortal(
    /* @__PURE__ */ ye.jsx("div", { ref: pe, style: Z, className: Et(), id: S, children: /* @__PURE__ */ ye.jsx(
      "div",
      {
        ref: We,
        style: A,
        className: te,
        onClick: st,
        children: /* @__PURE__ */ ye.jsx(
          "div",
          {
            ref: N,
            tabIndex: -1,
            style: oe,
            className: Q,
            role: ut,
            "aria-modal": Ke,
            "aria-labelledby": Rt,
            "aria-describedby": Ge,
            onKeyDown: St,
            onClick: ft,
            children: Ne
          }
        )
      }
    ) }),
    g
  ) : null;
};
cR.displayName = "BaseModal";
const LO = re.forwardRef(cR), fR = re.createContext(void 0), dR = re.forwardRef(
  ({
    className: b,
    backdropClassName: m,
    dialogClassName: g,
    closeTimeout: T = 300,
    onClose: L,
    "aria-labelledby": U,
    size: x,
    children: S,
    ...ne
  }, te) => {
    const Q = re.useMemo(() => ({ onClose: L, "aria-labelledby": U }), [L, U]);
    return /* @__PURE__ */ ye.jsx(fR.Provider, { value: Q, children: /* @__PURE__ */ ye.jsx(
      LO,
      {
        ref: te,
        className: Wf("acms-admin-modal", b),
        backdropClassName: Wf("acms-admin-modal-backdrop", m),
        dialogClassName: Wf("acms-admin-modal-dialog", g, x),
        closeTimeout: T,
        afterOpenClassName: "in",
        beforeCloseClassName: "out",
        onClose: L,
        "aria-labelledby": U,
        ...ne,
        children: /* @__PURE__ */ ye.jsx("div", { className: "acms-admin-modal-content", children: S })
      }
    ) });
  }
);
dR.displayName = "Modal";
const pR = re.forwardRef(({ children: b, className: m, ...g }, T) => {
  const L = re.useContext(fR);
  if (!L)
    throw new Error("Modal.Header must be used within a Modal");
  return /* @__PURE__ */ ye.jsxs("header", { ref: T, className: Wf("acms-admin-modal-header", m), ...g, children: [
    /* @__PURE__ */ ye.jsx("h1", { id: L["aria-labelledby"], className: "acms-admin-modal-heading", children: b }),
    /* @__PURE__ */ ye.jsx(
      "button",
      {
        type: "button",
        className: "acms-admin-modal-hide acms-admin-icon-delete",
        onClick: L.onClose,
        "aria-label": "閉じる"
      }
    )
  ] });
});
pR.displayName = "Modal.Header";
const vR = re.forwardRef(
  ({ children: b, className: m, tabContentScrollable: g = !1, ...T }, L) => /* @__PURE__ */ ye.jsx(
    "div",
    {
      ref: L,
      className: Wf("acms-admin-modal-body", m, {
        "acms-admin-modal-body-tab-scrollable": g
      }),
      ...T,
      children: b
    }
  )
);
vR.displayName = "Modal.Body";
const hR = re.forwardRef(({ children: b, className: m, ...g }, T) => /* @__PURE__ */ ye.jsx("footer", { ref: T, className: Wf("acms-admin-modal-footer", m), ...g, children: b }));
hR.displayName = "Modal.Footer";
const Zm = Object.assign(dR, { Header: pR, Body: vR, Footer: hR }), mR = re.forwardRef(({
  value: b,
  onChange: m,
  className: g = "",
  lineHeight: T = 24,
  // ピクセル単位で指定
  defaultRows: L = 1,
  maxRows: U = 6,
  ...x
}, S) => {
  const [ne, te] = re.useState(""), Q = re.useRef(null), Z = b !== void 0 ? b : ne;
  re.useImperativeHandle(S, () => ({
    focus: () => {
      var q;
      return (q = Q.current) == null ? void 0 : q.focus();
    },
    blur: () => {
      var q;
      return (q = Q.current) == null ? void 0 : q.blur();
    },
    getHeight: () => {
      var q;
      return ((q = Q.current) == null ? void 0 : q.offsetHeight) || 0;
    },
    recalculateHeight: A,
    value: Z,
    setValue: (q) => {
      b === void 0 && te(q), Q.current && (Q.current.value = q);
    }
  }));
  const A = () => {
    const q = Q.current;
    if (!q) return;
    q.style.height = "auto";
    const ve = q.scrollHeight, Ae = L * T, Ye = U * T, ut = Math.min(Math.max(ve, Ae), Ye);
    q.style.height = `${ut}px`;
  };
  re.useEffect(() => {
    A();
  }, [Z, T, L, U]);
  const oe = (q) => {
    const ve = q.target.value;
    b === void 0 && te(ve), m && m(q);
  };
  return /* @__PURE__ */ ye.jsx(
    "textarea",
    {
      ref: Q,
      value: Z,
      onChange: oe,
      className: QT(`${Ai.AutoResizeTextarea}`, g),
      style: {
        minHeight: `${L * T}px`,
        maxHeight: `${U * T}px`,
        lineHeight: `${T}px`,
        ...x.style
      },
      rows: L,
      ...x
    }
  );
});
mR.displayName = "AutoResizeTextarea";
const AO = re.memo(({
  isOpen: b,
  text: m,
  sentence: g,
  selectedSentence: T,
  isLoading: L,
  proofReadingPromptRef: U,
  onClose: x,
  onReProofreading: S,
  onInsert: ne,
  onSelectedSentenceHandler: te,
  onTextChange: Q,
  onSentenceChange: Z
}) => /* @__PURE__ */ ye.jsxs(
  Zm,
  {
    isOpen: b,
    onClose: x,
    className: "acms-admin-logger-modal",
    size: "large",
    "aria-labelledby": "acms-admin-logger-modal-title",
    children: [
      /* @__PURE__ */ ye.jsx(Zm.Header, { children: "ユニットのAI修正" }),
      /* @__PURE__ */ ye.jsx(Zm.Body, { children: /* @__PURE__ */ ye.jsxs("div", { className: `${Ai.proofreadingModalBody}`, children: [
        /* @__PURE__ */ ye.jsx("div", { children: /* @__PURE__ */ ye.jsxs("div", { className: Ai.proofreadingModalBodyTextareas, children: [
          /* @__PURE__ */ ye.jsxs("div", { children: [
            /* @__PURE__ */ ye.jsx("label", { htmlFor: "responsibilitySentenceArea", className: Ai.proofreadingModalBodyTextareasUnitLabel, children: "ユニットのテキスト" }),
            /* @__PURE__ */ ye.jsx(
              "textarea",
              {
                id: "responsibilitySentenceArea",
                className: Ai.proofreadingModalBodyTextareasUnit,
                rows: 10,
                onClick: () => te("responsibility"),
                value: m,
                onChange: (A) => Q(A.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ ye.jsxs("div", { children: [
            /* @__PURE__ */ ye.jsx(
              "label",
              {
                htmlFor: "proofreadingSentenceArea",
                className: `${Ai.proofreadingModalBodyTextareasUnitLabel} `,
                children: "生成されたテキスト"
              }
            ),
            /* @__PURE__ */ ye.jsxs("div", { style: { position: "relative" }, children: [
              /* @__PURE__ */ ye.jsx(
                "textarea",
                {
                  id: "proofreadingSentenceArea",
                  className: Ai.proofreadingModalBodyTextareasUnit,
                  rows: 10,
                  onClick: () => te("proofreading"),
                  value: L ? "" : g,
                  onChange: (A) => Z(A.target.value),
                  disabled: L || !g
                }
              ),
              L && /* @__PURE__ */ ye.jsx("span", { style: { position: "absolute", top: "10px", left: "10px" }, className: Ai.proofreadingResultModalLoading })
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ ye.jsxs("div", { className: Ai.proofreadingModalBodyPrompt, children: [
          /* @__PURE__ */ ye.jsx(
            mR,
            {
              style: { order: 2 },
              className: Ai.proofreadingModalBodyPromptTextarea,
              ref: U,
              placeholder: "校正内容を入力してください",
              disabled: L
            }
          ),
          /* @__PURE__ */ ye.jsxs("div", { style: { display: "flex", justifyContent: "flex-end", paddingBottom: "5px", gap: "5px", order: 1 }, children: [
            /* @__PURE__ */ ye.jsxs(
              "select",
              {
                className: Ai.proofreadingModalBodyPromptSelect,
                value: T,
                onChange: (A) => te(A.target.value),
                children: [
                  /* @__PURE__ */ ye.jsx("option", { value: "responsibility", children: "ユニットのテキスト" }),
                  /* @__PURE__ */ ye.jsx("option", { value: "proofreading", children: "生成されたテキスト" })
                ]
              }
            ),
            /* @__PURE__ */ ye.jsx(
              "button",
              {
                className: `${Ai.proofreadingModalBodyPrompButton} acms-admin-btn acms-admin-btn-info`,
                onClick: S,
                disabled: L,
                children: "生成"
              }
            )
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ ye.jsxs(Zm.Footer, { children: [
        /* @__PURE__ */ ye.jsx(
          "button",
          {
            type: "button",
            className: "acms-admin-btn acms-admin-margin-top-mini acms-admin-media-cancel-btn",
            onClick: x,
            children: "キャンセル"
          }
        ),
        /* @__PURE__ */ ye.jsx(
          "button",
          {
            className: "acms-admin-btn acms-admin-btn-primary acms-admin-margin-top-mini",
            onClick: ne,
            disabled: L,
            children: "ユニットを上書き"
          }
        )
      ] })
    ]
  }
)), UO = re.memo((b) => {
  const { liteEditor: m, text: g = "" } = b;
  if (!m)
    return null;
  const T = re.useRef(m).current, L = re.useRef(!1), U = re.useRef(null), [x, S] = re.useState({
    selectedSentence: "responsibility",
    text: g,
    sentence: "",
    isLoading: !1,
    isOpen: !0
  });
  re.useEffect(() => {
    L.current || (L.current = !0);
  }, []);
  const ne = re.useCallback(async (Ye) => {
    var Ne;
    const ut = (Ne = U.current) == null ? void 0 : Ne.value, Ke = document.querySelector('[data-ai-unit="tone"]'), Rt = {
      prompt: [
        {
          role: "user",
          content: `
            ${ut || `Please answer the text in Japanese${Ke && ` with a ${Ke.value} tone`}.`}

            condition:
            - Please choose one answer.

            text: """
            ${Ye}
            """
          `
        }
      ],
      mode: "unitProofreading"
    };
    try {
      const lt = await H0({
        url: window.ACMS.Config.root,
        data: Rt,
        exec: "ACMS_POST_AI_Chat",
        formToken: window.csrfToken
      });
      return !lt || lt.errorCode && lt.errorCode === 500 ? null : JSON.parse(lt);
    } catch (lt) {
      return console.error("Error in postPrompt:", lt), null;
    }
  }, []), te = re.useCallback(async () => {
    S((Ke) => ({ ...Ke, isLoading: !0 }));
    const Ye = x.selectedSentence === "responsibility" ? x.text : x.sentence, ut = await ne(Ye);
    if (!ut)
      return console.error("取得に失敗しました。"), null;
    if (!ut[0].content)
      return console.error("生成に失敗しました。"), null;
    S((Ke) => ({
      ...Ke,
      sentence: String(ut[0].content),
      isLoading: !1
    }));
  }, [x.selectedSentence, x.text, x.sentence, ne]), Q = re.useCallback((Ye) => {
    Ye.preventDefault(), Ye.stopPropagation(), te();
  }, [te]), Z = re.useCallback((Ye) => {
    S((ut) => ({ ...ut, text: Ye }));
  }, []), A = re.useCallback((Ye) => {
    S((ut) => ({ ...ut, sentence: Ye }));
  }, []), oe = re.useCallback((Ye) => {
    S((ut) => ({ ...ut, selectedSentence: Ye }));
  }, []), q = re.useCallback(() => {
    S((Ye) => ({ ...Ye, isOpen: !1 })), window.location.hash = "";
  }, []);
  re.useEffect(() => {
    x.sentence === "responsibility" ? S((Ye) => ({ ...Ye, selectedSentence: "responsibility" })) : x.sentence === "proofreading" && S((Ye) => ({ ...Ye, selectedSentence: "proofreading" }));
  }, [x.sentence]);
  const ve = re.useCallback((Ye) => {
    if (Ye.preventDefault(), Ye.stopPropagation(), !x.sentence) return null;
    if (T) {
      T.stopStack = !0;
      const ut = T.stackPosition;
      T.data.value = x.sentence;
      const Ke = T._getElementByQuery('[data-selector="lite-editor-source"]');
      Ke && (Ke.value = T.format(x.sentence)), T.stack = T.stack.slice(0, ut), T.stack.push(x.sentence), T.stackPosition = ut, T._fireEvent("change"), T.update();
    }
    q();
  }, [T, x.sentence]), Ae = document.querySelector(`[data-id=${T.id}]`);
  return Ae ? (Ae.style.position = "relative", DD.createPortal(
    /* @__PURE__ */ ye.jsx(
      AO,
      {
        isOpen: x.isOpen,
        text: x.text,
        sentence: x.sentence,
        selectedSentence: x.selectedSentence,
        isLoading: x.isLoading,
        proofReadingPromptRef: U,
        onClose: q,
        onReProofreading: Q,
        onInsert: ve,
        onSelectedSentenceHandler: oe,
        onTextChange: Z,
        onSentenceChange: A
      }
    ),
    Ae
  )) : null;
}), zO = (b) => {
  const { liteEditor: m } = b, g = re.useRef(!1), [T, L] = re.useState(m), [U, x] = re.useState(""), [S, ne] = re.useState(!0);
  return re.useEffect(() => {
    L(m);
  }, [m]), re.useEffect(() => {
    if (!g.current) {
      g.current = !0;
      return;
    }
    if (!T || T.id, T && T.stack) {
      const te = T.stackPosition <= 0 ? 0 : T.stackPosition - 1;
      x(T.stack[te] || "");
    }
    ne(!1);
  }, [T]), S ? null : /* @__PURE__ */ ye.jsx(ye.Fragment, { children: /* @__PURE__ */ ye.jsx(UO, { liteEditor: T, text: U }) });
};
var P0, FO = {}, ey = V0;
if (FO.NODE_ENV === "production")
  P0 = ey.createRoot, ey.hydrateRoot;
else {
  var VT = ey.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
  P0 = function(b, m) {
    VT.usingClientEntryPoint = !0;
    try {
      return ey.createRoot(b, m);
    } finally {
      VT.usingClientEntryPoint = !1;
    }
  };
}
function yR(b, m, g) {
  m._reactRoot && m._reactRoot.unmount();
  const T = P0(m, g);
  return m._reactRoot = T, T.render(/* @__PURE__ */ ye.jsx(re.StrictMode, { children: b })), T;
}
const jO = document.getElementById("js-acms-ai");
yR(
  /* @__PURE__ */ ye.jsx(hD, { children: /* @__PURE__ */ ye.jsx(CD, { children: /* @__PURE__ */ ye.jsx(RD, {}) }) }),
  jO
);
const PO = () => {
  window.ACMS.Config.LiteEditorConf.btnOptions.push({
    label: "AI",
    group: "mark",
    action: "extra",
    onClick: function(m) {
      const g = document.getElementById("js-acms-ai-re-mount");
      yR(/* @__PURE__ */ ye.jsx(zO, { liteEditor: m }), g);
    }
  });
};
window.ACMS.Ready(() => {
  PO();
});
