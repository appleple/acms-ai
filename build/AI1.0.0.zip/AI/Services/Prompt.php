<?php

namespace Acms\Plugins\AI\Sercices;

class Prompt
{
    public $mode = '';
    public $prompt = '';
}
