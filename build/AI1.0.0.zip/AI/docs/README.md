# Prompt(仮)

a-blog cms の AI機能を拡張するアプリです。

## 動作環境

- a-blog cms: >= Ver.3.1
- php: >= 7.3.0

## サポートモデル

エントリー編集機能
- gpt-4o-mini, gpt-4o, gpt-3.5-turbo モデルが対応

## 注意点
- ChatGPT の API KEY は利用できるモデルの制限をかけることができます。使用したいモデルが表示されない場合は、API KEY の設定を確認してみてください。
- このキーとモデルは、config として保存されます。config はキャッシュを残しますので、うまく設定できない場合はダッシュボードからコンフィグキャッシュをクリアしてください。

## インストール方法

拡張アプリをダウンロード後、zip ファイルを解凍して `extension/plugins/`に設置します。

設置が完了すると、「管理画面->拡張アプリ」に `Prompt` という名前で本拡張アプリが表示されるので、インストールをクリックしインストールします。

## 使い方

### 準備：ChatGPT API からキーの取得
`https://platform.openai.com/docs/overview` へログインし、`Organization ID` と `Project ID` と `API KEY` を取得してください。

#### Organization ID
`Setting > Organization > General` から取得できます。

#### Project ID
`Setting > Project > General` から取得できます。初期では Default Project が作成されていますが、利用するアプリケーション毎に作成することをお勧めします。利用量が Projectごとに確認できます。

#### API KEY
`Dashboard > API Keys` の `Create new secret Key` からキーが取得できます。この時、利用する `Project ID` を指定します。
※ User API Keys もありますが、この拡張アプリは対応しておりません。

### a-blog cms　の管理画面設定
準備で取得した `Organization ID` と `Project ID` と `API KEY` を Prompt管理画面で入力し、保存してください。

![Prompt拡張アプリの管理画面でキーを入力し保存](images/acms-admin-key.png)

キーが正しく設定できると、モデルが選択できるようになります。利用するモデルを選択し、再度保存してください。

![Prompt拡張アプリの管理画面でモデルを選択し保存](images/acms-admin-model.png)

## エントリー編集AI機能
「AI生成」ラベルのアコーディオンがSEO設定の下に追加されます。

### タイトル生成機能
「ユニットからタイトルを生成」ボタンをクリックすると、ユニットを元にタイトルが生成されます。

![エントリー編集画面にあるタイトル生成ボタン](images/acms-entry-create-title.png)

「再生成」ボタンをクリックするとタイトルが再生成されます。再生成すると、前回作成したタイトルは消えてしまいますのでご注意ください。「適応」ボタンクリックすることでタイトルに反映されます。エントリーの保存をしないと、エントリーのタイトルとして保存されないのでご注意ください。

![エントリー編集画面でユニットからタイトルの生成](images/acms-entry-title.png)

### タグ生成機能
「ユニットからタグを生成」ボタンをクリックすると、ユニットを元にタグが生成されます。

![エントリー編集画面にあるタグ生成ボタン](images/acms-entry-create-tag.png)

「追加生成」ボタンをクリックすると、前回のタグに加えて追加で生成されます。追加生成では、a-blog cms 本来のタグ設定とChatGPTで生成したタグで選択されているタグを情報も加えて生成されるので、より精度の高いタグが生成されます。エントリーの保存をしないと、エントリーのタグとして保存されないのでご注意ください。

![エントリー編集画面でユニットからタグの生成](images/acms-entry-tag.png)
