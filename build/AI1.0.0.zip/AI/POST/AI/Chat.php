<?php

namespace Acms\Plugins\AI\POST\AI;

use Common;
use Exception;
use Acms\Plugins\AI\POST\AI;
use Acms\Plugins\AI\Services\AI as ServiceAI;

/**
 * ACMS_POST_AI_Chat
 */
class Chat extends AI
{
    public function post()
    {
        $response = null;
        $apiUrl = "https://api.openai.com/v1/chat/completions";
        $appModel = $this->model;
        $apiKey = $this->apiKey;

        if (!$apiKey || !$appModel) {
            $response = [
                'message' => 'APIキーまたはモデルの設定がありません。',
                'errorCode' => 500
            ];
            \AcmsLogger::notice('APIキーまたはモデルの設定がありません。', $response);
            return Common::responseJson($response);
        }

        $messages = [];
        $prompt = $this->Post->get("prompt");
        $mode = $this->Post->get("mode");
        $dedicatedPrompt = [];
        $decodedPrompt = json_decode($prompt, true);

        $roleSystemContents = [
            [
                "role" => "system",
                "content" => "
                    You are a system that returns an array in JSON format.

                    condition:
                    - If there is a single answer, there will be only one answer in the array.
                    - If there are multiple answers, there will be multiple answers in the array.

                    format: \"\"\"
                    [
                        {
                            \"content\": \"response1\"
                        },
                        {
                            \"content\": \"response2\"
                        },
                        {
                            \"content\": \"response3\"
                        }
                    ]
                    \"\"\"
                "
            ]
        ];

        if ($mode == 'createTag') {
            $tagNameAll = ServiceAI::getTagNameAll();
            $tagStr = implode(", ", $tagNameAll);
            $dedicatedPrompt = [
                [
                    "role" => "user",
                    "content" => "
                            This is a list of existing tags.
                            When generating tags, please use the existing tag list notation for tags with duplicate meanings.

                            list of existing tags: \"\"\"
                            $tagStr
                            \"\"\"
                        "
                ],
                [
                    "role" => "assistant",
                    "content" => "I got it. Please give me some prompts regarding tag generation."
                ],
            ];
        }

        if (!is_array($decodedPrompt)) {
            $decodedPrompt = [$decodedPrompt];
        }

        $messages = array_merge(
            $roleSystemContents,
            $dedicatedPrompt,
            $decodedPrompt,
        );

        $headers = [
            "Content-Type: application/json",
            "Authorization: Bearer $apiKey"
        ];
        $postData = [
            "model" => $appModel,
            "messages" => $messages
        ];
        $json = json_encode($postData);

        $attempts = 0;
        $maxAttempts = 5;
        $isValidFormat = false;
        $content = null;
        while ($attempts < $maxAttempts && !$isValidFormat) {
            try {
                $ch = curl_init();
                $options = [
                    CURLOPT_URL => $apiUrl,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HTTPHEADER => $headers,
                    CURLOPT_POSTFIELDS => $json
                ];
                curl_setopt_array($ch, $options);
                $result = curl_exec($ch);

                if (curl_errno($ch)) {
                    throw new Exception(curl_error($ch));
                }

                $parse = json_decode($result);
                if (isset($parse->choices[0]->message->content)) {
                    $content = $parse->choices[0]->message->content;
                    $isValidFormat = $this->isValidJsonArray($content);
                }

                curl_close($ch);
            } catch (Exception $e) {
                $response = [
                    'message' => 'データを取得できませんでした。',
                    'errorCode' => 500
                ];
                \AcmsLogger::error($e->getMessage(), $response);
                return Common::responseJson($response);
            }

            $attempts++;
        }

        if (!$isValidFormat["success"]) {
            $response = [
                'message' => '有効な形式のデータを取得できませんでした。',
                'createdChat' => $isValidFormat["content"],
                'errorCode' => 500
            ];
            \AcmsLogger::notice('有効な形式のデータを取得できませんでした。', $response);
            return Common::responseJson($response);
        }


        return Common::responseJson($isValidFormat["content"]);
    }

    /**
     * @param string $content
     * @return array
     */
    private function isValidJsonArray(string $content): array
    {
        $content = trim($content);
        $content = preg_replace('/^"""[\n\r]?|[\n\r]?"""$/', '', $content);
        $content = $this->trimOuterBrackets($content);
        $decoded = json_decode($content, true);
        if (!is_array($decoded)) {
            \AcmsLogger::notice('有効な形式のデータを取得できませんでした。', $content);
            return [
                "success" => false,
                "content" => $content
            ];
        }
        return [
            "success" => is_array($decoded),
            "content" => $content
        ];
    }

    private function trimOuterBrackets(string $text): string
    {
        $startPos = strpos($text, '[');
        $endPos = strrpos($text, ']');

        // 開始位置
        if ($startPos !== false) {
            $finalStartPos = $startPos;
        } else {
            return null;
        }

        // 終了位置
        if ($endPos !== false) {
            $finalEndPos = $endPos + 1;
        } else {
            return null;
        }

        return substr($text, $finalStartPos, $finalEndPos - $finalStartPos);
    }
}
