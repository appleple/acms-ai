<?php

namespace Acms\Plugins\AI\POST;

use ACMS_POST;
use Acms\Plugins\AI\Services\AI as ServicesAI;

abstract class AI extends ACMS_POST
{
    /**
     * @var string
     */
    protected $organizationId = "";

    /**
     * @var string
     */
    protected $projectId = "";

    /**
     * @var string
     */
    protected $apiKey = "";


    /**
     * @var string
     */
    protected $model = "gpt-3.5-turbo";

    public function __construct()
    {
        try {
            $ServiceAI = new ServicesAI();
            $config = $ServiceAI->getConfig();
            $cert = $ServiceAI->getCertification($config);
            if ($cert['ai_organization_id'] && $cert['ai_project_id'] && $cert['ai_api_key'] && $cert['ai_model']) {
                $this->organizationId = $cert['ai_organization_id'];
                $this->projectId = $cert['ai_project_id'];
                $this->apiKey = $cert['ai_api_key'];
                $this->model = $cert['ai_model'];
            }
        } catch (\Exception $e) {
        }
    }
}
